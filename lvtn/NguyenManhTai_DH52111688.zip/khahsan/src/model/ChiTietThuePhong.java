package model;

public class ChiTietThuePhong {

    private int maPhieuThue;
    private int maPhong;
    private Integer maKhachHang;
    private double donGia;

    public int getMaPhieuThue() {
        return maPhieuThue;
    }

    public void setMaPhieuThue(int maPhieuThue) {
        this.maPhieuThue = maPhieuThue;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public Integer getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(Integer maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }
}