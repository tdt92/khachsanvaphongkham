package model;

import java.sql.Date;

public class Kho {

    private int maVatDung;
    private String tenVatDung;
    private String donViTinh;
    private int soLuongTon;
    private double donGiaNhap;
    private double donGiaBan;
    private Date ngayNhap;
    private String ghiChu;

    public Kho() {
    }

    public Kho(int maVatDung, String tenVatDung, String donViTinh,
               int soLuongTon, double donGiaNhap, double donGiaBan,
               Date ngayNhap, String ghiChu) {
        this.maVatDung = maVatDung;
        this.tenVatDung = tenVatDung;
        this.donViTinh = donViTinh;
        this.soLuongTon = soLuongTon;
        this.donGiaNhap = donGiaNhap;
        this.donGiaBan = donGiaBan;
        this.ngayNhap = ngayNhap;
        this.ghiChu = ghiChu;
    }

    public int getMaVatDung() {
        return maVatDung;
    }

    public void setMaVatDung(int maVatDung) {
        this.maVatDung = maVatDung;
    }

    public String getTenVatDung() {
        return tenVatDung;
    }

    public void setTenVatDung(String tenVatDung) {
        this.tenVatDung = tenVatDung;
    }

    public String getDonViTinh() {
        return donViTinh;
    }

    public void setDonViTinh(String donViTinh) {
        this.donViTinh = donViTinh;
    }

    public int getSoLuongTon() {
        return soLuongTon;
    }

    public void setSoLuongTon(int soLuongTon) {
        this.soLuongTon = soLuongTon;
    }

    public double getDonGiaNhap() {
        return donGiaNhap;
    }

    public void setDonGiaNhap(double donGiaNhap) {
        this.donGiaNhap = donGiaNhap;
    }

    public double getDonGiaBan() {
        return donGiaBan;
    }

    public void setDonGiaBan(double donGiaBan) {
        this.donGiaBan = donGiaBan;
    }

    public Date getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(Date ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    @Override
    public String toString() {

        if(maVatDung==0){
            return "-- Không sử dụng kho --";
        }

        return tenVatDung;
    }
    
}