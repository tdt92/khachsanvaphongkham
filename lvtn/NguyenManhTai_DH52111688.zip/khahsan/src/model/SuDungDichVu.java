package model;

import java.sql.Timestamp;

public class SuDungDichVu {

    private int maSuDung;
    private int maPhieuThue;
    private int maPhong;
    private int maDichVu;
    private int soLuong;
    private double thanhTien;
    private Timestamp ngaySuDung;
    private int maNhanVien;
    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }
    public SuDungDichVu() {

    }

    public SuDungDichVu(int maSuDung,
                        int maPhieuThue,
                        int maPhong,
                        int maDichVu,
                        int soLuong,
                        double thanhTien,
                        Timestamp ngaySuDung) {

        this.maSuDung = maSuDung;
        this.maPhieuThue = maPhieuThue;
        this.maPhong = maPhong;
        this.maDichVu = maDichVu;
        this.soLuong = soLuong;
        this.thanhTien = thanhTien;
        this.ngaySuDung = ngaySuDung;
    }

    public int getMaSuDung() {
        return maSuDung;
    }

    public void setMaSuDung(int maSuDung) {
        this.maSuDung = maSuDung;
    }

    public int getMaPhieuThue() {
        return maPhieuThue;
    }

    public void setMaPhieuThue(int maPhieuThue) {
        this.maPhieuThue = maPhieuThue;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public int getMaDichVu() {
        return maDichVu;
    }

    public void setMaDichVu(int maDichVu) {
        this.maDichVu = maDichVu;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public Timestamp getNgaySuDung() {
        return ngaySuDung;
    }

    public void setNgaySuDung(Timestamp ngaySuDung) {
        this.ngaySuDung = ngaySuDung;
    }
}