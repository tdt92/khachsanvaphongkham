package model;

public class DichVu {

    private int maDichVu;
    private String tenDichVu;
    private double donGia;
     private String donViTinh;
    private String ghiChu;
    private Integer maVatDung;
    public DichVu(int maDichVu, String tenDichVu,
            double donGia,
            String donViTinh,
            String ghiChu,
            Integer maVatDung) {

        this.maDichVu = maDichVu;
        this.tenDichVu = tenDichVu;
        this.donGia = donGia;
        this.donViTinh = donViTinh;
        this.ghiChu = ghiChu;
        this.maVatDung = maVatDung;
    }
    public DichVu() {
    }
    @Override
    public String toString() {

        return tenDichVu
                + " - "
                + donGia;
    }

	/*
	 * public DichVu(int maDichVu, String tenDichVu, double donGia, String
	 * donViTinh, String ghiChu) {
	 * 
	 * this.maDichVu = maDichVu; this.tenDichVu = tenDichVu; this.donGia = donGia;
	 * this.donViTinh = donViTinh; this.ghiChu = ghiChu; }
	 */
    public Integer getMaVatDung() {
        return maVatDung;
    }

    public void setMaVatDung(Integer maVatDung) {
        this.maVatDung = maVatDung;
    }
    public int getMaDichVu() {
        return maDichVu;
    }

    public void setMaDichVu(int maDichVu) {
        this.maDichVu = maDichVu;
    }

    public String getTenDichVu() {
        return tenDichVu;
    }

    public void setTenDichVu(String tenDichVu) {
        this.tenDichVu = tenDichVu;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    

    public String getDonViTinh() {
        return donViTinh;
    }

    public void setDonViTinh(String donViTinh) {
        this.donViTinh = donViTinh;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
}