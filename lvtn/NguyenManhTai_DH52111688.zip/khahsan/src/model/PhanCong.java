package model;

import java.sql.Date;
import java.sql.Time;

public class PhanCong {

    private int maPhanCong;
    private int maNhanVien;
    private int maPhong;
    private String tenVaiTro;
    private Date ngayPhanCong;
    private Time gioBatDau;
    private Time gioKetThuc;
    private String ghiChu;

    public PhanCong() {
    }

    public PhanCong(int maPhanCong, int maNhanVien, int maPhong,
                     String tenVaiTro, Date ngayPhanCong,
                     Time gioBatDau, Time gioKetThuc, String ghiChu) {

        this.maPhanCong = maPhanCong;
        this.maNhanVien = maNhanVien;
        this.maPhong = maPhong;
        this.tenVaiTro = tenVaiTro;
        this.ngayPhanCong = ngayPhanCong;
        this.gioBatDau = gioBatDau;
        this.gioKetThuc = gioKetThuc;
        this.ghiChu = ghiChu;
    }

    public int getMaPhanCong() {
        return maPhanCong;
    }

    public void setMaPhanCong(int maPhanCong) {
        this.maPhanCong = maPhanCong;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public String getTenVaiTro() {
        return tenVaiTro;
    }

    public void setTenVaiTro(String tenVaiTro) {
        this.tenVaiTro = tenVaiTro;
    }

    public Date getNgayPhanCong() {
        return ngayPhanCong;
    }

    public void setNgayPhanCong(Date ngayPhanCong) {
        this.ngayPhanCong = ngayPhanCong;
    }

    public Time getGioBatDau() {
        return gioBatDau;
    }

    public void setGioBatDau(Time gioBatDau) {
        this.gioBatDau = gioBatDau;
    }

    public Time getGioKetThuc() {
        return gioKetThuc;
    }

    public void setGioKetThuc(Time gioKetThuc) {
        this.gioKetThuc = gioKetThuc;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
}