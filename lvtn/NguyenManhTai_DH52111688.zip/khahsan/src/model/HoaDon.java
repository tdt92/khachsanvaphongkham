package model;

import java.sql.Timestamp;

public class HoaDon {

    private int maHoaDon;
    private int maPhieuThue;
    private int maNhanVien;

    private Timestamp ngayLap;

    private double tongTien;
    private double tienKhachTra;
    private double tienConLai;

    private String hinhThucThanhToan;
    private String trangThaiThanhToan;
    private String ghiChu;

    public HoaDon() {
    }

    public HoaDon(int maHoaDon,
                  int maPhieuThue,
                  int maNhanVien,
                  Timestamp ngayLap,
                  double tongTien,
                  double tienKhachTra,
                  double tienConLai,
                  String hinhThucThanhToan,
                  String trangThaiThanhToan,
                  String ghiChu) {

        this.maHoaDon = maHoaDon;
        this.maPhieuThue = maPhieuThue;
        this.maNhanVien = maNhanVien;
        this.ngayLap = ngayLap;
        this.tongTien = tongTien;
        this.tienKhachTra = tienKhachTra;
        this.tienConLai = tienConLai;
        this.hinhThucThanhToan = hinhThucThanhToan;
        this.trangThaiThanhToan = trangThaiThanhToan;
        this.ghiChu = ghiChu;
    }

    public int getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(int maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public int getMaPhieuThue() {
        return maPhieuThue;
    }

    public void setMaPhieuThue(int maPhieuThue) {
        this.maPhieuThue = maPhieuThue;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public Timestamp getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(Timestamp ngayLap) {
        this.ngayLap = ngayLap;
    }

    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }

    public double getTienKhachTra() {
        return tienKhachTra;
    }

    public void setTienKhachTra(double tienKhachTra) {
        this.tienKhachTra = tienKhachTra;
    }

    public double getTienConLai() {
        return tienConLai;
    }

    public void setTienConLai(double tienConLai) {
        this.tienConLai = tienConLai;
    }

    public String getHinhThucThanhToan() {
        return hinhThucThanhToan;
    }

    public void setHinhThucThanhToan(String hinhThucThanhToan) {
        this.hinhThucThanhToan = hinhThucThanhToan;
    }

    public String getTrangThaiThanhToan() {
        return trangThaiThanhToan;
    }

    public void setTrangThaiThanhToan(String trangThaiThanhToan) {
        this.trangThaiThanhToan = trangThaiThanhToan;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
}