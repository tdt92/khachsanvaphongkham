package model;

public class VaiTro {

    private int maVaiTro;
    private String tenVaiTro;

    // Constructor rỗng
    public VaiTro() {
    }

    // Constructor đầy đủ
    public VaiTro(int maVaiTro, String tenVaiTro) {
        this.maVaiTro = maVaiTro;
        this.tenVaiTro = tenVaiTro;
    }

    // Getter + Setter MaVaiTro
    public int getMaVaiTro() {
        return maVaiTro;
    }

    public void setMaVaiTro(int maVaiTro) {
        this.maVaiTro = maVaiTro;
    }

    // Getter + Setter TenVaiTro
    public String getTenVaiTro() {
        return tenVaiTro;
    }

    public void setTenVaiTro(String tenVaiTro) {
        this.tenVaiTro = tenVaiTro;
    }

    @Override
    public String toString() {
        return tenVaiTro;
    }
}