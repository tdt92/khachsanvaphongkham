package model;

/**
 * DTO dùng chung cho các báo cáo thống kê dạng (nhãn - giá trị).
 * Dùng cho: doanh thu theo ngày/tuần/tháng/năm, doanh thu theo loại phòng,
 * doanh thu theo dịch vụ, phương thức thanh toán...
 */
public class ThongKeDiemDTO {

    private String nhan;       // Nhãn hiển thị (VD: "01/07", "Tháng 7", "Phòng Deluxe")
    private double giaTri;     // Giá trị chính (thường là doanh thu)
    private int soLuong;       // Số lượng phụ (VD: số hoá đơn, số lượt bán)

    public ThongKeDiemDTO() {
    }

    public ThongKeDiemDTO(String nhan, double giaTri) {
        this.nhan = nhan;
        this.giaTri = giaTri;
    }

    public ThongKeDiemDTO(String nhan, double giaTri, int soLuong) {
        this.nhan = nhan;
        this.giaTri = giaTri;
        this.soLuong = soLuong;
    }

    public String getNhan() {
        return nhan;
    }

    public void setNhan(String nhan) {
        this.nhan = nhan;
    }

    public double getGiaTri() {
        return giaTri;
    }

    public void setGiaTri(double giaTri) {
        this.giaTri = giaTri;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
}