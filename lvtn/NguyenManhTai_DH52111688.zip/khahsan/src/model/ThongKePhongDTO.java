package model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DTO tổng hợp tình trạng phòng dùng cho tab "Thống kê phòng".
 */
public class ThongKePhongDTO {

    private int tongSoPhong;

    // Đếm số phòng theo từng giá trị cột Phong.TrangThai (lấy nguyên trạng từ DB,
    // không cứng giá trị, để tương thích với mọi quy ước đặt tên trạng thái đang dùng).
    private Map<String, Integer> theoTrangThai = new LinkedHashMap<>();

    private int soPhongSapCheckIn;   // Phiếu đặt phòng sắp tới trong N ngày
    private int soPhongSapCheckOut;  // Phiếu thuê sắp đến hạn trả trong N ngày

    public int getTongSoPhong() {
        return tongSoPhong;
    }

    public void setTongSoPhong(int tongSoPhong) {
        this.tongSoPhong = tongSoPhong;
    }

    public Map<String, Integer> getTheoTrangThai() {
        return theoTrangThai;
    }

    public void setTheoTrangThai(Map<String, Integer> theoTrangThai) {
        this.theoTrangThai = theoTrangThai;
    }

    public int getSoPhongSapCheckIn() {
        return soPhongSapCheckIn;
    }

    public void setSoPhongSapCheckIn(int soPhongSapCheckIn) {
        this.soPhongSapCheckIn = soPhongSapCheckIn;
    }

    public int getSoPhongSapCheckOut() {
        return soPhongSapCheckOut;
    }

    public void setSoPhongSapCheckOut(int soPhongSapCheckOut) {
        this.soPhongSapCheckOut = soPhongSapCheckOut;
    }
}