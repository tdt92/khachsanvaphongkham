package model;

public class CellLichPhong {

    private String tenKhach;
    private String trangThai;

    public CellLichPhong() {
    }

    public CellLichPhong(String tenKhach, String trangThai) {
        this.tenKhach = tenKhach;
        this.trangThai = trangThai;
    }

    public String getTenKhach() {
        return tenKhach;
    }

    public void setTenKhach(String tenKhach) {
        this.tenKhach = tenKhach;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return tenKhach;
    }
}