package model;

import java.sql.Date;
import java.sql.Timestamp;

public class PhieuDatPhong {

    private int maPhieuDat;
    private int maKhachHang;
    private Timestamp ngayDat;
    private Date ngayNhanPhong;
    private Date ngayTraPhong;
    private double tienCoc;
    private String trangThai;
    private Integer maPhieuThue;
    private String ghiChu;
    private Integer maNhanVien;

    public Integer getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(Integer maNhanVien) {
        this.maNhanVien = maNhanVien;
    }
    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    public Integer getMaPhieuThue() {
        return maPhieuThue;
    }

    public void setMaPhieuThue(Integer maPhieuThue) {
        this.maPhieuThue = maPhieuThue;
    }
    public int getMaPhieuDat() {
        return maPhieuDat;
    }

    public void setMaPhieuDat(int maPhieuDat) {
        this.maPhieuDat = maPhieuDat;
    }

    public int getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(int maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public Timestamp getNgayDat() {
        return ngayDat;
    }

    public void setNgayDat(Timestamp ngayDat) {
        this.ngayDat = ngayDat;
    }

    public Date getNgayNhanPhong() {
        return ngayNhanPhong;
    }

    public void setNgayNhanPhong(Date ngayNhanPhong) {
        this.ngayNhanPhong = ngayNhanPhong;
    }

    public Date getNgayTraPhong() {
        return ngayTraPhong;
    }

    public void setNgayTraPhong(Date ngayTraPhong) {
        this.ngayTraPhong = ngayTraPhong;
    }

    public double getTienCoc() {
        return tienCoc;
    }

    public void setTienCoc(double tienCoc) {
        this.tienCoc = tienCoc;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
    @Override
    public String toString() {

        return "PDP-" + maPhieuDat
                + " | KH: " + maKhachHang
                + " | " + ngayNhanPhong;
    }
}