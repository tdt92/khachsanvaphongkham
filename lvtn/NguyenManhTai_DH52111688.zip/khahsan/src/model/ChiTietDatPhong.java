package model;

public class ChiTietDatPhong {

    private int maPhieuDat;
    private int maPhong;
    private Integer maKhachHang;

    public int getMaPhieuDat() {
        return maPhieuDat;
    }

    public void setMaPhieuDat(int maPhieuDat) {
        this.maPhieuDat = maPhieuDat;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public Integer getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(Integer maKhachHang) {
        this.maKhachHang = maKhachHang;
    }
}