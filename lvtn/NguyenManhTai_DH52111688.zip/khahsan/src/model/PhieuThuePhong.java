package model;

import java.sql.Date;
import java.sql.Timestamp;

public class PhieuThuePhong {

    private int maPhieuThue;
    private int maKhachHang;
    private int maNhanVien;
    private Timestamp ngayNhanPhong;
    private Date ngayTraPhongDuKien;
    private String trangThai;

    public int getMaPhieuThue() {
        return maPhieuThue;
    }

    public void setMaPhieuThue(int maPhieuThue) {
        this.maPhieuThue = maPhieuThue;
    }

    public int getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(int maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public Timestamp getNgayNhanPhong() {
        return ngayNhanPhong;
    }

    public void setNgayNhanPhong(Timestamp ngayNhanPhong) {
        this.ngayNhanPhong = ngayNhanPhong;
    }

    public Date getNgayTraPhongDuKien() {
        return ngayTraPhongDuKien;
    }

    public void setNgayTraPhongDuKien(Date ngayTraPhongDuKien) {
        this.ngayTraPhongDuKien = ngayTraPhongDuKien;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
    @Override
    public String toString() {

        return "PTP-" + maPhieuThue
                + " | KH: " + maKhachHang
                + " | " + trangThai;
    }
}