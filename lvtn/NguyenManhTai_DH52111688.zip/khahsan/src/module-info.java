/**
 * 
 */
/**
 * 
 */
module khahsan {
	requires java.desktop;
	requires java.sql;
 	requires jcalendar;
 	requires jfreechart;
 	requires java.mail;
 	requires java.activation;
  }