package gui;

import bus.LoaiPhongBUS;
import bus.PhongBUS;
import model.LoaiPhong;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyLoaiPhongForm extends JInternalFrame {

    JTextField txtTenLoai;
    JTextField txtDonGia;
    JTextField txtSoNguoi;
    JTextField txtMoTa;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnLamMoi;

    JTable table;
    PhongBUS phongBUS = new PhongBUS();
    DefaultTableModel model;

    LoaiPhongBUS bus = new LoaiPhongBUS();

    int selectedMaLoai = -1;

    // Bảng màu giao diện Modern UI (Slate & Cyan Accent)
    private static final Color MAU_CHINH = new Color(14, 116, 144);    // Cyan/Teal đậm chuyên nghiệp
    private static final Color MAU_XOA = new Color(225, 29, 72);       // Đỏ Rose nổi bật cho nút xóa
    private static final Color NEN_XAM = new Color(248, 250, 252);     // Slate 50 làm nền dịu mắt
    private static final Color CHU_DAM = new Color(15, 23, 42);        // Slate 900 cho chữ chính
    private static final Color VIEN_NHE = new Color(226, 232, 240);    // Slate 200 làm đường viền mảnh

    public QuanLyLoaiPhongForm() {
        super("QUẢN LÝ LOẠI PHÒNG", true, true, true, true);

        setSize(950, 650);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(NEN_XAM);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 20, 15, 20));

        // =====================================================================
        // PANEL TOP: KHU VỰC NHẬP LIỆU (CẤU TRÚC LẠI LAYOUT GỌN GÀNG)
        // =====================================================================
        JPanel pTopMaster = new JPanel(new BorderLayout());
        pTopMaster.setBackground(Color.WHITE);
        pTopMaster.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                new EmptyBorder(20, 25, 20, 25)
        ));

        // Đổi từ Grid (4, 2) sang Grid (2, 2) để kéo giãn ô nhập liệu nằm ngang cân đối
        JPanel pTop = new JPanel(new GridLayout(2, 2, 30, 15));
        pTop.setBackground(Color.WHITE);

        txtTenLoai = new JTextField();
        txtDonGia = new JTextField();
        txtSoNguoi = new JTextField();
        txtMoTa = new JTextField();

        styleTextField(txtTenLoai);
        styleTextField(txtDonGia);
        styleTextField(txtSoNguoi);
        styleTextField(txtMoTa);

        // Tạo layout dạng ô nhãn nhỏ phía trên - ô nhập text liền kề phía dưới
        pTop.add(taoFormGroup("Tên loại phòng", txtTenLoai));
        pTop.add(taoFormGroup("Đơn giá thuê (VNĐ)", txtDonGia));
        pTop.add(taoFormGroup("Số người tối đa", txtSoNguoi));
        pTop.add(taoFormGroup("Mô tả chi tiết", txtMoTa));

        pTopMaster.add(pTop, BorderLayout.CENTER);
        add(pTopMaster, BorderLayout.NORTH);

        // =====================================================================
        // PANEL CENTER: KHU VỰC HIỂN THỊ BẢNG DỮ LIỆU CẢI TIẾN
        // =====================================================================
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã loại", "Tên loại", "Đơn giá", "Số người", "Mô tả"
        });

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        add(scrollPane, BorderLayout.CENTER);

        // =====================================================================
        // PANEL BOTTOM: KHU VỰC NÚT ĐIỀU KHIỂN THAO TÁC
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        pBottom.setBackground(NEN_XAM);

        btnThem = new JButton("THÊM MỚI");
        btnSua = new JButton("CẬP NHẬT");
        btnXoa = new JButton("XÓA LOẠI PHÒNG");
        btnLamMoi = new JButton("LÀM MỚI FORM");

        styleButton(btnThem, MAU_CHINH);
        styleButton(btnSua, new Color(71, 85, 105)); // Màu xám Slate lịch lãm cho nút sửa
        styleButton(btnXoa, MAU_XOA);
        styleButton(btnLamMoi, Color.WHITE);
        
        // Thiết lập viền mảnh và màu chữ tối cho riêng nút Làm mới nền trắng
        btnLamMoi.setForeground(CHU_DAM);
        btnLamMoi.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        pBottom.add(btnLamMoi);

        add(pBottom, BorderLayout.SOUTH);

        // Nạp dữ liệu vào bảng
        loadData();

        // =====================================================================
        // EVENT TABLE
        // =====================================================================
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedMaLoai = Integer.parseInt(model.getValueAt(row, 0).toString());
                txtTenLoai.setText(model.getValueAt(row, 1).toString());
                txtDonGia.setText(model.getValueAt(row, 2).toString());
                txtSoNguoi.setText(model.getValueAt(row, 3).toString());
                txtMoTa.setText(model.getValueAt(row, 4).toString());
            }
        });

        // =====================================================================
        // BUTTON EVENT
        // =====================================================================
        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadData();
        });

        setVisible(true);
    }

    // =====================================================================
    // CÁC HÀM TRỢ GIÚP ĐỔI MỚI GIAO DIỆN (UI DESIGN TOOLKIT)
    // =====================================================================
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(CHU_DAM);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
    }

    private void styleButton(JButton btn, Color background) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(background);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32); // Tăng chiều cao hàng để thoáng mắt
        table.setGridColor(new Color(241, 245, 249)); // Đường lưới ngang tinh tế
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(232, 240, 254)); // Màu nền highlight xanh nhạt khi chọn hàng
        table.setSelectionForeground(CHU_DAM);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(new Color(71, 85, 105));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, VIEN_NHE));

        // Padding lề trái/phải cho các chữ hiển thị trong ô của table
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 8, 0, 8));
        table.setDefaultRenderer(Object.class, renderer);
    }

    private JPanel taoFormGroup(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(100, 116, 139)); // Màu nhãn chữ phụ Slate 500 nhẹ nhàng
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    // =====================================================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN TOÀN BỘ THEO MÃ NGUỒN GỐC)
    // =====================================================================
    private void loadData() {
        model.setRowCount(0);
        for (LoaiPhong lp : bus.getAll()) {
            model.addRow(new Object[]{
                    lp.getMaLoaiPhong(),
                    lp.getTenLoaiPhong(),
                    lp.getDonGia(),
                    lp.getSoNguoiToiDa(),
                    lp.getMoTa()
            });
        }
    }

    private void them() {
        try {
        	if (!validateForm()) return;
            LoaiPhong lp = new LoaiPhong();
            lp.setTenLoaiPhong(txtTenLoai.getText());
            lp.setDonGia(Double.parseDouble(txtDonGia.getText()));
            lp.setSoNguoiToiDa(Integer.parseInt(txtSoNguoi.getText()));
            lp.setMoTa(txtMoTa.getText());

            if (bus.insert(lp)) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void sua() {
        try {
            if (selectedMaLoai == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn loại phòng cần sửa");
                return;
            }
            if (!validateForm()) return;
            LoaiPhong lp = new LoaiPhong();
            lp.setMaLoaiPhong(selectedMaLoai);
            lp.setTenLoaiPhong(txtTenLoai.getText());
            lp.setDonGia(Double.parseDouble(txtDonGia.getText()));
            lp.setSoNguoiToiDa(Integer.parseInt(txtSoNguoi.getText()));
            lp.setMoTa(txtMoTa.getText());

            if (bus.update(lp)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoa() {
        if (selectedMaLoai == -1) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn loại phòng cần xóa");
            return;
        }

        // Kiểm tra còn phòng thuộc loại này không
        if (phongBUS.hasPhongByLoaiPhong(selectedMaLoai)) {
            JOptionPane.showMessageDialog(this,
                    "Không thể xóa!\nLoại phòng này đang được sử dụng bởi một hoặc nhiều phòng.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            if (bus.delete(selectedMaLoai)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadData();
                clearForm();
            }
        }
    }
    private boolean validateForm() {

        if (txtTenLoai.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên loại phòng không được để trống");
            txtTenLoai.requestFocus();
            return false;
        }

        if (txtDonGia.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Đơn giá không được để trống");
            txtDonGia.requestFocus();
            return false;
        }

        if (txtSoNguoi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Số người tối đa không được để trống");
            txtSoNguoi.requestFocus();
            return false;
        }

        if (txtMoTa.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mô tả không được để trống");
            txtMoTa.requestFocus();
            return false;
        }

        try {
            double donGia = Double.parseDouble(txtDonGia.getText().trim());
            if (donGia <= 0) {
                JOptionPane.showMessageDialog(this, "Đơn giá phải lớn hơn 0");
                txtDonGia.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Đơn giá phải là số");
            txtDonGia.requestFocus();
            return false;
        }

        try {
            int soNguoi = Integer.parseInt(txtSoNguoi.getText().trim());
            if (soNguoi <= 0) {
                JOptionPane.showMessageDialog(this, "Số người tối đa phải lớn hơn 0");
                txtSoNguoi.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số người tối đa phải là số nguyên");
            txtSoNguoi.requestFocus();
            return false;
        }

        // Kiểm tra trùng tên loại phòng
        String ten = txtTenLoai.getText().trim();

        for (LoaiPhong lp : bus.getAll()) {

            if (lp.getTenLoaiPhong().equalsIgnoreCase(ten)
                    && lp.getMaLoaiPhong() != selectedMaLoai) {

                JOptionPane.showMessageDialog(this, "Tên loại phòng đã tồn tại");
                txtTenLoai.requestFocus();
                return false;
            }
        }

        return true;
    }
    private void clearForm() {
        txtTenLoai.setText("");
        txtDonGia.setText("");
        txtSoNguoi.setText("");
        txtMoTa.setText("");
        selectedMaLoai = -1;
        table.clearSelection();
    }
}