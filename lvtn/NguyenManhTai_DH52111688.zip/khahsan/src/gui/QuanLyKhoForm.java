package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class QuanLyKhoForm extends JInternalFrame {

    private QuanLyPhieuNhapPanel pnPhieuNhap;
    private QuanLyCTPhieuNhapPanel pnCTPhieuNhap;

    // Định nghĩa bảng màu Flat UI đồng bộ với hệ thống Main Frame
    private static final Color TEXT_COLOR = new Color(51, 65, 85);       // Slate 700 (Màu chữ tối dịu)
    private static final Color BACKGROUND_COLOR = new Color(241, 245, 249); // Slate 100 (Nền xám nhạt)

    public QuanLyKhoForm() {
        super(
                "Quản Lý Nhập Kho",
                true,   // closable
                true,   // resizable
                true,   // maximizable
                true    // iconifiable
        );

        setSize(1200, 700);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        
        // --- CẤU HÌNH LAYER VIỀN & NỀN TỔNG THỂ ---
        setLayout(new BorderLayout());
        JPanel contentPane = (JPanel) getContentPane();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15)); // Tạo khoảng đệm cách mép khung cửa sổ
        contentPane.setBackground(BACKGROUND_COLOR);

        // Khởi tạo Panel Chi tiết trước để làm tham số truyền vào Panel Phiếu nhập (Giữ nguyên Logic gốc)
        pnCTPhieuNhap = new QuanLyCTPhieuNhapPanel();

        // --- CUSTOM JTABBEDPANE THEO PHONG CÁCH FLAT MODERN ---
        JTabbedPane tab = new JTabbedPane();
        tab.setFont(new Font("Segoe UI", Font.BOLD, 14)); // Phông chữ Tab dày dặn, trực quan
        tab.setForeground(TEXT_COLOR);
        tab.setFocusable(false); // Triệt tiêu đường viền nét đứt (Dotted line) mất thẩm mỹ khi Focus
        
        // Loại bỏ đường viền xám mặc định bao quanh vùng nội dung của TabbedPane trong Java Swing
        tab.setBorder(BorderFactory.createEmptyBorder()); 

        // Khởi tạo Panel Phiếu nhập với các liên kết dữ liệu đồng bộ
        pnPhieuNhap = new QuanLyPhieuNhapPanel(tab, pnCTPhieuNhap);

        // Tích hợp các vùng giao diện nghiệp vụ vào cấu trúc Quản lý Tab
        tab.addTab("Phiếu Nhập", pnPhieuNhap);
        tab.addTab("Chi Tiết Phiếu Nhập", pnCTPhieuNhap);

        // Đưa thanh Tab hoàn chỉnh vào vùng trung tâm hiển thị
        add(tab, BorderLayout.CENTER);
    }
}