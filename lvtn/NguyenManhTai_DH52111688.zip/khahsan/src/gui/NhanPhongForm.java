package gui;

import javax.swing.JInternalFrame;
import bus.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

public class NhanPhongForm extends JInternalFrame {
    private JTextField txtTimPD;
    private JButton btnTimPD;
    private JButton btnSuaThue;
    private JButton btnDichVu;
    private JButton btnLamMoiPD;
    private PhieuDatPhong phieuDatDangNhan = null;
    private Integer maPhieuDatDangNhan = null;
    private JTable tblKhachHang;
    private JTable tblThuePhong;

    private JDialog dlgPhieuDat;
    private JTable tblPhieuDat;
    private DefaultTableModel modelPD;

    private JTextField txtTimKH;
    private JTextField txtTongTien;

    private JDateChooser dcNgayNhan;
    private JDateChooser dcNgayTra;

    private JComboBox<LoaiPhong> cboLoaiPhong;
    private JComboBox<Phong> cboPhong;

    private JButton btnThemKH;
    private JButton btnTimKH;
    private JButton btnLamMoiKH;
    private JButton btnHuyThue;
    private JButton btnThuePhong;
    private JButton btnPhieuDat;
    private JButton btnLamMoi;
    private JButton btnXacNhanPD;
    private JButton btnHuyDat;

    private KhachHangBUS khBUS = new KhachHangBUS();
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();

    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();

    private PhieuThuePhongBUS ptBUS = new PhieuThuePhongBUS();
    private ChiTietThuePhongBUS ctBUS = new ChiTietThuePhongBUS();

    private DefaultTableModel modelKH;
    private DefaultTableModel modelTP;

    // Định nghĩa Palette màu UI hiện đại
    private final Color PRIMARY_COLOR = new Color(41, 128, 185); // Xanh dương chủ đạo
    private final Color SUCCESS_COLOR = new Color(39, 174, 96);  // Xanh lá (Xác nhận/Thuê)
    private final Color DANGER_COLOR = new Color(211, 47, 47);   // Đỏ (Hủy)
    private final Color TEXT_COLOR = new Color(44, 62, 80);      // Chữ xám đậm
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public NhanPhongForm() {
        super("NHẬN PHÒNG / THUÊ PHÒNG", true, true, true, true);
        setSize(1350, 780);
        setVisible(true);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);

        initUI();
        loadAll();
    }

    List<PhongDangThueDTO> list = ctBUS.getPhongDangThue();

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().setBackground(Color.WHITE);

        // ==========================================
        // 1. PANEL BÊN TRÁI: QUẢN LÝ KHÁCH HÀNG
        // ==========================================
        JPanel pnlLeft = new JPanel(new BorderLayout(5, 5));
        pnlLeft.setBackground(Color.WHITE);
        pnlLeft.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)), 
                "Danh Sách Khách Hàng", TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, PRIMARY_COLOR));

        // Thanh tìm kiếm KH
        JPanel pnlKHControl = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        pnlKHControl.setBackground(Color.WHITE);
        
        txtTimKH = new JTextField(15);
        txtTimKH.setFont(MAIN_FONT);
        btnTimKH = createModernButton("Tìm kiếm", PRIMARY_COLOR, Color.WHITE);
        btnLamMoiKH = createModernButton("Làm mới", new Color(127, 140, 141), Color.WHITE);
        
        pnlKHControl.add(txtTimKH);
        pnlKHControl.add(btnTimKH);
        pnlKHControl.add(btnLamMoiKH);
        pnlLeft.add(pnlKHControl, BorderLayout.NORTH);

        // Bảng KH
        modelKH = new DefaultTableModel(new String[]{"Mã KH", "Họ và tên", "Số điện thoại"}, 0);
        tblKhachHang = createModernTable(modelKH);
        pnlLeft.add(new JScrollPane(tblKhachHang), BorderLayout.CENTER);

        // Nút thêm KH nhanh
        btnThemKH = createModernButton("+ Thêm khách hàng mới", SUCCESS_COLOR, Color.WHITE);
        btnThemKH.setFont(BOLD_FONT);
        pnlLeft.add(btnThemKH, BorderLayout.SOUTH);

        // ==========================================
        // 2. PANEL BÊN PHẢI: THÔNG TIN NHẬN/THUÊ PHÒNG
        // ==========================================
        JPanel pnlRightOuter = new JPanel(new BorderLayout());
        pnlRightOuter.setBackground(Color.WHITE);
        pnlRightOuter.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)), 
                "Thông Tin Thuê Phòng", TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, PRIMARY_COLOR));

        JPanel pnlRightFields = new JPanel(new GridBagLayout());
        pnlRightFields.setBackground(Color.WHITE);
        pnlRightFields.setBorder(new EmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new java.awt.Insets(6, 6, 6, 6);

        // Khởi tạo các components nhập liệu
        cboLoaiPhong = new JComboBox<>(); cboLoaiPhong.setFont(MAIN_FONT);
        cboPhong = new JComboBox<>(); cboPhong.setFont(MAIN_FONT);
        dcNgayNhan = new JDateChooser(); dcNgayNhan.setFont(MAIN_FONT);
        dcNgayTra = new JDateChooser(); dcNgayTra.setFont(MAIN_FONT);
        
        txtTongTien = new JTextField();
        txtTongTien.setFont(new Font("Segoe UI", Font.BOLD, 16));
        txtTongTien.setForeground(DANGER_COLOR);
        txtTongTien.setEditable(false);
        txtTongTien.setHorizontalAlignment(JTextField.RIGHT);

        java.util.Date homNay = new java.util.Date();
        dcNgayNhan.setMinSelectableDate(homNay);
        dcNgayTra.setMinSelectableDate(homNay);

        // Sự kiện DateChooser xử lý logic giữ nguyên
        dcNgayNhan.getDateEditor().addPropertyChangeListener(evt -> {
            if ("date".equals(evt.getPropertyName())) {
                if (dcNgayNhan.getDate() != null && dcNgayTra.getDate() != null 
                        && dcNgayTra.getDate().before(dcNgayNhan.getDate())) {
                    JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn hoặc bằng ngày nhận");
                    dcNgayTra.setDate(dcNgayNhan.getDate());
                }
                loadPhongTheoLoai();
                tinhTien();
            }
        });

        dcNgayTra.getDateEditor().addPropertyChangeListener(evt -> {
            if ("date".equals(evt.getPropertyName())) {
                if (dcNgayNhan.getDate() != null && dcNgayTra.getDate() != null 
                        && dcNgayTra.getDate().before(dcNgayNhan.getDate())) {
                    JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn hoặc bằng ngày nhận");
                    dcNgayTra.setDate(null);
                    return;
                }
                loadPhongTheoLoai();
                tinhTien();
            }
        });

        // Đổ dữ liệu vào GridBagLayout
        addFormRow(pnlRightFields, gbc, 0, "Loại phòng:", cboLoaiPhong);
        addFormRow(pnlRightFields, gbc, 1, "Chọn phòng:", cboPhong);
        addFormRow(pnlRightFields, gbc, 2, "Ngày nhận:", dcNgayNhan);
        addFormRow(pnlRightFields, gbc, 3, "Ngày trả dự kiến:", dcNgayTra);
        addFormRow(pnlRightFields, gbc, 4, "Tổng tiền toán tạm tính (VND):", txtTongTien);

        // Panel chứa nhóm nút chức năng bên phải
        JPanel pnlRightButtons = new JPanel(new GridLayout(3, 2, 8, 8));
        pnlRightButtons.setBackground(Color.WHITE);
        pnlRightButtons.setBorder(new EmptyBorder(0, 15, 15, 15));

        btnPhieuDat = createModernButton("DANH SÁCH PHIẾU ĐẶT", PRIMARY_COLOR, Color.WHITE);
        btnThuePhong = createModernButton("XÁC NHẬN THUÊ / NHẬN", SUCCESS_COLOR, Color.WHITE);
        btnSuaThue = createModernButton("CẬP NHẬT THÔNG TIN", new Color(241, 196, 15), TEXT_COLOR);
        btnDichVu = createModernButton("THÊM DỊCH VỤ", new Color(155, 89, 182), Color.WHITE);
        btnLamMoi = createModernButton("LÀM MỚI FORM", new Color(149, 165, 166), Color.WHITE);
        btnHuyThue = createModernButton("HỦY PHIẾU THUÊ", DANGER_COLOR, Color.WHITE);

        pnlRightButtons.add(btnPhieuDat);     pnlRightButtons.add(btnThuePhong);
        pnlRightButtons.add(btnSuaThue);      pnlRightButtons.add(btnDichVu);
        pnlRightButtons.add(btnLamMoi);       pnlRightButtons.add(btnHuyThue);

        pnlRightOuter.add(pnlRightFields, BorderLayout.CENTER);
        pnlRightOuter.add(pnlRightButtons, BorderLayout.SOUTH);

        // SplitPane phía trên (Trái: Khách hàng - Phải: Điền thông tin)
        JSplitPane splitTop = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pnlLeft, pnlRightOuter);
        splitTop.setDividerLocation(650);
        splitTop.setResizeWeight(0.5);
        splitTop.setBorder(null);
        splitTop.setOneTouchExpandable(true);

        // ==========================================
        // 3. PANEL PHÍA DƯỚI: DANH SÁCH ĐANG THUÊ
        // ==========================================
        modelTP = new DefaultTableModel(new String[]{
                "Mã phiếu", "Tên khách hàng", "Số phòng", "Ngày nhận thực tế", "Ngày trả dự kiến", "Tiền phòng", "Trạng thái"
        }, 0);
        tblThuePhong = createModernTable(modelTP);
        
        // Listener giữ nguyên logic cũ
        tblThuePhong.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            int row = tblThuePhong.getSelectedRow();
            if (row == -1) return;

            int maPT = Integer.parseInt(modelTP.getValueAt(row, 0).toString());
            PhieuThuePhong pt = ptBUS.getAll().stream()
                    .filter(x -> x.getMaPhieuThue() == maPT)
                    .findFirst().orElse(null);
            if (pt == null) return;

            dcNgayNhan.setDate(pt.getNgayNhanPhong());
            dcNgayTra.setDate(pt.getNgayTraPhongDuKien());

            List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(maPT);
            if (!ds.isEmpty()) {
                int maPhong = ds.get(0).getMaPhong();
                for (int i = 0; i < cboPhong.getItemCount(); i++) {
                    if (cboPhong.getItemAt(i).getMaPhong() == maPhong) {
                        cboPhong.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });

        JScrollPane scrollThuePhong = new JScrollPane(tblThuePhong);
        scrollThuePhong.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)), 
                "Danh Sách Phòng Đang Thuê Hệ Thống", TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, PRIMARY_COLOR));

        // Gom toàn bộ vào màn hình chính thông qua SplitPane dọc
        JSplitPane splitMain = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitTop, scrollThuePhong);
        splitMain.setDividerLocation(360);
        splitMain.setResizeWeight(0.5);
        splitMain.setBorder(null);
        splitMain.setOneTouchExpandable(true);

        add(splitMain, BorderLayout.CENTER);

        // ==========================================
        // 4. KHỞI TẠO DIALOG PHIẾU ĐẶT TRƯỚC (JDIALOG)
        // ==========================================
        initDialogPhieuDat();

        // Gán sự kiện ActionListeners (Giữ nguyên logic gốc)
        cboLoaiPhong.addActionListener(e -> loadPhongTheoLoai());
        cboPhong.addActionListener(e -> tinhTien());
        btnSuaThue.addActionListener(e -> suaPhieuThue());
        btnDichVu.addActionListener(e -> moFormDichVu());
        btnPhieuDat.addActionListener(e -> openPhieuDat());
        btnXacNhanPD.addActionListener(e -> xacNhanPhieuDat());
        btnHuyDat.addActionListener(e -> huyPhieuDat());
        btnThuePhong.addActionListener(e -> thuePhong());
        btnTimPD.addActionListener(e -> timPhieuDat());
        btnLamMoiPD.addActionListener(e -> openPhieuDat());
        btnHuyThue.addActionListener(e -> huyThue());
        btnTimKH.addActionListener(e -> timKH());
        btnLamMoiKH.addActionListener(e -> loadKhachHang());
        btnLamMoi.addActionListener(e -> loadAll());
        btnThemKH.addActionListener(e -> {
            JDesktopPane desktop = getDesktopPane();
            if (desktop != null) {
                QuanLyKhachHangForm form = new QuanLyKhachHangForm();
                desktop.add(form);
                form.setVisible(true);
                try { form.setSelected(true); } catch (Exception ex) { ex.printStackTrace(); }
            }
        });
    }

    private void initDialogPhieuDat() {
        dlgPhieuDat = new JDialog();
        dlgPhieuDat.setTitle("DANH SÁCH PHIẾU ĐẶT PHÒNG TRƯỚC");
        dlgPhieuDat.setModal(true);
        dlgPhieuDat.setSize(950, 520);
        dlgPhieuDat.setLocationRelativeTo(this);
        ((JPanel)dlgPhieuDat.getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));
        dlgPhieuDat.getContentPane().setBackground(Color.WHITE);

        modelPD = new DefaultTableModel(new String[]{
                "Mã đặt", "Khách hàng", "Phòng", "Ngày nhận", "Ngày trả", "Trạng thái"
        }, 0);
        tblPhieuDat = createModernTable(modelPD);

        txtTimPD = new JTextField(20);
        txtTimPD.setFont(MAIN_FONT);
        btnTimPD = createModernButton("Tìm", PRIMARY_COLOR, Color.WHITE);
        btnLamMoiPD = createModernButton("Làm mới", new Color(127, 140, 141), Color.WHITE);

        JPanel pnlSearchPD = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
        pnlSearchPD.setBackground(Color.WHITE);
        JLabel lblSearch = new JLabel("Tên khách / CCCD:");
        lblSearch.setFont(MAIN_FONT);
        pnlSearchPD.add(lblSearch);
        pnlSearchPD.add(txtTimPD);
        pnlSearchPD.add(btnTimPD);
        pnlSearchPD.add(btnLamMoiPD);

        JPanel pnlBtn = new JPanel(new GridLayout(1, 2, 10, 0));
        pnlBtn.setBackground(Color.WHITE);
        pnlBtn.setBorder(new EmptyBorder(10, 0, 0, 0));
        btnXacNhanPD = createModernButton("XÁC NHẬN NHẬN PHÒNG ĐÃ ĐẶT", SUCCESS_COLOR, Color.WHITE);
        btnXacNhanPD.setFont(BOLD_FONT);
        btnHuyDat = createModernButton("HỦY ĐƠN ĐẶT PHÒNG", DANGER_COLOR, Color.WHITE);
        btnHuyDat.setFont(BOLD_FONT);
        pnlBtn.add(btnXacNhanPD);
        pnlBtn.add(btnHuyDat);

        JPanel pnlDlg = new JPanel(new BorderLayout(5, 5));
        pnlDlg.setBackground(Color.WHITE);
        pnlDlg.add(pnlSearchPD, BorderLayout.NORTH);
        pnlDlg.add(new JScrollPane(tblPhieuDat), BorderLayout.CENTER);
        pnlDlg.add(pnlBtn, BorderLayout.SOUTH);

        dlgPhieuDat.add(pnlDlg);
    }

    // Helper tạo nút phẳng, hiện đại và bo góc nhẹ
    private JButton createModernButton(String text, Color background, Color foreground) {
        JButton btn = new JButton(text);
        btn.setFont(MAIN_FONT);
        btn.setBackground(background);
        btn.setForeground(foreground);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // Helper cấu hình Table giao diện đẹp, dễ nhìn
    private JTable createModernTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFont(MAIN_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(230, 230, 230));
        table.setSelectionBackground(new Color(52, 152, 219, 40));
        table.setSelectionForeground(Color.BLACK);
        table.setShowVerticalLines(false);

        JTableHeader header = table.getTableHeader();
        header.setFont(BOLD_FONT);
        header.setBackground(new Color(245, 247, 250));
        header.setForeground(TEXT_COLOR);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));
        return table;
    }

    // Helper add dòng vào ô nhập liệu nhanh
    private void addFormRow(JPanel panel, GridBagConstraints gbc, int row, String labelText, JComponent component) {
        JLabel label = new JLabel(labelText);
        label.setFont(MAIN_FONT);
        label.setForeground(TEXT_COLOR);
        
        gbc.gridy = row;
        gbc.gridx = 0;
        gbc.weightx = 0.3;
        panel.add(label, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(component, gbc);
    }

    // =========================================================================
    // TOÀN BỘ LOGIC NGHIỆP VỤ BÊN DƯỚI ĐƯỢC GIỮ NGUYÊN 100% NHƯ MÃ NGUỒN GỐC
    // =========================================================================
    private void loadAll() {
        loadKhachHang();
        loadLoaiPhong();
        loadPhieuThue();
    }
     
    private void loadKhachHang() {
        modelKH.setRowCount(0);
        for (KhachHang kh : khBUS.getAll()) {
            modelKH.addRow(new Object[]{
                    kh.getMaKhachHang(),
                    kh.getHoTen(),
                    kh.getSoDienThoai()
            });
        }
    }

    private void loadLoaiPhong() {
        cboLoaiPhong.removeAllItems();
        for (LoaiPhong lp : loaiBUS.getAll()) cboLoaiPhong.addItem(lp);
        loadPhongTheoLoai();
    }

    private void loadPhongTheoLoai() {
        cboPhong.removeAllItems();
        LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if (lp == null) return;

        java.util.Date ngayNhan = dcNgayNhan.getDate();
        java.util.Date ngayTra = dcNgayTra.getDate();

        if (ngayNhan == null || ngayTra == null) {
            for (Phong p : phongBUS.getAll()) {
                if (p.getMaLoaiPhong() == lp.getMaLoaiPhong()) {
                    cboPhong.addItem(p);
                }
            }
            return;
        }

        for (Phong p : phongBUS.getAll()) {
            if (p.getMaLoaiPhong() == lp.getMaLoaiPhong()) {
                if (maPhieuDatDangNhan != null) {
                    List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(maPhieuDatDangNhan);
                    if (!ds.isEmpty() && ds.get(0).getMaPhong() == p.getMaPhong()) {
                        cboPhong.addItem(p);
                        continue;
                    }
                }
                boolean trong = ctdpBUS.isPhongTrong(
                                p.getMaPhong(),
                                new java.sql.Date(ngayNhan.getTime()),
                                new java.sql.Date(ngayTra.getTime()));
                if (trong) {
                    cboPhong.addItem(p);
                }
            }
        }
        cboPhong.revalidate();
        cboPhong.repaint();
    }

    private void openPhieuDat() {
        modelPD.setRowCount(0);
        for (PhieuDatPhong pd : pdBUS.getAll()) {
            if (!"DA_DAT".equals(pd.getTrangThai())) continue;
            KhachHang kh = khBUS.getAll().stream()
                    .filter(x -> x.getMaKhachHang() == pd.getMaKhachHang())
                    .findFirst().orElse(null);

            List<ChiTietDatPhong> ctList = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
            String tenPhong = "";
            Phong phongObj = null;

            if (!ctList.isEmpty()) {
                int maPhong = ctList.get(0).getMaPhong();
                phongObj = phongBUS.getAll().stream()
                        .filter(p -> p.getMaPhong() == maPhong)
                        .findFirst().orElse(null);
                if (phongObj != null) {
                    tenPhong = phongObj.getSoPhong();
                }
            }

            modelPD.addRow(new Object[]{
                    pd.getMaPhieuDat(),
                    kh != null ? kh.getHoTen() : "",
                    tenPhong,
                    pd.getNgayNhanPhong(),
                    pd.getNgayTraPhong(),
                    pd.getTrangThai()
            });
        }
        dlgPhieuDat.setVisible(true);
    }

    private void xacNhanPhieuDat() {
        int row = tblPhieuDat.getSelectedRow();
        if (row == -1) return;

        int maPD = Integer.parseInt(modelPD.getValueAt(row, 0).toString());
        maPhieuDatDangNhan = maPD;
        PhieuDatPhong pd = pdBUS.getAll().stream()
                .filter(x -> x.getMaPhieuDat() == maPD)
                .findFirst().orElse(null);

        if (pd == null) return;
        phieuDatDangNhan = pd;

        dcNgayNhan.setDate(pd.getNgayNhanPhong());
        dcNgayTra.setDate(pd.getNgayTraPhong());
        dcNgayNhan.setMinSelectableDate(new java.util.Date());
        dcNgayTra.setMinSelectableDate(new java.util.Date());

        for (int i = 0; i < modelKH.getRowCount(); i++) {
            if (Integer.parseInt(modelKH.getValueAt(i, 0).toString()) == pd.getMaKhachHang()) {
                tblKhachHang.setRowSelectionInterval(i, i);
                break;
            }
        }

        List<ChiTietDatPhong> ctList = ctdpBUS.getByPhieuDat(maPD);
        if (!ctList.isEmpty()) {
            int maPhong = ctList.get(0).getMaPhong();
            Phong phongObj = phongBUS.getAll().stream()
                    .filter(p -> p.getMaPhong() == maPhong)
                    .findFirst().orElse(null);

            if (phongObj != null) {
                LoaiPhong selectedLoai = null;
                for (LoaiPhong lp : loaiBUS.getAll()) {
                    if (lp.getMaLoaiPhong() == phongObj.getMaLoaiPhong()) {
                        selectedLoai = lp;
                        break;
                    }
                }
                if (selectedLoai != null) {
                    cboLoaiPhong.setSelectedItem(selectedLoai);
                }
                loadPhongTheoLoai();
                for (int i = 0; i < cboPhong.getItemCount(); i++) {
                    Phong p = cboPhong.getItemAt(i);
                    if (p.getMaPhong() == maPhong) {
                        cboPhong.setSelectedIndex(i);
                        break;
                    }
                }
            }
        }
        dlgPhieuDat.dispose();
    }

    private void huyPhieuDat() {
        int row = tblPhieuDat.getSelectedRow();
        if (row == -1) return;

        int maPD = Integer.parseInt(modelPD.getValueAt(row, 0).toString());
        PhieuDatPhong pd = pdBUS.getAll().stream()
                .filter(x -> x.getMaPhieuDat() == maPD)
                .findFirst().orElse(null);

        if (pd == null) return;
        pd.setTrangThai("QUA_HAN");
        pdBUS.update(pd);
        openPhieuDat();
    }

    private boolean checkTrungPhong(int maPhong, java.util.Date a, java.util.Date b, Integer excludePhieuDatId, Integer excludePhieuThueId) {
        if (a == null || b == null) return false;
        if (a.after(b)) return true;

        for (PhieuDatPhong pd : pdBUS.getAll()) {
            if (excludePhieuDatId != null && pd.getMaPhieuDat() == excludePhieuDatId) continue;
            if ("DA_HUY".equals(pd.getTrangThai()) || "QUA_HAN".equals(pd.getTrangThai())) continue;

            List<ChiTietDatPhong> ctList = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
            for (ChiTietDatPhong ct : ctList) {
                if (ct.getMaPhong() != maPhong) continue;

                java.util.Date nn = pd.getNgayNhanPhong();
                java.util.Date nt = pd.getNgayTraPhong();
                java.sql.Date a1 = new java.sql.Date(a.getTime());
                java.sql.Date b1 = new java.sql.Date(b.getTime());
                java.sql.Date nn1 = new java.sql.Date(nn.getTime());
                java.sql.Date nt1 = new java.sql.Date(nt.getTime());

                if (!(b1.compareTo(nn1) <= 0 || a1.compareTo(nt1) >= 0)) {
                    return true;
                }
            }
        }

        for (PhieuThuePhong pt : ptBUS.getAll()) {
            if (excludePhieuThueId != null && pt.getMaPhieuThue() == excludePhieuThueId) continue;
            if ("DA_TRA".equals(pt.getTrangThai()) || "DA_HUY".equals(pt.getTrangThai())) continue;

            List<ChiTietThuePhong> ctList = ctBUS.getByPhieuThue(pt.getMaPhieuThue());
            for (ChiTietThuePhong ct : ctList) {
                if (ct.getMaPhong() != maPhong) continue;

                java.util.Date nn = pt.getNgayNhanPhong();
                java.util.Date nt = pt.getNgayTraPhongDuKien();
                java.sql.Date a1 = new java.sql.Date(a.getTime());
                java.sql.Date b1 = new java.sql.Date(b.getTime());
                java.sql.Date nn1 = new java.sql.Date(nn.getTime());
                java.sql.Date nt1 = new java.sql.Date(nt.getTime());

                if (a1.before(nt1) && b1.after(nn1)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void thuePhong() {
        int row = tblKhachHang.getSelectedRow();
        if (row == -1) return;

        if (cboPhong.getSelectedItem() == null || dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null) return;
        if (!kiemTraNgayThue()) return;

        int maKH = Integer.parseInt(modelKH.getValueAt(row, 0).toString());
        Phong p = (Phong) cboPhong.getSelectedItem();
        Integer excludePD = maPhieuDatDangNhan;

        if (checkTrungPhong(p.getMaPhong(), dcNgayNhan.getDate(), dcNgayTra.getDate(), excludePD, null)) {
            JOptionPane.showMessageDialog(this, "Phòng đã bị đặt trong khoảng thời gian này");
            return;
        }

        PhieuThuePhong pt = new PhieuThuePhong();
        pt.setMaKhachHang(maKH);
        pt.setMaNhanVien(1);
        pt.setNgayNhanPhong(new Timestamp(dcNgayNhan.getDate().getTime()));
        pt.setNgayTraPhongDuKien(new Date(dcNgayTra.getDate().getTime()));
        pt.setTrangThai("DANG_THUE");

        if (ptBUS.insert(pt)) {
            PhieuThuePhong ptMoi = ptBUS.getLastInserted();
            int maPhieuThueMoi = ptMoi.getMaPhieuThue();
            ChiTietThuePhong ct = new ChiTietThuePhong();

            ct.setMaPhieuThue(maPhieuThueMoi);
            ct.setMaPhong(p.getMaPhong());

            long soNgay = (dcNgayTra.getDate().getTime() - dcNgayNhan.getDate().getTime()) / (1000 * 60 * 60 * 24);
            if (soNgay <= 0) soNgay = 1;

            LoaiPhong lp = loaiBUS.getAll().stream()
                    .filter(x -> x.getMaLoaiPhong() == p.getMaLoaiPhong())
                    .findFirst().orElse(null);

            double tongTien = soNgay * lp.getDonGia();
            ct.setDonGia(tongTien);
            ctBUS.insert(ct);

            if (phieuDatDangNhan != null) {
                phieuDatDangNhan.setTrangThai("DA_NHAN");
                pdBUS.update(phieuDatDangNhan);
            }
            phongBUS.updateTrangThai(p.getMaPhong(), "DA_THUE");
            loadPhieuThue();
            JOptionPane.showMessageDialog(this, "Nhận phòng thành công");
            phieuDatDangNhan = null;
        }
    }

    private void huyThue() {
        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dòng thuê cần hủy");
            return;
        }
        int ma = Integer.parseInt(modelTP.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận hủy thuê phòng này?", "HỦY THUÊ", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        ptBUS.delete(ma);
        loadPhieuThue();
    }

    private void loadPhieuThue() {
        modelTP.setRowCount(0);
        for (PhieuThuePhong pt : ptBUS.getAll()) {
            KhachHang kh = khBUS.getAll().stream()
                    .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                    .findFirst().orElse(null);

            List<ChiTietThuePhong> dsCT = ctBUS.getByPhieuThue(pt.getMaPhieuThue());
            if (dsCT.isEmpty()) {
                modelTP.addRow(new Object[]{
                        pt.getMaPhieuThue(), kh != null ? kh.getHoTen() : "", "",
                        pt.getNgayNhanPhong(), pt.getNgayTraPhongDuKien(), 0, pt.getTrangThai()
                });
                continue;
            }

            for (ChiTietThuePhong ct : dsCT) {
                Phong phong = phongBUS.getAll().stream()
                        .filter(p -> p.getMaPhong() == ct.getMaPhong())
                        .findFirst().orElse(null);
                String soPhong = (phong != null) ? phong.getSoPhong() : "";

                modelTP.addRow(new Object[]{
                        pt.getMaPhieuThue(), kh != null ? kh.getHoTen() : "", soPhong,
                        pt.getNgayNhanPhong(), pt.getNgayTraPhongDuKien(), ct.getDonGia(), pt.getTrangThai()
                });
            }
        }
    }

    private void tinhTien() {
        try {
            if (cboPhong.getSelectedItem() == null || dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null) return;
            Phong p = (Phong) cboPhong.getSelectedItem();
            LoaiPhong lp = loaiBUS.getAll().stream()
                    .filter(x -> x.getMaLoaiPhong() == p.getMaLoaiPhong())
                    .findFirst().orElse(null);

            long day = (dcNgayTra.getDate().getTime() - dcNgayNhan.getDate().getTime()) / (1000 * 60 * 60 * 24);
            if (day <= 0) day = 1;
            txtTongTien.setText(String.valueOf(day * lp.getDonGia()));
        } catch (Exception e) {
            txtTongTien.setText("");
        }
    }

    private void timPhieuDat() {
        String key = txtTimPD.getText().trim().toLowerCase();
        modelPD.setRowCount(0);

        for (PhieuDatPhong pd : pdBUS.getAll()) {
            if (!"DA_DAT".equals(pd.getTrangThai())) continue;
            KhachHang kh = khBUS.getAll().stream()
                    .filter(x -> x.getMaKhachHang() == pd.getMaKhachHang())
                    .findFirst().orElse(null);

            if (kh == null) continue;
            boolean matchTen = kh.getHoTen().toLowerCase().contains(key);
            boolean matchCCCD = kh.getCccd() != null && kh.getCccd().contains(key);
            if (!matchTen && !matchCCCD) continue;

            List<ChiTietDatPhong> ctList = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
            String tenPhong = "";

            if (!ctList.isEmpty()) {
                int maPhong = ctList.get(0).getMaPhong();
                Phong phong = phongBUS.getAll().stream()
                        .filter(p -> p.getMaPhong() == maPhong)
                        .findFirst().orElse(null);
                if (phong != null) tenPhong = phong.getSoPhong();
            }

            modelPD.addRow(new Object[]{
                    pd.getMaPhieuDat(), kh.getHoTen(), tenPhong,
                    pd.getNgayNhanPhong(), pd.getNgayTraPhong(), pd.getTrangThai()
            });
        }
    }

    private void moFormDichVu() {
        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phiếu thuê");
            return;
        }

        JDesktopPane desktop = getDesktopPane();
        if (desktop != null) {
            QuanLyDichVuPhongForm form = new QuanLyDichVuPhongForm();
            desktop.add(form);
            form.setVisible(true);
            try { form.setSelected(true); } catch (Exception ex) { ex.printStackTrace(); }
        }
    }

    private void suaPhieuThue() {
        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn phiếu thuê cần sửa");
            return;
        }

        int maPhieuThue = Integer.parseInt(modelTP.getValueAt(row, 0).toString());
        PhieuThuePhong pt = ptBUS.getAll().stream()
                .filter(x -> x.getMaPhieuThue() == maPhieuThue)
                .findFirst().orElse(null);

        if (pt == null) return;
        if (dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null || cboPhong.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Nhập đầy đủ thông tin");
            return;
        }
        if (!kiemTraNgayThue()) return;

        Phong phong = (Phong) cboPhong.getSelectedItem();
        if (checkTrungPhong(phong.getMaPhong(), dcNgayNhan.getDate(), dcNgayTra.getDate(), null, maPhieuThue)) {
            JOptionPane.showMessageDialog(this, "Phòng đã được thuê trong thời gian này");
            return;
        }

        pt.setNgayNhanPhong(new Timestamp(dcNgayNhan.getDate().getTime()));
        pt.setNgayTraPhongDuKien(new Date(dcNgayTra.getDate().getTime()));
        ptBUS.update(pt);

        List<ChiTietThuePhong> dsCT = ctBUS.getByPhieuThue(maPhieuThue);
        if (!dsCT.isEmpty()) {
            ChiTietThuePhong ct = dsCT.get(0);
            ct.setMaPhong(phong.getMaPhong());

            long soNgay = (dcNgayTra.getDate().getTime() - dcNgayNhan.getDate().getTime()) / (1000 * 60 * 60 * 24);
            if (soNgay <= 0) soNgay = 1;

            LoaiPhong lp = loaiBUS.getAll().stream()
                    .filter(x -> x.getMaLoaiPhong() == phong.getMaLoaiPhong())
                    .findFirst().orElse(null);

            ct.setDonGia(soNgay * lp.getDonGia());
            ctBUS.update(ct);
        }
        loadPhieuThue();
        JOptionPane.showMessageDialog(this, "Cập nhật phiếu thuê thành công");
    }

    private boolean kiemTraNgayThue() {
        if (dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null) return false;

        Calendar c1 = Calendar.getInstance(); c1.setTime(dcNgayNhan.getDate());
        Calendar c2 = Calendar.getInstance(); c2.setTime(dcNgayTra.getDate());

        c1.set(Calendar.HOUR_OF_DAY, 0); c1.set(Calendar.MINUTE, 0); c1.set(Calendar.SECOND, 0); c1.set(Calendar.MILLISECOND, 0);
        c2.set(Calendar.HOUR_OF_DAY, 0); c2.set(Calendar.MINUTE, 0); c2.set(Calendar.SECOND, 0); c2.set(Calendar.MILLISECOND, 0);

        if (!c2.getTime().after(c1.getTime())) {
            JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn ngày nhận");
            return false;
        }
        return true;
    }

    private void timKH() {
        String key = txtTimKH.getText().toLowerCase();
        modelKH.setRowCount(0);
        for (KhachHang kh : khBUS.getAll()) {
            if (kh.getHoTen().toLowerCase().contains(key) || kh.getSoDienThoai().contains(key)) {
                modelKH.addRow(new Object[]{
                        kh.getMaKhachHang(), kh.getHoTen(), kh.getSoDienThoai()
                });
            }
        }
    }
}