package gui;

import bus.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import com.toedter.calendar.JDateChooser;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.awt.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

 

public class NhanPhongForm2 extends JInternalFrame {
    private JButton btnDichVu;
    private JButton btnDichVu1;
     private JButton btnCapNhat;
    private JButton btnInBill; // Thêm nút mới theo yêu cầu
    private PhieuDatPhong phieuDatDangNhan = null;
    private Integer maPhieuDatDangNhan = null;
    private JDialog dlgBill;
    private JTextArea txtBill;
    private JButton btnPrintBill;
    // Giữ đối tượng bảng ẩn để không làm lỗi logic nghiệp vụ cũ
    private JTable tblKhachHang; 
    private DefaultTableModel modelKH;
    
    private JTable tblThuePhong;
    private HoaDonBUS hdBUS = new HoaDonBUS();
    private JTextField txtTenKH;
    private JTextField txtCCCD;
    private JTextField txtSDT;
    private JDialog dlgPhieuDat;
    private JTable tblPhieuDat;
    private DefaultTableModel modelPD;

    private JTextField txtTongTien;
    private JDateChooser dcNgayNhan;
    private JDateChooser dcNgayTra;
  
     private JButton btnHuyThue;
    private JButton btnThuePhong;
     private JButton btnXacNhanPD;
 
    private KhachHangBUS khBUS = new KhachHangBUS();
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();

    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();

    private PhieuThuePhongBUS ptBUS = new PhieuThuePhongBUS();
    private ChiTietThuePhongBUS ctBUS = new ChiTietThuePhongBUS();

    private DefaultTableModel modelTP;

    // Định nghĩa Palette màu UI hiện đại
    private final Color PRIMARY_COLOR = new Color(41, 128, 185); // Xanh dương chủ đạo
    private final Color SUCCESS_COLOR = new Color(39, 174, 96);  // Xanh lá (Xác nhận/Thuê)
    private final Color DANGER_COLOR = new Color(211, 47, 47);   // Đỏ (Hủy)
    private final Color INFO_COLOR = new Color(52, 152, 219);     // Xanh lam (In bill)
    private final Color TEXT_COLOR = new Color(44, 62, 80);      // Chữ xám đậm
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 14);

    private int maHoaDon;

    public NhanPhongForm2(int maHoaDon) {
    	
        super("NHẬN PHÒNG", true, true, true, true);
        this.maHoaDon = maHoaDon;
        setSize(1350, 780);

        initUI();
         loadHoaDon();
    }

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));
        getContentPane().setBackground(Color.WHITE);

        // Khởi tạo các bảng ngầm để giữ nguyên logic cấu trúc cũ
        modelKH = new DefaultTableModel(new String[]{"Mã phòng", "Số phòng", "Loại", "Đơn giá"}, 0);
        tblKhachHang = createModernTable(modelKH);
        tblKhachHang.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            if (tblKhachHang.getSelectedRow() == -1) return;
            tinhTien();
        });

        // ========================================================
        // 1. PANEL PHÍA TRÊN: THÔNG TIN CHI TIẾT & CHỨC NĂNG
        // ========================================================
        JPanel pnlTopOuter = new JPanel(new BorderLayout(10, 10));
        pnlTopOuter.setBackground(Color.WHITE);
        pnlTopOuter.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)), 
                "Thông Tin Thuê Phòng & Khách Hàng", TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, PRIMARY_COLOR));

        // Thiết kế GridBagLayout 2 cột giúp form dàn ngang đẹp mắt khi xóa panel trái
        JPanel pnlFields = new JPanel(new GridBagLayout());
        pnlFields.setBackground(Color.WHITE);
        pnlFields.setBorder(new EmptyBorder(15, 15, 15, 15));
     
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new java.awt.Insets(8, 15, 8, 15);

        // Khởi tạo các components nhập liệu
     
        dcNgayNhan = new JDateChooser();
        dcNgayTra = new JDateChooser();

        txtTenKH = new JTextField();
        txtCCCD = new JTextField();
        txtSDT = new JTextField();

        txtTenKH.setEditable(false);
        txtCCCD.setEditable(false);
        txtSDT.setEditable(false);

        txtTenKH.setFont(MAIN_FONT);
        txtCCCD.setFont(MAIN_FONT);
        txtSDT.setFont(MAIN_FONT);

        txtTongTien = new JTextField();
        txtTongTien.setFont(new Font("Segoe UI", Font.BOLD, 18));
        txtTongTien.setForeground(DANGER_COLOR);
        txtTongTien = new JTextField();
        txtTongTien.setFont(new Font("Segoe UI", Font.BOLD, 18));
        txtTongTien.setForeground(DANGER_COLOR);
        txtTongTien.setEditable(false);
        txtTongTien.setFocusable(false);
        txtTongTien.setHorizontalAlignment(JTextField.RIGHT);
        txtTongTien.setBackground(new Color(245, 245, 245));
        txtTongTien.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));        txtTongTien.setHorizontalAlignment(JTextField.RIGHT);

     // ===== Khởi tạo ngày =====
        Calendar cal = Calendar.getInstance();

        // Hôm nay (00:00:00)
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        java.util.Date homNay = cal.getTime();

        // Ngày mai
        cal.add(Calendar.DATE, 1);
        java.util.Date ngayMai = cal.getTime();

        // Giá trị mặc định
        dcNgayNhan.setDate(homNay);
        dcNgayTra.setDate(ngayMai);

        // Không cho chọn ngày quá khứ
        dcNgayNhan.setMinSelectableDate(homNay);
        dcNgayTra.setMinSelectableDate(ngayMai);

        // Sự kiện xử lý logic ngày tháng giữ nguyên
        dcNgayNhan.getDateEditor().addPropertyChangeListener(evt -> {

            if (!"date".equals(evt.getPropertyName()))
                return;

            if (dcNgayNhan.getDate() == null)
                return;

            Calendar calNgayNhan = Calendar.getInstance();
            calNgayNhan.setTime(dcNgayNhan.getDate());

            calNgayNhan.set(Calendar.HOUR_OF_DAY, 0);
            calNgayNhan.set(Calendar.MINUTE, 0);
            calNgayNhan.set(Calendar.SECOND, 0);
            calNgayNhan.set(Calendar.MILLISECOND, 0);

            java.util.Date ngayNhan = calNgayNhan.getTime();

            calNgayNhan.add(Calendar.DATE, 1);

            java.util.Date ngayTraMin = calNgayNhan.getTime();

            dcNgayTra.setMinSelectableDate(ngayTraMin);

            if (dcNgayTra.getDate() == null ||
                !dcNgayTra.getDate().after(ngayNhan)) {

                dcNgayTra.setDate(ngayTraMin);
            }

            tinhTien();
        });

        dcNgayTra.getDateEditor().addPropertyChangeListener(evt -> {

            if (!"date".equals(evt.getPropertyName()))
                return;

            if (dcNgayNhan.getDate() == null ||
                    dcNgayTra.getDate() == null)
                return;

            Calendar cNhan = Calendar.getInstance();
            cNhan.setTime(dcNgayNhan.getDate());

            cNhan.set(Calendar.HOUR_OF_DAY, 0);
            cNhan.set(Calendar.MINUTE, 0);
            cNhan.set(Calendar.SECOND, 0);
            cNhan.set(Calendar.MILLISECOND, 0);

            Calendar cTra = Calendar.getInstance();
            cTra.setTime(dcNgayTra.getDate());

            cTra.set(Calendar.HOUR_OF_DAY, 0);
            cTra.set(Calendar.MINUTE, 0);
            cTra.set(Calendar.SECOND, 0);
            cTra.set(Calendar.MILLISECOND, 0);

            if (!cTra.getTime().after(cNhan.getTime())) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ngày trả phải lớn hơn ngày nhận ít nhất 1 ngày!"
                );

                cNhan.add(Calendar.DATE, 1);
                dcNgayTra.setDate(cNhan.getTime());
                return;
            }

            int row = tblThuePhong.getSelectedRow();

            if (row != -1) {

                int maPT = Integer.parseInt(
                        modelTP.getValueAt(row, 0).toString());

                PhieuThuePhong pt = ptBUS.getById(maPT);

                List<ChiTietThuePhong> ds =
                        ctBUS.getByPhieuThue(maPT);

                tinhTienTheoPhieu(pt, ds);
            }

            tinhTien();
        });

        // Phân bổ các dòng thành form 2 cột cân xứng
        // Cột 1
         addFormColumn(pnlFields, gbc, 1, 0, "Tên khách:", txtTenKH);
        addFormColumn(pnlFields, gbc, 2, 0, "CCCD:", txtCCCD);
        // Cột 2
        addFormColumn(pnlFields, gbc, 0, 2, "SĐT:", txtSDT);
        addFormColumn(pnlFields, gbc, 1, 2, "Ngày nhận:", dcNgayNhan);
        addFormColumn(pnlFields, gbc, 2, 2, "Ngày trả:", dcNgayTra);
        
        // Hàng tổng tiền trải dài ở dưới cùng
        gbc.gridy = 3; gbc.gridx = 0; gbc.weightx = 0.1;
        JLabel lblTongTien = new JLabel("Tạm tính:");
        lblTongTien.setFont(MAIN_FONT); lblTongTien.setForeground(TEXT_COLOR);
        pnlFields.add(lblTongTien, gbc);
        
        gbc.gridx = 1; gbc.gridwidth = 3; gbc.weightx = 0.9;
        pnlFields.add(txtTongTien, gbc);
        gbc.gridwidth = 1; // reset gridwidth

        // Panel nhóm nút chức năng (Đổi sang lưới 2x3 để chứa đủ 6 nút bao gồm In Bill)
        JPanel pnlButtons = new JPanel(new GridLayout(2, 3, 10, 10));
        pnlButtons.setBackground(Color.WHITE);
        pnlButtons.setBorder(new EmptyBorder(0, 15, 15, 15));

        btnThuePhong = createModernButton("XÁC NHẬN THUÊ / NHẬN", SUCCESS_COLOR, Color.WHITE);
        btnDichVu = createModernButton("THÊM PHÒNG", new Color(155, 89, 182), Color.WHITE);
        btnDichVu1 = createModernButton("DỊCH VỤ PHÒNG", new Color(155, 89, 182), Color.WHITE);
        btnInBill = createModernButton("IN HÓA ĐƠN (BILL)", INFO_COLOR, Color.WHITE);
         btnHuyThue = createModernButton("HỦY PHIẾU THUÊ", DANGER_COLOR, Color.WHITE);
         btnCapNhat = createModernButton(
        	        "CẬP NHẬT NGÀY TRẢ",
        	        new Color(230,126,34),
        	        Color.WHITE);
         pnlButtons.add(btnThuePhong);

         pnlButtons.add(btnDichVu);
         pnlButtons.add(btnDichVu1);

         pnlButtons.add(btnCapNhat);

         pnlButtons.add(btnInBill);

         pnlButtons.add(btnHuyThue);

        pnlTopOuter.add(pnlFields, BorderLayout.CENTER);
        pnlTopOuter.add(pnlButtons, BorderLayout.SOUTH);

        // ========================================================
        // 2. PANEL PHÍA DƯỚI: DANH SÁCH ĐANG THUÊ
        // ========================================================
        modelTP = new DefaultTableModel(new String[]{
                "Mã phiếu", "Tên khách hàng", "Số phòng", "Ngày nhận thực tế", "Ngày trả dự kiến",   "Trạng thái"
        }, 0);
        tblThuePhong = createModernTable(modelTP);
        
        // Giữ nguyên hoàn toàn logic tương tác phản hồi của hệ thống cũ
        tblThuePhong.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            int row = tblThuePhong.getSelectedRow();
            if (row == -1) return;

            int maPT = Integer.parseInt(modelTP.getValueAt(row, 0).toString());

            PhieuThuePhong pt = ptBUS.getById(maPT);
            if (pt == null) return;

            PhieuThuePhong ptFull = ptBUS.getById(maPT);
            List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(maPT);
            if (ds.isEmpty()) return;

            if (pt == null) return;

            dcNgayNhan.setDate(pt.getNgayNhanPhong());
            dcNgayTra.setDate(pt.getNgayTraPhongDuKien());
            loadKhachHangTheoPhieu(pt);
 
             if (!ds.isEmpty()) {
                int maPhong = ds.get(0).getMaPhong();
                for (int i = 0; i < modelKH.getRowCount(); i++) {
                    if (Integer.parseInt(modelKH.getValueAt(i,0).toString()) == maPhong) {
                        tblKhachHang.setRowSelectionInterval(i, i);
                        Rectangle r = tblKhachHang.getCellRect(i,0,true);
                        tblKhachHang.scrollRectToVisible(r);
                        break;
                    }
                }
            }
             loadKhachHangTheoPhieu(ptFull);

             dcNgayNhan.setDate(ptFull.getNgayNhanPhong());
             dcNgayTra.setDate(ptFull.getNgayTraPhongDuKien());
             tinhTienTheoPhieu(ptFull, ds);
            tinhTien();
        });

        JScrollPane scrollThuePhong = new JScrollPane(tblThuePhong);
        scrollThuePhong.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)), 
                "Danh Sách Phòng Đang Thuê Hệ Thống", TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, PRIMARY_COLOR));

        // Gom phối cảnh bằng JSplitPane dọc chia đôi màn hình trên dưới
        JSplitPane splitMain = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pnlTopOuter, scrollThuePhong);
        splitMain.setDividerLocation(380);
        splitMain.setResizeWeight(0.5);
        splitMain.setBorder(null);
        splitMain.setOneTouchExpandable(true);

        add(splitMain, BorderLayout.CENTER);

        // Khởi tạo các JDialog phụ
        initDialogPhieuDat();

        // Wiring lại Event ActionListeners hệ thống ổn định
       
        btnDichVu.addActionListener(e -> mothuephongform1());
        btnDichVu1.addActionListener(e -> moFormDichVu());
         btnThuePhong.addActionListener(e -> xacNhanThanhToan());
         btnHuyThue.addActionListener(e -> huyThue());
         btnCapNhat.addActionListener(e -> capNhatNgayTra());
        // Sự kiện nút In hóa đơn mới thêm
        btnInBill.addActionListener(e -> handlingInHoaDon());
    }

    private void initDialogPhieuDat() {
        dlgPhieuDat = new JDialog();
        dlgPhieuDat.setTitle("DANH SÁCH PHIẾU ĐẶT PHÒNG TRƯỚC");
        dlgPhieuDat.setModal(true);
        dlgPhieuDat.setSize(950, 520);
        dlgPhieuDat.setLocationRelativeTo(this);
        ((JPanel)dlgPhieuDat.getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));
        dlgPhieuDat.getContentPane().setBackground(Color.WHITE);

        modelPD = new DefaultTableModel(new String[]{
                "Mã đặt", "Khách hàng", "Phòng", "Ngày nhận", "Ngày trả", "Trạng thái"
        }, 0);
        tblPhieuDat = createModernTable(modelPD);
 
        JPanel pnlSearchPD = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
        pnlSearchPD.setBackground(Color.WHITE);
        JLabel lblSearch = new JLabel("Tên khách / CCCD:");
        lblSearch.setFont(MAIN_FONT);
        pnlSearchPD.add(lblSearch);
  
        JPanel pnlBtn = new JPanel(new GridLayout(1, 2, 10, 0));
        pnlBtn.setBackground(Color.WHITE);
        pnlBtn.setBorder(new EmptyBorder(10, 0, 0, 0));
        btnXacNhanPD = createModernButton("XÁC NHẬN NHẬN PHÒNG ĐÃ ĐẶT", SUCCESS_COLOR, Color.WHITE);
        btnXacNhanPD.setFont(BOLD_FONT);
        pnlBtn.add(btnXacNhanPD);
 
        JPanel pnlDlg = new JPanel(new BorderLayout(5, 5));
        pnlDlg.setBackground(Color.WHITE);
        pnlDlg.add(pnlSearchPD, BorderLayout.NORTH);
        pnlDlg.add(new JScrollPane(tblPhieuDat), BorderLayout.CENTER);
        pnlDlg.add(pnlBtn, BorderLayout.SOUTH);

        dlgPhieuDat.add(pnlDlg);

        btnXacNhanPD.addActionListener(e -> {
            if (txtTongTien.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Chưa có tổng tiền.");
                return;
            }
            double tong = Double.parseDouble(txtTongTien.getText());
            boolean ok = hdBUS.xacNhanThanhToan(maHoaDon, tong, 0);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Thanh toán thành công.");
            } else {
                JOptionPane.showMessageDialog(this, "Thanh toán thất bại.");
            }
        });
    }
    private void capNhatNgayTra() {

        int row = tblThuePhong.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn phiếu thuê");
            return;
        }

        if (dcNgayTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn ngày trả");
            return;
        }

        int maPhieu =
                Integer.parseInt(modelTP.getValueAt(row, 0).toString());

        java.sql.Date ngayTra =
                new java.sql.Date(dcNgayTra.getDate().getTime());

        //------------------------------------------------
        // cập nhật ngày trả
        //------------------------------------------------

        boolean ok =
                ptBUS.updateNgayTra(maPhieu, ngayTra);

        if (!ok) {
            JOptionPane.showMessageDialog(this,
                    "Không cập nhật được ngày trả");
            return;
        }

        //------------------------------------------------
        // lấy lại phiếu thuê sau khi cập nhật
        //------------------------------------------------

        PhieuThuePhong pt = ptBUS.getById(maPhieu);

        //------------------------------------------------
        // tính lại tổng tiền
        //------------------------------------------------

        double tongTien = 0;

        List<ChiTietThuePhong> ds =
                ctBUS.getByPhieuThue(maPhieu);

        long soNgay =
                tinhSoNgay(
                        pt.getNgayNhanPhong(),
                        pt.getNgayTraPhongDuKien());

        if (soNgay <= 0)
            soNgay = 1;

        for (ChiTietThuePhong ct : ds) {

            tongTien += ct.getDonGia() * soNgay;

        }

        //------------------------------------------------
        // cập nhật hóa đơn
        //------------------------------------------------

        HoaDon hd =
                hdBUS.getByPhieuThue(maPhieu);

        if (hd != null) {

            hd.setTongTien(tongTien);

            double tienConLai =
                    tongTien - hd.getTienKhachTra();

            if (tienConLai < 0)
                tienConLai = 0;

            hd.setTienConLai(tienConLai);

            if (tienConLai == 0)
                hd.setTrangThaiThanhToan("DA_THANH_TOAN");
            else
                hd.setTrangThaiThanhToan("CHUA_THANH_TOAN");

            hdBUS.update(hd);
        }

        txtTongTien.setText(String.valueOf(tongTien));

        loadHoaDon();

        JOptionPane.showMessageDialog(this,
                "Cập nhật thành công");
    }
    private void mothuephongform1() {

        JDesktopPane desktop = getDesktopPane();

        ThuePhongForm2 frm =
                new ThuePhongForm2(maHoaDon);

        desktop.add(frm);
        frm.setVisible(true);

        dispose();
    }
    private void handlingInHoaDon() {

        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Chọn phiếu thuê để in bill");
            return;
        }

        int maPhieu = Integer.parseInt(modelTP.getValueAt(row, 0).toString());

        PhieuThuePhong pt = ptBUS.getById(maPhieu);
        if (pt == null) return;

        KhachHang kh = khBUS.getAll().stream()
                .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                .findFirst().orElse(null);

        List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(maPhieu);

        showBillDialog(pt, kh, ds);
    }
    private void showBillDialog(PhieuThuePhong pt,
            KhachHang kh,
            List<ChiTietThuePhong> dsCT) {

JDialog dlg = new JDialog();
dlg.setTitle("HÓA ĐƠN THANH TOÁN");
dlg.setSize(750, 700);
dlg.setLocationRelativeTo(this);
dlg.setModal(true);

JTextArea txt = new JTextArea();
txt.setFont(new Font("Consolas", Font.PLAIN, 13));
txt.setEditable(false);

StringBuilder sb = new StringBuilder();

sb.append("============================================================\n");
sb.append("                 LUXURY HOTEL PAYMENT BILL                  \n");
sb.append("============================================================\n\n");

sb.append("Mã phiếu thuê : ").append(pt.getMaPhieuThue()).append("\n");

sb.append("Khách hàng    : ")
.append(kh == null ? "" : kh.getHoTen())
.append("\n");

sb.append("CCCD          : ")
.append(kh == null ? "" : kh.getCccd())
.append("\n");

sb.append("SĐT           : ")
.append(kh == null ? "" : kh.getSoDienThoai())
.append("\n");

sb.append("Email         : ")
.append(kh == null ? "" : kh.getEmail())
.append("\n");

sb.append("Ngày nhận     : ")
.append(pt.getNgayNhanPhong())
.append("\n");

sb.append("Ngày trả      : ")
.append(pt.getNgayTraPhongDuKien())
.append("\n\n");

long soNgay = tinhSoNgay(
pt.getNgayNhanPhong(),
pt.getNgayTraPhongDuKien());

if (soNgay <= 0) {
soNgay = 1;
}

long tongTien = 0;

sb.append("============================================================\n");
sb.append("                   CHI TIẾT PHÒNG THUÊ                      \n");
sb.append("============================================================\n\n");

int stt = 1;

for (ChiTietThuePhong ct : dsCT) {

Phong phong = phongBUS.findById(ct.getMaPhong());

if (phong == null)
continue;

LoaiPhong lp = loaiBUS.findById(phong.getMaLoaiPhong());

if (lp == null)
continue;

long donGia = (long) lp.getDonGia();
long thanhTien = donGia * soNgay;

tongTien += thanhTien;

sb.append("Phòng ").append(stt++).append("\n");
sb.append("----------------------------------------\n");
sb.append("Số phòng         : ").append(phong.getSoPhong()).append("\n");
sb.append("Loại phòng       : ").append(lp.getTenLoaiPhong()).append("\n");
sb.append("Sức chứa tối đa  : ")
.append(lp.getSoNguoiToiDa())
.append(" người\n");

sb.append("Đơn giá          : ")
.append(String.format("%,d", donGia))
.append(" VNĐ / đêm\n");

sb.append("Số đêm           : ")
.append(soNgay)
.append("\n");

sb.append("Thành tiền       : ")
.append(String.format("%,d", thanhTien))
.append(" VNĐ\n");

sb.append("Mô tả phòng      : ");

if (lp.getMoTa() == null || lp.getMoTa().trim().isEmpty()) {
sb.append("Không có");
} else {
sb.append(lp.getMoTa());
}

sb.append("\n\n");
}

sb.append("============================================================\n");
sb.append("                   TỔNG THANH TOÁN                          \n");
sb.append("============================================================\n");

sb.append("Số đêm lưu trú : ")
.append(soNgay)
.append("\n");

sb.append("Tổng tiền      : ")
.append(String.format("%,d", tongTien))
.append(" VNĐ\n");

sb.append("\n============================================================\n");
sb.append("        CẢM ƠN QUÝ KHÁCH ĐÃ SỬ DỤNG DỊCH VỤ CỦA CHÚNG TÔI\n");
sb.append("============================================================");

txt.setText(sb.toString());

JScrollPane scroll = new JScrollPane(txt);

JButton btnPrint = new JButton("IN BILL");
btnPrint.setBackground(new Color(39, 174, 96));
btnPrint.setForeground(Color.WHITE);
btnPrint.setFocusPainted(false);

btnPrint.addActionListener(e -> {
try {
txt.print();
} catch (Exception ex) {
ex.printStackTrace();
}
});

JPanel bottom = new JPanel();
bottom.add(btnPrint);

dlg.setLayout(new BorderLayout());
dlg.add(scroll, BorderLayout.CENTER);
dlg.add(bottom, BorderLayout.SOUTH);

dlg.setVisible(true);
}

    // Helper tạo cấu trúc Form 2 cột đều nhau
    private void addFormColumn(JPanel panel, GridBagConstraints gbc, int row, int col, String labelText, JComponent component) {
        JLabel label = new JLabel(labelText);
        label.setFont(MAIN_FONT);
        label.setForeground(TEXT_COLOR);
        
        gbc.gridy = row;
        gbc.gridx = col;
        gbc.weightx = 0.1;
        panel.add(label, gbc);
        
        gbc.gridx = col + 1;
        gbc.weightx = 0.4;
        panel.add(component, gbc);
    }

    // Helper tạo nút phẳng, hiện đại và bo góc nhẹ
    private JButton createModernButton(String text, Color background, Color foreground) {
        JButton btn = new JButton(text);
        btn.setFont(MAIN_FONT);
        btn.setBackground(background);
        btn.setForeground(foreground);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // Helper cấu hình Table giao diện đẹp, dễ nhìn
    private JTable createModernTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFont(MAIN_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(230, 230, 230));
        table.setSelectionBackground(new Color(52, 152, 219, 40));
        table.setSelectionForeground(Color.BLACK);
        table.setShowVerticalLines(false);

        JTableHeader header = table.getTableHeader();
        header.setFont(BOLD_FONT);
        header.setBackground(new Color(245, 247, 250));
        header.setForeground(TEXT_COLOR);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));
        return table;
    }

    // =========================================================================
    // TOÀN BỘ LOGIC NGHIỆP VỤ PHÍA DƯỚI ĐƯỢC ĐẢM BẢO GIỮ NGUYÊN HOÀN TOÀN 100%
    // =========================================================================
    

    private void loadHoaDon() {
        HoaDon hd = hdBUS.getById(maHoaDon);
        if (hd == null) return;

        txtTongTien.setText(String.valueOf(hd.getTongTien()));
        PhieuThuePhong pt = ptBUS.getById(hd.getMaPhieuThue());
        if (pt == null) return;

        List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(pt.getMaPhieuThue());
        if(!ds.isEmpty()){
            int maPhong = ds.get(0).getMaPhong();
            Phong p = phongBUS.getAll().stream()
                    .filter(x -> x.getMaPhong() == maPhong)
                    .findFirst().orElse(null);

           
        }

        dcNgayNhan.setDate(pt.getNgayNhanPhong());
        dcNgayTra.setDate(pt.getNgayTraPhongDuKien());

        loadKhachHangTheoPhieu(pt);
        loadPhongTheoPhieu(pt);
     }

    private void loadKhachHangTheoPhieu(PhieuThuePhong pt){
        KhachHang kh = khBUS.getAll().stream()
                .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                .findFirst().orElse(null);

        if(kh == null) return;
        if(txtTenKH != null) txtTenKH.setText(kh.getHoTen());
        if(txtCCCD != null) txtCCCD.setText(kh.getCccd());
        if(txtSDT != null) txtSDT.setText(kh.getSoDienThoai());
    }

	/*
	 * private void loadPhongTrong() { modelKH.setRowCount(0);
	 * txtTongTien.setText(""); LoaiPhong lp = (LoaiPhong)
	 * cboLoaiPhong.getSelectedItem();
	 * 
	 * if(lp == null || dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null)
	 * return;
	 * 
	 * for(Phong p : phongBUS.getAll()){ if(p.getMaLoaiPhong() !=
	 * lp.getMaLoaiPhong()) continue;
	 * 
	 * boolean trong = ctdpBUS.isPhongTrong( p.getMaPhong(), new
	 * java.sql.Date(dcNgayNhan.getDate().getTime()), new
	 * java.sql.Date(dcNgayTra.getDate().getTime()));
	 * 
	 * if(trong){ modelKH.addRow(new Object[]{ p.getMaPhong(), p.getSoPhong(),
	 * lp.getTenLoaiPhong(), lp.getDonGia() }); } } }
	 */
    private void moFormDichVu() {
        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phiếu thuê");
            return;
        }

        JDesktopPane desktop = getDesktopPane();
        if (desktop != null) {
            QuanLyDichVuPhongForm form = new QuanLyDichVuPhongForm();
            desktop.add(form);
            form.setVisible(true);
            try { form.setSelected(true); } catch (Exception ex) { ex.printStackTrace(); }
        }
    }
    private void xacNhanThanhToan() {

        int row = tblThuePhong.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn phiếu thuê cần xác nhận");
            return;
        }

        int maPhieuThue = Integer.parseInt(modelTP.getValueAt(row, 0).toString());

        PhieuThuePhong pt = ptBUS.getById(maPhieuThue);
        if (pt == null) return;

        HoaDon hd = hdBUS.getByPhieuThue(maPhieuThue);
        if (hd == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy hóa đơn");
            return;
        }

        String txt = txtTongTien.getText().trim();

        if (txt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tổng tiền đang trống");
            return;
        }

        double tongTien = Double.parseDouble(txt);
        // 👉 số tiền khách trả lần này (KHÔNG phải cộng dồn sai như bạn đang làm)
        double tienKhachTraMoi = tongTien;

        // 👉 cộng dồn tiền khách đã trả trước đó
        double tienKhachTraCu = hd.getTienKhachTra();
        double tongDaTra = tienKhachTraCu + tienKhachTraMoi;

        double conLai = hd.getTongTien() - tongDaTra;
        if (conLai < 0) conLai = 0;

        // ===== UPDATE HÓA ĐƠN =====
        hd.setTienKhachTra(tongDaTra);
        hd.setTienConLai(conLai);

        if (conLai == 0) {
            hd.setTrangThaiThanhToan("ĐÃ THANH TOÁN");
        } else {
            hd.setTrangThaiThanhToan("CHƯA THANH TOÁN");
        }

        hdBUS.sua(hd);

        // ===== PHIẾU THUÊ (KHÔNG set DANG_THUE khi thanh toán) =====
        pt.setTrangThai(pt.getTrangThai()); // giữ nguyên trạng thái hiện tại
        ptBUS.update(pt);

        JOptionPane.showMessageDialog(this,
                "Thanh toán thành công!\n" );

        loadHoaDon();
    }

    private boolean checkTrungPhong(int maPhong, java.util.Date a, java.util.Date b, Integer excludePhieuDatId, Integer excludePhieuThueId) {
        if (a == null || b == null) return false;
        if (a.after(b)) return true;

        for (PhieuDatPhong pd : pdBUS.getAll()) {
            if (excludePhieuDatId != null && pd.getMaPhieuDat() == excludePhieuDatId) continue;
            if ("DA_HUY".equals(pd.getTrangThai()) || "QUA_HAN".equals(pd.getTrangThai())) continue;

            List<ChiTietDatPhong> ctList = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
            for (ChiTietDatPhong ct : ctList) {
                if (ct.getMaPhong() != maPhong) continue;

                java.util.Date nn = pd.getNgayNhanPhong();
                java.util.Date nt = pd.getNgayTraPhong();
                java.sql.Date a1 = new java.sql.Date(a.getTime());
                java.sql.Date b1 = new java.sql.Date(b.getTime());
                java.sql.Date nn1 = new java.sql.Date(nn.getTime());
                java.sql.Date nt1 = new java.sql.Date(nt.getTime());

                if (!(b1.compareTo(nn1) <= 0 || a1.compareTo(nt1) >= 0)) {
                    return true;
                }
            }
        }

        for (PhieuThuePhong pt : ptBUS.getAll()) {
            if (excludePhieuThueId != null && pt.getMaPhieuThue() == excludePhieuThueId) continue;
            if ("DA_TRA".equals(pt.getTrangThai()) || "DA_HUY".equals(pt.getTrangThai())) continue;

            List<ChiTietThuePhong> ctList = ctBUS.getByPhieuThue(pt.getMaPhieuThue());
            for (ChiTietThuePhong ct : ctList) {
                if (ct.getMaPhong() != maPhong) continue;

                java.util.Date nn = pt.getNgayNhanPhong();
                java.util.Date nt = pt.getNgayTraPhongDuKien();
                java.sql.Date a1 = new java.sql.Date(a.getTime());
                java.sql.Date b1 = new java.sql.Date(b.getTime());
                java.sql.Date nn1 = new java.sql.Date(nn.getTime());
                java.sql.Date nt1 = new java.sql.Date(nt.getTime());

                if (a1.before(nt1) && b1.after(nn1)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void thuePhong() {
        int row = tblKhachHang.getSelectedRow();
        if (row == -1 || dcNgayNhan.getDate() == null || dcNgayTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn phòng.");
            return;
        }
        if (!kiemTraNgayThue()) return;

        HoaDon hd = hdBUS.getById(maHoaDon);
        PhieuThuePhong ptCu = ptBUS.getById(hd.getMaPhieuThue());
        int maKH = ptCu.getMaKhachHang();

        int maPhong = Integer.parseInt(modelKH.getValueAt(row, 0).toString());
        Phong p = phongBUS.getAll().stream()
                .filter(x -> x.getMaPhong() == maPhong)
                .findFirst().orElse(null);

        if (p == null) return;
        Integer excludePD = maPhieuDatDangNhan;

        if (checkTrungPhong(p.getMaPhong(), dcNgayNhan.getDate(), dcNgayTra.getDate(), excludePD, null)) {
            JOptionPane.showMessageDialog(this, "Phòng đã bị đặt trong khoảng thời gian này");
            return;
        }

        PhieuThuePhong pt = new PhieuThuePhong();
        pt.setMaKhachHang(maKH);
        pt.setMaNhanVien(1);
        pt.setNgayNhanPhong(new Timestamp(dcNgayNhan.getDate().getTime()));
        pt.setNgayTraPhongDuKien(new Date(dcNgayTra.getDate().getTime()));
        pt.setTrangThai("DANG_THUE");

        if (ptBUS.insert(pt)) {
            PhieuThuePhong ptMoi = ptBUS.getLastInserted();
            int maPhieuThueMoi = ptMoi.getMaPhieuThue();
            ChiTietThuePhong ct = new ChiTietThuePhong();

            ct.setMaPhieuThue(maPhieuThueMoi);
            ct.setMaPhong(p.getMaPhong());

            long soNgay = (dcNgayTra.getDate().getTime() - dcNgayNhan.getDate().getTime()) / (1000 * 60 * 60 * 24);
            if (soNgay <= 0) soNgay = 1;

            LoaiPhong lp = loaiBUS.getAll().stream()
                    .filter(x -> x.getMaLoaiPhong() == p.getMaLoaiPhong())
                    .findFirst().orElse(null);

            ct.setDonGia(lp.getDonGia());
            ctBUS.insert(ct);

            if (phieuDatDangNhan != null) {
                phieuDatDangNhan.setTrangThai("DA_NHAN");
                pdBUS.update(phieuDatDangNhan);
            }
            phongBUS.updateTrangThai(p.getMaPhong(), "DA_THUE");
            loadHoaDon();
            JOptionPane.showMessageDialog(this, "Nhận phòng thành công");
            phieuDatDangNhan = null;
        }
    }
    private void loadHoaDonTheoPhieu(int maPhieuThue){

        HoaDon hd = hdBUS.getByPhieuThue(maPhieuThue);

        if(hd==null){
            JOptionPane.showMessageDialog(this,"Không tìm thấy hóa đơn");
            return;
        }

        this.maHoaDon = hd.getMaHoaDon();

        loadHoaDon();
    }
    private void huyThue() {
        int row = tblThuePhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dòng thuê cần hủy");
            return;
        }
        int ma = Integer.parseInt(modelTP.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận hủy thuê phòng này?", "HỦY THUÊ", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        ptBUS.delete(ma);
        loadHoaDon();
    }
    private long tinhSoNgay(java.util.Date ngayNhan,
            java.util.Date ngayTra) {

LocalDate d1 = Instant.ofEpochMilli(ngayNhan.getTime())
.atZone(ZoneId.systemDefault())
.toLocalDate();

LocalDate d2 = Instant.ofEpochMilli(ngayTra.getTime())
.atZone(ZoneId.systemDefault())
.toLocalDate();

long soNgay = ChronoUnit.DAYS.between(d1, d2);

if (soNgay <= 0)
soNgay = 1;

return soNgay;
}
    private void loadPhongTheoPhieu(PhieuThuePhong pt) {

        modelTP.setRowCount(0);

        KhachHang kh = khBUS.getAll().stream()
                .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                .findFirst()
                .orElse(null);

        List<ChiTietThuePhong> dsCT =
                ctBUS.getByPhieuThue(pt.getMaPhieuThue());

        long soNgay =
                (pt.getNgayTraPhongDuKien().getTime()
                        - pt.getNgayNhanPhong().getTime())
                        / (1000 * 60 * 60 * 24);

        if (soNgay <= 0)
            soNgay = 1;

        double tongTien = 0;

        for (ChiTietThuePhong ct : dsCT) {

            Phong phong = phongBUS.getAll().stream()
                    .filter(p -> p.getMaPhong() == ct.getMaPhong())
                    .findFirst()
                    .orElse(null);

            if (phong == null)
                continue;

            LoaiPhong lp = loaiBUS.getAll().stream()
                    .filter(x -> x.getMaLoaiPhong() == phong.getMaLoaiPhong())
                    .findFirst()
                    .orElse(null);

            if (lp == null)
                continue;

            double thanhTien = lp.getDonGia() * soNgay;

            tongTien += thanhTien;

            modelTP.addRow(new Object[]{
                    pt.getMaPhieuThue(),
                    kh != null ? kh.getHoTen() : "",
                    phong.getSoPhong(),
                    pt.getNgayNhanPhong(),
                    pt.getNgayTraPhongDuKien(),
                     pt.getTrangThai()
            });
        }

        txtTongTien.setText(String.valueOf(tongTien));
    }

    // Các hàm stub bổ sung để tránh lỗi compile nếu thiếu trong đoạn code mẫu của bạn
    private void tinhTien() {

        try {

            int row = tblKhachHang.getSelectedRow();

            if (row == -1)
                return;

            int maPhong = Integer.parseInt(
                    modelKH.getValueAt(row, 0).toString());

            Phong p = phongBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaPhong() == maPhong)
                    .findFirst()
                    .orElse(null);

            if (p == null)
                return;

            LoaiPhong lp = loaiBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaLoaiPhong() == p.getMaLoaiPhong())
                    .findFirst()
                    .orElse(null);

            if (lp == null)
                return;

            LocalDate ngayNhan = dcNgayNhan.getDate()
                    .toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();

            LocalDate ngayTra = dcNgayTra.getDate()
                    .toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();

            long soNgay = ChronoUnit.DAYS.between(ngayNhan, ngayTra);

            if (soNgay <= 0)
                soNgay = 1;

            double tongTien = lp.getDonGia() * soNgay;

            txtTongTien.setText(String.valueOf(tongTien));

        } catch (Exception ex) {

            txtTongTien.setText("");

        }
    }

     

  

    
	 
    private void tinhTienTheoPhieu(PhieuThuePhong pt, List<ChiTietThuePhong> dsCT) {

        if (pt == null || dsCT == null || dsCT.isEmpty()) {
            txtTongTien.setText("");
            return;
        }

        long soNgay = tinhSoNgay(
                pt.getNgayNhanPhong(),
                pt.getNgayTraPhongDuKien());

        if (soNgay <= 0) {
            soNgay = 1;
        }

        double tongTien = 0;

        for (ChiTietThuePhong ct : dsCT) {

            Phong phong = phongBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaPhong() == ct.getMaPhong())
                    .findFirst()
                    .orElse(null);

            if (phong == null)
                continue;

            LoaiPhong lp = loaiBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaLoaiPhong() == phong.getMaLoaiPhong())
                    .findFirst()
                    .orElse(null);

            if (lp == null)
                continue;

            tongTien += lp.getDonGia() * soNgay;
        }

        txtTongTien.setText(String.valueOf(tongTien));
    }
    private boolean kiemTraNgayThue() {

        if (dcNgayNhan.getDate() == null ||
                dcNgayTra.getDate() == null) {

            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn ngày nhận và ngày trả.");
            return false;
        }

        Calendar homNay = Calendar.getInstance();
        homNay.set(Calendar.HOUR_OF_DAY, 0);
        homNay.set(Calendar.MINUTE, 0);
        homNay.set(Calendar.SECOND, 0);
        homNay.set(Calendar.MILLISECOND, 0);

        Calendar ngayNhan = Calendar.getInstance();
        ngayNhan.setTime(dcNgayNhan.getDate());
        ngayNhan.set(Calendar.HOUR_OF_DAY, 0);
        ngayNhan.set(Calendar.MINUTE, 0);
        ngayNhan.set(Calendar.SECOND, 0);
        ngayNhan.set(Calendar.MILLISECOND, 0);

        Calendar ngayTra = Calendar.getInstance();
        ngayTra.setTime(dcNgayTra.getDate());
        ngayTra.set(Calendar.HOUR_OF_DAY, 0);
        ngayTra.set(Calendar.MINUTE, 0);
        ngayTra.set(Calendar.SECOND, 0);
        ngayTra.set(Calendar.MILLISECOND, 0);

        // Không cho ngày nhận nhỏ hơn hôm nay
        if (ngayNhan.before(homNay)) {

            JOptionPane.showMessageDialog(this,
                    "Không được chọn ngày nhận trong quá khứ.");
            return false;
        }

        // Ngày trả phải lớn hơn ngày nhận
        if (!ngayTra.after(ngayNhan)) {

            JOptionPane.showMessageDialog(this,
                    "Ngày trả phải lớn hơn ngày nhận ít nhất 1 ngày.");
            return false;
        }

        return true;
    }

    
}
