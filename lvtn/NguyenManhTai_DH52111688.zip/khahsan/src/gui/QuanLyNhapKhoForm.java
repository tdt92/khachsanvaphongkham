package gui;

import bus.KhoBUS;
import model.Kho;

import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.sql.Date;

public class QuanLyNhapKhoForm extends JInternalFrame {

    private JTextField txtTen;
    private JTextField txtDVT;
    private JTextField txtSL;
    private JTextField txtNhap;
    private JTextField txtBan;
    private JTextField txtGhiChu;
    private JTextField txtTim;

    private JDateChooser dateChooser;

    private JTable table;
    private DefaultTableModel model;

    private KhoBUS bus = new KhoBUS();

    private int maDangChon = -1;

    public QuanLyNhapKhoForm() {

        super(
                "QUẢN LÝ NHẬP KHO",
                true,
                true,
                true,
                true
        );

        setSize(1000, 650);

        setDefaultCloseOperation(
                JInternalFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        JPanel pTop = new JPanel(new GridLayout(7, 2, 5, 5));

        txtTen = new JTextField();
        txtDVT = new JTextField();
        txtSL = new JTextField();
        txtNhap = new JTextField();
        txtBan = new JTextField();
        txtGhiChu = new JTextField();

        dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");

        ((AbstractDocument) txtSL.getDocument())
                .setDocumentFilter(new NumberFilter(false));

        ((AbstractDocument) txtNhap.getDocument())
                .setDocumentFilter(new NumberFilter(true));

        ((AbstractDocument) txtBan.getDocument())
                .setDocumentFilter(new NumberFilter(true));

        pTop.add(new JLabel("Tên vật dụng"));
        pTop.add(txtTen);

        pTop.add(new JLabel("Đơn vị tính"));
        pTop.add(txtDVT);

        pTop.add(new JLabel("Số lượng"));
        pTop.add(txtSL);

        pTop.add(new JLabel("Đơn giá nhập"));
        pTop.add(txtNhap);

        pTop.add(new JLabel("Đơn giá bán"));
        pTop.add(txtBan);

        pTop.add(new JLabel("Ngày nhập"));
        pTop.add(dateChooser);

        pTop.add(new JLabel("Ghi chú"));
        pTop.add(txtGhiChu);

        add(pTop, BorderLayout.NORTH);

        model = new DefaultTableModel();

        model.setColumnIdentifiers(new Object[]{
                "Mã",
                "Tên vật dụng",
                "ĐVT",
                "Số lượng",
                "Giá nhập",
                "Giá bán",
                "Ngày nhập",
                "Ghi chú"
        });

        table = new JTable(model);
        SoLuongRenderer renderer = new SoLuongRenderer();

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel()
                    .getColumn(i)
                    .setCellRenderer(renderer);
        }
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel pBottom = new JPanel();

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnLamMoi = new JButton("Làm mới");

        txtTim = new JTextField(15);

        JButton btnTim = new JButton("Tìm");

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        pBottom.add(btnLamMoi);
        pBottom.add(txtTim);
        pBottom.add(btnTim);

        add(pBottom, BorderLayout.SOUTH);

        loadData();

        btnThem.addActionListener(e -> {

            if (!kiemTraDuLieu())
                return;

            Kho k = layDuLieuForm();

            if (bus.them(k)) {
                JOptionPane.showMessageDialog(this,
                        "Thêm thành công");
                loadData();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Thêm thất bại");
            }
        });

        btnSua.addActionListener(e -> {

            if (maDangChon == -1) {
                JOptionPane.showMessageDialog(this,
                        "Vui lòng chọn dữ liệu cần sửa");
                return;
            }

            if (!kiemTraDuLieu())
                return;

            Kho k = layDuLieuForm();
            k.setMaVatDung(maDangChon);

            if (bus.sua(k)) {
                JOptionPane.showMessageDialog(this,
                        "Cập nhật thành công");
                loadData();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Cập nhật thất bại");
            }
        });

        btnXoa.addActionListener(e -> {

            if (maDangChon == -1) {
                JOptionPane.showMessageDialog(this,
                        "Vui lòng chọn dữ liệu cần xóa");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Bạn có chắc muốn xóa?",
                    "Xác nhận",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {

                if (bus.xoa(maDangChon)) {

                    JOptionPane.showMessageDialog(this,
                            "Xóa thành công");

                    loadData();
                    clearForm();

                } else {

                    JOptionPane.showMessageDialog(this,
                            "Xóa thất bại");
                }
            }
        });

        btnTim.addActionListener(e -> {

            model.setRowCount(0);

            for (Kho k : bus.timKiem(txtTim.getText())) {

                model.addRow(new Object[]{
                        k.getMaVatDung(),
                        k.getTenVatDung(),
                        k.getDonViTinh(),
                        k.getSoLuongTon(),
                        k.getDonGiaNhap(),
                        k.getDonGiaBan(),
                        k.getNgayNhap(),
                        k.getGhiChu()
                });
            }
        });

        btnLamMoi.addActionListener(e -> {

            clearForm();
            loadData();
        });

        table.getSelectionModel().addListSelectionListener(e -> {

            int row = table.getSelectedRow();

            if (row >= 0) {

                maDangChon =
                        Integer.parseInt(model.getValueAt(row, 0).toString());

                txtTen.setText(model.getValueAt(row, 1).toString());
                txtDVT.setText(model.getValueAt(row, 2).toString());
                txtSL.setText(model.getValueAt(row, 3).toString());
                txtNhap.setText(model.getValueAt(row, 4).toString());
                txtBan.setText(model.getValueAt(row, 5).toString());

                try {
                    dateChooser.setDate(
                            Date.valueOf(
                                    model.getValueAt(row, 6).toString()));
                } catch (Exception ex) {
                    dateChooser.setDate(null);
                }

                txtGhiChu.setText(model.getValueAt(row, 7).toString());
            }
        });
    }

    private Kho layDuLieuForm() {

        Kho k = new Kho();

        k.setTenVatDung(txtTen.getText().trim());
        k.setDonViTinh(txtDVT.getText().trim());
        k.setSoLuongTon(Integer.parseInt(txtSL.getText()));
        k.setDonGiaNhap(Double.parseDouble(txtNhap.getText()));
        k.setDonGiaBan(Double.parseDouble(txtBan.getText()));

        k.setNgayNhap(
                new Date(dateChooser.getDate().getTime()));

        k.setGhiChu(txtGhiChu.getText().trim());

        return k;
    }

    private boolean kiemTraDuLieu() {

        if (txtTen.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Tên vật dụng không được để trống");
            txtTen.requestFocus();
            return false;
        }

        if (txtDVT.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Đơn vị tính không được để trống");
            txtDVT.requestFocus();
            return false;
        }

        if (txtSL.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Số lượng không được để trống");
            txtSL.requestFocus();
            return false;
        }

        if (txtNhap.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Giá nhập không được để trống");
            txtNhap.requestFocus();
            return false;
        }

        if (txtBan.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Giá bán không được để trống");
            txtBan.requestFocus();
            return false;
        }

        if (dateChooser.getDate() == null) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn ngày nhập");
            return false;
        }

        return true;
    }

    private void clearForm() {

        maDangChon = -1;

        txtTen.setText("");
        txtDVT.setText("");
        txtSL.setText("");
        txtNhap.setText("");
        txtBan.setText("");
        txtGhiChu.setText("");

        dateChooser.setDate(null);

        table.clearSelection();
    }

    private void loadData() {

        model.setRowCount(0);

        for (Kho k : bus.getAll()) {

            model.addRow(new Object[]{
                    k.getMaVatDung(),
                    k.getTenVatDung(),
                    k.getDonViTinh(),
                    k.getSoLuongTon(),
                    k.getDonGiaNhap(),
                    k.getDonGiaBan(),
                    k.getNgayNhap(),
                    k.getGhiChu()
            });
        }
    }
    class SoLuongRenderer extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            int soLuong = Integer.parseInt(
                    table.getValueAt(row, 3).toString()); // cột Số lượng

            if (!isSelected) {

            	if (soLuong < 20) {
            	    c.setBackground(new Color(255,180,180)); // đỏ
            	    c.setForeground(Color.RED);
            	}
            	else if (soLuong < 50) {
            	    c.setBackground(new Color(255,245,180)); // vàng
            	    c.setForeground(Color.BLACK);
            	}
            	else {
            	    c.setBackground(Color.WHITE);
            	    c.setForeground(Color.BLACK);
            	}

            }

            return c;
        }
    }
    class NumberFilter extends DocumentFilter {

        private boolean allowDecimal;

        public NumberFilter(boolean allowDecimal) {
            this.allowDecimal = allowDecimal;
        }

        @Override
        public void insertString(FilterBypass fb,
                                 int offset,
                                 String string,
                                 AttributeSet attr)
                throws BadLocationException {

            replace(fb, offset, 0, string, attr);
        }

        @Override
        public void replace(FilterBypass fb,
                            int offset,
                            int length,
                            String text,
                            AttributeSet attrs)
                throws BadLocationException {

            String oldText =
                    fb.getDocument().getText(
                            0,
                            fb.getDocument().getLength());

            String newText =
                    oldText.substring(0, offset)
                            + text
                            + oldText.substring(offset + length);

            String regex =
                    allowDecimal
                            ? "\\d*(\\.\\d*)?"
                            : "\\d*";

            if (newText.matches(regex)) {
                fb.replace(offset, length, text, attrs);
            }
        }
    }
}