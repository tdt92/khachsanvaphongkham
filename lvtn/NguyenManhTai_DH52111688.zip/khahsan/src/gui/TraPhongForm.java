package gui;

import bus.*;
import dao.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.List;

public class TraPhongForm extends JInternalFrame {

	private JTable tblPhongDangThue;
	private DefaultTableModel model;
	private JTextField txtTimKiem;
	private JButton btnDichVu;
	private JButton btnDichVu1;
	private HoaDonBUS hdBUS = new HoaDonBUS();
	private JButton btnTim;
	private JButton btnChiTiet;
	private JButton btnThanhToan;
	private JButton btnLamMoi;
	private JButton btnInHoaDon;

	private PhieuThuePhongBUS phieuBUS = new PhieuThuePhongBUS();
	private ChiTietThuePhongDAO ctThueDAO = new ChiTietThuePhongDAO();
	private SuDungDichVuDAO suDungDAO = new SuDungDichVuDAO();
	private DichVuBUS dichVuBUS = new DichVuBUS();
	private HoaDonDAO hoaDonDAO = new HoaDonDAO();
	private PhongBUS phongBUS = new PhongBUS();
	private PhieuDatPhongBUS phieuDatBUS = new PhieuDatPhongBUS();
	private KhachHangBUS khachHangBUS = new KhachHangBUS();

	public TraPhongForm() {
		super("Trả Phòng", true, true, true, true);
		setSize(1100, 650);
		setLayout(new BorderLayout(15, 15));
		((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));

		// ==========================================
		// 1. PANEL TOP: KHU VỰC TÌM KIẾM
		// ==========================================
		JPanel pnTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
		pnTop.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Trả phòng trước 12h trưa",
				TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 12)));

		txtTimKiem = new JTextField(25);
		txtTimKiem.setPreferredSize(new Dimension(250, 26));
		btnTim = new JButton("Tìm kiếm");
		btnLamMoi = new JButton("Làm mới");
		btnDichVu1 = new JButton("Dịch vụ phòng");

		btnDichVu1.setBackground(new Color(255, 193, 7));
		btnDichVu1.setForeground(Color.BLACK);
		pnTop.add(new JLabel("Tên KH / CCCD / Số phòng:"));
		pnTop.add(txtTimKiem);
		pnTop.add(btnTim);
		pnTop.add(btnLamMoi);
		pnTop.add(btnDichVu1);
		add(pnTop, BorderLayout.NORTH);

		// ==========================================
		// 2. PANEL CENTER: BẢNG THÔNG TIN
		// ==========================================
		model = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Không cho chỉnh sửa trực tiếp trên bảng
			}
		};
		model.addColumn("Mã Phiếu");
		model.addColumn("Mã Phòng");
		model.addColumn("Tên Khách");
		model.addColumn("Ngày Nhận");
		model.addColumn("Ngày Trả DK");
		model.addColumn("Số Ngày Còn Lại");

		tblPhongDangThue = new JTable(model);
		tblPhongDangThue.setRowHeight(26); // Tăng chiều cao hàng cho thoáng
		tblPhongDangThue.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblPhongDangThue.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));

		JScrollPane scrollPane = new JScrollPane(tblPhongDangThue);
		scrollPane.setBorder(
				BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Danh Sách Phòng Đang Thuê"));
		add(scrollPane, BorderLayout.CENTER);

		// ==========================================
		// 3. PANEL BOTTOM: NÚT ĐIỀU KHIỂN
		// ==========================================
		JPanel pnBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
		btnChiTiet = new JButton("Xem Chi Tiết Bill");
		btnThanhToan = new JButton("Thanh Toán Xuất Hóa Đơn");
		btnInHoaDon = new JButton("In Hóa Đơn (Phần cứng)");
		btnDichVu = new JButton("Quản Lý Dịch Vụ");
		// Tạo điểm nhấn màu sắc nhẹ cho các nút hành động chính
		btnThanhToan.setBackground(new Color(46, 139, 87));
		btnThanhToan.setForeground(Color.WHITE);
		btnChiTiet.setBackground(new Color(70, 130, 180));
		btnChiTiet.setForeground(Color.WHITE);
		btnDichVu.setBackground(new Color(255, 140, 0));
		btnDichVu.setForeground(Color.WHITE);
		pnBottom.add(btnChiTiet);
		pnBottom.add(btnDichVu);
		pnBottom.add(btnThanhToan);
		pnBottom.add(btnInHoaDon);
		add(pnBottom, BorderLayout.SOUTH);
		TraPhongRenderer renderer = new TraPhongRenderer();

		for (int i = 0; i < tblPhongDangThue.getColumnCount(); i++) {
		    tblPhongDangThue.getColumnModel()
		            .getColumn(i)
		            .setCellRenderer(renderer);
		}
		// Khởi tạo dữ liệu và sự kiện
		loadData();
		btnTim.addActionListener(e -> timKiem());
		btnLamMoi.addActionListener(e -> loadData());
		btnChiTiet.addActionListener(e -> xemChiTiet());
		btnThanhToan.addActionListener(e -> thanhToan());
		btnInHoaDon.addActionListener(e -> inHoaDon());
		btnDichVu1.addActionListener(e -> moQuanLyDichVuPhongDangChon());
		btnDichVu.addActionListener(e -> moQuanLyDichVu());
		setVisible(true);

	}

	private void loadData() {
		model.setRowCount(0);
		List<PhieuThuePhong> list = phieuBUS.getDangThueSapHetHan();
		for (PhieuThuePhong pt : list) {
			String tenKhach = "";
			KhachHang kh = khachHangBUS.findById(pt.getMaKhachHang());
			if (kh != null) {
				tenKhach = kh.getHoTen();
			}

			String dsPhong = "";
			List<ChiTietThuePhong> cts = ctThueDAO.getByPhieuThue(pt.getMaPhieuThue());
			for (ChiTietThuePhong ct : cts) {
				Phong p = phongBUS.findById(ct.getMaPhong());
				if (p != null) {
					dsPhong += p.getSoPhong() + " ";
				}
			}

			/*
			 * long soNgayConLai = (pt.getNgayTraPhongDuKien().getTime() -
			 * System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
			 */
			LocalDate today = LocalDate.now();

			java.util.Date d = pt.getNgayTraPhongDuKien();

			Calendar cal = Calendar.getInstance();
			cal.setTime(d);

			LocalDate ngayTra = LocalDate.of(
			        cal.get(Calendar.YEAR),
			        cal.get(Calendar.MONTH) + 1,
			        cal.get(Calendar.DAY_OF_MONTH));

			long soNgayConLai = ChronoUnit.DAYS.between(today, ngayTra);
			model.addRow(new Object[] { pt.getMaPhieuThue(), dsPhong, tenKhach, pt.getNgayNhanPhong(),
					pt.getNgayTraPhongDuKien(), soNgayConLai });
		}
	}
	private void moQuanLyDichVuPhongDangChon() {

	    int row = tblPhongDangThue.getSelectedRow();

	    if (row < 0) {
	        JOptionPane.showMessageDialog(this,
	                "Vui lòng chọn phòng!");
	        return;
	    }

	    int maPhieu = Integer.parseInt(model.getValueAt(row, 0).toString());

	    QuanLyDichVuPhongForm1 frm =
	            new QuanLyDichVuPhongForm1(maPhieu);

	    JDesktopPane desktop = getDesktopPane();

	    if (desktop != null) {
	        desktop.add(frm);
	        frm.setVisible(true);

	        try {
	            frm.setSelected(true);
	        } catch (Exception ex) {
	        }

	    } else {

	        JFrame f = new JFrame();

	        f.setSize(1200,700);

	        f.add(frm);

	        frm.setVisible(true);

	        f.setVisible(true);
	    }
	}
	private void timKiem() {
		String key = txtTimKiem.getText().trim().toLowerCase();
		model.setRowCount(0);
		for (PhieuThuePhong pt : phieuBUS.getDangThueSapHetHan()) {
			String tenKhach = "";
			String cccd = "";
			String dsPhong = "";

			KhachHang kh = khachHangBUS.findById(pt.getMaKhachHang());
			if (kh != null) {
				tenKhach = kh.getHoTen();
				cccd = kh.getCccd();
			}

			List<ChiTietThuePhong> cts = ctThueDAO.getByPhieuThue(pt.getMaPhieuThue());
			for (ChiTietThuePhong ct : cts) {
				Phong p = phongBUS.findById(ct.getMaPhong());
				if (p != null) {
					dsPhong += p.getSoPhong() + " ";
				}
			}

			boolean match = String.valueOf(pt.getMaPhieuThue()).contains(key) || tenKhach.toLowerCase().contains(key)
					|| cccd.toLowerCase().contains(key) || dsPhong.toLowerCase().contains(key);

			if (match) {
				/*
				 * long soNgayConLai = (pt.getNgayTraPhongDuKien().getTime() -
				 * System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
				 */
				LocalDate today = LocalDate.now();

				java.util.Date d = pt.getNgayTraPhongDuKien();

				Calendar cal = Calendar.getInstance();
				cal.setTime(d);

				LocalDate ngayTra = LocalDate.of(
				        cal.get(Calendar.YEAR),
				        cal.get(Calendar.MONTH) + 1,
				        cal.get(Calendar.DAY_OF_MONTH));

				long soNgayConLai = ChronoUnit.DAYS.between(today, ngayTra);
				model.addRow(new Object[] { pt.getMaPhieuThue(), dsPhong, tenKhach, pt.getNgayNhanPhong(),
						pt.getNgayTraPhongDuKien(), soNgayConLai });
			}
		}
	}
	private void moQuanLyDichVu() {

	    QuanLyDichVuPhongForm frm = new QuanLyDichVuPhongForm();

	    frm.setVisible(true);

	    JDesktopPane desktop = getDesktopPane();

	    if (desktop != null) {

	        desktop.add(frm);

	        try {
	            frm.setSelected(true);
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    } else {

	        JFrame frame = new JFrame("Quản lý dịch vụ");

	        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	        frame.setSize(1250, 750);

	        frame.setLocationRelativeTo(null);

	        frame.add(frm);

	        frm.setVisible(true);

	        frame.setVisible(true);
	    }
	}
	private long tinhSoNgay(Timestamp ngayNhan, java.sql.Date ngayTra) {

	    LocalDate d1 = ngayNhan.toLocalDateTime().toLocalDate();
	    LocalDate d2 = ngayTra.toLocalDate();

	    long soNgay = ChronoUnit.DAYS.between(d1, d2);

	    return soNgay <= 0 ? 1 : soNgay;
	}
	private int getSelectedMaPhieu() {
		int row = tblPhongDangThue.getSelectedRow();
		if (row < 0) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn một phiếu thuê trên bảng!", "Thông báo",
					JOptionPane.WARNING_MESSAGE);
			return -1;
		}
		return Integer.parseInt(model.getValueAt(row, 0).toString());
	}
	 
	// ==========================================
	// TRỌNG TÂM: CẢI TIẾN GIAO DIỆN XEM CHI TIẾT ĐẸP MẮT
	// ==========================================
	private void xemChiTiet() {

	    int maPhieu = getSelectedMaPhieu();

	    if (maPhieu == -1)
	        return;

	    PhieuThuePhong phieuThue = phieuBUS.getById(maPhieu);

	    if (phieuThue == null) {
	        JOptionPane.showMessageDialog(this,
	                "Không tìm thấy phiếu thuê!");
	        return;
	    }

	    KhachHang kh = khachHangBUS.findById(phieuThue.getMaKhachHang());

	    HoaDon hd = hdBUS.getByPhieuThue(maPhieu);

	    StringBuilder sb = new StringBuilder();

	    sb.append("=========== BENEFIT HOTEL ===========\n");
	    sb.append("          CHI TIẾT THANH TOÁN\n\n");

	    sb.append("Mã hóa đơn : ")
	            .append(hd == null ? "" : hd.getMaHoaDon())
	            .append("\n");

	    sb.append("Mã phiếu   : ")
	            .append(maPhieu)
	            .append("\n\n");

	    if (kh != null) {

	        sb.append("Khách hàng : ")
	                .append(kh.getHoTen())
	                .append("\n");

	        sb.append("CCCD       : ")
	                .append(kh.getCccd())
	                .append("\n");

	        sb.append("SĐT        : ")
	                .append(kh.getSoDienThoai())
	                .append("\n");
	    }

	    sb.append("\n");

	    sb.append("Ngày nhận  : ")
	            .append(phieuThue.getNgayNhanPhong())
	            .append("\n");

	    sb.append("Ngày trả   : ")
	            .append(phieuThue.getNgayTraPhongDuKien())
	            .append("\n");

	    long soNgay = tinhSoNgay(
	            phieuThue.getNgayNhanPhong(),
	            phieuThue.getNgayTraPhongDuKien());

	    sb.append("Số ngày thuê : ")
	            .append(soNgay)
	            .append(" ngày\n");

	    sb.append("Trạng thái : ")
	            .append(phieuThue.getTrangThai())
	            .append("\n");

	    sb.append("\n============================================\n");
	    sb.append("                TIỀN PHÒNG\n");
	    sb.append("============================================\n");

	    double tienPhong = 0;

	    List<ChiTietThuePhong> dsPhong =
	            ctThueDAO.getByPhieuThue(maPhieu);

	    for (ChiTietThuePhong ct : dsPhong) {

	        Phong p = phongBUS.findById(ct.getMaPhong());

	        String soPhong =
	                p == null ? String.valueOf(ct.getMaPhong())
	                          : p.getSoPhong();

	        double thanhTien = ct.getDonGia() * soNgay;

	        sb.append(String.format(
	                "Phòng %-8s %2d ngày x %12s = %12s\n",
	                soPhong,
	                soNgay,
	                String.format("%,.0f", ct.getDonGia()),
	                String.format("%,.0f", thanhTien)));

	        tienPhong += thanhTien;
	    }

	    sb.append("\n============================================\n");
	    sb.append("                 DỊCH VỤ\n");
	    sb.append("============================================\n");

	    double tienDV = 0;

	    List<SuDungDichVu> dsDV =
	            suDungDAO.getByPhieuThue(maPhieu);

	    if (dsDV.isEmpty()) {

	        sb.append("Không phát sinh dịch vụ.\n");

	    } else {

	        for (SuDungDichVu sd : dsDV) {

	            DichVu dv =
	                    dichVuBUS.findById(sd.getMaDichVu());

	            sb.append(String.format(
	                    "%-20s x%-2d %12s\n",
	                    dv.getTenDichVu(),
	                    sd.getSoLuong(),
	                    String.format("%,.0f",
	                            sd.getThanhTien())));

	            tienDV += sd.getThanhTien();
	        }
	    }

	    sb.append("\n============================================\n");

	    double tongHoaDon = tienPhong + tienDV;
	    double daThanhToan = tienPhong;
	    double conPhaiThanhToan = tienDV;

	    sb.append(String.format(
	            "Tiền phòng          : %15s\n",
	            String.format("%,.0f", tienPhong)));

	    sb.append(String.format(
	            "Tiền dịch vụ        : %15s\n",
	            String.format("%,.0f", tienDV)));

	    sb.append(String.format(
	            "Tổng hóa đơn        : %15s\n",
	            String.format("%,.0f", tongHoaDon)));

	    sb.append(String.format(
	            "Đã thanh toán phòng : %15s\n",
	            String.format("%,.0f", daThanhToan)));

	    sb.append(String.format(
	            "Còn phải thanh toán : %15s\n",
	            String.format("%,.0f", conPhaiThanhToan)));
	    sb.append("\n============================================\n");

	    if (hd != null && hd.getGhiChu() != null
	            && !hd.getGhiChu().trim().isEmpty()) {

	        sb.append("Ghi chú: ")
	                .append(hd.getGhiChu())
	                .append("\n");
	    }

	    JTextArea area = new JTextArea(sb.toString());

	    area.setEditable(false);
	    area.setFont(new Font("Monospaced", Font.PLAIN, 13));
	    area.setBackground(new Color(253,253,245));
	    area.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

	    JScrollPane sp = new JScrollPane(area);
	    sp.setPreferredSize(new Dimension(700,600));

	    JOptionPane.showMessageDialog(
	            this,
	            sp,
	            "Chi tiết hóa đơn",
	            JOptionPane.INFORMATION_MESSAGE);
	}
	private void thanhToan() {

	    int maPhieu = getSelectedMaPhieu();

	    if (maPhieu == -1)
	        return;
	    PhieuThuePhong pt = phieuBUS.getById(maPhieu);

		/*
		 * long soNgayConLai = (pt.getNgayTraPhongDuKien().getTime() -
		 * System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
		 */
	    LocalDate today = LocalDate.now();

	    java.util.Date d = pt.getNgayTraPhongDuKien();

	    Calendar cal = Calendar.getInstance();
	    cal.setTime(d);

	    LocalDate ngayTra = LocalDate.of(
	            cal.get(Calendar.YEAR),
	            cal.get(Calendar.MONTH) + 1,
	            cal.get(Calendar.DAY_OF_MONTH));

	    long soNgayConLai = ChronoUnit.DAYS.between(today, ngayTra);
	    if (soNgayConLai > 0) {

	        int chon = JOptionPane.showConfirmDialog(
	                this,
	                "Khách còn "
	                        + soNgayConLai
	                        + " ngày thuê.\n\n"
	                        + "Bạn có chắc muốn trả phòng sớm?",
	                "Xác nhận",
	                JOptionPane.YES_NO_OPTION);

	        if (chon != JOptionPane.YES_OPTION)
	            return;
	    }
	    HoaDon hd = hoaDonDAO.getByPhieuThue(maPhieu);

	 // Nếu chưa có hóa đơn thì tạo mới
	    if (hd == null) {

	        // Tính tiền phòng đã thanh toán
	        double tienPhong = 0;

	        List<ChiTietThuePhong> dsPhong =
	                ctThueDAO.getByPhieuThue(maPhieu);

	        for (ChiTietThuePhong ct : dsPhong) {
	            tienPhong += ct.getDonGia();
	        }

	        hd = new HoaDon();

	        hd.setMaPhieuThue(maPhieu);
	        hd.setMaNhanVien(1);
	        hd.setNgayLap(new Timestamp(System.currentTimeMillis()));

	        // Tiền phòng đã thu khi nhận phòng
	        hd.setTongTien(tienPhong);

	        // Khách đã thanh toán tiền phòng
	        hd.setTienKhachTra(tienPhong);

	        hd.setTienConLai(0);

	        hd.setHinhThucThanhToan("Tiền mặt");

	        hd.setTrangThaiThanhToan("Chưa thanh toán");

	        hd.setGhiChu("Đã thanh toán tiền phòng khi nhận phòng");

	        int maHD = hoaDonDAO.insertAndGetId(hd);

	        if (maHD <= 0) {

	            JOptionPane.showMessageDialog(this,
	                    "Không thể tạo hóa đơn!");

	            return;
	        }

	        hd = hoaDonDAO.getById(maHD);
	    }

	    // Chỉ tính tiền dịch vụ
	    double tienDV = 0;

	    List<SuDungDichVu> dsDV = suDungDAO.getByPhieuThue(maPhieu);

	    for (SuDungDichVu sd : dsDV) {
	        tienDV += sd.getThanhTien();
	    }

	    if (tienDV <= 0) {

	        if (hd.getMaHoaDon() > 0) {

	            hd.setTrangThaiThanhToan("Đã thanh toán");

	            hoaDonDAO.update(hd);
	        }

 
	        pt.setTrangThai("DA_TRA");

	        phieuBUS.update(pt);

	        for (ChiTietThuePhong ct : ctThueDAO.getByPhieuThue(maPhieu)) {

	            Phong p = phongBUS.findById(ct.getMaPhong());

	            p.setTrangThai("TRONG");

	            phongBUS.update(p);
	        }

	        JOptionPane.showMessageDialog(this,
	                "Khách không phát sinh dịch vụ.\nĐã hoàn tất trả phòng.");

	        loadData();

	        return;
	    }

	    String s = JOptionPane.showInputDialog(
	            this,
	            "Tiền dịch vụ phải thu: "
	                    + String.format("%,.0f", tienDV)
	                    + "\n\nNhập tiền khách đưa:");

	    if (s == null)
	        return;

	    double tienKhachTra;

	    try {
	        tienKhachTra = Double.parseDouble(s);
	    } catch (Exception ex) {

	        JOptionPane.showMessageDialog(this,
	                "Số tiền không hợp lệ!");

	        return;
	    }

	    if (tienKhachTra < tienDV) {

	        JOptionPane.showMessageDialog(this,
	                "Khách chưa thanh toán đủ!");

	        return;
	    }

	    double tienThoi = tienKhachTra - tienDV;

	    int ok = JOptionPane.showConfirmDialog(
	            this,
	            "Tiền dịch vụ : " + String.format("%,.0f", tienDV)
	                    + "\nTiền khách trả : " + String.format("%,.0f", tienKhachTra)
	                    + "\nTiền thối : " + String.format("%,.0f", tienThoi)
	                    + "\n\nXác nhận thanh toán?",
	            "Thanh toán",
	            JOptionPane.YES_NO_OPTION);

	    if (ok != JOptionPane.YES_OPTION)
	        return;

	 // Tổng tiền hóa đơn = tiền phòng + tiền dịch vụ
	    hd.setTongTien(hd.getTongTien() + tienDV);

	    // Tổng tiền khách đã trả = tiền phòng + tiền dịch vụ
	    hd.setTienKhachTra(hd.getTienKhachTra() + tienKhachTra);

	    // Tiền thối
	    hd.setTienConLai(tienThoi);

	    hd.setTrangThaiThanhToan("Đã thanh toán");

	    hd.setGhiChu("Đã thanh toán tiền phòng và dịch vụ");

	    hoaDonDAO.update(hd);

	    PhieuThuePhong pt1 = phieuBUS.getById(maPhieu);

	    pt1.setTrangThai("DA_TRA");

	    phieuBUS.update(pt1);

	    for (ChiTietThuePhong ct : ctThueDAO.getByPhieuThue(maPhieu)) {

	        Phong p = phongBUS.findById(ct.getMaPhong());

	        p.setTrangThai("TRONG");

	        phongBUS.update(p);
	    }

	    JOptionPane.showMessageDialog(this,
	            "Thanh toán thành công!");

	    loadData();
	}
	/*
	 * private void thanhToan() { int maPhieu = getSelectedMaPhieu(); if (maPhieu ==
	 * -1) return;
	 * 
	 * double tienPhong = 0; double tienDV = 0;
	 * 
	 * List<ChiTietThuePhong> dsPhong = ctThueDAO.getByPhieuThue(maPhieu); for
	 * (ChiTietThuePhong ct : dsPhong) { tienPhong += ct.getDonGia(); }
	 * 
	 * List<SuDungDichVu> dsDV = suDungDAO.getByPhieuThue(maPhieu); for
	 * (SuDungDichVu sd : dsDV) { tienDV += sd.getThanhTien(); }
	 * 
	 * PhieuThuePhong ptThue = null; for (PhieuThuePhong pt :
	 * phieuBUS.getDangThueSapHetHan()) { if (pt.getMaPhieuThue() == maPhieu) {
	 * ptThue = pt; break; } }
	 * 
	 * double tienCoc = 0; if (ptThue != null) { for (PhieuDatPhong pd :
	 * phieuDatBUS.getAll()) { if (pd.getMaKhachHang() == ptThue.getMaKhachHang()) {
	 * tienCoc = pd.getTienCoc(); break; } } }
	 * 
	 * double tongTien = tienPhong + tienDV - tienCoc;
	 * 
	 * int confirm = JOptionPane.showConfirmDialog( this,
	 * "Tổng thanh toán (Đã trừ cọc): " + String.format("%,.0f", tongTien) +
	 * " VND\nXác nhận tiến hành thanh toán xuất kho?", "Xác Nhận Thanh Toán",
	 * JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	 * 
	 * if (confirm != JOptionPane.YES_OPTION) return;
	 * 
	 * HoaDon hd = new HoaDon(); hd.setMaPhieuThue(maPhieu); hd.setMaNhanVien(1);
	 * hd.setNgayLap(new Timestamp(System.currentTimeMillis()));
	 * hd.setTongTien(tongTien); hd.setHinhThucThanhToan("Tiền mặt");
	 * hd.setTrangThaiThanhToan("DA_THANH_TOAN"); hd.setGhiChu("Đã trừ tiền cọc: " +
	 * tienCoc);
	 * 
	 * 
	 * if (hoaDonDAO.insert(hd)) { PhieuThuePhong pt = new PhieuThuePhong();
	 * pt.setMaPhieuThue(maPhieu); pt.setTrangThai("DA_TRA"); phieuBUS.update(pt);
	 * 
	 * for (ChiTietThuePhong ct : dsPhong) { Phong p =
	 * phongBUS.findById(ct.getMaPhong()); p.setTrangThai("TRONG");
	 * phongBUS.update(p); }
	 * 
	 * JOptionPane.showMessageDialog(this,
	 * "Thành công! Hệ thống đã ghi nhận hóa đơn và cập nhật lại trạng thái phòng trống."
	 * , "Thông báo", JOptionPane.INFORMATION_MESSAGE); loadData(); }
	 * 
	 * }
	 */

	private void inHoaDon() {

	    int maPhieu = getSelectedMaPhieu();

	    if (maPhieu == -1)
	        return;

	    HoaDon hoaDon = hoaDonDAO.getByPhieuThue(maPhieu);

	    if (hoaDon == null) {

	        JOptionPane.showMessageDialog(this,
	                "Phiếu thuê chưa thanh toán!");

	        return;
	    }

	    PhieuThuePhong pt = phieuBUS.getById(maPhieu);

	    if (pt == null) {

	        JOptionPane.showMessageDialog(this,
	                "Không tìm thấy phiếu thuê!");

	        return;
	    }

	    StringBuilder hd = new StringBuilder();

	    hd.append("=========== BENEFIT HOTEL ===========\n");
	    hd.append("             HÓA ĐƠN\n\n");

	    hd.append("Mã Phiếu Thuê : ").append(maPhieu).append("\n");

	    KhachHang kh = khachHangBUS.findById(pt.getMaKhachHang());

	    hd.append("Khách hàng    : ")
	            .append(kh != null ? kh.getHoTen() : "")
	            .append("\n");

	    hd.append("Ngày nhận     : ")
	            .append(pt.getNgayNhanPhong())
	            .append("\n");

	    hd.append("Ngày trả      : ")
	            .append(pt.getNgayTraPhongDuKien())
	            .append("\n");

	    hd.append("-------------------------------------------\n");

	    double tienPhong = 0;

	    hd.append("TIỀN PHÒNG\n");

	    List<ChiTietThuePhong> dsPhong =
	            ctThueDAO.getByPhieuThue(maPhieu);

	    for (ChiTietThuePhong ct : dsPhong) {

	        Phong p = phongBUS.findById(ct.getMaPhong());

	        String soPhong = p == null ?
	                String.valueOf(ct.getMaPhong())
	                : p.getSoPhong();

	        hd.append(String.format("Phòng %-8s %15s\n",
	                soPhong,
	                String.format("%,.0f", ct.getDonGia())));

	        tienPhong += ct.getDonGia();
	    }

	    double tienDV = 0;

	    List<SuDungDichVu> dsDV =
	            suDungDAO.getByPhieuThue(maPhieu);

	    if (!dsDV.isEmpty()) {

	        hd.append("\nDỊCH VỤ\n");

	        for (SuDungDichVu sd : dsDV) {

	            DichVu dv =
	                    dichVuBUS.findById(sd.getMaDichVu());

	            String ten =
	                    dv == null ? "Dịch vụ"
	                            : dv.getTenDichVu();

	            hd.append(String.format("%-18s x%-2d %12s\n",
	                    ten,
	                    sd.getSoLuong(),
	                    String.format("%,.0f",
	                            sd.getThanhTien())));

	            tienDV += sd.getThanhTien();
	        }
	    }

	    hd.append("-------------------------------------------\n");

	    hd.append(String.format("Tiền phòng    : %15s\n",
	            String.format("%,.0f", tienPhong)));

	    hd.append(String.format("Tiền dịch vụ  : %15s\n",
	            String.format("%,.0f", tienDV)));

	    hd.append("-------------------------------------------\n");

	    hd.append(String.format("TỔNG TIỀN     : %15s\n",
	            String.format("%,.0f",
	                    hoaDon.getTongTien())));

	    hd.append(String.format("Khách trả     : %15s\n",
	            String.format("%,.0f",
	                    hoaDon.getTienKhachTra())));

	    hd.append(String.format("Tiền thối     : %15s\n",
	            String.format("%,.0f",
	                    hoaDon.getTienConLai())));

	    hd.append("-------------------------------------------\n");

	    hd.append("Thanh toán    : ")
	            .append(hoaDon.getTrangThaiThanhToan())
	            .append("\n");

	    hd.append("Hình thức TT  : ")
	            .append(hoaDon.getHinhThucThanhToan())
	            .append("\n");

	    hd.append("\n");

	    hd.append("        Xin cảm ơn Quý khách!\n");

	    JTextArea area = new JTextArea(hd.toString());

	    area.setFont(new Font("Monospaced", Font.PLAIN, 11));

	    area.setEditable(false);

	    try {

	        area.print();

	    } catch (Exception ex) {

	        ex.printStackTrace();

	        JOptionPane.showMessageDialog(this,
	                "Không thể in hóa đơn!");
	    }
	}
}