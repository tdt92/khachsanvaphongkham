package gui;

import bus.CT_PhieuNhapBUS;
import bus.KhoBUS;
import bus.NhanVienBUS;
import bus.PhieuNhapBUS;
import model.CT_PhieuNhap;
import model.Kho;
import model.NhanVien;
import model.PhieuNhap;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class QuanLyCTPhieuNhapPanel extends JPanel {

	private int maPhieuNhapDangXem = -1;
private JComboBox<PhieuNhap> cboPhieuNhap;
private JComboBox<Kho> cboVatDung;

private JTextField txtSoLuong;
private JTextField txtDonGiaNhap;
private JTextField txtThanhTien;
private JTextField txtTim;

private JLabel lblThongTinPhieu;

private JTable table;
private DefaultTableModel model;

private CT_PhieuNhapBUS bus =
        new CT_PhieuNhapBUS();

private PhieuNhapBUS phieuNhapBUS =
        new PhieuNhapBUS();

private KhoBUS khoBUS =
        new KhoBUS();

private NhanVienBUS nhanVienBUS =
        new NhanVienBUS();

private int maCTDangChon = -1;

public QuanLyCTPhieuNhapPanel() {

    setLayout(new BorderLayout());

    JPanel pnTop =
            new JPanel(new GridLayout(6, 2, 5, 5));

    cboPhieuNhap = new JComboBox<>();

    cboVatDung = new JComboBox<>();

    txtSoLuong = new JTextField();

    txtDonGiaNhap = new JTextField();

    txtThanhTien = new JTextField();
    txtThanhTien.setEditable(false);

    lblThongTinPhieu =
            new JLabel("Thông tin phiếu nhập");

    pnTop.add(new JLabel("Phiếu Nhập"));
    pnTop.add(cboPhieuNhap);

    pnTop.add(new JLabel("Thông Tin"));
    pnTop.add(lblThongTinPhieu);

    pnTop.add(new JLabel("Vật Dụng"));
    pnTop.add(cboVatDung);

    pnTop.add(new JLabel("Số Lượng"));
    pnTop.add(txtSoLuong);

    pnTop.add(new JLabel("Đơn Giá Nhập"));
    pnTop.add(txtDonGiaNhap);

    pnTop.add(new JLabel("Thành Tiền"));
    pnTop.add(txtThanhTien);

    add(pnTop, BorderLayout.NORTH);

    loadComboPhieuNhap();
    loadComboVatDung();
    loadThongTinPhieu();

    model = new DefaultTableModel();

    model.setColumnIdentifiers(new Object[]{
            "Mã CT",
            "Mã PN",
            "Tên Vật Dụng",
            "Số Lượng",
            "Đơn Giá",
            "Thành Tiền"
    });

    table = new JTable(model);

    add(new JScrollPane(table),
            BorderLayout.CENTER);

    JPanel pnBottom = new JPanel();

    JButton btnThem =
            new JButton("Thêm");

    JButton btnSua =
            new JButton("Sửa");

    JButton btnXoa =
            new JButton("Xóa");

    JButton btnLamMoi =
            new JButton("Làm mới");

    txtTim = new JTextField(15);

    JButton btnTim =
            new JButton("Tìm");

    pnBottom.add(btnThem);
    pnBottom.add(btnSua);
    pnBottom.add(btnXoa);
    pnBottom.add(btnLamMoi);
    pnBottom.add(txtTim);
    pnBottom.add(btnTim);

    add(pnBottom, BorderLayout.SOUTH);

    loadData();

    cboPhieuNhap.addActionListener(e -> {

        loadThongTinPhieu();

        loadData();
    });

    table.getSelectionModel()
            .addListSelectionListener(e -> {

                int row = table.getSelectedRow();

                if (row >= 0) {

                    maCTDangChon =
                            Integer.parseInt(
                                    model.getValueAt(row, 0).toString());

                    int maPN =
                            Integer.parseInt(
                                    model.getValueAt(row, 1).toString());

                     

                    txtSoLuong.setText(
                            model.getValueAt(row, 3).toString());

                    txtDonGiaNhap.setText(
                            model.getValueAt(row, 4).toString());

                    txtThanhTien.setText(
                            model.getValueAt(row, 5).toString());

                    for (int i = 0; i < cboPhieuNhap.getItemCount(); i++) {

                        if (cboPhieuNhap.getItemAt(i)
                                .getMaPhieuNhap() == maPN) {

                            cboPhieuNhap.setSelectedIndex(i);
                            break;
                        }
                    }
                    String tenVatDung =
                            model.getValueAt(row,2).toString();
                    for (int i = 0; i < cboVatDung.getItemCount(); i++) {

                        Kho k = cboVatDung.getItemAt(i);

                        if (k.getTenVatDung().equals(tenVatDung)) {

                            cboVatDung.setSelectedIndex(i);
                            break;
                        }
                    }

                    loadThongTinPhieu();
                }
            });

    btnThem.addActionListener(e -> them());

    btnSua.addActionListener(e -> sua());

    btnXoa.addActionListener(e -> xoa());

    btnTim.addActionListener(e -> timKiem());

    btnLamMoi.addActionListener(e -> {

        clearForm();

        loadComboPhieuNhap();

        loadComboVatDung();

        loadData();

        loadThongTinPhieu();
    });

    txtSoLuong.addKeyListener(
            new java.awt.event.KeyAdapter() {

                public void keyReleased(
                        java.awt.event.KeyEvent evt) {

                    tinhThanhTien();
                }
            });

    txtDonGiaNhap.addKeyListener(
            new java.awt.event.KeyAdapter() {

                public void keyReleased(
                        java.awt.event.KeyEvent evt) {

                    tinhThanhTien();
                }
            });
}

private void loadThongTinPhieu() {

    PhieuNhap pn =
            (PhieuNhap) cboPhieuNhap.getSelectedItem();

    if (pn == null) {

        lblThongTinPhieu.setText(
                "Không có phiếu");

        return;
    }

    lblThongTinPhieu.setText(
            "Mã PN: " + pn.getMaPhieuNhap()
                    + " | NV: " + pn.getMaNhanVien()
                    + " | Tổng tiền: " + pn.getTongTien());
}

private void tinhThanhTien() {

    try {

        int soLuong =
                Integer.parseInt(
                        txtSoLuong.getText());

        double donGia =
                Double.parseDouble(
                        txtDonGiaNhap.getText());

        txtThanhTien.setText(
                String.valueOf(
                        soLuong * donGia));

    } catch (Exception ex) {

        txtThanhTien.setText("");
    }
}

private void them() {

    try {

        if (cboPhieuNhap.getSelectedItem() == null
                || cboVatDung.getSelectedItem() == null
                || txtSoLuong.getText().trim().isEmpty()
                || txtDonGiaNhap.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Nhập đầy đủ thông tin");

            return;
        }

        PhieuNhap pn =
                (PhieuNhap) cboPhieuNhap.getSelectedItem();

        Kho kho =
                (Kho) cboVatDung.getSelectedItem();

        CT_PhieuNhap ct =
                new CT_PhieuNhap();

        ct.setMaPhieuNhap(
                pn.getMaPhieuNhap());

        ct.setMaVatDung(
                kho.getMaVatDung());

        ct.setSoLuong(
                Integer.parseInt(
                        txtSoLuong.getText()));

        ct.setDonGiaNhap(
                Double.parseDouble(
                        txtDonGiaNhap.getText()));

        if (bus.them(ct)) {

            JOptionPane.showMessageDialog(this,
                    "Thêm thành công");

            clearForm();

            loadData();
        }

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(this,
                "Dữ liệu không hợp lệ");
    }
}

private void sua() {

    try {

        if (maCTDangChon == -1) {

            JOptionPane.showMessageDialog(this,
                    "Chọn dòng cần sửa");

            return;
        }

        PhieuNhap pn =
                (PhieuNhap) cboPhieuNhap.getSelectedItem();

        Kho kho =
                (Kho) cboVatDung.getSelectedItem();

        CT_PhieuNhap ct =
                new CT_PhieuNhap();

        ct.setMaCT(maCTDangChon);

        ct.setMaPhieuNhap(
                pn.getMaPhieuNhap());

        ct.setMaVatDung(
                kho.getMaVatDung());

        ct.setSoLuong(
                Integer.parseInt(
                        txtSoLuong.getText()));

        ct.setDonGiaNhap(
                Double.parseDouble(
                        txtDonGiaNhap.getText()));

        if (bus.sua(ct)) {

            JOptionPane.showMessageDialog(this,
                    "Cập nhật thành công");

            clearForm();

            loadData();
        }

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(this,
                "Lỗi cập nhật");
    }
}

private void xoa() {

    if (maCTDangChon == -1) {

        JOptionPane.showMessageDialog(this,
                "Chọn dòng cần xóa");

        return;
    }

    if (bus.xoa(maCTDangChon)) {

        JOptionPane.showMessageDialog(this,
                "Xóa thành công");

        clearForm();

        loadData();
    }
}

private void timKiem() {

    model.setRowCount(0);

    for (CT_PhieuNhap ct :
            bus.timKiem(txtTim.getText())) {

    	Kho kho = khoBUS.timTheoMa(ct.getMaVatDung());

    	String tenVatDung = "";

    	if(kho != null){
    	    tenVatDung = kho.getTenVatDung();
    	}

    	model.addRow(new Object[]{
    	        ct.getMaCT(),
    	        ct.getMaPhieuNhap(),
    	        tenVatDung,
    	        ct.getSoLuong(),
    	        ct.getDonGiaNhap(),
    	        ct.getThanhTien()
    	});
    }
}

private void loadComboVatDung() {

    cboVatDung.removeAllItems();

    for (Kho k : khoBUS.getAll()) {

        cboVatDung.addItem(k);
    }
}

private void loadComboPhieuNhap() {

    cboPhieuNhap.removeAllItems();

    if (util.Session.taiKhoanDangNhap == null)
        return;

    NhanVien nv = nhanVienBUS.findByMaTaiKhoan(
            util.Session.taiKhoanDangNhap.getMaTaiKhoan());

    if (nv == null)
        return;

    for (PhieuNhap pn :
            phieuNhapBUS.getPhieuNhapHomNayTheoNhanVien(
                    nv.getMaNhanVien())) {

        cboPhieuNhap.addItem(pn);
    }

    // Chọn lại phiếu đang xem
    if (maPhieuNhapDangXem != -1) {

        for (int i = 0; i < cboPhieuNhap.getItemCount(); i++) {

            if (cboPhieuNhap.getItemAt(i).getMaPhieuNhap()
                    == maPhieuNhapDangXem) {

                cboPhieuNhap.setSelectedIndex(i);
                break;
            }
        }
    }
}

private void clearForm() {

    maCTDangChon = -1;

    txtSoLuong.setText("");

    txtDonGiaNhap.setText("");

    txtThanhTien.setText("");

    if (cboPhieuNhap.getItemCount() > 0) {

        cboPhieuNhap.setSelectedIndex(0);

        loadThongTinPhieu();
    }

    if (cboVatDung.getItemCount() > 0) {

        cboVatDung.setSelectedIndex(0);
    }
}

private void loadData() {

    model.setRowCount(0);

    PhieuNhap pn =
            (PhieuNhap) cboPhieuNhap.getSelectedItem();

    if (pn == null) {
        return;
    }

    for (CT_PhieuNhap ct :
            bus.getByPhieuNhap(
                    pn.getMaPhieuNhap())) {

    	Kho kho = khoBUS.timTheoMa(ct.getMaVatDung());

    	String tenVatDung = "";

    	if(kho != null){
    	    tenVatDung = kho.getTenVatDung();
    	}

    	model.addRow(new Object[]{
    	        ct.getMaCT(),
    	        ct.getMaPhieuNhap(),
    	        tenVatDung,
    	        ct.getSoLuong(),
    	        ct.getDonGiaNhap(),
    	        ct.getThanhTien()
    	});
    }
}
public void hienThiTheoPhieuNhap(int maPhieuNhap) {

    maPhieuNhapDangXem = maPhieuNhap;

    // Nạp lại danh sách phiếu nhập
    loadComboPhieuNhap();

    // Chọn đúng phiếu nhập
    for (int i = 0; i < cboPhieuNhap.getItemCount(); i++) {

        PhieuNhap pn = cboPhieuNhap.getItemAt(i);

        if (pn.getMaPhieuNhap() == maPhieuNhap) {

            cboPhieuNhap.setSelectedIndex(i);
            break;
        }
    }

    // Hiển thị thông tin phiếu
    loadThongTinPhieu();

    // Hiển thị chi tiết
    model.setRowCount(0);

    for (CT_PhieuNhap ct : bus.getByPhieuNhap(maPhieuNhap)) {

    	Kho kho = khoBUS.timTheoMa(ct.getMaVatDung());

    	String tenVatDung = "";

    	if(kho != null){
    	    tenVatDung = kho.getTenVatDung();
    	}

    	model.addRow(new Object[]{
    	        ct.getMaCT(),
    	        ct.getMaPhieuNhap(),
    	        tenVatDung,
    	        ct.getSoLuong(),
    	        ct.getDonGiaNhap(),
    	        ct.getThanhTien()
    	});
    }
}

}
