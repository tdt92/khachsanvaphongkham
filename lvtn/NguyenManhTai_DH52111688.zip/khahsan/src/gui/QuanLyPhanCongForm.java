package gui;

import bus.NhanVienBUS;
import bus.PhanCongBUS;
import bus.PhongBUS;
import model.NhanVien;
import model.PhanCong;
import model.Phong;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.Date;
import java.sql.Time;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuanLyPhanCongForm extends JInternalFrame {

    JComboBox<NhanVien> cboNhanVien;
 
    JTextField txtVaiTro;
    JTextField txtBatDau;
    JTextField txtKetThuc;
    JTextField txtGhiChu;
    JTextField txtTimKiem;

    JDateChooser dateNgay;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnTim;
    JButton btnLamMoi;

    JButton btnThemNgay;
    JButton btnXoaNgayChon;
    DefaultListModel<LocalDate> dsNgayModel = new DefaultListModel<>();
    JList<LocalDate> lstNgayDaChon = new JList<>(dsNgayModel);
    private static final DateTimeFormatter DINH_DANG_NGAY = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    JTable table;
    DefaultTableModel model;

    PhanCongBUS bus = new PhanCongBUS();
    NhanVienBUS nhanVienBUS = new NhanVienBUS();
    PhongBUS phongBUS = new PhongBUS();

    int selectedMaPC = -1;

    // Bảng màu Flat Modern UI nâng cấp chuyên nghiệp
    private static final Color MAU_CHINH = new Color(14, 116, 144);    
    private static final Color MAU_XANH_LA = new Color(16, 185, 129);  
    private static final Color MAU_CAM = new Color(245, 158, 11);      
    private static final Color MAU_DO = new Color(225, 29, 72);        
    private static final Color NEN_XAM = new Color(241, 245, 249);     // Slate 100 sáng sủa hơn
    private static final Color CHU_DAM = new Color(15, 23, 42);        
    private static final Color VIEN_NHE = new Color(226, 232, 240);    
    private static final Color TEXT_MUTED = new Color(100, 116, 139);

    public QuanLyPhanCongForm() {
        super("QUẢN LÝ PHÂN CÔNG", true, true, true, true);

        setSize(1350, 780);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(20, 20));

        getContentPane().setBackground(NEN_XAM);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(20, 25, 20, 25));

        // =====================================================================
        // 1. KHU VỰC TRÊN: NHẬP LIỆU & TÌM KIẾM
        // =====================================================================
        JPanel pTopMaster = new JPanel(new BorderLayout(20, 15));
        pTopMaster.setBackground(NEN_XAM);

        // Khối nhập thông tin bên trái (Sử dụng Panel bo góc tùy biến)
        JPanel pInputMaster = new RoundedPanel(12, Color.WHITE);
        pInputMaster.setLayout(new BorderLayout(0, 15));
        pInputMaster.setBorder(new EmptyBorder(10, 18, 10, 18));
        
        JPanel pInput = new JPanel(new GridLayout(2, 3, 18, 8));
        pInput.setBackground(Color.WHITE);

        cboNhanVien = new JComboBox<>();
         txtVaiTro = new JTextField();
        txtBatDau = new JTextField("07:00:00");
        txtKetThuc = new JTextField("15:00:00");
        txtGhiChu = new JTextField();
        dateNgay = new JDateChooser();

        dateNgay.setDateFormatString("yyyy-MM-dd");
        dateNgay.setMinSelectableDate(java.sql.Date.valueOf(LocalDate.now()));
        styleDateChooser(dateNgay);

        styleComboBox(cboNhanVien);
         styleTextField(txtVaiTro);
        styleTextField(txtBatDau);
        styleTextField(txtKetThuc);
        styleTextField(txtGhiChu);
        txtVaiTro.setEditable(false);

        loadNhanVien();
 
        cboNhanVien.addActionListener(e -> {
            NhanVien nv = (NhanVien) cboNhanVien.getSelectedItem();
            if (nv != null) {
                txtVaiTro.setText(nv.getChucVu());
            }
        });

        pInput.add(taoFormGroup("Nhân viên", cboNhanVien));
         pInput.add(taoFormGroup("Vai trò", txtVaiTro));
        pInput.add(taoFormGroup("Ngày phân công (Bấm '+ Thêm ngày')", dateNgay));
        pInput.add(taoFormGroup("Giờ bắt đầu", txtBatDau));
        pInput.add(taoFormGroup("Giờ kết thúc", txtKetThuc));
        pInput.add(taoFormGroup("Ghi chú", txtGhiChu));

        pInputMaster.add(pInput, BorderLayout.CENTER);

        // Khu vực danh sách nhiều ngày được bọc trong sub-panel đẹp hơn
        JPanel pDanhSachNgay = new RoundedPanel(8, new Color(248, 250, 252));
        pDanhSachNgay.setLayout(new BorderLayout(15, 10));
        pDanhSachNgay.setBorder(new EmptyBorder(12, 15, 12, 15));

        JLabel lblDsNgay = new JLabel("Các ngày đã chọn để phân công đồng thời:");
        lblDsNgay.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblDsNgay.setForeground(TEXT_MUTED);

        lstNgayDaChon.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        lstNgayDaChon.setVisibleRowCount(0);
        lstNgayDaChon.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lstNgayDaChon.setBackground(new Color(248, 250, 252));
        lstNgayDaChon.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                           boolean isSelected, boolean cellHasFocus) {
                JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof LocalDate) {
                    lbl.setText(((LocalDate) value).format(DINH_DANG_NGAY));
                }
                lbl.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(218, 226, 237), 1, true),
                        new EmptyBorder(5, 12, 5, 12)
                ));
                lbl.setOpaque(true);
                if (isSelected) {
                    lbl.setBackground(new Color(14, 116, 144));
                    lbl.setForeground(Color.WHITE);
                } else {
                    lbl.setBackground(Color.WHITE);
                    lbl.setForeground(CHU_DAM);
                }
                return lbl;
            }
        });

        JScrollPane scrollNgay = new JScrollPane(lstNgayDaChon);
        scrollNgay.setPreferredSize(new Dimension(100, 38));
        
        scrollNgay.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollNgay.getViewport().setBackground(new Color(248, 250, 252));

        btnThemNgay = new JButton("+ Thêm ngày");
        btnXoaNgayChon = new JButton("Xóa ngày đã chọn");
        styleButton(btnThemNgay, MAU_CHINH);
        styleButton(btnXoaNgayChon, new Color(100, 116, 139));

        JPanel pNutNgay = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pNutNgay.setOpaque(false);
        pNutNgay.add(btnThemNgay);
        pNutNgay.add(btnXoaNgayChon);

        pDanhSachNgay.add(lblDsNgay, BorderLayout.NORTH);
        pDanhSachNgay.add(scrollNgay, BorderLayout.CENTER);
        pDanhSachNgay.add(pNutNgay, BorderLayout.EAST);

        pInputMaster.add(pDanhSachNgay, BorderLayout.SOUTH);

        // Khối tìm kiếm bên phải
        JPanel pSearch = new RoundedPanel(12, Color.WHITE);
        pSearch.setLayout(new GridBagLayout());
        pSearch.setBorder(new EmptyBorder(25, 20, 25, 20));
        pSearch.setPreferredSize(new Dimension(300, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtTimKiem = new JTextField();
        styleTextField(txtTimKiem);

        btnTim = new JButton("TÌM KIẾM");
        btnLamMoi = new JButton("LÀM MỚI");
        styleButton(btnTim, new Color(51, 65, 85)); 
        styleButton(btnLamMoi, Color.WHITE);
        btnLamMoi.setForeground(CHU_DAM);
        btnLamMoi.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));

        JLabel lblTimKiem = new JLabel("Tìm kiếm theo vai trò:");
        lblTimKiem.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTimKiem.setForeground(TEXT_MUTED);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        pSearch.add(lblTimKiem, gbc);

        gbc.gridy = 1; gbc.weightx = 1.0;
        pSearch.add(txtTimKiem, gbc);

        gbc.gridy = 2; gbc.gridwidth = 1; gbc.weightx = 0.5;
        pSearch.add(btnTim, gbc);

        gbc.gridx = 1;
        pSearch.add(btnLamMoi, gbc);

        pTopMaster.add(pInputMaster, BorderLayout.CENTER);
        pTopMaster.add(pSearch, BorderLayout.EAST);
        pTopMaster.add(pInputMaster, BorderLayout.CENTER);
        pTopMaster.add(pSearch, BorderLayout.EAST);

        //====================== PANEL TABLE ======================

        JPanel pCenter = new JPanel(new BorderLayout());
        pCenter.setBackground(NEN_XAM);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã PC",
                "Mã NV",
                "Tên nhân viên",
                "Vai trò",
                "Ngày",
                "Bắt đầu",
                "Kết thúc",
                "Ghi chú"
        });

        table = new JTable(model);
        styleTable(table);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scroll.getViewport().setBackground(Color.WHITE);

        pCenter.add(scroll, BorderLayout.CENTER);

        //====================== SPLIT PANE ======================

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                pTopMaster,
                pCenter);

        splitPane.setResizeWeight(0.28);
        splitPane.setDividerLocation(250);
        splitPane.setDividerSize(10);         // Thanh kéo dày 10px
        splitPane.setContinuousLayout(true);
        splitPane.setOneTouchExpandable(true);
        splitPane.setBorder(null);

        add(splitPane, BorderLayout.CENTER);

        // =====================================================================
        // 3. KHU VỰC DƯỚI: NÚT THAO TÁC CHÍNH
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        pBottom.setBackground(NEN_XAM);

        btnThem = new JButton("THÊM MỚI HÀNG LOẠT");
        btnSua = new JButton("SỬA THÔNG TIN");
        btnXoa = new JButton("XÓA PHÂN CÔNG");

        styleButton(btnThem, MAU_XANH_LA);
        styleButton(btnSua, MAU_CAM);
        styleButton(btnXoa, MAU_DO);

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        add(pBottom, BorderLayout.SOUTH);

        loadData();

        // =====================================================================
        // LOGIC EVENTS HANDLERS
        // =====================================================================
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedMaPC = Integer.parseInt(model.getValueAt(row, 0).toString());
                txtVaiTro.setText(model.getValueAt(row, 3).toString());

                Object ngay = model.getValueAt(row, 4);
                if (ngay instanceof java.sql.Date) {
                    dateNgay.setDate((java.sql.Date) ngay);
                } else {
                    dateNgay.setDate(java.sql.Date.valueOf(ngay.toString()));
                }

                txtBatDau.setText(model.getValueAt(row, 5).toString());
                txtKetThuc.setText(model.getValueAt(row, 6).toString());
                txtGhiChu.setText(model.getValueAt(row, 7).toString());

                dsNgayModel.clear();

                String maNV = model.getValueAt(row, 1).toString();
                for (int i = 0; i < cboNhanVien.getItemCount(); i++) {
                    if (String.valueOf(cboNhanVien.getItemAt(i).getMaNhanVien()).equals(maNV)) {
                        cboNhanVien.setSelectedIndex(i);
                        break;
                    }
                }

                
            }
        });

        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnTim.addActionListener(e -> timKiem());
        btnLamMoi.addActionListener(e -> {
            loadData();
            clearForm();
        });

        btnThemNgay.addActionListener(e -> themNgayVaoDanhSach());
        btnXoaNgayChon.addActionListener(e -> xoaNgayKhoiDanhSach());
    }

    // =====================================================================
    // UI MODERNIZATION UTILITIES
    // =====================================================================
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.getInsets().set(6, 10, 6, 10);
        field.setForeground(CHU_DAM);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
    }

    private void styleComboBox(JComboBox<?> combo) {
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        combo.setForeground(CHU_DAM);
        combo.setBackground(Color.WHITE);
        combo.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
    }

    private void styleDateChooser(JDateChooser chooser) {
        chooser.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        chooser.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));

        com.toedter.calendar.JTextFieldDateEditor editor =
            (com.toedter.calendar.JTextFieldDateEditor) chooser.getDateEditor();
        editor.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        editor.setBackground(Color.WHITE);
        editor.setForeground(CHU_DAM);
    }

    private void styleButton(JButton btn, Color background) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(background == Color.WHITE ? CHU_DAM : Color.WHITE);
        btn.setBackground(background);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(background == Color.WHITE ? VIEN_NHE : background, 1, true),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Tạo hiệu ứng Hover mượt mà
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if(background != Color.WHITE) {
                    btn.setBackground(background.brighter());
                } else {
                    btn.setBackground(new Color(248, 250, 252));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(background);
            }
        });
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(36);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(234, 242, 253));
        table.setSelectionForeground(CHU_DAM);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(248, 250, 252));
        header.setForeground(new Color(71, 85, 105));
        header.setPreferredSize(new Dimension(100, 40));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, VIEN_NHE));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 5, 0, 5));
                return this;
            }
        };
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                return this;
            }
        };
        leftRenderer.setHorizontalAlignment(JLabel.LEFT);

        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i == 0 || i == 1 || i == 3 || i == 5 || i == 6 || i == 7) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            } else {
                table.getColumnModel().getColumn(i).setCellRenderer(leftRenderer);
            }
        }
        table.getColumnModel().getColumn(0).setPreferredWidth(65);
    }

    private JPanel taoFormGroup(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(TEXT_MUTED);

        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    // Custom Panel Helper phục vụ bo góc giao diện Flat Modern
    private static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private final Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }

    // =====================================================================
    // LOGIC BUSINESS METHODS (Giữ nguyên toàn bộ logic cũ)
    // =====================================================================
    private void loadNhanVien() {
        cboNhanVien.removeAllItems();
        for (NhanVien nv : nhanVienBUS.getAll()) {
            cboNhanVien.addItem(nv);
        }
    }

   

    private String getTenNhanVien(int maNV) {
        for (NhanVien nv : nhanVienBUS.getAll()) {
            if (nv.getMaNhanVien() == maNV) {
                return nv.getHoTen();
            }
        }
        return "";
    }

    private void loadData() {
        model.setRowCount(0);
        for (PhanCong pc : bus.getAll()) {
            model.addRow(new Object[]{
                    pc.getMaPhanCong(),
                    pc.getMaNhanVien(),
                    getTenNhanVien(pc.getMaNhanVien()),
                     pc.getTenVaiTro(),
                    pc.getNgayPhanCong(),
                    pc.getGioBatDau(),
                    pc.getGioKetThuc(),
                    pc.getGhiChu()
            });
        }
    }

    private void themNgayVaoDanhSach() {
        if (dateNgay.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn 1 ngày trước khi bấm Thêm ngày");
            return;
        }

        LocalDate ld = new java.sql.Date(dateNgay.getDate().getTime()).toLocalDate();

        if (ld.isBefore(LocalDate.now())) {
            JOptionPane.showMessageDialog(this, "Không được chọn ngày quá khứ");
            return;
        }

        if (dsNgayModel.contains(ld)) {
            JOptionPane.showMessageDialog(this, "Ngày này đã có trong danh sách");
            return;
        }

        List<LocalDate> ds = new ArrayList<>();
        for (int i = 0; i < dsNgayModel.size(); i++) {
            ds.add(dsNgayModel.get(i));
        }
        ds.add(ld);
        Collections.sort(ds);

        dsNgayModel.clear();
        for (LocalDate d : ds) {
            dsNgayModel.addElement(d);
        }
    }

    private void xoaNgayKhoiDanhSach() {
        List<LocalDate> selected = lstNgayDaChon.getSelectedValuesList();
        if (selected.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chọn ngày trong danh sách cần xóa");
            return;
        }
        for (LocalDate ld : selected) {
            dsNgayModel.removeElement(ld);
        }
    }

    private boolean validateInput() {
        if (txtVaiTro.getText().trim().isEmpty()
                || txtBatDau.getText().trim().isEmpty()
                || txtKetThuc.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this, "Phải nhập đầy đủ dữ liệu");
            return false;
        }

        try {
            LocalTime bd = LocalTime.parse(txtBatDau.getText());
            LocalTime kt = LocalTime.parse(txtKetThuc.getText());

            long hours = Duration.between(bd, kt).toHours();

            if (hours <= 0) {
                JOptionPane.showMessageDialog(this, "Giờ kết thúc phải lớn hơn giờ bắt đầu");
                return false;
            }

            if (hours > 10) {
                JOptionPane.showMessageDialog(this, "Thời gian làm không quá 10 giờ");
                return false;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sai định dạng giờ hh:mm:ss");
            return false;
        }

        return true;
    }

    private void them() {
        try {
            if (!validateInput()) return;

            if (dsNgayModel.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Vui lòng chọn ngày rồi bấm \"+ Thêm ngày\" để đưa vào danh sách trước khi Thêm mới");
                return;
            }

            NhanVien nv = (NhanVien) cboNhanVien.getSelectedItem();
 
            if (nv == null  ) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên ");
                return;
            }

            int tongSo = dsNgayModel.size();
            int thanhCong = 0;

            for (int i = 0; i < tongSo; i++) {
                LocalDate ld = dsNgayModel.get(i);
                if(bus.isTrungLich(
                        nv.getMaNhanVien(),
                        Date.valueOf(ld),
                        Time.valueOf(txtBatDau.getText()),
                        Time.valueOf(txtKetThuc.getText()),
                        0)){

                    JOptionPane.showMessageDialog(
                            this,
                            "Nhân viên đã có lịch ngày "
                            + ld);

                    continue;
                }
                if(bus.isTrungVaiTro(
                        nv.getMaNhanVien(),
                        txtVaiTro.getText(),
                        Date.valueOf(ld),
                        Time.valueOf(txtBatDau.getText()),
                        Time.valueOf(txtKetThuc.getText()),
                        0)){

                    int chon = JOptionPane.showConfirmDialog(
                            this,
                            "Đã có nhân viên khác cùng vai trò được phân công trong khoảng thời gian này.\n"
                            + "Bạn vẫn muốn tiếp tục?",
                            "Xác nhận",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);

                    if(chon != JOptionPane.YES_OPTION){
                        continue;
                    }
                }
                PhanCong pc = new PhanCong();
                pc.setMaNhanVien(nv.getMaNhanVien());
                 pc.setTenVaiTro(txtVaiTro.getText());
                pc.setNgayPhanCong(Date.valueOf(ld));
                pc.setGioBatDau(Time.valueOf(txtBatDau.getText()));
                pc.setGioKetThuc(Time.valueOf(txtKetThuc.getText()));
                pc.setGhiChu(txtGhiChu.getText());

                if (bus.insert(pc)) {
                    thanhCong++;
                }
            }

            JOptionPane.showMessageDialog(this, "Đã thêm thành công " + thanhCong + "/" + tongSo + " phân công");
            loadData();
            clearForm();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void sua() {
        try {
            if (selectedMaPC == -1) {
                JOptionPane.showMessageDialog(this, "Chọn dữ liệu cần sửa");
                return;
            }

            if (!validateInput()) return;

            if (dateNgay.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Phải chọn ngày phân công");
                return;
            }

            LocalDate selectedDate = new java.sql.Date(dateNgay.getDate().getTime()).toLocalDate();
            if (selectedDate.isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "Không được chọn ngày quá khứ");
                return;
            }

            NhanVien nv = (NhanVien) cboNhanVien.getSelectedItem();
 
            PhanCong pc = new PhanCong();
            pc.setMaPhanCong(selectedMaPC);
            pc.setMaNhanVien(nv.getMaNhanVien());
             pc.setTenVaiTro(txtVaiTro.getText());
            pc.setNgayPhanCong(new Date(dateNgay.getDate().getTime()));
            pc.setGioBatDau(Time.valueOf(txtBatDau.getText()));
            pc.setGioKetThuc(Time.valueOf(txtKetThuc.getText()));
            pc.setGhiChu(txtGhiChu.getText());
            if(bus.isTrungLich(
                    nv.getMaNhanVien(),
                    pc.getNgayPhanCong(),
                    pc.getGioBatDau(),
                    pc.getGioKetThuc(),
                    selectedMaPC)){

                JOptionPane.showMessageDialog(
                        this,
                        "Nhân viên đã có lịch trong khoảng thời gian này.");

                return;
            }
            if(bus.isTrungVaiTro(
                    nv.getMaNhanVien(),
                    txtVaiTro.getText(),
                    pc.getNgayPhanCong(),
                    pc.getGioBatDau(),
                    pc.getGioKetThuc(),
                    selectedMaPC)){

                int chon = JOptionPane.showConfirmDialog(
                        this,
                        "Đã có nhân viên khác cùng vai trò trong khoảng thời gian này.\n"
                        + "Bạn vẫn muốn cập nhật?",
                        "Xác nhận",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if(chon != JOptionPane.YES_OPTION){
                    return;
                }
            }
            if (bus.update(pc)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoa() {
        if (selectedMaPC == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dữ liệu cần xóa");
            return;
        }

        if (bus.delete(selectedMaPC)) {
            JOptionPane.showMessageDialog(this, "Xóa thành công");
            loadData();
            clearForm();
        }
    }

    private void timKiem() {
        model.setRowCount(0);
        for (PhanCong pc : bus.search(txtTimKiem.getText())) {
        	model.addRow(new Object[]{
        		    pc.getMaPhanCong(),
        		    pc.getMaNhanVien(),
        		    getTenNhanVien(pc.getMaNhanVien()),
        		    pc.getTenVaiTro(),
        		    pc.getNgayPhanCong(),
        		    pc.getGioBatDau(),
        		    pc.getGioKetThuc(),
        		    pc.getGhiChu()
        		});
        }
    }

    private void clearForm() {
        txtVaiTro.setText("");
        txtBatDau.setText("07:00:00");
        txtKetThuc.setText("15:00:00");
        txtGhiChu.setText("");
        txtTimKiem.setText("");
        dateNgay.setDate(null);
        dsNgayModel.clear(); 
        selectedMaPC = -1;
        table.clearSelection();
    }
}