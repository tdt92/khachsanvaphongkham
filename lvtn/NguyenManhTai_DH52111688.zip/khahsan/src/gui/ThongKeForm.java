package gui;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import bus.ThongKeBUS1;
import gui.chart.BarChartPanel;
import gui.chart.LineChartPanel;
import model.ThongKeDiemDTO;
import model.ThongKePhongDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.Date;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ThongKeForm extends JInternalFrame {

    private final ThongKeBUS1 bus = new ThongKeBUS1();

    private static final Color MAU_CHINH = new Color(14, 116, 144);  // Tông xanh Teal hiện đại
    private static final Color MAU_HEADER = new Color(15, 23, 42);   // Deep Navy sâu sắc
    private static final Color NEN_NHE = new Color(248, 250, 252);   // Slate Light nền
    private final NumberFormat nf = NumberFormat.getInstance(new Locale("vi", "VN"));

    public ThongKeForm() {
        super("THỐNG KÊ", true, true, true, true);
        setSize(1150, 700);
        setLayout(new BorderLayout());
        getContentPane().setBackground(NEN_NHE);

        add(taoHeader(), BorderLayout.NORTH);

        JTabbedPane tab = new JTabbedPane();
        tab.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tab.setBackground(Color.WHITE);
        
        tab.addTab("Doanh thu theo thời gian", taoTabDoanhThuTheoThoiGian());
        tab.addTab("Cơ cấu doanh thu", taoTabCoCauDoanhThu());
		/*
		 * tab.addTab("Tổng quan & RevPAR", taoTabTongQuan());
		 */        tab.addTab("Tình trạng phòng", taoTabTinhTrangPhong());
        tab.addTab("Công suất theo ngày", taoTabCongSuat());

        add(tab, BorderLayout.CENTER);

     // Thanh nút báo cáo
     JPanel panelBaoCao = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
     panelBaoCao.setBackground(Color.WHITE);
     panelBaoCao.setBorder(BorderFactory.createMatteBorder(
             1, 0, 0, 0,
             new Color(226, 232, 240)
     ));

     JButton btnXemBaoCao = new JButton("XEM BÁO CÁO");
     JButton btnInBaoCao = new JButton("IN BÁO CÁO");

     styleButton(btnXemBaoCao);
     styleButton(btnInBaoCao);

     panelBaoCao.add(btnXemBaoCao);
     panelBaoCao.add(btnInBaoCao);

     add(panelBaoCao, BorderLayout.SOUTH);

     // Xem báo cáo
     btnXemBaoCao.addActionListener(e -> xemBaoCao(tab));

     // In báo cáo
     btnInBaoCao.addActionListener(e -> inBaoCao(tab));
     }

    private JPanel taoHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(MAU_HEADER);
        headerPanel.setBorder(new EmptyBorder(18, 40, 18, 40));

        JLabel lblTitle = new JLabel("BÁO CÁO THỐNG KÊ KINH DOANH");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Doanh thu • Quản lý phòng • Hiệu suất vận hành");
        lblSub.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSub.setForeground(new Color(148, 163, 184));

        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(lblSub, BorderLayout.EAST);
        return headerPanel;
    }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(MAU_CHINH);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 15, 6, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(130, 32));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(new Color(51, 65, 85));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));
        
        // Căn trái lề dữ liệu ô để nhìn gọn hơn
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 10, 0, 10));
        table.setDefaultRenderer(Object.class, renderer);
    }

    private JSpinner taoSpinnerNgay(java.util.Date giaTriMacDinh) {
        SpinnerDateModel model = new SpinnerDateModel();
        JSpinner spinner = new JSpinner(model);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy"));
        spinner.setValue(giaTriMacDinh);
        spinner.setPreferredSize(new Dimension(120, 28));
        return spinner;
    }

    private Date toSqlDate(JSpinner spinner) {
        java.util.Date d = (java.util.Date) spinner.getValue();
        return new Date(d.getTime());
    }

    private java.util.Date dauThang() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        return c.getTime();
    }

    private JLabel taoNhanTieuDe(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(new Color(71, 85, 105));
        return l;
    }

    private DefaultTableModel taoTableModel(String... cols) {
        return new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
    }

    private JPanel taoTabDoanhThuTheoThoiGian() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(NEN_NHE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        JComboBox<String> cboKieu = new JComboBox<>(new String[]{
                "Theo ngày", "Theo tuần", "Theo tháng", "Theo năm"});
        cboKieu.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JSpinner spTu = taoSpinnerNgay(dauThang());
        JSpinner spDen = taoSpinnerNgay(new java.util.Date());
        JSpinner spNam = new JSpinner(new SpinnerNumberModel(
                Calendar.getInstance().get(Calendar.YEAR), 2000, 2100, 1));
        spNam.setPreferredSize(new Dimension(80, 28));
        spNam.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JButton btnXem = new JButton("Xem báo cáo");
        styleButton(btnXem);

        top.add(taoNhanTieuDe("Loại thống kê:"));
        top.add(cboKieu);
        top.add(taoNhanTieuDe("Từ ngày:"));
        top.add(spTu);
        top.add(taoNhanTieuDe("Đến ngày:"));
        top.add(spDen);
        top.add(taoNhanTieuDe("Năm:"));
        top.add(spNam);
        top.add(btnXem);

        BarChartPanel chart = new BarChartPanel("Tình hình tăng trưởng doanh thu", new ArrayList<>(), new ArrayList<>());
        chart.setFormatAsCurrency(true);
        chart.setBarColor(MAU_CHINH);

        String[] cols = {"Mốc thời gian", "Doanh thu (VNĐ)", "Số hoá đơn"};
        DefaultTableModel model = taoTableModel(cols);
        JTable table = new JTable(model);
        styleTable(table);
        JScrollPane scrollTable = new JScrollPane(table);
        scrollTable.setPreferredSize(new Dimension(1150, 180));
        scrollTable.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        cboKieu.addActionListener(e -> {
            boolean theoThang = "Theo tháng".equals(cboKieu.getSelectedItem());
            boolean theoNam = "Theo năm".equals(cboKieu.getSelectedItem());
            spTu.setEnabled(!theoThang && !theoNam);
            spDen.setEnabled(!theoThang && !theoNam);
            spNam.setEnabled(theoThang);
        });

        btnXem.addActionListener(e -> {
            List<ThongKeDiemDTO> ds;
            String kieu = (String) cboKieu.getSelectedItem();

            if ("Theo ngày".equals(kieu)) {
                ds = bus.doanhThuTheoNgay(toSqlDate(spTu), toSqlDate(spDen));
            } else if ("Theo tuần".equals(kieu)) {
                ds = bus.doanhThuTheoTuan(toSqlDate(spTu), toSqlDate(spDen));
            } else if ("Theo tháng".equals(kieu)) {
                ds = bus.doanhThuTheoThang((Integer) spNam.getValue());
            } else {
                ds = bus.doanhThuTheoNam();
            }

            List<String> labels = new ArrayList<>();
            List<Double> values = new ArrayList<>();
            model.setRowCount(0);

            for (ThongKeDiemDTO dto : ds) {
                labels.add(dto.getNhan());
                values.add(dto.getGiaTri());
                model.addRow(new Object[]{dto.getNhan(), nf.format(dto.getGiaTri()), dto.getSoLuong()});
            }

            chart.setData("Doanh thu (" + kieu + ")", labels, values);
        });

        panel.add(top, BorderLayout.NORTH);
        panel.add(chart, BorderLayout.CENTER);
        panel.add(scrollTable, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel taoTabCoCauDoanhThu() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(NEN_NHE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        JComboBox<String> cboKieu = new JComboBox<>(new String[]{
				"Theo loại phòng", "Theo dịch vụ" /* "Theo hình thức thanh toán" */});
        cboKieu.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JSpinner spTu = taoSpinnerNgay(dauThang());
        JSpinner spDen = taoSpinnerNgay(new java.util.Date());

        JButton btnXem = new JButton("Xem báo cáo");
        styleButton(btnXem);

        top.add(taoNhanTieuDe("Thống kê:"));
        top.add(cboKieu);
        top.add(taoNhanTieuDe("Từ ngày:"));
        top.add(spTu);
        top.add(taoNhanTieuDe("Đến ngày:"));
        top.add(spDen);
        top.add(btnXem);

        BarChartPanel chart = new BarChartPanel("Phân tích tỷ trọng cơ cấu nguồn thu", new ArrayList<>(), new ArrayList<>());
        chart.setBarColor(new Color(13, 148, 136)); // Teal đậm đặc trưng phân tích

        String[] cols = {"Phân loại", "Doanh thu (VNĐ)", "Số lượng"};
        DefaultTableModel model = taoTableModel(cols);
        JTable table = new JTable(model);
        styleTable(table);
        JScrollPane scrollTable = new JScrollPane(table);
        scrollTable.setPreferredSize(new Dimension(1150, 180));
        scrollTable.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        btnXem.addActionListener(e -> {
            List<ThongKeDiemDTO> ds;
            String kieu = (String) cboKieu.getSelectedItem();

            if ("Theo loại phòng".equals(kieu)) {
                ds = bus.doanhThuTheoLoaiPhong(toSqlDate(spTu), toSqlDate(spDen));
            } else if ("Theo dịch vụ".equals(kieu)) {
                ds = bus.doanhThuTheoDichVu(toSqlDate(spTu), toSqlDate(spDen));
            } else {
                ds = bus.thongKeHinhThucThanhToan(toSqlDate(spTu), toSqlDate(spDen));
            }

            List<String> labels = new ArrayList<>();
            List<Double> values = new ArrayList<>();
            model.setRowCount(0);

            for (ThongKeDiemDTO dto : ds) {
                labels.add(dto.getNhan());
                values.add(dto.getGiaTri());
                model.addRow(new Object[]{dto.getNhan(), nf.format(dto.getGiaTri()), dto.getSoLuong()});
            }

            chart.setData(kieu, labels, values);
        });

        panel.add(top, BorderLayout.NORTH);
        panel.add(chart, BorderLayout.CENTER);
        panel.add(scrollTable, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel taoTabTongQuan() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(NEN_NHE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        JSpinner spTu = taoSpinnerNgay(dauThang());
        JSpinner spDen = taoSpinnerNgay(new java.util.Date());
        JButton btnTinh = new JButton("Tính chỉ số");
        styleButton(btnTinh);

        top.add(taoNhanTieuDe("Từ ngày:"));
        top.add(spTu);
        top.add(taoNhanTieuDe("Đến ngày:"));
        top.add(spDen);
        top.add(btnTinh);

        JPanel grid = new JPanel(new GridLayout(2, 3, 25, 25));
        grid.setBackground(NEN_NHE);
        grid.setBorder(new EmptyBorder(30, 40, 30, 40));

        JLabel lblTongDoanhThu = taoThe(grid, "TỔNG DOANH THU", "0 đ");
        JLabel lblTongHD = taoThe(grid, "TỔNG SỐ HOÁ ĐƠN", "0");
        JLabel lblTB = taoThe(grid, "GIÁ TRỊ TRUNG BÌNH / HOÁ ĐƠN", "0 đ");
        JLabel lblRevPAR = taoThe(grid, "RevPAR (Doanh thu trên phòng trống)", "0 đ");
        JLabel lblADR = taoThe(grid, "ADR (Giá phòng trung bình ngày)", "0 đ");
        JLabel lblOccupancy = taoThe(grid, "CÔNG SUẤT PHÒNG (Occupancy Rate)", "0%");

        btnTinh.addActionListener(e -> {
            Date tu = toSqlDate(spTu);
            Date den = toSqlDate(spDen);

            double tongDoanhThu = bus.tongDoanhThu(tu, den);
            int tongHD = bus.tongSoHoaDon(tu, den);
            double giaTB = bus.giaTriHoaDonTrungBinh(tu, den);
            double[] revpar = bus.tinhRevPAR(tu, den);

            lblTongDoanhThu.setText(nf.format(tongDoanhThu) + " đ");
            lblTongHD.setText(String.valueOf(tongHD));
            lblTB.setText(nf.format(giaTB) + " đ");
            lblRevPAR.setText(nf.format(revpar[0]) + " đ");
            lblADR.setText(nf.format(revpar[1]) + " đ");
            lblOccupancy.setText(String.format("%.1f%%", revpar[2] * 100));
        });

        panel.add(top, BorderLayout.NORTH);
        panel.add(grid, BorderLayout.CENTER);

        return panel;
    }

    private JLabel taoThe(JPanel parent, String tieuDe, String giaTriMacDinh) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240), 1, true),
                new EmptyBorder(20, 24, 20, 24)));

        JLabel lblTieuDe = new JLabel(tieuDe);
        lblTieuDe.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTieuDe.setForeground(new Color(100, 116, 139));

        JLabel lblGiaTri = new JLabel(giaTriMacDinh);
        lblGiaTri.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblGiaTri.setForeground(new Color(30, 41, 59));

        card.add(lblTieuDe);
        card.add(Box.createVerticalStrut(10));
        card.add(lblGiaTri);

        parent.add(card);
        return lblGiaTri;
    }

    private JPanel taoTabTinhTrangPhong() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(NEN_NHE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        JSpinner spSoNgay = new JSpinner(new SpinnerNumberModel(3, 1, 60, 1));
        spSoNgay.setPreferredSize(new Dimension(60, 28));
        spSoNgay.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JButton btnXem = new JButton("Xem tình trạng");
        styleButton(btnXem);

        top.add(taoNhanTieuDe("Số ngày cảnh báo sắp check-in/out:"));
        top.add(spSoNgay);
        top.add(btnXem);

        JPanel infoPanel = new JPanel(new GridLayout(1, 3, 25, 0));
        infoPanel.setBackground(NEN_NHE);
        infoPanel.setBorder(new EmptyBorder(20, 40, 10, 40));

        JLabel lblTongPhong = taoThe(infoPanel, "TỔNG SỐ PHÒNG", "0");
        JLabel lblSapCheckIn = taoThe(infoPanel, "SẮP CHECK-IN", "0");
        JLabel lblSapCheckOut = taoThe(infoPanel, "SẮP CHECK-OUT", "0");

        String[] cols = {"Trạng thái hoạt động", "Số lượng phòng hiện tại"};
        DefaultTableModel model = taoTableModel(cols);
        JTable table = new JTable(model);
        styleTable(table);
        JScrollPane scrollTable = new JScrollPane(table);
        scrollTable.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(10, 40, 20, 40),
                BorderFactory.createLineBorder(new Color(226, 232, 240), 1, true)
        ));
        scrollTable.setBackground(NEN_NHE);
        scrollTable.getViewport().setBackground(Color.WHITE);

        btnXem.addActionListener(e -> {
            ThongKePhongDTO dto = bus.thongKePhong((Integer) spSoNgay.getValue());

            lblTongPhong.setText(String.valueOf(dto.getTongSoPhong()));
            lblSapCheckIn.setText(String.valueOf(dto.getSoPhongSapCheckIn()));
            lblSapCheckOut.setText(String.valueOf(dto.getSoPhongSapCheckOut()));

            model.setRowCount(0);
            for (Map.Entry<String, Integer> entry : dto.getTheoTrangThai().entrySet()) {
                model.addRow(new Object[]{entry.getKey(), entry.getValue()});
            }
        });

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(NEN_NHE);
        center.add(infoPanel, BorderLayout.NORTH);
        center.add(scrollTable, BorderLayout.CENTER);

        panel.add(top, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);

        return panel;
    }

    private JPanel taoTabCongSuat() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(NEN_NHE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        Calendar cal = Calendar.getInstance();
        JSpinner spNam = new JSpinner(new SpinnerNumberModel(cal.get(Calendar.YEAR), 2000, 2100, 1));
        JSpinner spThang = new JSpinner(new SpinnerNumberModel(cal.get(Calendar.MONTH) + 1, 1, 12, 1));
        spNam.setPreferredSize(new Dimension(80, 28));
        spThang.setPreferredSize(new Dimension(60, 28));
        spNam.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        spThang.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JButton btnXem = new JButton("Xem công suất");
        styleButton(btnXem);

        top.add(taoNhanTieuDe("Năm:"));
        top.add(spNam);
        top.add(taoNhanTieuDe("Tháng:"));
        top.add(spThang);
        top.add(btnXem);

        LineChartPanel chart = new LineChartPanel("Theo dõi tần suất công suất phòng",
                new ArrayList<>(), new ArrayList<>(), true);
        chart.setLineColor(MAU_CHINH);

        panel.add(top, BorderLayout.NORTH);
        panel.add(chart, BorderLayout.CENTER);

        btnXem.addActionListener(e -> {
            int nam = (Integer) spNam.getValue();
            int thang = (Integer) spThang.getValue();

            List<ThongKeDiemDTO> ds = bus.congSuatTheoNgayTrongThang(nam, thang);

            List<String> labels = new ArrayList<>();
            List<Double> values = new ArrayList<>();
            for (ThongKeDiemDTO dto : ds) {
                labels.add(dto.getNhan());
                values.add(dto.getGiaTri());
            }

            chart.setData("Công suất phòng - Tháng " + thang + "/" + nam, labels, values);
        });

        return panel;
    }
    /**
     * Chụp toàn bộ nội dung tab hiện tại thành ảnh
     */
    private BufferedImage taoAnhBaoCao(JTabbedPane tab) {

        Component component = tab.getSelectedComponent();

        if (component == null) {
            return null;
        }

        // Kích thước hiện tại của component
        int width = component.getWidth();
        int height = component.getHeight();

        if (width <= 0 || height <= 0) {
            return null;
        }

        BufferedImage image = new BufferedImage(
                width,
                height,
                BufferedImage.TYPE_INT_RGB
        );

        Graphics2D g2 = image.createGraphics();

        // Nền trắng
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, width, height);

        // Render component vào ảnh
        component.printAll(g2);

        g2.dispose();

        return image;
    }
    /**
     * Hiển thị ảnh báo cáo trong cửa sổ xem trước
     */
    private void xemBaoCao(JTabbedPane tab) {

        BufferedImage image = taoAnhBaoCao(tab);

        if (image == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Không thể tạo ảnh báo cáo!",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        JLabel lblImage = new JLabel(new ImageIcon(image));

        JScrollPane scrollPane = new JScrollPane(lblImage);
        scrollPane.setPreferredSize(new Dimension(1100, 650));

        String tenBaoCao = tab.getTitleAt(tab.getSelectedIndex());

        JDialog dialog = new JDialog(
                SwingUtilities.getWindowAncestor(this),
                "XEM BÁO CÁO - " + tenBaoCao,
                Dialog.ModalityType.APPLICATION_MODAL
        );

        dialog.setLayout(new BorderLayout());
        dialog.add(scrollPane, BorderLayout.CENTER);

        JButton btnDong = new JButton("ĐÓNG");
        styleButton(btnDong);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setBackground(Color.WHITE);
        bottom.add(btnDong);

        dialog.add(bottom, BorderLayout.SOUTH);

        btnDong.addActionListener(e -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    /**
     * In báo cáo hiện tại
     */
    private void inBaoCao(JTabbedPane tab) {

        BufferedImage image = taoAnhBaoCao(tab);

        if (image == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Không thể tạo báo cáo để in!",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        PrinterJob printerJob = PrinterJob.getPrinterJob();

        String tenBaoCao = tab.getTitleAt(tab.getSelectedIndex());

        printerJob.setJobName("Báo cáo thống kê - " + tenBaoCao);

        printerJob.setPrintable((graphics, pageFormat, pageIndex) -> {

            if (pageIndex > 0) {
                return Printable.NO_SUCH_PAGE;
            }

            Graphics2D g2 = (Graphics2D) graphics;

            double pageWidth = pageFormat.getImageableWidth();
            double pageHeight = pageFormat.getImageableHeight();

            double imageWidth = image.getWidth();
            double imageHeight = image.getHeight();

            // Tính tỷ lệ để ảnh vừa trang giấy
            double scaleX = pageWidth / imageWidth;
            double scaleY = pageHeight / imageHeight;

            double scale = Math.min(scaleX, scaleY);

            double newWidth = imageWidth * scale;
            double newHeight = imageHeight * scale;

            // Căn giữa ảnh trên trang
            double x = pageFormat.getImageableX()
                    + (pageWidth - newWidth) / 2;

            double y = pageFormat.getImageableY()
                    + (pageHeight - newHeight) / 2;

            g2.drawImage(
                    image,
                    (int) x,
                    (int) y,
                    (int) newWidth,
                    (int) newHeight,
                    null
            );

            return Printable.PAGE_EXISTS;
        });

        try {

            // Hiện hộp thoại chọn máy in
            if (printerJob.printDialog()) {
                printerJob.print();

                JOptionPane.showMessageDialog(
                        this,
                        "In báo cáo thành công!",
                        "Thông báo",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (PrinterException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi khi in báo cáo:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}