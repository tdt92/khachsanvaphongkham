package gui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private JDesktopPane desktopPane;

    public MainFrame() {

        setTitle("HỆ THỐNG QUẢN LÝ KHÁCH SẠN");
        setSize(1400, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        desktopPane = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(240,242,245));
                g.fillRect(0,0,getWidth(),getHeight());
            }
        };

        add(desktopPane);

        // Hiển thị JFrame trước
        setVisible(true);

        QuanLyForm qlForm = new QuanLyForm(desktopPane);

        desktopPane.add(qlForm);
        qlForm.setVisible(true);

        // Căn giữa sau khi DesktopPane đã có kích thước
        SwingUtilities.invokeLater(() -> {

            Dimension desktopSize = desktopPane.getSize();
            Dimension frameSize = qlForm.getSize();

            int x = (desktopSize.width - frameSize.width) / 2;
            int y = (desktopSize.height - frameSize.height) / 2;

            if (x < 0) x = 0;
            if (y < 0) y = 0;

            qlForm.setLocation(x, y);

            try {
                qlForm.setSelected(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }

    

    public JDesktopPane getDesktopPane() {
        return desktopPane;
    }
}