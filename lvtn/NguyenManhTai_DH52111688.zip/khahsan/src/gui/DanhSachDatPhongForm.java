package gui;

import bus.PhieuDatPhongBUS;
import model.DatPhongDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.awt.Color;
public class DanhSachDatPhongForm extends JInternalFrame {

    private JTable tbl;
    private DefaultTableModel model;
    private JButton btnChiTiet;
    private JButton btnThuePhong;
    private JTextField txtTim;
    private JButton btnTim;
    private JButton btnLamMoi;
    private PhieuDatPhongBUS bus = new PhieuDatPhongBUS();
    private JButton btnHuyDat;
    public DanhSachDatPhongForm() {
        super("DANH SÁCH PHIẾU ĐẶT", true, true, true, true);
        initUI();
        loadData();
    }

    private void initUI() {
        setSize(1000, 600);
        setLayout(new BorderLayout(0, 15)); // Tạo khoảng cách 15px giữa các vùng chính
        
        // Thêm khoảng đệm bao quanh toàn bộ Form (Top, Left, Bottom, Right)
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));
        getContentPane().setBackground(Color.WHITE);

        // 1. THANH TÌM KIẾM (TOP PANEL)
        JPanel top = new JPanel();
        top.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 5));
        top.setBackground(Color.WHITE);

        JLabel lblTim = new JLabel("Tên KH / CCCD:");
        lblTim.setFont(new Font("Segoe UI", Font.BOLD, 13));

        txtTim = new JTextField(25);
        txtTim.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtTim.setPreferredSize(new Dimension(250, 30)); // Tăng chiều cao ô nhập liệu

        btnTim = new JButton("Tìm Kiếm");
        btnTim.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnTim.setPreferredSize(new Dimension(100, 30));

        btnLamMoi = new JButton("Làm Mới");
        btnLamMoi.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnLamMoi.setPreferredSize(new Dimension(100, 30));

        top.add(lblTim);
        top.add(txtTim);
        top.add(btnTim);
        top.add(btnLamMoi);
        add(top, BorderLayout.NORTH);

        // 2. BẢNG HIỂN THỊ DỮ LIỆU (CENTER PANEL)
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho phép sửa trực tiếp trên bảng
            }
        };

        model.setColumnIdentifiers(new String[]{
        	    "Mã Phiếu",
        	    "Khách Hàng",
        	    "CCCD",
        	    "Nhân viên đặt",
        	    "Ngày Nhận",
        	    "Ngày Trả",
        	    "SL Phòng",
        	    "Tiền Cọc"
        	});

        tbl = new JTable(model);
        tbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tbl.setRowHeight(30); // Tăng chiều cao dòng giúp bảng thoáng, dễ nhìn
        tbl.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tbl.getTableHeader().setReorderingAllowed(false); // Không cho kéo đổi vị trí cột
        tbl.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Chỉ cho chọn 1 dòng
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {

            @Override
            public Component getTableCellRendererComponent(
                    JTable table,
                    Object value,
                    boolean isSelected,
                    boolean hasFocus,
                    int row,
                    int column) {

                super.getTableCellRendererComponent(
                        table,
                        value,
                        isSelected,
                        hasFocus,
                        row,
                        column);

                // ===== Căn lề =====
                if (column == 6) {
                    setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    setHorizontalAlignment(SwingConstants.CENTER);
                }

                if (column == 1 || column == 2) {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }

                // ===== Tô màu =====
                if (!isSelected) {

                    try {

                        LocalDate homNay = LocalDate.now();

                        LocalDate ngayNhan =
                                LocalDate.parse(table.getValueAt(row, 3).toString());

                        if (ngayNhan.isEqual(homNay)) {

                            setBackground(new Color(198,239,206));
                            setForeground(Color.BLACK);

                        } else if (ngayNhan.isBefore(homNay)) {

                            setBackground(new Color(255,199,206));
                            setForeground(Color.BLACK);

                        } else {

                            setBackground(Color.WHITE);
                            setForeground(Color.BLACK);

                        }

                    } catch (Exception ex) {

                        setBackground(Color.WHITE);
                        setForeground(Color.BLACK);

                    }

                }

                return this;
            }

        };

        for (int i = 0; i < tbl.getColumnCount(); i++) {
            tbl.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        JScrollPane scrollPane = new JScrollPane(tbl);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        add(scrollPane, BorderLayout.CENTER);

        // 3. THANH HÀNH ĐỘNG (BOTTOM PANEL)
        JPanel bottom = new JPanel();
        bottom.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        bottom.setBackground(Color.WHITE);

        btnChiTiet = new JButton("Xem Chi Tiết");
        btnChiTiet.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnChiTiet.setPreferredSize(new Dimension(130, 35));

        btnThuePhong = new JButton("Thuê Phòng");
        btnHuyDat = new JButton("Hủy Đặt");
        btnHuyDat.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnHuyDat.setPreferredSize(new Dimension(130, 35));
        btnThuePhong.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnThuePhong.setPreferredSize(new Dimension(130, 35));
        // Bạn có thể đổi màu nút nổi bật (Ví dụ màu xanh) nếu thích:
        // btnThuePhong.setBackground(new Color(0, 123, 255));
        // btnThuePhong.setForeground(Color.WHITE);

        bottom.add(btnChiTiet);
        bottom.add(btnThuePhong);
        bottom.add(btnHuyDat);
        add(bottom, BorderLayout.SOUTH);

        // 4. ĐĂNG KÝ SỰ KIỆN (LISTENERS)
        btnChiTiet.addActionListener(e -> moChiTiet());
        btnHuyDat.addActionListener(e -> huyDatPhong());
        btnLamMoi.addActionListener(e -> {
            txtTim.setText("");
            loadData();
        });
        
        btnThuePhong.addActionListener(e -> {
            int row = tbl.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một phiếu đặt từ danh sách!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int maPD = Integer.parseInt(model.getValueAt(row, 0).toString());
            NhanPhongTuDatForm f = new NhanPhongTuDatForm(maPD, getDesktopPane());
            getDesktopPane().add(f);
            f.setVisible(true);
        });

        btnTim.addActionListener(e -> timKiem());
    }

    private void loadData() {

        model.setRowCount(0);

        java.util.List<DatPhongDTO> list =
                bus.getDanhSachDatPhong();

        list.sort((a, b) -> {

            LocalDate d1 = a.getNgayNhan().toLocalDate();
            LocalDate d2 = b.getNgayNhan().toLocalDate();

            return d1.compareTo(d2);

        });

        for (DatPhongDTO dto : list) {

        	model.addRow(new Object[]{
        	        dto.getMaPhieuDat(),
        	        dto.getTenKhachHang(),
        	        dto.getCccd(),
        	        dto.getTenNhanVien(),
        	        dto.getNgayNhan(),
        	        dto.getNgayTra(),
        	        dto.getSoPhong(),
        	        String.format("%,.0f", dto.getTienCoc())
        	});

        }

    }

    private void moChiTiet() {
        int row = tbl.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một phiếu đặt từ danh sách!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maPhieuDat = Integer.parseInt(model.getValueAt(row, 0).toString());
        ChiTietPhieuDatForm f = new ChiTietPhieuDatForm(maPhieuDat);
        getDesktopPane().add(f);
        f.setVisible(true);
    }
    private void huyDatPhong() {

        int row = tbl.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng chọn một phiếu đặt!",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE);

            return;
        }

        int maPhieuDat =
                Integer.parseInt(
                        model.getValueAt(row, 0).toString());

        String tenKhach =
                model.getValueAt(row, 1).toString();

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc chắn muốn hủy phiếu đặt của khách hàng:\n\n"
                                + tenKhach + " ?",
                        "Xác nhận hủy đặt",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        boolean kq = bus.delete(maPhieuDat);

        if (kq) {

            JOptionPane.showMessageDialog(
                    this,
                    "Đã hủy phiếu đặt thành công!");

            loadData();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Hủy phiếu đặt thất bại!");
        }
    }
    private void timKiem() {

        String key = txtTim.getText().trim().toLowerCase();

        model.setRowCount(0);

        java.util.List<DatPhongDTO> list =
                bus.getDanhSachDatPhong();

        list.sort((a, b) ->
                a.getNgayNhan().toLocalDate()
                        .compareTo(b.getNgayNhan().toLocalDate()));

        for (DatPhongDTO dto : list) {

            boolean ok =
                    String.valueOf(dto.getMaPhieuDat()).contains(key)
                    || dto.getTenKhachHang().toLowerCase().contains(key)
                    || dto.getCccd().toLowerCase().contains(key);

            if (ok) {

            	model.addRow(new Object[]{
            	        dto.getMaPhieuDat(),
            	        dto.getTenKhachHang(),
            	        dto.getCccd(),
            	        dto.getTenNhanVien(),
            	        dto.getNgayNhan(),
            	        dto.getNgayTra(),
            	        dto.getSoPhong(),
            	        String.format("%,.0f", dto.getTienCoc())
            	});

            }

        }

    }
}