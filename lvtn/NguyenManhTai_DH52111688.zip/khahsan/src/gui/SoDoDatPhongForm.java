package gui;

import bus.LichPhongBUS;
import bus.PhongBUS;
import model.CellLichPhong;
import model.LichPhongDTO;
import model.Phong;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Vector;

public class SoDoDatPhongForm extends JInternalFrame {

    private JTable table;
    private DefaultTableModel model;
    private PhongBUS phongBUS = new PhongBUS();
    private LichPhongBUS lichBUS = new LichPhongBUS();
    private List<Phong> dsPhong;
    private LocalDate ngayBatDau;
    private int soNgay = 30;
    private JButton btnDatThue;
    private JButton btnLamMoi;    // Bảng màu Flat UI cho Ma trận lịch
    private static final Color MAU_TIEU_DE_BANG = new Color(30, 41, 59);  // Slate 800 đẳng cấp
    private static final Color MAU_TEXT_TIEU_DE = Color.black;
    private static final Color MAU_DUONG_LUOI = new Color(226, 232, 240); // Lưới xám rất mảnh
    private static final Color MAU_NEN_FORM = new Color(248, 250, 252);   // Slate 50

    public SoDoDatPhongForm() {
        // Khởi tạo các thuộc tính cơ bản của JInternalFrame
        super("SƠ ĐỒ ĐẶT PHÒNG", true, true, true, true);
        setSize(1200, 700);
        setLayout(new BorderLayout(0, 15));
        getContentPane().setBackground(MAU_NEN_FORM);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(20, 20, 20, 20));

     // ===============================
     // TIÊU ĐỀ + NÚT ĐẶT/THUÊ
     // ===============================
     JPanel pnlTop = new JPanel(new BorderLayout());
     pnlTop.setBackground(MAU_NEN_FORM);

     JLabel lblHeader = new JLabel("LỊCH TRÌNH ĐẶT PHÒNG (30 NGÀY TỚI)");
     lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
     lblHeader.setForeground(MAU_TIEU_DE_BANG);

     JPanel pnlButton = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,0));
     pnlButton.setOpaque(false);

     btnLamMoi = new JButton("LÀM MỚI");
     btnLamMoi.setFont(new Font("Segoe UI", Font.BOLD, 14));
     btnLamMoi.setBackground(new Color(52, 152, 219));
     btnLamMoi.setForeground(Color.WHITE);
     btnLamMoi.setFocusPainted(false);
     btnLamMoi.setCursor(new Cursor(Cursor.HAND_CURSOR));
     btnLamMoi.setPreferredSize(new Dimension(120,40));

     btnDatThue = new JButton("ĐẶT / THUÊ");
     btnDatThue.setFont(new Font("Segoe UI", Font.BOLD, 14));
     btnDatThue.setBackground(new Color(46, 204, 113));
     btnDatThue.setForeground(Color.WHITE);
     btnDatThue.setFocusPainted(false);
     btnDatThue.setCursor(new Cursor(Cursor.HAND_CURSOR));
     btnDatThue.setPreferredSize(new Dimension(150,40));

     btnLamMoi.addActionListener(e -> lamMoi());

     btnDatThue.addActionListener(e -> moQuanLyKhachHang());

     pnlButton.add(btnLamMoi);
     pnlButton.add(btnDatThue);

     pnlTop.add(lblHeader, BorderLayout.WEST);
     pnlTop.add(pnlButton, BorderLayout.EAST);

     add(pnlTop, BorderLayout.NORTH);

        // --- CẤU HÌNH TABLE MODERN MA TRẬN ---
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(48); // Tăng nhẹ độ cao hàng để hiển thị text tên khách thoáng hơn
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setGridColor(MAU_DUONG_LUOI);
        table.setShowGrid(true);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Custom giao diện thanh tiêu đề bảng phẳng (TableHeader)
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(MAU_TIEU_DE_BANG);
        table.getTableHeader().setForeground(MAU_TEXT_TIEU_DE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40)); // Độ cao tiêu đề chuẩn UI hiện đại
        
        // Hủy bỏ viền nổi mặc định 3D của Table Header hệ thống
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, MAU_DUONG_LUOI));

        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        // Giữ nguyên Renderer xử lý hiển thị màu trạng thái phòng của bạn
        table.setDefaultRenderer(Object.class, new LichPhongRenderer());

        // Đóng gói bảng vào ScrollPane phẳng mịn
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(MAU_DUONG_LUOI, 1, true));
        scroll.getViewport().setBackground(Color.WHITE);
        add(scroll, BorderLayout.CENTER);

        // --- TẢI DỮ LIỆU ĐỒNG BỘ LOGIC ---
        loadCotPhong();
        loadNgay();
        loadBooking();
    }

    /**
     * Tìm vị trí cột phòng dựa vào tên phòng (Giữ nguyên logic gốc)
     */
    private int timCotPhong(String soPhong) {
        for (int i = 1; i < table.getColumnCount(); i++) {
            if (table.getColumnName(i).equals(soPhong)) {
                return i;
            }
        }
        return -1;
    }
    private void lamMoi() {

        model.setRowCount(0);

        loadCotPhong();

        loadNgay();

        loadBooking();

    }
    
    private int timDong(LocalDate ngay) {
        return (int) java.time.temporal.ChronoUnit.DAYS.between(ngayBatDau, ngay);
    }

    
    private void loadBooking() {
        List<LichPhongDTO> list = lichBUS.getAll();

        for (LichPhongDTO dto : list) {
            int cot = timCotPhong(dto.getSoPhong());
            if (cot == -1) continue;

            LocalDate bd = dto.getNgayNhan().toLocalDate();
            LocalDate kt = dto.getNgayTra().toLocalDate();

            for (LocalDate d = bd; !d.isAfter(kt); d = d.plusDays(1)) {
                int dong = timDong(d);

                if (dong < 0) continue;
                if (dong >= model.getRowCount()) continue;

                CellLichPhong cell = new CellLichPhong(
                        dto.getTenKhach(),
                        dto.getTrangThai()
                );

                model.setValueAt(cell, dong, cot);
            }
        }
    }

    /**
     * Tạo danh sách cột phòng nằm ngang (Giữ nguyên logic gốc)
     */
    private void loadCotPhong() {
        dsPhong = phongBUS.getAll();
        Vector<String> cols = new Vector<>();
        cols.add("Ngày");

        for (Phong p : dsPhong) {
            cols.add(p.getSoPhong());
        }

        model.setColumnIdentifiers(cols);

        // Đặt độ rộng cố định phẳng cho cột Ngày
        table.getColumnModel().getColumn(0).setPreferredWidth(110);

        // Đặt độ rộng đều đặn cho các cột Phòng phía sau
        for (int i = 1; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(125);
        }
    }

    /**
     * Sinh tự động 30 ngày tương lai đổ vào cột đầu tiên (Giữ nguyên logic gốc)
     */
    private void moQuanLyKhachHang() {

        QuanLyKhachHangForm2 form = new QuanLyKhachHangForm2();

        Container parent = getDesktopPane();

        if (parent instanceof JDesktopPane) {

            JDesktopPane desktop = (JDesktopPane) parent;

            desktop.add(form);

            form.setVisible(true);

            try {
                form.setSelected(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else {

            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy DesktopPane.");

        }
    }
    private void loadNgay() {
        ngayBatDau = LocalDate.now();
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM");

        model.setRowCount(0);

        for (int i = 0; i < soNgay; i++) {
            Vector<Object> row = new Vector<>();
            row.add(ngayBatDau.plusDays(i).format(f));

            for (int j = 0; j < dsPhong.size(); j++) {
                row.add(""); // Khởi tạo ô trống
            }

            model.addRow(row);
        }
    }
}