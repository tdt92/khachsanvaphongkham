package gui;

import bus.*;
import model.*;

 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

public class DatPhongForm extends JInternalFrame {

    private JTable tblKhachHang;
    private JTable tblDatPhong;
    private JTextField txtTimDatPhong;
    private JButton btnTimDatPhong;
    private JTextField txtTimKH;
    private JTextField txtTienCoc;
    private JTextField txtTongTien;

    private JDateChooser dcNgayNhan;
    private JDateChooser dcNgayTra;

    private JComboBox<LoaiPhong> cboLoaiPhong;
    private JComboBox<Phong> cboPhong;

    private JButton btnThemKH;
    private JButton btnTimKH;
    private JButton btnLamMoi;
    private JButton btnDatPhong;
    private JButton btnHuyDatPhong;

    private KhachHangBUS khBUS = new KhachHangBUS();
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private ChiTietDatPhongBUS ctBUS = new ChiTietDatPhongBUS();

    private DefaultTableModel modelKH;
    private DefaultTableModel modelPD;

    public DatPhongForm() {

        super(
                "QUẢN LÝ ĐẶT PHÒNG",
                true,
                true,
                true,
                true);

        setSize(1200,700);

        setDefaultCloseOperation(
                JInternalFrame.DISPOSE_ON_CLOSE);

        initComponent();

        loadLoaiPhong();
        loadKhachHang();
        loadDatPhong();

        setVisible(true);
    }

    private void initComponent() {
    	 
        setLayout(new BorderLayout());

        

         // KHÁCH HÀNG
         JPanel pnlKH =
                new JPanel(new BorderLayout());

        JPanel pnlTim =
                new JPanel();

        txtTimKH = new JTextField(15);

        btnTimKH = new JButton("Tìm");
        btnLamMoi = new JButton("Làm mới");
        btnThemKH = new JButton("Thêm KH");

        pnlTim.add(txtTimKH);
        pnlTim.add(btnTimKH);
        pnlTim.add(btnLamMoi);

        pnlKH.add(pnlTim, BorderLayout.NORTH);

        modelKH = new DefaultTableModel();

        modelKH.setColumnIdentifiers(
                new String[]{
                        "Mã KH",
                        "Họ tên",
                        "SĐT"
                });

        tblKhachHang =
                new JTable(modelKH);

        pnlKH.add(
                new JScrollPane(tblKhachHang),
                BorderLayout.CENTER);

        pnlKH.add(
                btnThemKH,
                BorderLayout.SOUTH);

 
         // ĐẶT PHÒNG
         JPanel pnlDat =
                new JPanel(new GridLayout(8, 2, 5, 5));

        cboLoaiPhong = new JComboBox<>();
        cboPhong = new JComboBox<>();

        txtTienCoc = new JTextField();

        txtTongTien = new JTextField();
        txtTongTien.setEditable(false);

        dcNgayNhan = new JDateChooser();
        dcNgayTra = new JDateChooser();
        dcNgayNhan.setMinSelectableDate(
                new java.util.Date());

        dcNgayTra.setMinSelectableDate(
                new java.util.Date());
        dcNgayNhan.setDateFormatString("yyyy-MM-dd");
        dcNgayTra.setDateFormatString("yyyy-MM-dd");

        dcNgayNhan.getDateEditor().addPropertyChangeListener(
                evt -> {

                    if ("date".equals(evt.getPropertyName())) {

                        loadPhongTheoLoai();
                        tinhTongTien();
                    }
                });

        dcNgayTra.getDateEditor().addPropertyChangeListener(
                evt -> {

                    if ("date".equals(evt.getPropertyName())) {

                        loadPhongTheoLoai();
                        tinhTongTien();
                    }
                });

        cboPhong.addActionListener(
                e -> tinhTongTien());

        btnDatPhong =
                new JButton("ĐẶT PHÒNG");

        pnlDat.add(new JLabel("Loại phòng"));
        pnlDat.add(cboLoaiPhong);

        pnlDat.add(new JLabel("Phòng"));
        pnlDat.add(cboPhong);

        pnlDat.add(new JLabel("Ngày nhận"));
        pnlDat.add(dcNgayNhan);

        pnlDat.add(new JLabel("Ngày trả"));
        pnlDat.add(dcNgayTra);

        pnlDat.add(new JLabel("Tổng tiền"));
        pnlDat.add(txtTongTien);

        pnlDat.add(new JLabel("Thanh toán "));
        pnlDat.add(txtTienCoc);

        pnlDat.add(new JLabel(""));
        pnlDat.add(btnDatPhong);

 
 
         // BẢNG PHIẾU ĐẶT
         
     // ================= BẢNG PHIẾU ĐẶT =================

        JPanel pnlBottom = new JPanel(new BorderLayout());

        JPanel pnlTimDatPhong = new JPanel();

        txtTimDatPhong = new JTextField(20);
        btnTimDatPhong = new JButton("Tìm đặt phòng");

        pnlTimDatPhong.add(new JLabel("Tên KH / SDT:"));
        pnlTimDatPhong.add(txtTimDatPhong);
        pnlTimDatPhong.add(btnTimDatPhong);

        pnlBottom.add(pnlTimDatPhong, BorderLayout.NORTH);

        modelPD = new DefaultTableModel();

        modelPD.setColumnIdentifiers(
                new String[]{
                        "Mã Phiếu",
                        "Tên KH",
                        "Loại Phòng",
                        "Số Phòng",
                        "Ngày nhận",
                        "Ngày trả",
                        "Tiền cọc",
                        "Trạng thái"
                });

        tblDatPhong = new JTable(modelPD);

        pnlBottom.add(
                new JScrollPane(tblDatPhong),
                BorderLayout.CENTER);

        JPanel pnlButton = new JPanel();

        btnHuyDatPhong = new JButton("HỦY ĐẶT PHÒNG");

        pnlButton.add(btnHuyDatPhong);

        pnlBottom.add(
                pnlButton,
                BorderLayout.SOUTH);

        // ================= JSplitPane =================

        JSplitPane splitTop =
                new JSplitPane(
                        JSplitPane.HORIZONTAL_SPLIT,
                        pnlKH,
                        pnlDat);

        splitTop.setDividerLocation(550);
        splitTop.setResizeWeight(0.5);
        splitTop.setOneTouchExpandable(true);

        JSplitPane splitMain =
                new JSplitPane(
                        JSplitPane.VERTICAL_SPLIT,
                        splitTop,
                        pnlBottom);

        splitMain.setDividerLocation(280);
        splitMain.setResizeWeight(0.4);
        splitMain.setOneTouchExpandable(true);

        add(splitMain, BorderLayout.CENTER);
       
        
        cboLoaiPhong.addActionListener(
                e -> loadPhongTheoLoai());

        btnDatPhong.addActionListener(
                e -> datPhong());
        btnTimDatPhong.addActionListener(
                e -> timDatPhong());
        btnHuyDatPhong.addActionListener(
                e -> huyDatPhong());

        btnLamMoi.addActionListener(
                e -> {

                    txtTimKH.setText("");
                    txtTimDatPhong.setText("");

                    loadKhachHang();
                    loadDatPhong();
                    loadLoaiPhong();
                });

        btnThemKH.addActionListener(e -> {

            JDesktopPane desktop =
                    getDesktopPane();

            if (desktop != null) {

                QuanLyKhachHangForm form =
                        new QuanLyKhachHangForm();

                desktop.add(form);

                form.setVisible(true);

                try {
                    form.setSelected(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }); 

        btnTimKH.addActionListener(
                e -> timKhachHang());
    }
    

    private void loadLoaiPhong() {

        cboLoaiPhong.removeAllItems();

        for (LoaiPhong lp :
                loaiBUS.getAll()) {

            cboLoaiPhong.addItem(lp);
        }

        loadPhongTheoLoai();
    }

    private void loadPhongTheoLoai() {

        cboPhong.removeAllItems();

        LoaiPhong lp =
                (LoaiPhong) cboLoaiPhong.getSelectedItem();

        if (lp == null) {
            return;
        }

        java.util.Date ngayNhan =
                dcNgayNhan.getDate();

        java.util.Date ngayTra =
                dcNgayTra.getDate();

         if (ngayNhan == null || ngayTra == null) {

            for (Phong p : phongBUS.getAll()) {

                if (p.getMaLoaiPhong()
                        == lp.getMaLoaiPhong()) {

                    cboPhong.addItem(p);
                }
            }

            return;
        }

        for (Phong p : phongBUS.getAll()) {

            if (p.getMaLoaiPhong()
                    == lp.getMaLoaiPhong()) {

                boolean trong =
                        ctBUS.isPhongTrong(
                                p.getMaPhong(),
                                new java.sql.Date(
                                        ngayNhan.getTime()),
                                new java.sql.Date(
                                        ngayTra.getTime()));

                if (trong) {

                    cboPhong.addItem(p);
                }
            }
        }
    }

    private void loadKhachHang() {

        modelKH.setRowCount(0);

        for (KhachHang kh :
                khBUS.getAll()) {

            modelKH.addRow(
                    new Object[]{
                            kh.getMaKhachHang(),
                            kh.getHoTen(),
                            kh.getSoDienThoai()
                    });
        }
    }

    private void timKhachHang() {

        String keyword =
                txtTimKH.getText()
                        .trim()
                        .toLowerCase();

        modelKH.setRowCount(0);

        for (KhachHang kh :
                khBUS.getAll()) {

            if (kh.getHoTen()
                    .toLowerCase()
                    .contains(keyword)

                    ||

                    kh.getSoDienThoai()
                            .contains(keyword)) {

                modelKH.addRow(
                        new Object[]{
                                kh.getMaKhachHang(),
                                kh.getHoTen(),
                                kh.getSoDienThoai()
                        });
            }
        }
    }

    private void loadDatPhong() {

        modelPD.setRowCount(0);

        List<PhieuDatPhong> dsPhieuDat =
                pdBUS.getAll();

        List<KhachHang> dsKH =
                khBUS.getAll();

        List<Phong> dsPhong =
                phongBUS.getAll();

        List<LoaiPhong> dsLoai =
                loaiBUS.getAll();

        for (PhieuDatPhong pd : dsPhieuDat) {

            String tenKH = "";
            String soPhong = "";
            String tenLoaiPhong = "";

            for (KhachHang kh : dsKH) {

                if (kh.getMaKhachHang()
                        == pd.getMaKhachHang()) {

                    tenKH = kh.getHoTen();
                    break;
                }
            }

            List<ChiTietDatPhong> dsCT =
                    ctBUS.getByPhieuDat(
                            pd.getMaPhieuDat());

            if (!dsCT.isEmpty()) {

                int maPhong =
                        dsCT.get(0).getMaPhong();

                for (Phong p : dsPhong) {

                    if (p.getMaPhong()
                            == maPhong) {

                        soPhong =
                                p.getSoPhong();

                        for (LoaiPhong lp : dsLoai) {

                            if (lp.getMaLoaiPhong()
                                    == p.getMaLoaiPhong()) {

                                tenLoaiPhong =
                                        lp.getTenLoaiPhong();

                                break;
                            }
                        }

                        break;
                    }
                }
            }

            modelPD.addRow(
                    new Object[]{
                            pd.getMaPhieuDat(),
                            tenKH,
                            tenLoaiPhong,
                            soPhong,
                            pd.getNgayNhanPhong(),
                            pd.getNgayTraPhong(),
                            pd.getTienCoc(),
                            pd.getTrangThai()
                    });
        }
    }

    private void datPhong() {

        try {

            int row =
                    tblKhachHang.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng chọn khách hàng");

                return;
            }

            if (cboPhong.getSelectedItem() == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Không có phòng trống");

                return;
            }

            java.util.Date ngayNhan =
                    dcNgayNhan.getDate();

            java.util.Date ngayTra =
                    dcNgayTra.getDate();

            if (ngayNhan == null
                    || ngayTra == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng chọn ngày");

                return;
            }
            
            java.util.Date homNay = new java.util.Date();

            if (ngayNhan.before(homNay)
                    && !isSameDay(ngayNhan, homNay)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ngày nhận phòng không được nhỏ hơn ngày hiện tại");

                return;
            }
            LocalDate ngayNhanLD =
                    ngayNhan.toInstant()
                            .atZone(ZoneId.systemDefault())
                            .toLocalDate();

            LocalDate ngayTraLD =
                    ngayTra.toInstant()
                           .atZone(ZoneId.systemDefault())
                           .toLocalDate();

            if (!ngayTraLD.isAfter(ngayNhanLD)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ngày trả phải lớn hơn ngày nhận");

                return;
            }

            int maKH =
                    Integer.parseInt(
                            modelKH.getValueAt(
                                    row,
                                    0).toString());

            Phong phong =
                    (Phong) cboPhong
                            .getSelectedItem();

            PhieuDatPhong pd =
                    new PhieuDatPhong();

            pd.setMaKhachHang(maKH);

            pd.setNgayDat(
                    new Timestamp(
                            System.currentTimeMillis()));

            pd.setNgayNhanPhong(
                    new Date(
                            ngayNhan.getTime()));

            pd.setNgayTraPhong(
                    new Date(
                            ngayTra.getTime()));

            double tienCoc;

            try {

                tienCoc =
                        Double.parseDouble(
                                txtTienCoc.getText().trim());

            } catch (Exception e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Tiền cọc phải là số");

                return;
            }

            double tongTien =
                    Double.parseDouble(
                            txtTongTien.getText());

            double tienCocBatBuoc =
                    tongTien;

            if (Math.abs(
                    tienCoc - tienCocBatBuoc) > 1000) {

                JOptionPane.showMessageDialog(
                        this,
                        "Tiền cọc phải bằng 50% tổng tiền phòng");

                return;
            }

            pd.setTienCoc(tienCoc);

            pd.setTrangThai("DA_DAT");

            int maPhieuDatMoi =
                    pdBUS.insertAndGetId(pd);

            if(maPhieuDatMoi > 0){

                ChiTietDatPhong ct =
                        new ChiTietDatPhong();

                ct.setMaPhieuDat(maPhieuDatMoi);

                ct.setMaPhong(
                        phong.getMaPhong());

                ct.setMaKhachHang(
                        maKH);

                if(!ctBUS.insert(ct)){

                    JOptionPane.showMessageDialog(
                            this,
                            "Lỗi thêm chi tiết đặt phòng");

                    return;
                }
                phongBUS.updateTrangThai(
                        phong.getMaPhong(),
                        "DA_DAT");
                

                loadDatPhong();
                loadPhongTheoLoai();

                JOptionPane.showMessageDialog(
                        this,
                        "Đặt phòng thành công");

                txtTienCoc.setText("");
                dcNgayNhan.setDate(null);
                dcNgayTra.setDate(null);
                txtTongTien.setText("");

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Đặt phòng thất bại");
            }

        } catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi dữ liệu");
        }
    }

    private void huyDatPhong() {

        try {

            int row = tblDatPhong.getSelectedRow();

            if (row == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng chọn phiếu đặt");

                return;
            }

            int maPhieuDat =
                    Integer.parseInt(
                            modelPD.getValueAt(
                                    row,
                                    0).toString());

            int confirm =
                    JOptionPane.showConfirmDialog(
                            this,
                            "Bạn có chắc muốn hủy đặt phòng?",
                            "Xác nhận",
                            JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

             List<ChiTietDatPhong> dsCT =
                    ctBUS.getByPhieuDat(maPhieuDat);

             for (ChiTietDatPhong ct : dsCT) {

                ctBUS.delete(
                        ct.getMaPhieuDat(),
                        ct.getMaPhong());
            }

             if (pdBUS.delete(maPhieuDat)) {

                loadDatPhong();
                loadLoaiPhong();

                JOptionPane.showMessageDialog(
                        this,
                        "Hủy đặt phòng thành công");
            }
            else {

                JOptionPane.showMessageDialog(
                        this,
                        "Hủy đặt phòng thất bại");
            }

        } catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Có lỗi xảy ra");
        }
    }
    private boolean isSameDay(
            java.util.Date d1,
            java.util.Date d2) {

        java.util.Calendar c1 =
                java.util.Calendar.getInstance();

        java.util.Calendar c2 =
                java.util.Calendar.getInstance();

        c1.setTime(d1);
        c2.setTime(d2);

        return c1.get(java.util.Calendar.YEAR)
                == c2.get(java.util.Calendar.YEAR)

                &&

                c1.get(java.util.Calendar.DAY_OF_YEAR)
                == c2.get(java.util.Calendar.DAY_OF_YEAR);
    }
    private void timDatPhong() {

        String keyword =
                txtTimDatPhong.getText()
                        .trim()
                        .toLowerCase();

        modelPD.setRowCount(0);

        List<PhieuDatPhong> dsPhieuDat =
                pdBUS.getAll();

        List<KhachHang> dsKH =
                khBUS.getAll();

        List<Phong> dsPhong =
                phongBUS.getAll();

        List<LoaiPhong> dsLoai =
                loaiBUS.getAll();

        for (PhieuDatPhong pd : dsPhieuDat) {

            KhachHang khTimThay = null;

            for (KhachHang kh : dsKH) {

                if (kh.getMaKhachHang()
                        == pd.getMaKhachHang()) {

                    khTimThay = kh;
                    break;
                }
            }

            if (khTimThay == null) {
                continue;
            }

            boolean match =
                    khTimThay.getHoTen()
                            .toLowerCase()
                            .contains(keyword)

                    ||

                    khTimThay.getSoDienThoai()
                            .contains(keyword);

            if (!match) {
                continue;
            }

            String tenLoaiPhong = "";
            String soPhong = "";

            List<ChiTietDatPhong> dsCT =
                    ctBUS.getByPhieuDat(
                            pd.getMaPhieuDat());

            if (!dsCT.isEmpty()) {

                int maPhong =
                        dsCT.get(0).getMaPhong();

                for (Phong p : dsPhong) {

                    if (p.getMaPhong()
                            == maPhong) {

                        soPhong =
                                p.getSoPhong();

                        for (LoaiPhong lp : dsLoai) {

                            if (lp.getMaLoaiPhong()
                                    == p.getMaLoaiPhong()) {

                                tenLoaiPhong =
                                        lp.getTenLoaiPhong();

                                break;
                            }
                        }

                        break;
                    }
                }
            }

            modelPD.addRow(
                    new Object[]{
                            pd.getMaPhieuDat(),
                            khTimThay.getHoTen(),
                            tenLoaiPhong,
                            soPhong,
                            pd.getNgayNhanPhong(),
                            pd.getNgayTraPhong(),
                            pd.getTienCoc(),
                            pd.getTrangThai()
                    });
        }
    }
    private void tinhTongTien() {

        try {

            if (cboPhong.getSelectedItem() == null
                    || dcNgayNhan.getDate() == null
                    || dcNgayTra.getDate() == null) {

                txtTongTien.setText("");
                return;
            }

            Phong phong =
                    (Phong) cboPhong.getSelectedItem();

            LoaiPhong loaiPhong = null;

            for (LoaiPhong lp : loaiBUS.getAll()) {

                if (lp.getMaLoaiPhong()
                        == phong.getMaLoaiPhong()) {

                    loaiPhong = lp;
                    break;
                }
            }

            if (loaiPhong == null) {
                return;
            }

            long soNgay =
                    (dcNgayTra.getDate().getTime()
                            - dcNgayNhan.getDate().getTime())
                            / (1000 * 60 * 60 * 24);

            if (soNgay <= 0) {
                soNgay = 1;
            }

            double tongTien =
                    soNgay * loaiPhong.getDonGia();

            txtTongTien.setText(
                    String.valueOf(tongTien));

            txtTienCoc.setText(
                    String.valueOf(tongTien * 0.5));

        } catch (Exception e) {

            txtTongTien.setText("");
        }
    }
}