package gui;

import bus.NhaCungCapBUS;
import model.NhaCungCap;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class QuanLyNhaCungCapForm extends JInternalFrame {

    JTextField txtTen;
    JTextField txtDiaChi;
    JTextField txtSDT;
    JTextField txtEmail;
    JTextField txtTim;

    JTable tableNCC;
    JTable tableHangHoa;

    DefaultTableModel modelNCC;
    DefaultTableModel modelHangHoa;

    NhaCungCapBUS bus = new NhaCungCapBUS();

    private int maNCCDangChon = -1;

    // Hệ màu sắc Modern UI cao cấp
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);     // Xanh dương chủ đạo
    private final Color SUCCESS_COLOR = new Color(46, 204, 113);     // Xanh lá (Thêm)
    private final Color WARNING_COLOR = new Color(241, 196, 15);     // Vàng hổ phách (Sửa)
    private final Color DANGER_COLOR = new Color(231, 76, 60);       // Đỏ Coral (Xóa)
    private final Color BACKGROUND_COLOR = new Color(245, 246, 250);  // Nền Form xám dịu

    public QuanLyNhaCungCapForm() {
        super(
                "Quản Lý Nhà Cung Cấp",
                true,
                true,
                true,
                true
        );

        setSize(1100, 750);
        setLocation(20, 20);
        setVisible(true);
        
        // Thiết lập khoảng đệm xung quanh form
        setLayout(new BorderLayout(0, 15));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));
        getContentPane().setBackground(BACKGROUND_COLOR);

        // ----------------- VÙNG NHẬP THÔNG TIN (NORTH) -----------------
        JPanel pTop = new JPanel(new GridBagLayout());
        pTop.setBackground(Color.WHITE);
        pTop.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.weightx = 1.0;

        txtTen = createStyledTextField();
        txtDiaChi = createStyledTextField();
        txtSDT = createStyledTextField();
        txtEmail = createStyledTextField();

        // Dòng 1: Tên nhà cung cấp & Địa chỉ
        gbc.gridx = 0; gbc.gridy = 0; pTop.add(createStyledLabel("Tên Nhà Cung Cấp"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; pTop.add(createStyledLabel("Địa Chỉ"), gbc);
        gbc.gridx = 0; gbc.gridy = 1; pTop.add(txtTen, gbc);
        gbc.gridx = 1; gbc.gridy = 1; pTop.add(txtDiaChi, gbc);

        // Dòng 2: Số điện thoại & Email
        gbc.gridx = 0; gbc.gridy = 2; pTop.add(createStyledLabel("Số Điện Thoại"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; pTop.add(createStyledLabel("Email Hệ Trọng"), gbc);
        gbc.gridx = 0; gbc.gridy = 3; pTop.add(txtSDT, gbc);
        gbc.gridx = 1; gbc.gridy = 3; pTop.add(txtEmail, gbc);

        add(pTop, BorderLayout.NORTH);

        // ----------------- VÙNG DỮ LIỆU ĐÔI (CENTER) -----------------
        // Khởi tạo Table Nhà cung cấp
        modelNCC = new DefaultTableModel() {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        modelNCC.setColumnIdentifiers(new Object[]{"Mã NCC", "Tên NCC", "Địa Chỉ", "SĐT", "Email"});
        tableNCC = new JTable(modelNCC);
        styleTable(tableNCC);

        // Khởi tạo Table Hàng hóa trực thuộc
        modelHangHoa = new DefaultTableModel() {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        modelHangHoa.setColumnIdentifiers(new Object[]{"Mã Vật Dụng", "Tên Vật Dụng", "Đơn Vị Tính", "Tổng Số Lượng", "Đơn Giá Nhập"});
        tableHangHoa = new JTable(modelHangHoa);
        styleTable(tableHangHoa);

        // Bọc viền tiêu đề thông minh cho JScrollPane
        JScrollPane scrollNCC = new JScrollPane(tableNCC);
        scrollNCC.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(218, 223, 230)), 
                " DANH SÁCH NHÀ CUNG CẤP ", TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 12), PRIMARY_COLOR));
        scrollNCC.getViewport().setBackground(Color.WHITE);

        JScrollPane scrollHangHoa = new JScrollPane(tableHangHoa);
        scrollHangHoa.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(218, 223, 230)), 
                " DANH MỤC HÀNG HÓA LIÊN KẾT (Double-click hàng trên để xem) ", TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 12), PRIMARY_COLOR));
        scrollHangHoa.getViewport().setBackground(Color.WHITE);

        // SplitPane phẳng hiện đại chia cắt không gian dữ liệu
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollNCC, scrollHangHoa);
        splitPane.setDividerLocation(260);
        splitPane.setDividerSize(7);
        splitPane.setBorder(null);
        splitPane.setBackground(BACKGROUND_COLOR);

        add(splitPane, BorderLayout.CENTER);

        // ----------------- THANH ĐIỀU KHIỂN & TÌM KIẾM (SOUTH) -----------------
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 5));
        pBottom.setBackground(BACKGROUND_COLOR);

        JButton btnThem = createStyledButton("Thêm Mới", SUCCESS_COLOR);
        JButton btnSua = createStyledButton("Cập Nhật", WARNING_COLOR);
        JButton btnXoa = createStyledButton("Xóa Bỏ", DANGER_COLOR);

        // Phân tách khu vực Tìm kiếm
        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        pBottom.add(Box.createHorizontalStrut(25)); // Khoảng đệm phân vùng

        pBottom.add(createStyledLabel("Tìm kiếm:"));
        txtTim = createStyledTextField();
        txtTim.setPreferredSize(new Dimension(200, 36));
        pBottom.add(txtTim);

        JButton btnTim = createStyledButton("Tra Cứu", PRIMARY_COLOR);
        btnTim.setPreferredSize(new Dimension(100, 36));
        pBottom.add(btnTim);

        add(pBottom, BorderLayout.SOUTH);

        // ----------------- ĐĂNG KÝ EVENTS LOGIC GỐC -----------------
        loadData();

        tableNCC.getSelectionModel().addListSelectionListener(e -> {
            int row = tableNCC.getSelectedRow();
            if(row >= 0){
                maNCCDangChon = Integer.parseInt(modelNCC.getValueAt(row,0).toString());
                txtTen.setText(modelNCC.getValueAt(row,1).toString());
                txtDiaChi.setText(modelNCC.getValueAt(row,2).toString());
                txtSDT.setText(modelNCC.getValueAt(row,3).toString());
                txtEmail.setText(modelNCC.getValueAt(row,4).toString());
            }
        });

        tableNCC.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableNCC.rowAtPoint(e.getPoint());
                    if (row == -1) return;

                    int maNCC = Integer.parseInt(tableNCC.getValueAt(row, 0).toString());
                    System.out.println("Double Click NCC = " + maNCC);
                    loadHangHoaTheoNCC(maNCC);
                    JOptionPane.showMessageDialog(null, "Đã tải danh mục hàng hóa của NCC mã: " + maNCC);
                }
            }
        });

        btnThem.addActionListener(e -> {
            NhaCungCap ncc = new NhaCungCap();
            ncc.setTenNCC(txtTen.getText());
            ncc.setDiaChi(txtDiaChi.getText());
            ncc.setSoDienThoai(txtSDT.getText());
            ncc.setEmail(txtEmail.getText());

            if(bus.them(ncc)){
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }
        });

        btnSua.addActionListener(e -> {
            if(maNCCDangChon == -1) return;

            NhaCungCap ncc = new NhaCungCap();
            ncc.setMaNCC(maNCCDangChon);
            ncc.setTenNCC(txtTen.getText());
            ncc.setDiaChi(txtDiaChi.getText());
            ncc.setSoDienThoai(txtSDT.getText());
            ncc.setEmail(txtEmail.getText());

            if(bus.sua(ncc)){
                JOptionPane.showMessageDialog(this, "Cập nhật thành công");
                loadData();
            }
        });

        btnXoa.addActionListener(e -> {
            if(maNCCDangChon == -1) return;

            int output = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa?", "Xác nhận", JOptionPane.YES_NO_OPTION);
            if (output == JOptionPane.YES_OPTION) {
                if(bus.xoa(maNCCDangChon)){
                    JOptionPane.showMessageDialog(this, "Xóa thành công");
                    loadData();
                    clearForm();
                }
            }
        });

        btnTim.addActionListener(e -> {
            modelNCC.setRowCount(0);
            for(NhaCungCap n : bus.timKiem(txtTim.getText())){
                modelNCC.addRow(new Object[]{
                        n.getMaNCC(), n.getTenNCC(), n.getDiaChi(), n.getSoDienThoai(), n.getEmail()
                });
            }
        });
    }

    // --- CÁC PHƯƠNG THỨC LIÊN KẾT DỮ LIỆU GỐC ---
    private void loadData(){
        modelNCC.setRowCount(0);
        for(NhaCungCap n : bus.getAll()){
            modelNCC.addRow(new Object[]{
                    n.getMaNCC(), n.getTenNCC(), n.getDiaChi(), n.getSoDienThoai(), n.getEmail()
            });
        }
    }

    private void loadHangHoaTheoNCC(int maNCC) {
        modelHangHoa.setRowCount(0);
        java.util.List<Object[]> ds = bus.getHangHoaTheoNCC(maNCC);
        System.out.println("So dong = " + ds.size());

        for(Object[] row : ds){
            modelHangHoa.addRow(new Object[]{
                    row[0], row[1], row[2], row[3], row[4]
            });
        }
        modelHangHoa.fireTableDataChanged();
    }

    private void clearForm(){
        maNCCDangChon = -1;
        txtTen.setText("");
        txtDiaChi.setText("");
        txtSDT.setText("");
        txtEmail.setText("");
        modelHangHoa.setRowCount(0);
    }

    // --- HELPER PHỤ TRỢ THIẾT KẾ FLAT COMPONENTS ---
    private JTextField createStyledTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return field;
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(71, 85, 105));
        return label;
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowVerticalLines(false); // Loại bỏ lưới dọc theo chuẩn Modern Grid

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(51, 65, 85)); // Màu xám Slate đậm sang trọng
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));
        header.setReorderingAllowed(false);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.setDefaultRenderer(Object.class, centerRenderer);
    }

    private JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.black);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(115, 38));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor.brighter());
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor);
            }
        });
        return btn;
    }
}