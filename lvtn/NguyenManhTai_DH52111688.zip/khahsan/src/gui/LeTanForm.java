package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class LeTanForm extends JInternalFrame {

    private JDesktopPane desktop;

    // Bảng màu Flat UI Modern cao cấp
    private static final Color MAU_NỀN = new Color(241, 245, 249);       // Xám nhạt Slate 100
    private static final Color MAU_CHỮ_ĐẬM = new Color(30, 41, 59);     // Slate 800
    private static final Color MAU_CHỦ_ĐẠO = new Color(14, 165, 233);   // Sky Blue hiện đại
    private static final Color MAU_HOVER = new Color(224, 242, 254);     // Sky Blue nhạt khi hover
    private static final Color MAU_NÚT_XÓA = new Color(239, 68, 68);     // Đỏ chỉn chu Rose 500

    public LeTanForm(JDesktopPane desktop) {
        super("HỆ THỐNG LỄ TÂN - MENU CHÍNH", true, true, true, true);
        this.desktop = desktop;
        setSize(1200, 800);
        setLayout(new BorderLayout(0, 25));
        
        // Cài đặt nền tổng thể
        getContentPane().setBackground(MAU_NỀN);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(30, 30, 30, 30));

        // --- TIÊU ĐỀ DASHBOARD FLAT ---
        JPanel pnlHeader = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlHeader.setOpaque(false);
        JLabel lblHeader = new JLabel("BÀN LÀM VIỆC LỄ TÂN");
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblHeader.setForeground(MAU_CHỮ_ĐẬM);
        pnlHeader.add(lblHeader);
        add(pnlHeader, BorderLayout.NORTH);

        // --- KHỞI TẠO CÁC NÚT BẤM VỚI STYLE HIỆN ĐẠI ---
         JButton btnDSDat = createMenuButton("DANH SÁCH ĐẶT PHÒNG");
         JButton btnNhanPhong1 = createMenuButton("DS NHẬN PHÒNG KHÁCH");
        JButton btnTraPhong = createMenuButton("TRẢ PHÒNG & BILL");
        JButton btnDichVu = createMenuButton("DỊCH VỤ PHÒNG");
        JButton btnKhachHang = createMenuButton("QUẢN LÝ KHÁCH HÀNG");
        JButton btnlichsu = createMenuButton("LỊCH SỬ HÓA ĐƠN");
        JButton btnTaiKhoan = createMenuButton("TÀI KHOẢN CÁ NHÂN");
        JButton btnLichLam = createMenuButton("LỊCH LÀM VIỆC");
        JButton btnDanhSachPhong = createMenuButton("SƠ ĐỒ ĐẶT PHÒNG");
        
        JButton btnDangXuat = createMenuButton("ĐĂNG XUẤT HỆ THỐNG");
        btnDangXuat.setBackground(MAU_NÚT_XÓA);
        btnDangXuat.setForeground(Color.WHITE);

        // --- PHÂN KHU CHỨC NĂNG (PANEL CHÍNH) ---
        JPanel pMainDashboard = new JPanel(new GridLayout(1, 3, 25, 25));
        pMainDashboard.setOpaque(false);

        // Group 1: Nghiệp vụ phòng (Định dạng lưới 5 dòng linh hoạt)
        JPanel pRoomOps = createGroupPanel("NGHIỆP VỤ PHÒNG OPS", 5);
         pRoomOps.add(btnDSDat);
         pRoomOps.add(btnNhanPhong1);
        pRoomOps.add(btnTraPhong);

        // Group 2: Dịch vụ & Khách hàng
        JPanel pServices = createGroupPanel("DỊCH VỤ & KHÁCH HÀNG", 4);
        pServices.add(btnDichVu);
        pServices.add(btnKhachHang);
        pServices.add(btnlichsu);
        pServices.add(btnDanhSachPhong);

        // Group 3: Hệ thống
        JPanel pSystem = createGroupPanel("HỆ THỐNG & CÁ NHÂN", 3);
        pSystem.add(btnTaiKhoan);
        pSystem.add(btnLichLam);
        pSystem.add(btnDangXuat);

        pMainDashboard.add(pRoomOps);
        pMainDashboard.add(pServices);
        pMainDashboard.add(pSystem);
        add(pMainDashboard, BorderLayout.CENTER);

        // =====================================================================
        // SỰ KIỆN ACTION LISTENER (GIỮ NGUYÊN)
        // =====================================================================
        btnDichVu.addActionListener(e -> {
            QuanLyDichVuPhongForm f = new QuanLyDichVuPhongForm();
            hienThiFormCon(f);
        });
        btnDSDat.addActionListener(e -> {
            DanhSachDatPhongForm f = new DanhSachDatPhongForm();
            hienThiFormCon(f);
        });
        btnlichsu.addActionListener(e -> {
            TraCuuHoaDonForm f = new TraCuuHoaDonForm();
            hienThiFormCon(f);
        });
        btnKhachHang.addActionListener(e -> {
        	QuanLyKhachHangForm f = new QuanLyKhachHangForm();
            hienThiFormCon(f);
        });
        btnDanhSachPhong.addActionListener(e -> {
            SoDoDatPhongForm f = new SoDoDatPhongForm();
            hienThiFormCon(f);
        });
        btnTaiKhoan.addActionListener(e -> {
            TaiKhoanCaNhanForm f = new TaiKhoanCaNhanForm();
            hienThiFormCon(f);
        });
        btnLichLam.addActionListener(e -> {
            LichLamViecForm f = new LichLamViecForm();
            hienThiFormCon(f);
        });
       
        btnNhanPhong1.addActionListener(e -> {
            DanhSachNhanPhongForm f = new DanhSachNhanPhongForm();
            hienThiFormCon(f);
        });
       
        btnTraPhong.addActionListener(e -> {
            TraPhongForm f = new TraPhongForm();
            hienThiFormCon(f);
        });
        btnDangXuat.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) {
                window.dispose();
            }
            new DangNhapForm().setVisible(true);
        });
    }

    /**
     * Hàm dùng chung đã tích hợp tính năng MỞ FULL FORM TỰ ĐỘNG
     */
    private void hienThiFormCon(JInternalFrame f) {
        desktop.add(f);
        f.setVisible(true);
        desktop.moveToFront(f);
        
        try {
            f.setMaximum(true); // <<-- BỔ SUNG: Ép form con phóng to toàn màn hình desktop
            f.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(true);
        btn.setBackground(Color.WHITE);
        btn.setForeground(MAU_CHỮ_ĐẬM);
        
        // Thiết kế phẳng mượt mà kèm đường viền mỏng tinh tế
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240), 1, true),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (btn.getBackground() != MAU_NÚT_XÓA) {
                    btn.setBackground(MAU_HOVER);
                    btn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(MAU_CHỦ_ĐẠO, 1, true),
                        BorderFactory.createEmptyBorder(12, 15, 12, 15)
                    ));
                }
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (btn.getBackground() != MAU_NÚT_XÓA) {
                    btn.setBackground(Color.WHITE);
                    btn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(226, 232, 240), 1, true),
                        BorderFactory.createEmptyBorder(12, 15, 12, 15)
                    ));
                }
            }
        });
        return btn;
    }

    private JPanel createGroupPanel(String title, int rows) {
        // Sử dụng số lượng dòng linh hoạt kèm khoảng cách thông thoáng
        JPanel panel = new JPanel(new GridLayout(rows, 1, 12, 12));
        
        // Đổ bóng viền bằng Matte & lồng EmptyBorder tạo padding
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(226, 232, 240), 1, true), 
                        "  " + title + "  ",
                        TitledBorder.LEFT, 
                        TitledBorder.TOP, 
                        new Font("Segoe UI", Font.BOLD, 12), 
                        new Color(100, 116, 139)
                ),
                BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        
        panel.setBackground(Color.WHITE);
        return panel;
    }
}