package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;

public class BookingCellRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        JLabel lb = (JLabel) super.getTableCellRendererComponent(
                table,
                value,
                isSelected,
                hasFocus,
                row,
                column);

        lb.setHorizontalAlignment(SwingConstants.CENTER);
        lb.setBorder(new LineBorder(new Color(220,220,220)));

        // ===== Cột ngày =====
        if(column==0){
            lb.setBackground(new Color(245,245,245));
            lb.setForeground(Color.BLACK);
            lb.setFont(new Font("Segoe UI",Font.BOLD,12));
            return lb;
        }

        String text=value==null?"":value.toString();

        if(text.startsWith("DAT|")){

            lb.setBackground(new Color(102,187,255));
            lb.setForeground(Color.BLACK);
            lb.setText(text.substring(4));

        }else if(text.startsWith("THUE|")){

            lb.setBackground(new Color(255,193,7));
            lb.setForeground(Color.BLACK);
            lb.setText(text.substring(5));

        }else{

            lb.setBackground(Color.WHITE);
            lb.setForeground(Color.BLACK);
            lb.setText("");
        }

        return lb;
    }
}