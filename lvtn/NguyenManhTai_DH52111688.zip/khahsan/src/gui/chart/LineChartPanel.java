package gui.chart;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.List;

public class LineChartPanel extends JPanel {

    private String title;
    private List<String> labels;
    private List<Double> values;
    private boolean isPercent = false;
    private Color lineColor = new Color(14, 116, 144);

    public LineChartPanel(String title, List<String> labels, List<Double> values, boolean isPercent) {
        this.title = title;
        this.labels = labels;
        this.values = values;
        this.isPercent = isPercent;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(700, 350));
    }

    public void setLineColor(Color c) {
        this.lineColor = c;
    }

    public void setData(String title, List<String> labels, List<Double> values) {
        this.title = title;
        this.labels = labels;
        this.values = values;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        // Bật khử răng cưa chất lượng cao cho cả text và hình vẽ
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        int marginLeft = 70;
        int marginRight = 40;
        int marginTop = 50;
        int marginBottom = 60;

        g2.setColor(new Color(15, 23, 42));
        g2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        g2.drawString(title == null ? "" : title.toUpperCase(), 25, 30);

        if (labels == null || labels.isEmpty() || values == null || values.isEmpty()) {
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            g2.setColor(new Color(148, 163, 184));
            g2.drawString("Chưa tìm thấy bản ghi dữ liệu phù hợp", w / 2 - 110, h / 2);
            return;
        }

        double max = isPercent ? 1.0 : 0;
        if (!isPercent) {
            for (double v : values) max = Math.max(max, v);
            if (max <= 0) max = 1;
        }

        int chartW = w - marginLeft - marginRight;
        int chartH = h - marginTop - marginBottom;
        int n = values.size();

        g2.setColor(new Color(226, 232, 240));
        g2.drawLine(marginLeft, marginTop, marginLeft, marginTop + chartH);
        g2.drawLine(marginLeft, marginTop + chartH, marginLeft + chartW, marginTop + chartH);

        g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        for (int i = 0; i <= 4; i++) {
            double val = max * i / 4.0;
            int y = marginTop + chartH - (int) (chartH * i / 4.0);
            g2.setColor(new Color(241, 245, 249));
            g2.drawLine(marginLeft + 1, y, marginLeft + chartW, y);
            
            g2.setColor(new Color(100, 116, 139));
            String s = isPercent ? String.format("%.0f%%", val * 100) : String.format("%.0f", val);
            g2.drawString(s, 18, y + 4);
        }

        int[] xs = new int[n];
        int[] ys = new int[n];

        for (int i = 0; i < n; i++) {
            xs[i] = marginLeft + (n == 1 ? chartW / 2 : chartW * i / (n - 1));
            double ratio = values.get(i) / max;
            ys[i] = marginTop + chartH - (int) (chartH * ratio);
        }

        // Vùng phủ mờ Gradient (Area Chart Blend) cực đẹp mắt bên dưới đường kẻ line
        Polygon area = new Polygon();
        area.addPoint(xs[0], marginTop + chartH);
        for (int i = 0; i < n; i++) area.addPoint(xs[i], ys[i]);
        area.addPoint(xs[n - 1], marginTop + chartH);
        
        GradientPaint areaGp = new GradientPaint(0, marginTop, new Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), 55),
                                                 0, marginTop + chartH, new Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), 0));
        g2.setPaint(areaGp);
        g2.fillPolygon(area);

        // Vẽ đường Line mảnh nối các điểm dữ liệu lại
        g2.setColor(lineColor);
        g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int i = 0; i < n - 1; i++) {
            g2.drawLine(xs[i], ys[i], xs[i + 1], ys[i + 1]);
        }

        // Vẽ các chấm điểm tròn node data và text chân trang X
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        int step = Math.max(1, n / 16); 
        for (int i = 0; i < n; i++) {
            // Điểm tròn với viền trắng tạo chiều sâu nổi khối
            g2.setColor(Color.WHITE);
            g2.fill(new Ellipse2D.Double(xs[i] - 4, ys[i] - 4, 8, 8));
            g2.setColor(lineColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new Ellipse2D.Double(xs[i] - 4, ys[i] - 4, 8, 8));

            if (i % step == 0) {
                g2.setColor(new Color(71, 85, 105));
                String label = labels.get(i);
                int lw = g2.getFontMetrics().stringWidth(label);
                g2.drawString(label, xs[i] - lw / 2, marginTop + chartH + 18);
            }
        }
    }
}