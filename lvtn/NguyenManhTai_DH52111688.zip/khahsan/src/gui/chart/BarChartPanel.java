package gui.chart;

import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class BarChartPanel extends JPanel {

    private String title;
    private List<String> labels;
    private List<Double> values;
    private Color barColor = new Color(14, 116, 144);
    private boolean formatAsCurrency = true;

    public BarChartPanel(String title, List<String> labels, List<Double> values) {
        this.title = title;
        this.labels = labels;
        this.values = values;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(600, 350));
    }

    public void setBarColor(Color c) {
        this.barColor = c;
    }

    public void setFormatAsCurrency(boolean b) {
        this.formatAsCurrency = b;
    }

    public void setData(String title, List<String> labels, List<Double> values) {
        this.title = title;
        this.labels = labels;
        this.values = values;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        int marginLeft = 100; // Tăng nhẹ để tránh tràn số tiền lớn
        int marginRight = 40;
        int marginTop = 50;
        int marginBottom = 75;

        // Tiêu đề biểu đồ phong cách Modern Dashboard
        g2.setColor(new Color(15, 23, 42));
        g2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        g2.drawString(title == null ? "" : title.toUpperCase(), 25, 30);

        if (labels == null || labels.isEmpty() || values == null || values.isEmpty()) {
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            g2.setColor(new Color(148, 163, 184));
            g2.drawString("Chưa tìm thấy bản ghi dữ liệu phù hợp", w / 2 - 110, h / 2);
            return;
        }

        double max = 0;
        for (double v : values) max = Math.max(max, v);
        if (max <= 0) max = 1;

        int chartW = w - marginLeft - marginRight;
        int chartH = h - marginTop - marginBottom;
        int n = values.size();
        int gap = 16;
        int barW = Math.max(8, (chartW - gap * (n + 1)) / n);

        // Trục hệ tọa độ phẳng
        g2.setColor(new Color(226, 232, 240));
        g2.drawLine(marginLeft, marginTop, marginLeft, marginTop + chartH);
        g2.drawLine(marginLeft, marginTop + chartH, marginLeft + chartW, marginTop + chartH);

        // Lưới dòng ngang mờ
        NumberFormat nf = NumberFormat.getInstance(new Locale("vi", "VN"));
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        for (int i = 0; i <= 4; i++) {
            double val = max * i / 4.0;
            int y = marginTop + chartH - (int) (chartH * i / 4.0);
            g2.setColor(new Color(241, 245, 249));
            g2.drawLine(marginLeft + 1, y, marginLeft + chartW, y);
            
            g2.setColor(new Color(100, 116, 139));
            String s = formatAsCurrency ? nf.format(val) : String.valueOf((long) val);
            g2.drawString(s, 15, y + 4);
        }

        int x = marginLeft + gap;
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));

        for (int i = 0; i < n; i++) {
            double v = values.get(i);
            int barH = (int) (chartH * (v / max));
            int y = marginTop + chartH - barH;

            // Đổ màu Gradient chiều dọc mượt mà cho thanh cột
            GradientPaint gp = new GradientPaint(x, y, barColor, x, y + barH, new Color(barColor.getRed(), barColor.getGreen(), barColor.getBlue(), 160));
            g2.setPaint(gp);
            g2.fillRoundRect(x, y, barW, Math.max(barH, 2), 6, 6); // Bo góc đầu thanh cột mềm mại

            // Nhãn text dưới chân cột
            g2.setColor(new Color(71, 85, 105));
            String label = labels.get(i);
            if (n > 14) {
                Graphics2D gr = (Graphics2D) g2.create();
                gr.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                gr.rotate(Math.toRadians(45), x + barW / 2.0, marginTop + chartH + 12);
                gr.drawString(label, x + (barW / 2), marginTop + chartH + 12);
                gr.dispose();
            } else {
                int lw = g2.getFontMetrics().stringWidth(label);
                g2.drawString(label, x + barW / 2 - lw / 2, marginTop + chartH + 18);
            }

            x += barW + gap;
        }
    }
}