package gui;

import bus.NhaCungCapBUS;
import bus.PhieuNhapBUS;
import model.NhaCungCap;
import model.PhieuNhap;
import bus.NhanVienBUS;
import util.Session;
import model.NhanVien;
 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Timestamp;
import java.util.Date;

public class QuanLyPhieuNhapPanel extends JPanel {
	private NhanVienBUS nhanVienBUS = new NhanVienBUS();
    private JTabbedPane tabbedPane;
    private QuanLyCTPhieuNhapPanel ctPanel;

    private JTextField txtMaPN;
    private JComboBox<NhaCungCap> cboNCC;
    private JTextField txtMaNV;
    private JDateChooser dcNgayNhap;
    private JTextField txtTongTien;
    private JTextField txtGhiChu;
    private JTextField txtTim;

    private JTable table;
    private DefaultTableModel model;

    private PhieuNhapBUS bus =
            new PhieuNhapBUS();

    private NhaCungCapBUS nccBUS =
            new NhaCungCapBUS();

    public QuanLyPhieuNhapPanel(
            JTabbedPane tabbedPane,
            QuanLyCTPhieuNhapPanel ctPanel) {

        this.tabbedPane = tabbedPane;
        this.ctPanel = ctPanel;

        setLayout(new BorderLayout());

        JPanel pnTop =
                new JPanel(
                        new GridLayout(6, 2, 5, 5));

        txtMaPN = new JTextField();
        txtMaPN.setEditable(false);

        cboNCC = new JComboBox<>();

        txtMaNV = new JTextField();
        txtMaNV.setEditable(false);

        dcNgayNhap = new JDateChooser();
        dcNgayNhap.setDateFormatString("dd/MM/yyyy");
        dcNgayNhap.setDate(new Date());

        txtTongTien = new JTextField("0");
        txtTongTien.setEditable(false);

        txtGhiChu = new JTextField();

        pnTop.add(new JLabel("Mã Phiếu Nhập"));
        pnTop.add(txtMaPN);

        pnTop.add(new JLabel("Nhà Cung Cấp"));
        pnTop.add(cboNCC);

        pnTop.add(new JLabel("Mã Nhân Viên"));
        pnTop.add(txtMaNV);

        pnTop.add(new JLabel("Ngày Nhập"));
        pnTop.add(dcNgayNhap);

        pnTop.add(new JLabel("Tổng Tiền"));
        pnTop.add(txtTongTien);

        pnTop.add(new JLabel("Ghi Chú"));
        pnTop.add(txtGhiChu);

        add(pnTop, BorderLayout.NORTH);

        model = new DefaultTableModel();

        model.setColumnIdentifiers(
                new Object[]{
                        "Mã PN",
                        "Mã NCC",
                        "Mã NV",
                        "Ngày Nhập",
                        "Tổng Tiền",
                        "Ghi Chú"
                });

        table = new JTable(model);

        add(new JScrollPane(table),
                BorderLayout.CENTER);

        JPanel pnBottom = new JPanel();

        JButton btnThem =
                new JButton("Thêm");

        JButton btnSua =
                new JButton("Sửa");

        JButton btnXoa =
                new JButton("Xóa");

        JButton btnLamMoi =
                new JButton("Làm Mới");

        txtTim = new JTextField(15);

        JButton btnTim =
                new JButton("Tìm");

        pnBottom.add(btnThem);
        pnBottom.add(btnSua);
        pnBottom.add(btnXoa);
        pnBottom.add(btnLamMoi);
        pnBottom.add(txtTim);
        pnBottom.add(btnTim);

        add(pnBottom, BorderLayout.SOUTH);

        loadNCC();
        loadData();

        loadNhanVienDangNhap();
        table.getSelectionModel()
                .addListSelectionListener(e -> {

                    int row =
                            table.getSelectedRow();

                    if (row >= 0) {

                        txtMaPN.setText(
                                model.getValueAt(row, 0)
                                        .toString());

                        int maNCC =
                                Integer.parseInt(
                                        model.getValueAt(row, 1)
                                                .toString());

                        chonNCC(maNCC);

                        txtMaNV.setText(
                                model.getValueAt(row, 2)
                                        .toString());

                        Object ngay =
                                model.getValueAt(row, 3);

                        if (ngay instanceof Date) {

                            dcNgayNhap.setDate(
                                    (Date) ngay);
                        }

                        txtTongTien.setText(
                                model.getValueAt(row, 4)
                                        .toString());

                        txtGhiChu.setText(
                                String.valueOf(
                                        model.getValueAt(row, 5)));
                    }
                });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {

                if (e.getClickCount() == 2 && table.getSelectedRow() != -1) {

                    int row = table.getSelectedRow();

                    int maPN = Integer.parseInt(
                            model.getValueAt(row, 0).toString()
                    );

                    if (ctPanel != null) {
                        ctPanel.hienThiTheoPhieuNhap(maPN);
                    }

                    if (tabbedPane != null) {
                        tabbedPane.setSelectedIndex(1);
                    }
                }
            }
        });

        btnThem.addActionListener(
                e -> them());

        btnSua.addActionListener(
                e -> sua());

        btnXoa.addActionListener(
                e -> xoa());

        btnTim.addActionListener(
                e -> timKiem());

        btnLamMoi.addActionListener(
                e -> lamMoi());
    }

    private void loadNCC() {

        cboNCC.removeAllItems();

        for (NhaCungCap ncc :
                nccBUS.getAll()) {

            cboNCC.addItem(ncc);
        }
    }

    private void chonNCC(int maNCC) {

        for (int i = 0;
             i < cboNCC.getItemCount();
             i++) {

            NhaCungCap ncc =
                    cboNCC.getItemAt(i);

            if (ncc.getMaNCC() == maNCC) {

                cboNCC.setSelectedIndex(i);

                break;
            }
        }
    }

    private void them() {

        try {

            if (cboNCC.getSelectedItem()
                    == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Chọn nhà cung cấp");

                return;
            }

            NhaCungCap ncc =
                    (NhaCungCap)
                            cboNCC.getSelectedItem();

            PhieuNhap pn =
                    new PhieuNhap();

            pn.setMaNCC(
                    ncc.getMaNCC());

            pn.setMaNhanVien(
                    Integer.parseInt(
                            txtMaNV.getText()));

            Date d =
                    dcNgayNhap.getDate();

            pn.setNgayNhap(
                    new Timestamp(
                            d.getTime()));

            pn.setTongTien(0);

            pn.setGhiChu(
                    txtGhiChu.getText());

            if (bus.them(pn)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Thêm thành công");

                loadData();
                lamMoi();
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private void sua() {

        try {

            if (txtMaPN.getText()
                    .isEmpty()) {

                return;
            }

            NhaCungCap ncc =
                    (NhaCungCap)
                            cboNCC.getSelectedItem();

            PhieuNhap pn =
                    new PhieuNhap();

            pn.setMaPhieuNhap(
                    Integer.parseInt(
                            txtMaPN.getText()));

            pn.setMaNCC(
                    ncc.getMaNCC());

            pn.setMaNhanVien(
                    Integer.parseInt(
                            txtMaNV.getText()));

            Date d =
                    dcNgayNhap.getDate();

            pn.setNgayNhap(
                    new Timestamp(
                            d.getTime()));

            pn.setTongTien(
                    Double.parseDouble(
                            txtTongTien.getText()));

            pn.setGhiChu(
                    txtGhiChu.getText());

            if (bus.sua(pn)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Cập nhật thành công");

                loadData();
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private void xoa() {

        if (txtMaPN.getText()
                .isEmpty()) {

            return;
        }

        int maPN =
                Integer.parseInt(
                        txtMaPN.getText());

        if (bus.xoa(maPN)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Xóa thành công");

            loadData();
            lamMoi();
        }
    }
    private void loadNhanVienDangNhap() {

        txtMaNV.setText("");

        if (Session.taiKhoanDangNhap != null) {

            NhanVien nv = nhanVienBUS.getByMaTaiKhoan(
                    Session.taiKhoanDangNhap.getMaTaiKhoan());

            if (nv != null) {
                txtMaNV.setText(String.valueOf(nv.getMaNhanVien()));
            }
        }
    }
    private void timKiem() {

        model.setRowCount(0);

        for (PhieuNhap pn :
                bus.timKiem(
                        txtTim.getText())) {

            model.addRow(
                    new Object[]{
                            pn.getMaPhieuNhap(),
                            pn.getMaNCC(),
                            pn.getMaNhanVien(),
                            pn.getNgayNhap(),
                            pn.getTongTien(),
                            pn.getGhiChu()
                    });
        }
    }

    private void lamMoi() {

        txtMaPN.setText("");
        txtTongTien.setText("0");
        txtGhiChu.setText("");
        txtTim.setText("");

        dcNgayNhap.setDate(new Date());

        if (cboNCC.getItemCount() > 0) {
            cboNCC.setSelectedIndex(0);
        }

        table.clearSelection();

        loadNhanVienDangNhap();

        loadData();
    }
    private void loadData() {

        model.setRowCount(0);

        for (PhieuNhap pn :
                bus.getAll()) {

            model.addRow(
                    new Object[]{
                            pn.getMaPhieuNhap(),
                            pn.getMaNCC(),
                            pn.getMaNhanVien(),
                            pn.getNgayNhap(),
                            pn.getTongTien(),
                            pn.getGhiChu()
                    });
        }
    }
}