package gui;

import bus.NhanVienBUS;
import bus.VaiTroBUS;
import model.NhanVien;
import model.VaiTro;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;

public class QuanLyNhanVienForm extends JInternalFrame {

    JTextField txtHoTen;
    JTextField txtSDT;
    JTextField txtEmail;
    JTextField txtDiaChi;
    JTextField txtCCCD;
    JTextField txtTimKiem;

    JComboBox<String> cboGioiTinh;
    JComboBox<VaiTro> cboChucVu;

    JDateChooser dcNgaySinh;
    JDateChooser dcNgayVaoLam;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnTimKiem;
    JButton btnLamMoi;

    JTable table;
    DefaultTableModel model;

    NhanVienBUS bus = new NhanVienBUS();
    VaiTroBUS vaiTroBUS = new VaiTroBUS();

    int selectedMaNV = -1;

    public QuanLyNhanVienForm() {
        super("QUẢN LÝ NHÂN VIÊN", true, true, true, true);
        setSize(1300, 750);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));

        // Khởi tạo các component control trước
        initControls();

        // ==========================================
        // 1. PANEL LEFT: KHU VỰC NHẬP THÔNG TIN
        // ==========================================
        JPanel pLeft = new JPanel(new BorderLayout(10, 10));
        pLeft.setPreferredSize(new Dimension(420, 0));

        JPanel pInputForm = new JPanel(new GridBagLayout());
        pInputForm.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Thông Tin Nhân Viên", 
                TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 14)));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Hàm tiện ích thêm component vào GridBagLayout nhanh
        addGrid(pInputForm, new JLabel("Họ tên (*)"), gbc, 0, 0, 1, 1.0);
        addGrid(pInputForm, txtHoTen, gbc, 0, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Giới tính"), gbc, 1, 0, 1, 1.0);
        addGrid(pInputForm, cboGioiTinh, gbc, 1, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Ngày sinh (*)"), gbc, 2, 0, 1, 1.0);
        addGrid(pInputForm, dcNgaySinh, gbc, 2, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Số điện thoại (*)"), gbc, 3, 0, 1, 1.0);
        addGrid(pInputForm, txtSDT, gbc, 3, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("CCCD (*)"), gbc, 4, 0, 1, 1.0);
        addGrid(pInputForm, txtCCCD, gbc, 4, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Email"), gbc, 5, 0, 1, 1.0);
        addGrid(pInputForm, txtEmail, gbc, 5, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Chức vụ (*)"), gbc, 6, 0, 1, 1.0);
        addGrid(pInputForm, cboChucVu, gbc, 6, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Ngày vào làm"), gbc, 7, 0, 1, 1.0);
        addGrid(pInputForm, dcNgayVaoLam, gbc, 7, 1, 2, 2.0);

        addGrid(pInputForm, new JLabel("Địa chỉ"), gbc, 8, 0, 1, 1.0);
        gbc.gridx = 0; gbc.gridy = 9; gbc.gridwidth = 3; gbc.weightx = 1.0;
        pInputForm.add(txtDiaChi, gbc);

        // Group các nút chức năng (Thêm, Sửa, Xóa, Làm mới) ngay dưới form nhập liệu
        JPanel pActionButtons = new JPanel(new GridLayout(2, 2, 10, 10));
        pActionButtons.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        pActionButtons.add(btnThem);
        pActionButtons.add(btnSua);
        pActionButtons.add(btnXoa);
        pActionButtons.add(btnLamMoi);

        pLeft.add(pInputForm, BorderLayout.CENTER);
        pLeft.add(pActionButtons, BorderLayout.SOUTH);
        add(pLeft, BorderLayout.WEST);

        // ==========================================
        // 2. PANEL RIGHT: KHU VỰC TÌM KIẾM & BẢNG SỐ LIỆU
        // ==========================================
        JPanel pRight = new JPanel(new BorderLayout(10, 10));

        // Thanh tìm kiếm phía trên bảng số liệu
        JPanel pSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        pSearch.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Tìm Kiếm Nhanh"));
        pSearch.add(new JLabel("Nhập tên nhân viên:"));
        txtTimKiem.setPreferredSize(new Dimension(250, 26));
        pSearch.add(txtTimKiem);
        pSearch.add(btnTimKiem);
        pRight.add(pSearch, BorderLayout.NORTH);

        // Cấu hình bảng hiển thị dữ liệu dữ dằn thanh thoát hơn
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho sửa trực tiếp trên ô của bảng
            }
        };
        model.setColumnIdentifiers(new String[]{
                "Mã NV", "Họ tên", "Giới tính", "Ngày sinh", "SĐT", "Email", "Địa chỉ", "Chức vụ", "Ngày vào làm", "CCCD"
        });
        table = new JTable(model);
        table.setRowHeight(24); // Tăng chiều cao dòng cho dễ nhìn
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JScrollPane scrollPane = new JScrollPane(table);
        pRight.add(scrollPane, BorderLayout.CENTER);
        add(pRight, BorderLayout.CENTER);

        // ==========================================
        // 3. KHỞI TẠO DỮ LIỆU & SỰ KIỆN (Giữ nguyên logic gốc)
        // ==========================================
        loadVaiTro();
        loadData();

        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnTimKiem.addActionListener(e -> timKiem());
        btnLamMoi.addActionListener(e -> {
            loadData();
            clearForm();
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    selectedMaNV = Integer.parseInt(model.getValueAt(row, 0).toString());
                    txtHoTen.setText(model.getValueAt(row, 1).toString());
                    cboGioiTinh.setSelectedItem(model.getValueAt(row, 2).toString());
                    dcNgaySinh.setDate(java.sql.Date.valueOf(model.getValueAt(row, 3).toString()));
                    txtSDT.setText(model.getValueAt(row, 4).toString());
                    txtEmail.setText(model.getValueAt(row, 5).toString());
                    txtDiaChi.setText(model.getValueAt(row, 6).toString());
                    
                    // Logic fix cho việc so sánh object của combobox chức vụ
                    String tenChucVu = model.getValueAt(row, 7).toString();
                    for (int i = 0; i < cboChucVu.getItemCount(); i++) {
                        if (cboChucVu.getItemAt(i).getTenVaiTro().equals(tenChucVu)) {
                            cboChucVu.setSelectedIndex(i);
                            break;
                        }
                    }

                    if (model.getValueAt(row, 8) != null && !model.getValueAt(row, 8).toString().isEmpty()) {
                        dcNgayVaoLam.setDate(java.sql.Date.valueOf(model.getValueAt(row, 8).toString()));
                    } else {
                        dcNgayVaoLam.setDate(null);
                    }
                    txtCCCD.setText(model.getValueAt(row, 9).toString());
                }
            }
        });

        setVisible(true);
    }

    // Khởi tạo kích thước chuẩn hóa và component ban đầu
    private void initControls() {
        txtHoTen = new JTextField();
        txtSDT = new JTextField();
        txtEmail = new JTextField();
        txtDiaChi = new JTextField();
        txtCCCD = new JTextField();
        txtTimKiem = new JTextField();

        cboGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ"});
        cboChucVu = new JComboBox<>();

        dcNgaySinh = new JDateChooser();
        dcNgaySinh.setDateFormatString("yyyy-MM-dd");
        dcNgayVaoLam = new JDateChooser();
        dcNgayVaoLam.setDateFormatString("yyyy-MM-dd");

        // Style nhẹ cho các nút
        btnThem = new JButton("THÊM");
        btnSua = new JButton("SỬA");
        btnXoa = new JButton("XÓA");
        btnTimKiem = new JButton("TÌM KIẾM");
        btnLamMoi = new JButton("LÀM MỚI");
    }

    // Hàm phụ trợ tạo GridBagLayout nhanh gọn gọn hơn
    private void addGrid(Container container, Component comp, GridBagConstraints gbc, int row, int col, int width, double weightX) {
        gbc.gridy = row;
        gbc.gridx = col;
        gbc.gridwidth = width;
        gbc.weightx = weightX;
        container.add(comp, gbc);
    }

    private void loadVaiTro() {
        List<VaiTro> list = vaiTroBUS.getAll();
        for (VaiTro vt : list) {
            cboChucVu.addItem(vt);
        }
    }

    private void loadData() {
        model.setRowCount(0);
        for (NhanVien nv : bus.getAll()) {
            model.addRow(new Object[]{
                    nv.getMaNhanVien(), nv.getHoTen(), nv.getGioiTinh(), nv.getNgaySinh(),
                    nv.getSoDienThoai(), nv.getEmail(), nv.getDiaChi(), nv.getChucVu(),
                    nv.getNgayVaoLam(), nv.getCccd()
            });
        }
    }

    private boolean validateForm() {

        if (txtHoTen.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Phải nhập họ tên");
            txtHoTen.requestFocus();
            return false;
        }

        if (txtCCCD.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Phải nhập CCCD");
            txtCCCD.requestFocus();
            return false;
        }

        // CCCD phải gồm đúng 12 số
        if (!txtCCCD.getText().trim().matches("\\d{12}")) {
            JOptionPane.showMessageDialog(this, "CCCD phải gồm đúng 12 số");
            txtCCCD.requestFocus();
            return false;
        }

        // Kiểm tra CCCD trùng
        long cccd = Long.parseLong(txtCCCD.getText().trim());

        for (NhanVien nv : bus.getAll()) {

            if (selectedMaNV == -1) { // Thêm mới
                if (nv.getCccd() == cccd) {
                    JOptionPane.showMessageDialog(this, "CCCD đã tồn tại");
                    txtCCCD.requestFocus();
                    return false;
                }
            } else { // Sửa
                if (nv.getCccd() == cccd && nv.getMaNhanVien() != selectedMaNV) {
                    JOptionPane.showMessageDialog(this, "CCCD đã tồn tại");
                    txtCCCD.requestFocus();
                    return false;
                }
            }
        }

        if (txtSDT.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Phải nhập số điện thoại");
            txtSDT.requestFocus();
            return false;
        }

        // SĐT phải gồm 10 số và bắt đầu bằng số 0
        if (!txtSDT.getText().trim().matches("0\\d{9}")) {
            JOptionPane.showMessageDialog(this, "Số điện thoại phải gồm 10 số và bắt đầu bằng số 0");
            txtSDT.requestFocus();
            return false;
        }

        // Email
        if (!txtEmail.getText().trim().isEmpty()) {

            String email = txtEmail.getText().trim();

            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                JOptionPane.showMessageDialog(this, "Email không hợp lệ");
                txtEmail.requestFocus();
                return false;
            }
        }

        if (dcNgaySinh.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Phải chọn ngày sinh");
            return false;
        }

        if (cboChucVu.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Phải chọn chức vụ");
            return false;
        }

        LocalDate ngaySinh = new java.sql.Date(dcNgaySinh.getDate().getTime()).toLocalDate();
        int tuoi = Period.between(ngaySinh, LocalDate.now()).getYears();

        if (tuoi < 18) {
            JOptionPane.showMessageDialog(this, "Nhân viên phải đủ 18 tuổi");
            return false;
        }

        if (dcNgayVaoLam.getDate() != null) {

            LocalDate ngayVaoLam = new java.sql.Date(dcNgayVaoLam.getDate().getTime()).toLocalDate();

            if (ngayVaoLam.isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "Ngày vào làm không được ở quá khứ");
                return false;
            }
        }
 
        if (tonTaiCCCD(cccd)) {
            JOptionPane.showMessageDialog(this, "CCCD đã tồn tại");
            txtCCCD.requestFocus();
            return false;
        }
        return true;
    }
    private boolean tonTaiCCCD(long cccd) {

        for (NhanVien nv : bus.getAll()) {

            if (selectedMaNV == -1) {
                if (nv.getCccd() == cccd) {
                    return true;
                }
            } else {
                if (nv.getCccd() == cccd
                        && nv.getMaNhanVien() != selectedMaNV) {
                    return true;
                }
            }
        }

        return false;
    }
    private void them() {
        try {
            if (!validateForm()) return;

            VaiTro vt = (VaiTro) cboChucVu.getSelectedItem();
            NhanVien nv = new NhanVien();
            nv.setHoTen(txtHoTen.getText());
            nv.setGioiTinh(cboGioiTinh.getSelectedItem().toString());
            nv.setNgaySinh(new Date(dcNgaySinh.getDate().getTime()));
            nv.setSoDienThoai(txtSDT.getText());
            nv.setEmail(txtEmail.getText());
            nv.setDiaChi(txtDiaChi.getText());
            nv.setChucVu(vt.getTenVaiTro());

            if (dcNgayVaoLam.getDate() != null) {
                nv.setNgayVaoLam(new Date(dcNgayVaoLam.getDate().getTime()));
            }
            nv.setCccd(Long.parseLong(txtCCCD.getText()));
            nv.setMaTaiKhoan(null);

            if (bus.insert(nv)) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void sua() {
        try {
            if (selectedMaNV == -1) {
                JOptionPane.showMessageDialog(this, "Chọn nhân viên cần sửa");
                return;
            }
            if (!validateForm()) return;

            VaiTro vt = (VaiTro) cboChucVu.getSelectedItem();
            NhanVien nv = new NhanVien();
            nv.setMaNhanVien(selectedMaNV);
            nv.setHoTen(txtHoTen.getText());
            nv.setGioiTinh(cboGioiTinh.getSelectedItem().toString());
            nv.setNgaySinh(new Date(dcNgaySinh.getDate().getTime()));
            nv.setSoDienThoai(txtSDT.getText());
            nv.setEmail(txtEmail.getText());
            nv.setDiaChi(txtDiaChi.getText());
            nv.setChucVu(vt.getTenVaiTro());

            if (dcNgayVaoLam.getDate() != null) {
                nv.setNgayVaoLam(new Date(dcNgayVaoLam.getDate().getTime()));
            }
            nv.setCccd(Long.parseLong(txtCCCD.getText()));

            if (bus.update(nv)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void xoa() {
        if (selectedMaNV == -1) {
            JOptionPane.showMessageDialog(this, "Chọn nhân viên cần xóa");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (bus.delete(selectedMaNV)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadData();
                clearForm();
            }
        }
    }

    private void timKiem() {
        model.setRowCount(0);
        for (NhanVien nv : bus.search(txtTimKiem.getText())) {
            model.addRow(new Object[]{
                    nv.getMaNhanVien(), nv.getHoTen(), nv.getGioiTinh(), nv.getNgaySinh(),
                    nv.getSoDienThoai(), nv.getEmail(), nv.getDiaChi(), nv.getChucVu(),
                    nv.getNgayVaoLam(), nv.getCccd()
            });
        }
    }

    private void clearForm() {
        txtHoTen.setText("");
        txtSDT.setText("");
        txtEmail.setText("");
        txtDiaChi.setText("");
        txtCCCD.setText("");
        txtTimKiem.setText("");
        cboGioiTinh.setSelectedIndex(0);
        if (cboChucVu.getItemCount() > 0) {
            cboChucVu.setSelectedIndex(0);
        }
        dcNgaySinh.setDate(null);
        dcNgayVaoLam.setDate(null);
        selectedMaNV = -1;
    }
}