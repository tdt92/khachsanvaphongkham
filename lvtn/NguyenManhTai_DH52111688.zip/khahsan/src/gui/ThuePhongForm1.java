package gui;

import java.util.Calendar;
import bus.*;
import model.*;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.Timestamp;

public class ThuePhongForm1 extends JInternalFrame {

    private KhachHang kh;

    private Integer maPhieuThueHienTai = null;
    private Integer maHoaDonHienTai = null;
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private HoaDonBUS hoaDonBUS = new HoaDonBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();
    private PhieuThuePhongBUS ptBUS = new PhieuThuePhongBUS();

    private ChiTietThuePhongBUS ctBUS = new ChiTietThuePhongBUS();
    private HoaDonBUS hdBUS = new HoaDonBUS();
    private JTextField txtTenKH;
    private JTextField txtCCCD;

    private JComboBox<LoaiPhong> cboLoaiPhong;

    private JTextArea txtMoTa;

    private JDateChooser dcNhan;
    private JDateChooser dcTra;

    private JTextField txtSoNgay;
    private JTextField txtTongTien;

    private JLabel lblMaPhieuThue;

    private JTable tblPhong;

    private DefaultTableModel model;

	/*
	 * private JButton btnThemPhong;
	 */    private JButton btnXacNhan;

    // Định nghĩa bảng màu Modern UI
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);   // Xanh dương lịch lãm
    private final Color SUCCESS_COLOR = new Color(39, 174, 96);    // Xanh lá cây tươi trẻ
    private final Color BACKGROUND_COLOR = new Color(245, 247, 250); // Xám trắng nhẹ
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public ThuePhongForm1(KhachHang kh){
        super("THUÊ PHÒNG", true, true, true, true);

        this.kh = kh;

        initUI();

        loadLoaiPhong();

        txtTenKH.setText(kh.getHoTen());
        txtCCCD.setText(kh.getCccd());
        hienThiLoaiPhong();
        loadPhongTrong();
        tinhTien();
    }

    private void initUI(){
        setSize(1050, 720);
        getContentPane().setBackground(BACKGROUND_COLOR);
        setLayout(new BorderLayout(15, 15));

        // ----------------- PANEL PHÍA TRÊN (THÔNG TIN NHẬP LIỆU) -----------------
        JPanel pnlTopWrapper = new JPanel(new GridLayout(1, 2, 15, 0));
        pnlTopWrapper.setBackground(BACKGROUND_COLOR);
        pnlTopWrapper.setBorder(new EmptyBorder(15, 15, 0, 15));

        // Nhóm 1: Thông tin khách hàng & Thời gian
        JPanel pnlCustomerTime = new JPanel(new GridBagLayout());
        pnlCustomerTime.setBackground(Color.WHITE);
        pnlCustomerTime.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230), 1, true),
                "Thông tin khách & Thời gian đặt", TitledBorder.LEFT, TitledBorder.TOP, HEADER_FONT, PRIMARY_COLOR));
        
        // Nhóm 2: Thông tin Loại phòng & Tính tiền
        JPanel pnlRoomBilling = new JPanel(new GridBagLayout());
        pnlRoomBilling.setBackground(Color.WHITE);
        pnlRoomBilling.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230), 1, true),
                "Chi tiết phòng & Thanh toán", TitledBorder.LEFT, TitledBorder.TOP, HEADER_FONT, PRIMARY_COLOR));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.weightx = 1.0;

        // Khởi tạo các Component với style mới
        lblMaPhieuThue = new JLabel("Mã phiếu thuê: Chưa tạo");
        lblMaPhieuThue.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblMaPhieuThue.setForeground(new Color(192, 57, 43)); // Màu đỏ tạo điểm nhấn

        txtTenKH = new JTextField();
        txtCCCD = new JTextField();
        txtTenKH.setEditable(false);
        txtCCCD.setEditable(false);
        txtTenKH.setFont(MAIN_FONT);
        txtCCCD.setFont(MAIN_FONT);

        cboLoaiPhong = new JComboBox<>();
        cboLoaiPhong.setFont(MAIN_FONT);
        cboLoaiPhong.setBackground(Color.WHITE);

        txtMoTa = new JTextArea(3, 20);
        txtMoTa.setEditable(false);
        txtMoTa.setFont(MAIN_FONT);
        txtMoTa.setLineWrap(true);
        txtMoTa.setWrapStyleWord(true);

        dcNhan = new JDateChooser();
        dcTra = new JDateChooser();
        dcNhan.setFont(MAIN_FONT);
        dcTra.setFont(MAIN_FONT);

        java.util.Date homNay = new java.util.Date();
        dcNhan.setMinSelectableDate(homNay);
        dcNhan.setDate(homNay);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(homNay);
        calendar.add(Calendar.DATE, 1);
        dcTra.setDate(calendar.getTime());
        dcTra.setMinSelectableDate(calendar.getTime());

        txtSoNgay = new JTextField();
        txtTongTien = new JTextField();
        txtSoNgay.setEditable(false);
        txtTongTien.setEditable(false);
        
        // Định dạng ô tiền và số ngày nhìn cho nổi bật
        txtSoNgay.setFont(new Font("Segoe UI", Font.BOLD, 14));
        txtTongTien.setFont(new Font("Segoe UI", Font.BOLD, 15));
        txtTongTien.setForeground(new Color(211, 47, 47));

        // --- Đưa components vào Nhóm 1 (Khách hàng & Thời gian) ---
        gbc.gridwidth = 2; gbc.gridx = 0; gbc.gridy = 0;
        pnlCustomerTime.add(lblMaPhieuThue, gbc);

        gbc.gridwidth = 1; gbc.gridx = 0; gbc.gridy = 1;
        pnlCustomerTime.add(new JLabel("Khách hàng:"), gbc);
        gbc.gridx = 1;
        pnlCustomerTime.add(txtTenKH, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        pnlCustomerTime.add(new JLabel("Số CCCD:"), gbc);
        gbc.gridx = 1;
        pnlCustomerTime.add(txtCCCD, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        pnlCustomerTime.add(new JLabel("Ngày nhận phòng:"), gbc);
        gbc.gridx = 1;
        pnlCustomerTime.add(dcNhan, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        pnlCustomerTime.add(new JLabel("Ngày trả dự kiến:"), gbc);
        gbc.gridx = 1;
        pnlCustomerTime.add(dcTra, gbc);

        // --- Đưa components vào Nhóm 2 (Loại phòng & Thanh toán) ---
        gbc.gridwidth = 1; gbc.gridx = 0; gbc.gridy = 0;
        pnlRoomBilling.add(new JLabel("Loại phòng mục tiêu:"), gbc);
        gbc.gridx = 1;
        pnlRoomBilling.add(cboLoaiPhong, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        pnlRoomBilling.add(new JLabel("Mô tả loại phòng:"), gbc);
        gbc.gridx = 1;
        pnlRoomBilling.add(new JScrollPane(txtMoTa), gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        pnlRoomBilling.add(new JLabel("Số đêm dự kiến:"), gbc);
        gbc.gridx = 1;
        pnlRoomBilling.add(txtSoNgay, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        pnlRoomBilling.add(new JLabel("Tạm tính (VNĐ):"), gbc);
        gbc.gridx = 1;
        pnlRoomBilling.add(txtTongTien, gbc);

        pnlTopWrapper.add(pnlCustomerTime);
        pnlTopWrapper.add(pnlRoomBilling);
        add(pnlTopWrapper, BorderLayout.NORTH);

        // ----------------- PANEL GIỮA (BẢNG HIỂN THỊ PHÒNG TRỐNG) -----------------
        JPanel pnlCenter = new JPanel(new BorderLayout());
        pnlCenter.setBackground(BACKGROUND_COLOR);
        pnlCenter.setBorder(new EmptyBorder(10, 15, 10, 15));

        JLabel lblTableTitle = new JLabel("Danh sách phòng trống khả dụng thỏa điều kiện:");
        lblTableTitle.setFont(HEADER_FONT);
        lblTableTitle.setBorder(new EmptyBorder(0, 0, 8, 0));
        pnlCenter.add(lblTableTitle, BorderLayout.NORTH);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Mã phòng", "Số phòng", "Vị trí Tầng"});

        tblPhong = new JTable(model);
        tblPhong.setFont(MAIN_FONT);
        tblPhong.setRowHeight(30); // Dòng cao dễ nhìn hơn
        tblPhong.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblPhong.setGridColor(new Color(230, 233, 240));

        // Tân trang Header của JTable
        JTableHeader header = tblPhong.getTableHeader();
        header.setFont(HEADER_FONT);
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));

        // Căn giữa toàn bộ nội dung trong bảng cho đẹp mắt
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tblPhong.setDefaultRenderer(Object.class, centerRenderer);

        JScrollPane scrollPane = new JScrollPane(tblPhong);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(210, 215, 225)));
        pnlCenter.add(scrollPane, BorderLayout.CENTER);
        add(pnlCenter, BorderLayout.CENTER);

        // ----------------- PANEL PHÍA DƯỚI (NÚT CHỨC NĂNG) -----------------
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        pnlBottom.setBackground(Color.WHITE);
        pnlBottom.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220, 224, 230)));

		/*
		 * btnThemPhong = new JButton("LẬP PHIẾU THUÊ");
		 * btnThemPhong.setFont(HEADER_FONT); btnThemPhong.setBackground(SUCCESS_COLOR);
		 * btnThemPhong.setForeground(Color.WHITE); btnThemPhong.setFocusPainted(false);
		 * btnThemPhong.setPreferredSize(new Dimension(200, 40));
		 * btnThemPhong.setCursor(new Cursor(Cursor.HAND_CURSOR));
		 */

        btnXacNhan = new JButton("XÁC NHẬN ĐẶT PHÒNG");
        btnXacNhan.setFont(HEADER_FONT);
        btnXacNhan.setBackground(PRIMARY_COLOR);
        btnXacNhan.setForeground(Color.WHITE);
        btnXacNhan.setFocusPainted(false);
        btnXacNhan.setPreferredSize(new Dimension(220, 40));
        btnXacNhan.setCursor(new Cursor(Cursor.HAND_CURSOR));

		/*
		 * pnlBottom.add(btnThemPhong);
		 */        pnlBottom.add(btnXacNhan);
        add(pnlBottom, BorderLayout.SOUTH);

        // ----------------- KHU VỰC LISTENERS (GIỮ NGUYÊN 100%) -----------------
        cboLoaiPhong.addActionListener(e->{
            hienThiLoaiPhong();
            loadPhongTrong();
            tinhTien();
        });

        dcNhan.getDateEditor().addPropertyChangeListener(evt -> {
            if (!"date".equals(evt.getPropertyName())) return;
            if (dcNhan.getDate() == null) return;

            Calendar c = Calendar.getInstance();
            c.setTime(dcNhan.getDate());
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);

            java.util.Date ngayNhan = c.getTime();
            c.add(Calendar.DATE, 1);
            java.util.Date ngayTraMin = c.getTime();

            dcTra.setMinSelectableDate(ngayTraMin);

            if (dcTra.getDate() == null || !dcTra.getDate().after(ngayNhan)) {
                dcTra.setDate(ngayTraMin);
            }

            loadPhongTrong();
            tinhTien();
        });

        dcTra.getDateEditor().addPropertyChangeListener(evt -> {
            if (!"date".equals(evt.getPropertyName())) return;
            if (dcNhan.getDate() == null || dcTra.getDate() == null) return;

            if (!dcTra.getDate().after(dcNhan.getDate())) {
                JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn ngày nhận ít nhất 1 ngày.");
                Calendar c = Calendar.getInstance();
                c.setTime(dcNhan.getDate());
                c.add(Calendar.DATE, 1);
                dcTra.setDate(c.getTime());
                return;
            }

            loadPhongTrong();
            tinhTien();
        });

		/*
		 * btnThemPhong.addActionListener(e->themPhong());
		 */        btnXacNhan.addActionListener(e -> xacNhanThue());
    }

    private void loadLoaiPhong(){
        cboLoaiPhong.removeAllItems();
        for(LoaiPhong lp : loaiBUS.getAll()){
            cboLoaiPhong.addItem(lp);
        }
    }

    private void hienThiLoaiPhong(){
        LoaiPhong lp = (LoaiPhong)cboLoaiPhong.getSelectedItem();
        if(lp==null) return;
        txtMoTa.setText(lp.getMoTa() + "\nGiá: " + lp.getDonGia());
    }

    private void tinhTien(){
        if(dcNhan.getDate()==null || dcTra.getDate()==null) return;
        LoaiPhong lp = (LoaiPhong)cboLoaiPhong.getSelectedItem();
        if(lp==null) return;

        Calendar calNhan = Calendar.getInstance();
        calNhan.setTime(dcNhan.getDate());
        calNhan.set(Calendar.HOUR_OF_DAY, 0);
        calNhan.set(Calendar.MINUTE, 0);
        calNhan.set(Calendar.SECOND, 0);
        calNhan.set(Calendar.MILLISECOND, 0);

        Calendar calTra = Calendar.getInstance();
        calTra.setTime(dcTra.getDate());
        calTra.set(Calendar.HOUR_OF_DAY, 0);
        calTra.set(Calendar.MINUTE, 0);
        calTra.set(Calendar.SECOND, 0);
        calTra.set(Calendar.MILLISECOND, 0);

        long soNgay =
                (calTra.getTimeInMillis()
                - calNhan.getTimeInMillis())
                / (24 * 60 * 60 * 1000);
        if(soNgay<=0){
            txtSoNgay.setText("");
            txtTongTien.setText("");
            return;
        }

        txtSoNgay.setText(String.valueOf(soNgay));
        txtTongTien.setText(String.valueOf(soNgay * lp.getDonGia()));
    }

    private boolean kiemTraNgayThue() {
        if (dcNhan.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn ngày nhận.");
            return false;
        }
        if (dcTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn ngày trả.");
            return false;
        }

        Calendar homNay = Calendar.getInstance();
        homNay.set(Calendar.HOUR_OF_DAY, 0);
        homNay.set(Calendar.MINUTE, 0);
        homNay.set(Calendar.SECOND, 0);
        homNay.set(Calendar.MILLISECOND, 0);

        Calendar ngayNhan = Calendar.getInstance();
        ngayNhan.setTime(dcNhan.getDate());
        ngayNhan.set(Calendar.HOUR_OF_DAY, 0);
        ngayNhan.set(Calendar.MINUTE, 0);
        ngayNhan.set(Calendar.SECOND, 0);
        ngayNhan.set(Calendar.MILLISECOND, 0);

        Calendar ngayTra = Calendar.getInstance();
        ngayTra.setTime(dcTra.getDate());
        ngayTra.set(Calendar.HOUR_OF_DAY, 0);
        ngayTra.set(Calendar.MINUTE, 0);
        ngayTra.set(Calendar.SECOND, 0);
        ngayTra.set(Calendar.MILLISECOND, 0);

        if (ngayNhan.before(homNay)) {
            JOptionPane.showMessageDialog(this, "Ngày nhận không được nhỏ hơn hôm nay.");
            return false;
        }

        Calendar minTra = (Calendar) ngayNhan.clone();
        minTra.add(Calendar.DATE, 1);

        if (ngayTra.before(minTra)) {
            JOptionPane.showMessageDialog(this, "Ngày trả phải sau ngày nhận ít nhất 1 ngày.");
            return false;
        }
        return true;
    }

    private void xacNhanThue() {
    	themPhong();
        if (maPhieuThueHienTai == null) {
            JOptionPane.showMessageDialog(this, "Chưa có phòng nào được thêm.");
            return;
        }

        HoaDon hd = new HoaDon();
        hd.setMaPhieuThue(maPhieuThueHienTai);
        hd.setMaNhanVien(1);
        hd.setNgayLap(new Timestamp(System.currentTimeMillis()));

        double tongTien = Double.parseDouble(txtTongTien.getText());
        hd.setTongTien(tongTien);
        hd.setTienKhachTra(0);
        hd.setTienConLai(tongTien);
        hd.setHinhThucThanhToan("");
        hd.setTrangThaiThanhToan("CHUA_THANH_TOAN");
        hd.setGhiChu("");

        int maHD = hoaDonBUS.insertAndGetId(hd);

        if (maHD <= 0) {
            JOptionPane.showMessageDialog(this, "Tạo hóa đơn thất bại.");
            return;
        }

        maHoaDonHienTai = maHD;
         moNhanPhongForm();
    }

    private void moNhanPhongForm() {
        JDesktopPane desktop = getDesktopPane();
        if (desktop == null) return;

        NhanPhongForm1 form = new NhanPhongForm1(maHoaDonHienTai);
        desktop.add(form);
        form.setVisible(true);
        dispose();
    }

    private void loadPhongTrong(){
        model.setRowCount(0);

        if(dcNhan.getDate()==null || dcTra.getDate()==null){
            return;
        }

        LoaiPhong lp = (LoaiPhong)cboLoaiPhong.getSelectedItem();
        if(lp==null){
            return;
        }

        java.sql.Date ngayNhan = new java.sql.Date(dcNhan.getDate().getTime());
        java.sql.Date ngayTra = new java.sql.Date(dcTra.getDate().getTime());

        for(Phong p : phongBUS.getAll()){
            if(p.getMaLoaiPhong() != lp.getMaLoaiPhong()){
                continue;
            }

            boolean trong = ctdpBUS.isPhongTrong(p.getMaPhong(), ngayNhan, ngayTra);

            if(trong){
                model.addRow(new Object[]{
                        p.getMaPhong(),
                        p.getSoPhong(),
                        p.getTang()
                });
            }
        }
    }

    private void themPhong(){
        if (!kiemTraNgayThue()) {
            return;
        }
        int row = tblPhong.getSelectedRow();

        if(row==-1){
            JOptionPane.showMessageDialog(this, "Chọn phòng");
            return;
        }

        int maPhong = Integer.parseInt(model.getValueAt(row, 0).toString());
        LoaiPhong lp = (LoaiPhong)cboLoaiPhong.getSelectedItem();

        if(maPhieuThueHienTai == null){
            PhieuThuePhong pt = new PhieuThuePhong();
            pt.setMaKhachHang(kh.getMaKhachHang());
            pt.setMaNhanVien(1);
            pt.setNgayNhanPhong(new Timestamp(System.currentTimeMillis()));
            pt.setNgayTraPhongDuKien(new java.sql.Date(dcTra.getDate().getTime()));
            pt.setTrangThai("DANG_THUE");

            int maPT = ptBUS.insertAndGetId(pt);

            if(maPT <= 0){
                JOptionPane.showMessageDialog(this, "Tạo phiếu thuê thất bại");
                return;
            }

            maPhieuThueHienTai = maPT;
            lblMaPhieuThue.setText("Mã phiếu thuê: " + maPT);
        }
        
        if(ctBUS.exists(maPhieuThueHienTai, maPhong)){
            JOptionPane.showMessageDialog(this, "Phòng đã tồn tại trong phiếu thuê");
            return;
        }
        
        ChiTietThuePhong ct = new ChiTietThuePhong();
        ct.setMaPhieuThue(maPhieuThueHienTai);
        ct.setMaPhong(maPhong);
        ct.setMaKhachHang(kh.getMaKhachHang());
        ct.setDonGia(lp.getDonGia());

        ctBUS.insert(ct);
        phongBUS.updateTrangThai(maPhong, "DANG_THUE");

        loadPhongTrong();
        JOptionPane.showMessageDialog(this, "Đã thêm phòng vào phiếu thuê");
    }
}