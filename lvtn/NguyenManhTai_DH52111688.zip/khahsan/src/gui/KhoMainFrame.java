package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class KhoMainFrame extends JFrame {

    private JDesktopPane desktop;
    
    // Hệ màu Flat Modern UI cao cấp
    private static final Color MAU_SIDEBAR = new Color(30, 41, 59);    // Slate 800 (Nền thanh bên)
    private static final Color MAU_MENU_ACTIVE = new Color(15, 23, 42); // Slate 900 (Nút khi kích hoạt)
    private static final Color MAU_TEXT_NHE = new Color(241, 245, 249); // Chữ trắng sáng dịu
    private static final Color NEN_DESKTOP = new Color(241, 245, 249);  // Nền xám nhạt cho khu vực làm việc

    public KhoMainFrame() {
        setTitle("HỆ THỐNG QUẢN LÝ KHO");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Cấu trúc bố cục chính ---
        JPanel pnlMainLayout = new JPanel(new BorderLayout());
        setContentPane(pnlMainLayout);

        // 1. THANH ĐIỀU HƯỚNG DỌC BÊN TRÁI (SIDEBAR)代替 FlowLayout CŨ
        JPanel pnlSidebar = new JPanel();
        pnlSidebar.setLayout(new BoxLayout(pnlSidebar, BoxLayout.Y_AXIS));
        pnlSidebar.setBackground(MAU_SIDEBAR);
        pnlSidebar.setBorder(new EmptyBorder(20, 10, 20, 10));
        pnlSidebar.setPreferredSize(new Dimension(260, 0));

        // Tiêu đề ứng dụng trên Sidebar
        JLabel lblLogo = new JLabel("HỆ THỐNG KHO");
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblLogo.setForeground(Color.WHITE);
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblLogo.setBorder(new EmptyBorder(0, 0, 30, 0));
        pnlSidebar.add(lblLogo);

        // Khởi tạo các nút chức năng phẳng
        JButton btnNhapKho = taoNutSidebar("Quản lý nhập kho");
        JButton btnNhaCungCap = taoNutSidebar("Quản lý nhà cung cấp");
        JButton btnKho = taoNutSidebar("Quản lý kho");
        JButton btnTaiKhoan = taoNutSidebar("Tài khoản cá nhân");

        pnlSidebar.add(btnNhapKho);
        pnlSidebar.add(Box.createVerticalStrut(10)); // Khoảng cách giữa các nút
        pnlSidebar.add(btnNhaCungCap);
        pnlSidebar.add(Box.createVerticalStrut(10));
        pnlSidebar.add(btnKho);
        pnlSidebar.add(Box.createVerticalStrut(10));
        pnlSidebar.add(btnTaiKhoan);

        pnlMainLayout.add(pnlSidebar, BorderLayout.WEST);

        // 2. VÙNG HIỂN THỊ CHÍNH (DESKTOP PANE)
        desktop = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(NEN_DESKTOP);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        pnlMainLayout.add(desktop, BorderLayout.CENTER);

        // 3. THANH MENU NGANG (MENUBAR CO TINH CHỈNH FLAT)
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(Color.WHITE);
        menuBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));

        JMenu menuKho = new JMenu("Quản lý kho");
        JMenu menuTaiKhoan = new JMenu("Tài khoản");
        styleMenu(menuKho);
        styleMenu(menuTaiKhoan);

        JMenuItem mnTaiKhoan = new JMenuItem("Tài khoản cá nhân");
        menuTaiKhoan.add(mnTaiKhoan);

        JMenuItem mnNhapKho = new JMenuItem("Quản lý nhập kho");
        JMenuItem mnNhaCungCap = new JMenuItem("Quản lý nhà cung cấp");
        JMenuItem mnKho = new JMenuItem("Quản lý kho");

        menuKho.add(mnNhapKho);
        menuKho.add(mnNhaCungCap);
        menuKho.add(mnKho);

        menuBar.add(menuKho);
        menuBar.add(menuTaiKhoan);
        setJMenuBar(menuBar);

        // --- GÁN EVENTS (Giữ nguyên logic của bạn) ---
        btnNhapKho.addActionListener(e -> moNhapKho());
        btnNhaCungCap.addActionListener(e -> moNhaCungCap());
        btnKho.addActionListener(e -> moKho());
        btnTaiKhoan.addActionListener(e -> moTaiKhoan());

        mnNhapKho.addActionListener(e -> moNhapKho());
        mnNhaCungCap.addActionListener(e -> moNhaCungCap());
        mnKho.addActionListener(e -> moKho());
        mnTaiKhoan.addActionListener(e -> moTaiKhoan());
    }

    // =====================================================================
    // LOGIC CÁC HÀM MỞ FORM (Bổ sung tính năng mở full tự động)
    // =====================================================================
    private void moNhapKho() {
        QuanLyNhapKhoForm form = new QuanLyNhapKhoForm();
        desktop.add(form);
        form.setVisible(true);
        try {
            form.setMaximum(true); // Tự động bung to hết cỡ (Full Form)
            form.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void moTaiKhoan() {
        TaiKhoanCaNhanForm form = new TaiKhoanCaNhanForm();
        desktop.add(form);
        form.setVisible(true);
        try {
            form.setMaximum(true); // Tự động bung to hết cỡ (Full Form)
            form.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void moNhaCungCap() {
        QuanLyNhaCungCapForm form = new QuanLyNhaCungCapForm();
        desktop.add(form);
        form.setVisible(true);
        try {
            form.setMaximum(true); // Tự động bung to hết cỡ (Full Form)
            form.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void moKho() {
        QuanLyKhoForm form = new QuanLyKhoForm();
        desktop.add(form);
        form.setVisible(true);
        try {
            form.setMaximum(true); // Tự động bung to hết cỡ (Full Form)
            form.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // =====================================================================
    // THIẾT KẾ HELPER COMPONENT FLAT UI
    // =====================================================================
    private JButton taoNutSidebar(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(MAU_TEXT_NHE);
        btn.setBackground(MAU_SIDEBAR);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(240, 45));
        btn.setPreferredSize(new Dimension(240, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Thiết lập viền trong nút thoáng mắt
        btn.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        // Tạo hiệu ứng Hover (rê chuột đổi màu)
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(MAU_MENU_ACTIVE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(MAU_SIDEBAR);
            }
        });
        return btn;
    }

    private void styleMenu(JMenu menu) {
        menu.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        menu.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
    }
}