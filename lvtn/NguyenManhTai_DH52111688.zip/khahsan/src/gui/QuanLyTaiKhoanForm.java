package gui;

import bus.NhanVienBUS;
import bus.TaiKhoanBUS;
import bus.VaiTroBUS;
import model.NhanVien;
import model.TaiKhoan;
import model.VaiTro;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyTaiKhoanForm extends JInternalFrame {

    JTextField txtUser;
    JTextField txtPass;

    JComboBox<VaiTro> cboVaiTro;

    JCheckBox chkTrangThai;

    JButton btnCapTaiKhoan;
    JButton btnSua;
    JButton btnXoa;
    JButton btnLamMoi;

    JTable tableDaCap;
    JTable tableChuaCap;

    DefaultTableModel modelDaCap;
    DefaultTableModel modelChuaCap;

    TaiKhoanBUS taiKhoanBUS = new TaiKhoanBUS();
    NhanVienBUS nhanVienBUS = new NhanVienBUS();
    VaiTroBUS vaiTroBUS = new VaiTroBUS();

    int selectedMaTaiKhoan = -1;
    int selectedMaNhanVien = -1;

    // Hệ màu UI Cao Cấp (Slate & Teal Accent)
    private static final Color MAU_CHINH = new Color(14, 116, 144);    // Cyan/Teal đậm chuyên nghiệp
    private static final Color MAU_XOA = new Color(225, 29, 72);       // Đỏ Rose cho nút xóa
    private static final Color NEN_XAM = new Color(248, 250, 252);     // Slate 50 dịu mắt
    private static final Color CHU_DAM = new Color(15, 23, 42);        // Slate 900
    private static final Color VIEN_NHE = new Color(226, 232, 240);    // Slate 200

    public QuanLyTaiKhoanForm() {
        super("QUẢN LÝ TÀI KHOẢN", true, true, true, true);

        setSize(1300, 680);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(NEN_XAM);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 20, 15, 20));

        // =====================================================================
        // PANEL TOP: KHU VỰC NHẬP LIỆU (FORM CHỨA TEXTFIELD & COMBOBOX)
        // =====================================================================
        JPanel pTopMaster = new JPanel(new BorderLayout());
        pTopMaster.setBackground(Color.WHITE);
        pTopMaster.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                new EmptyBorder(20, 25, 20, 25)
        ));

        JPanel pTop = new JPanel(new GridLayout(2, 4, 25, 15));
        pTop.setBackground(Color.WHITE);

        txtUser = new JTextField();
        txtPass = new JTextField();
        cboVaiTro = new JComboBox<>();
        chkTrangThai = new JCheckBox("Hoạt động");
        
        // Style cho Checkbox & ComboBox
        chkTrangThai.setBackground(Color.WHITE);
        chkTrangThai.setFont(new Font("Segoe UI", Font.BOLD, 13));
        chkTrangThai.setForeground(MAU_CHINH);
        cboVaiTro.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cboVaiTro.setBackground(Color.WHITE);

        styleTextField(txtUser);
        styleTextField(txtPass);
        loadVaiTro();

        // Tạo layout dạng ô nhãn trên - ô nhập dưới
        pTop.add(taoFormGroup("Tên đăng nhập", txtUser));
        pTop.add(taoFormGroup("Mật khẩu", txtPass));
        pTop.add(taoFormGroup("Vai trò bảo mật", cboVaiTro));
        pTop.add(taoFormGroup("Trạng thái tài khoản", chkTrangThai));

        pTopMaster.add(pTop, BorderLayout.CENTER);
        add(pTopMaster, BorderLayout.NORTH);

        // =====================================================================
        // PANEL CENTER: KHU VỰC BẢNG HIỂN THỊ DỮ LIỆU ĐÔI (SPLIT WINDOW)
        // =====================================================================
        JPanel pCenter = new JPanel(new GridLayout(1, 2, 20, 0));
        pCenter.setBackground(NEN_XAM);

        // ===== BẢNG 1: ĐÃ CẤP =====
        modelDaCap = new DefaultTableModel();
        modelDaCap.setColumnIdentifiers(new String[]{
                "Mã NV", "Họ tên", "Mã TK", "Tên đăng nhập", "Mã VT", "Tên vai trò", "Trạng thái"
        });
        tableDaCap = new JTable(modelDaCap);
        styleTable(tableDaCap);

        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setBackground(NEN_XAM);
        
        JLabel lblLeft = new JLabel("NHÂN VIÊN ĐÃ CÓ TÀI KHOẢN", SwingConstants.LEFT);
        lblLeft.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblLeft.setForeground(CHU_DAM);
        left.add(lblLeft, BorderLayout.NORTH);

        JScrollPane scrollLeft = new JScrollPane(tableDaCap);
        scrollLeft.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollLeft.getViewport().setBackground(Color.WHITE);
        left.add(scrollLeft, BorderLayout.CENTER);

        // ===== BẢNG 2: CHƯA CẤP =====
        modelChuaCap = new DefaultTableModel();
        modelChuaCap.setColumnIdentifiers(new String[]{
                "Mã NV", "Họ tên", "Chức vụ"
        });
        tableChuaCap = new JTable(modelChuaCap);
        styleTable(tableChuaCap);

        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(NEN_XAM);
        
        JLabel lblRight = new JLabel("NHÂN VIÊN CHƯA CÓ TÀI KHOẢN", SwingConstants.LEFT);
        lblRight.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblRight.setForeground(new Color(100, 116, 139));
        right.add(lblRight, BorderLayout.NORTH);

        JScrollPane scrollRight = new JScrollPane(tableChuaCap);
        scrollRight.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollRight.getViewport().setBackground(Color.WHITE);
        right.add(scrollRight, BorderLayout.CENTER);

        pCenter.add(left);
        pCenter.add(right);
        add(pCenter, BorderLayout.CENTER);

        // =====================================================================
        // PANEL BOTTOM: KHU VỰC CÁC NÚT THAO TÁC HÀNH ĐỘNG
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        pBottom.setBackground(NEN_XAM);

        btnCapTaiKhoan = new JButton("CẤP TÀI KHOẢN");
        btnSua = new JButton("CẬP NHẬT");
        btnXoa = new JButton("XÓA TÀI KHOẢN");
        btnLamMoi = new JButton("LÀM MỚI FORM");

        styleButton(btnCapTaiKhoan, MAU_CHINH);
        styleButton(btnSua, new Color(71, 85, 105)); // Slate Gray tinh tế cho nút sửa
        styleButton(btnXoa, MAU_XOA);
        styleButton(btnLamMoi, Color.WHITE);
        
        // Đặc chế riêng viền cho nút Làm mới nền trắng chữ đen
        btnLamMoi.setForeground(CHU_DAM);
        btnLamMoi.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));

        pBottom.add(btnCapTaiKhoan);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        pBottom.add(btnLamMoi);

        add(pBottom, BorderLayout.SOUTH);

        // Gọi nạp dữ liệu ban đầu
        loadDaCap();
        loadChuaCap();

        // =====================================================================
        // EVENT TABLE ĐÃ CẤP
        // =====================================================================
        tableDaCap.getSelectionModel().addListSelectionListener(e -> {
            int row = tableDaCap.getSelectedRow();
            if (row >= 0) {
                selectedMaNhanVien = Integer.parseInt(modelDaCap.getValueAt(row, 0).toString());
                selectedMaTaiKhoan = Integer.parseInt(modelDaCap.getValueAt(row, 2).toString());
                txtUser.setText(modelDaCap.getValueAt(row, 3).toString());
                txtPass.setText("");

                int maVT = Integer.parseInt(modelDaCap.getValueAt(row, 4).toString());
                for (int i = 0; i < cboVaiTro.getItemCount(); i++) {
                    VaiTro vt = cboVaiTro.getItemAt(i);
                    if (vt.getMaVaiTro() == maVT) {
                        cboVaiTro.setSelectedIndex(i);
                        break;
                    }
                }

                chkTrangThai.setSelected(modelDaCap.getValueAt(row, 6).toString().equals("Hoạt động"));
            }
        });

        // =====================================================================
        // EVENT TABLE CHƯA CẤP
        // =====================================================================
		/*
		 * tableChuaCap.getSelectionModel().addListSelectionListener(e -> { int row =
		 * tableChuaCap.getSelectedRow(); if (row >= 0) { selectedMaNhanVien =
		 * Integer.parseInt(modelChuaCap.getValueAt(row, 0).toString());
		 * selectedMaTaiKhoan = -1; } });
		 */
        tableChuaCap.getSelectionModel().addListSelectionListener(e -> {

            if (e.getValueIsAdjusting()) return;

            int row = tableChuaCap.getSelectedRow();

            if (row >= 0) {

                selectedMaNhanVien =
                        Integer.parseInt(modelChuaCap.getValueAt(row, 0).toString());

                selectedMaTaiKhoan = -1;

                // Lấy thông tin nhân viên
                NhanVien nv = nhanVienBUS.findById(selectedMaNhanVien);

                if (nv != null) {

                    // Tự điền email vào ô tài khoản
                    txtUser.setText(nv.getEmail());

                    // Xóa mật khẩu cũ
                    txtPass.setText("");

                    // Đưa con trỏ sang ô mật khẩu
                    txtPass.requestFocus();
                }
            }
        });
        // =====================================================================
        // BUTTON EVENTS
        // =====================================================================
        btnCapTaiKhoan.addActionListener(e -> capTaiKhoan());
        btnSua.addActionListener(e -> suaTaiKhoan());
        btnXoa.addActionListener(e -> xoaTaiKhoan());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadDaCap();
            loadChuaCap();
        });

        setVisible(true);
    }

    // =====================================================================
    // CÁC PHƯƠNG THỨC TIỆN ÍCH HỖ TRỢ ĐỔI MỚI GIAO DIỆN (UI STYLING TOOLKIT)
    // =====================================================================
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
    }

    private void styleButton(JButton btn, Color background) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(background);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(CHU_DAM);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(new Color(71, 85, 105));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, VIEN_NHE));

        // Thêm khoảng lề trái phải cho chữ trong ô dữ liệu
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 8, 0, 8));
        table.setDefaultRenderer(Object.class, renderer);
    }

    /** Tạo một khối panel gồm tiêu đề nhãn nằm bên trên thành phần nhập liệu giúp UI thoáng đãng */
    private JPanel taoFormGroup(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(100, 116, 139)); // Mắt màu Slate 500 nhẹ nhàng
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    // =====================================================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN HOÀN TOÀN KHÔNG THAY ĐỔI)
    // =====================================================================
    private void loadVaiTro() {
        cboVaiTro.removeAllItems();
        for (VaiTro vt : vaiTroBUS.getAll()) {
            cboVaiTro.addItem(vt);
        }
    }

    private void loadDaCap() {
        modelDaCap.setRowCount(0);
        for (NhanVien nv : nhanVienBUS.getAll()) {
            if (nv.getMaTaiKhoan() != null) {
                TaiKhoan tk = taiKhoanBUS.findById(nv.getMaTaiKhoan());
                if (tk != null) {
                    VaiTro vt = vaiTroBUS.findById(tk.getMaVaiTro());
                    modelDaCap.addRow(new Object[]{
                            nv.getMaNhanVien(),
                            nv.getHoTen(),
                            tk.getMaTaiKhoan(),
                            tk.getTenDangNhap(),
                            tk.getMaVaiTro(),
                            vt != null ? vt.getTenVaiTro() : "",
                            tk.isTrangThai() ? "Hoạt động" : "Khóa"
                    });
                }
            }
        }
    }

    private void loadChuaCap() {
        modelChuaCap.setRowCount(0);
        for (NhanVien nv : nhanVienBUS.getAll()) {
            if (nv.getMaTaiKhoan() == null) {
                modelChuaCap.addRow(new Object[]{
                        nv.getMaNhanVien(),
                        nv.getHoTen(),
                        nv.getChucVu()
                });
            }
        }
    }

    private void capTaiKhoan() {

        try {

            if (selectedMaNhanVien == -1) {
                JOptionPane.showMessageDialog(this,
                        "Chọn nhân viên chưa có tài khoản");
                return;
            }

            NhanVien nv = nhanVienBUS.findById(selectedMaNhanVien);

            if (nv.getMaTaiKhoan() != null) {
                JOptionPane.showMessageDialog(this,
                        "Nhân viên này đã có tài khoản!");
                return;
            }

            if (txtUser.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Tên đăng nhập không được để trống");
                txtUser.requestFocus();
                return;
            }

            if (txtPass.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Mật khẩu không được để trống");
                txtPass.requestFocus();
                return;
            }

            if (tonTaiTenDangNhap(txtUser.getText())) {
                JOptionPane.showMessageDialog(this,
                        "Tên đăng nhập đã tồn tại!");
                txtUser.requestFocus();
                return;
            }

            VaiTro vt = (VaiTro) cboVaiTro.getSelectedItem();

            TaiKhoan tk = new TaiKhoan();
            tk.setTenDangNhap(txtUser.getText().trim());
            tk.setMatKhau(txtPass.getText().trim());
            tk.setMaVaiTro(vt.getMaVaiTro());
            tk.setTrangThai(chkTrangThai.isSelected());

            if (taiKhoanBUS.insert(tk)) {

                TaiKhoan tkMoi = taiKhoanBUS.getLast();

                nv.setMaTaiKhoan(tkMoi.getMaTaiKhoan());

                nhanVienBUS.update(nv);

                JOptionPane.showMessageDialog(this,
                        "Cấp tài khoản thành công");

                loadDaCap();
                loadChuaCap();
                clearForm();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void suaTaiKhoan() {

        try {

            if (selectedMaTaiKhoan == -1) {
                JOptionPane.showMessageDialog(this,
                        "Chọn tài khoản cần sửa");
                return;
            }

            if (txtUser.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Tên đăng nhập không được để trống");
                return;
            }

            if (txtPass.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Mật khẩu không được để trống");
                return;
            }

            if (tonTaiTenDangNhapKhac(txtUser.getText(), selectedMaTaiKhoan)) {
                JOptionPane.showMessageDialog(this,
                        "Tên đăng nhập đã tồn tại!");
                return;
            }

            VaiTro vt = (VaiTro) cboVaiTro.getSelectedItem();

            TaiKhoan tk = new TaiKhoan();
            tk.setMaTaiKhoan(selectedMaTaiKhoan);
            tk.setTenDangNhap(txtUser.getText().trim());
            tk.setMatKhau(txtPass.getText().trim());
            tk.setMaVaiTro(vt.getMaVaiTro());
            tk.setTrangThai(chkTrangThai.isSelected());

            if (taiKhoanBUS.update(tk)) {

                JOptionPane.showMessageDialog(this,
                        "Sửa thành công");

                loadDaCap();
                clearForm();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoaTaiKhoan() {
        try {
            if (selectedMaTaiKhoan == -1) {
                JOptionPane.showMessageDialog(this, "Chọn tài khoản cần xóa");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Bạn có chắc muốn xóa?",
                    "Xác nhận",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                NhanVien nv = nhanVienBUS.findById(selectedMaNhanVien);
                nv.setMaTaiKhoan(null);
                nhanVienBUS.update(nv);

                taiKhoanBUS.delete(selectedMaTaiKhoan);

                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadDaCap();
                loadChuaCap();
                clearForm();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private boolean tonTaiTenDangNhap(String username) {
        for (TaiKhoan tk : taiKhoanBUS.getAll()) {
            if (tk.getTenDangNhap().equalsIgnoreCase(username.trim())) {
                return true;
            }
        }
        return false;
    }
    private boolean tonTaiTenDangNhapKhac(String username, int maTaiKhoan) {
        for (TaiKhoan tk : taiKhoanBUS.getAll()) {
            if (tk.getMaTaiKhoan() != maTaiKhoan
                    && tk.getTenDangNhap().equalsIgnoreCase(username.trim())) {
                return true;
            }
        }
        return false;
    }
    private void clearForm() {
        txtUser.setText("");
        txtPass.setText("");
        chkTrangThai.setSelected(false);
        selectedMaNhanVien = -1;
        selectedMaTaiKhoan = -1;
    }
}