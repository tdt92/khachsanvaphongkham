package gui;

import bus.*;
import model.*;
import util.Session;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
public class DatPhongForm1 extends JInternalFrame {

    private KhachHang kh;
    private Integer maPhieuDatHienTai = null;
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();
    private JTextArea txtGhiChu;
     private JButton btnXacNhan;
    private JTextField txtTenKH;
    private JTextField txtCCCD;
    private JLabel lblMaPhieuDat;
    private JComboBox<LoaiPhong> cboLoaiPhong;
    private JTextArea txtMoTa;
    private JDateChooser dcNhan;
    private JDateChooser dcTra;
    private JTextField txtSoNgay;
    private JTextField txtTongTien;
    private JTextField txtTienCoc;

    private JTable tblPhong;
    private DefaultTableModel model;
    private JButton btnDat;

    // BẢNG MÀU ĐỘ TƯƠNG PHẢN CAO - ĐẢM BẢO RÕ CHỮ
    private final Color PRIMARY_COLOR = new Color(24, 76, 120);  // Xanh biển đậm (cho tiêu đề)
    private final Color SUCCESS_COLOR = new Color(21, 115, 71);  // Xanh lá đậm (cho nút bấm)
    private final Color TEXT_DARK = new Color(17, 17, 17);       // Chữ màu đen hẳn (thay vì xám)
    private final Color BG_LIGHT = new Color(240, 242, 245);     // Nền xám nhạt để nổi khối các ô nhập

    public DatPhongForm1(KhachHang kh) {
        super("ĐẶT PHÒNG", true, true, true, true);
        this.kh = kh;

        initUI();
        loadLoaiPhong();

        txtTenKH.setText(kh.getHoTen());
        txtCCCD.setText(kh.getCccd());
    }

    private void initUI() {
        setSize(1050, 700);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(BG_LIGHT);
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));

        // ==========================================
        // PANEL TOP: THÔNG TIN VÀ BỘ LỌC
        // ==========================================
        JPanel pnlTop = new JPanel(new GridBagLayout());
        pnlTop.setBackground(Color.WHITE);
        pnlTop.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 185, 190), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        Font labelFont = new Font("Segoe UI", Font.BOLD, 13);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 13);

        txtTenKH = new JTextField();
        txtCCCD = new JTextField();
        txtTenKH.setEditable(false);
        txtCCCD.setEditable(false);

        cboLoaiPhong = new JComboBox<>();
        cboLoaiPhong.setFont(inputFont);
        cboLoaiPhong.setForeground(TEXT_DARK);

        txtMoTa = new JTextArea(3, 20);
        txtMoTa.setEditable(false);
        txtMoTa.setFont(inputFont);
        txtMoTa.setLineWrap(true);
        txtMoTa.setWrapStyleWord(true);
        txtMoTa.setDisabledTextColor(TEXT_DARK); // Ép chữ không bị mờ khi disabled
        txtGhiChu = new JTextArea(3,20);
        txtGhiChu.setFont(inputFont);
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        dcNhan = new JDateChooser();
        dcTra = new JDateChooser();

        dcNhan.setFont(inputFont);
        dcTra.setFont(inputFont);

        // ==========================
        // Thiết lập ngày mặc định
        // ==========================

        Date homNay = new Date();

        dcNhan.setDate(homNay);

        // Không cho chọn ngày quá khứ
        dcNhan.setMinSelectableDate(homNay);

        Calendar cal = Calendar.getInstance();
        cal.setTime(homNay);
        cal.add(Calendar.DATE, 1);

        // Ngày trả mặc định = ngày nhận + 1
        dcTra.setDate(cal.getTime());

        // Không cho chọn <= ngày nhận
        dcTra.setMinSelectableDate(cal.getTime());

        txtSoNgay = new JTextField();
        txtTongTien = new JTextField();
        txtTienCoc = new JTextField();
        gbc.gridy = 6;

        gbc.gridx = 0;
        gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Yêu cầu đặc biệt:", labelFont), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        gbc.weightx = 1;

        JScrollPane spGhiChu = new JScrollPane(txtGhiChu);
        spGhiChu.setPreferredSize(new Dimension(300,70));

        pnlTop.add(spGhiChu, gbc);

        gbc.gridwidth = 1;
        txtSoNgay.setEditable(false);
        txtTongTien.setEditable(false);
        txtTienCoc.setEditable(false);

        // Khắc phục chữ mờ của JTextField khi setEditable(false)
        JTextField[] fields = {txtTenKH, txtCCCD, txtSoNgay, txtTongTien, txtTienCoc};
        for (JTextField f : fields) {
            f.setFont(inputFont);
            f.setForeground(TEXT_DARK);      // 👈 bắt buộc
            f.setCaretColor(TEXT_DARK);      // 👈 con trỏ đen
            f.setDisabledTextColor(TEXT_DARK);
        }

        lblMaPhieuDat = new JLabel("Mã phiếu đặt: " + maPhieuDatHienTai);
        lblMaPhieuDat.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMaPhieuDat.setForeground(PRIMARY_COLOR);

        // --- BỐ TRÍ LƯỚI GRIDBAG (SỬA LỖI ĐÈ CỘT) ---
        // Hàng 0: Mã phiếu đặt
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 4;
        pnlTop.add(lblMaPhieuDat, gbc);
        gbc.gridwidth = 1; 

        // Hàng 1: Khách hàng & CCCD
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Khách hàng:", labelFont), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        pnlTop.add(txtTenKH, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("CCCD:", labelFont), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        pnlTop.add(txtCCCD, gbc);

        // Hàng 2: Loại phòng & Ngày nhận
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Loại phòng:", labelFont), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        pnlTop.add(cboLoaiPhong, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Ngày nhận:", labelFont), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        pnlTop.add(dcNhan, gbc);

        // Hàng 3: Mô tả & Ngày trả
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Mô tả loại:", labelFont), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.gridheight = 2; 
        gbc.fill = GridBagConstraints.BOTH;
        pnlTop.add(new JScrollPane(txtMoTa), gbc);

        gbc.gridheight = 1; 
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Ngày trả:", labelFont), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        pnlTop.add(dcTra, gbc);

        // Hàng 4: Số ngày
        gbc.gridy = 4;
        gbc.gridx = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Số ngày ở:", labelFont), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        pnlTop.add(txtSoNgay, gbc);

        // Hàng 5: Tổng tiền & Tiền cọc
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Tổng tiền:", labelFont), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        pnlTop.add(txtTongTien, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        pnlTop.add(createStyledLabel("Thanh toán:", labelFont), gbc);
        gbc.gridx = 3; gbc.weightx = 1.0;
        pnlTop.add(txtTienCoc, gbc);

        add(pnlTop, BorderLayout.NORTH);

        // ==========================================
        // PANEL CENTER: DANH SÁCH PHÒNG TRỐNG
        // ==========================================
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Mã phòng", "Số phòng", "Tầng" });
        tblPhong = new JTable(model);
        
        // Cấu hình bảng chữ đen đậm, rõ nét
        tblPhong.setFont(inputFont);
        tblPhong.setForeground(TEXT_DARK);
        tblPhong.setRowHeight(30);
        tblPhong.setGridColor(new Color(200, 205, 210));
        tblPhong.setSelectionBackground(new Color(200, 225, 245));
        tblPhong.setSelectionForeground(Color.BLACK);
        
        JTableHeader header = tblPhong.getTableHeader();
        header.setFont(labelFont);
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));

        JScrollPane scrTable = new JScrollPane(tblPhong);
        scrTable.setBackground(Color.WHITE);
        scrTable.getViewport().setBackground(Color.WHITE);
        scrTable.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(180, 185, 190)), 
                " DANH SÁCH PHÒNG TRỐNG KHẢ DỤNG ", 
                TitledBorder.LEFT, 
                TitledBorder.TOP, 
                labelFont, 
                PRIMARY_COLOR
        ));

        add(scrTable, BorderLayout.CENTER);

        // ==========================================
        // PANEL BOTTOM: NÚT BẤM XÁC NHẬN
        // ==========================================
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBottom.setOpaque(false);
         btnXacNhan = new JButton("XÁC NHẬN");

         pnlBottom.add(btnXacNhan);
        btnDat = new JButton("ĐẶT PHÒNG");
        btnDat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDat.setBackground(SUCCESS_COLOR);
        btnDat.setForeground(Color.WHITE);
        btnDat.setFocusPainted(false);
        btnDat.setBorder(new EmptyBorder(12, 30, 12, 30));
        btnDat.setCursor(new Cursor(Cursor.HAND_CURSOR));

        pnlBottom.add(btnDat);
        add(pnlBottom, BorderLayout.SOUTH);

        // ==========================================
        // LOGIC SỰ KIỆN GỐC (GIỮ NGUYÊN)
        // ==========================================
        cboLoaiPhong.addActionListener(e -> {
            LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();
            if(lp==null) return;
            txtMoTa.setText(lp.getMoTa() + "\nGiá: " + lp.getDonGia() + " VNĐ/đêm");
            loadPhongTrong();
            tinhTien();
        });

        dcNhan.getDateEditor().addPropertyChangeListener(evt -> {

            if (!"date".equals(evt.getPropertyName()))
                return;

            if (dcNhan.getDate() == null)
                return;

            Calendar calNgayTra = Calendar.getInstance();
            calNgayTra.setTime(dcNhan.getDate());
            calNgayTra.add(Calendar.DATE, 1);

            // Không cho chọn ngày trả <= ngày nhận
            dcTra.setMinSelectableDate(calNgayTra.getTime());

            // Nếu ngày trả đang sai thì tự nhảy sang ngày hôm sau
            if (dcTra.getDate() == null ||
                    !dcTra.getDate().after(dcNhan.getDate())) {

                dcTra.setDate(calNgayTra.getTime());
            }

            loadPhongTrong();
            tinhTien();
        });
 
        dcTra.getDateEditor().addPropertyChangeListener(evt -> {

            if (!"date".equals(evt.getPropertyName()))
                return;

            if (dcNhan.getDate() == null ||
                    dcTra.getDate() == null)
                return;

            if (!dcTra.getDate().after(dcNhan.getDate())) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ngày trả phải lớn hơn ngày nhận ít nhất 1 ngày."
                );

                Calendar calNgayTra = Calendar.getInstance();
                calNgayTra.setTime(dcNhan.getDate());
                calNgayTra.add(Calendar.DATE, 1);

                dcTra.setDate(calNgayTra.getTime());
                return;
            }

            loadPhongTrong();
            tinhTien();
        });
        btnXacNhan.addActionListener(e -> moChiTietPhieuDat());
        dcTra.getDateEditor().addPropertyChangeListener(evt -> {
            loadPhongTrong();
            tinhTien();
        });
        btnDat.addActionListener(e -> datPhong());
    }

    private JLabel createStyledLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(TEXT_DARK);
        return label;
    }

    // --- CÁC HÀM NGHIỆP VỤ BÊN DƯỚI GIỮ NGUYÊN HOÀN TOÀN 100% ---
    private void loadLoaiPhong(){
        cboLoaiPhong.removeAllItems();
        for(LoaiPhong lp : loaiBUS.getAll()){
            cboLoaiPhong.addItem(lp);
        }
    }

    private void tinhTien(){
        if(dcNhan.getDate()==null || dcTra.getDate()==null) return;
        LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if(lp==null) return;

        long soNgay = (dcTra.getDate().getTime() - dcNhan.getDate().getTime()) / (1000*60*60*24);
        if(soNgay<=0){
            txtSoNgay.setText("");
            txtTongTien.setText("");
            txtTienCoc.setText("");
            return;
        }

        double tongTien = soNgay * lp.getDonGia();
        double tienCoc = tongTien;

        txtSoNgay.setText(String.valueOf(soNgay));
        txtTongTien.setText(String.valueOf(tongTien));
        txtTienCoc.setText(String.valueOf(tongTien));
    }

    private void loadPhongTrong(){
        model.setRowCount(0);
        if(dcNhan.getDate()==null || dcTra.getDate()==null) return;
        LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if(lp==null) return;

        java.sql.Date ngayNhan = new java.sql.Date(dcNhan.getDate().getTime());
        java.sql.Date ngayTra = new java.sql.Date(dcTra.getDate().getTime());

        for(Phong p : phongBUS.getAll()){
            if(p.getMaLoaiPhong() != lp.getMaLoaiPhong()) continue;
            boolean trong = ctdpBUS.isPhongTrong(p.getMaPhong(), ngayNhan, ngayTra);
            if(trong){
                model.addRow(new Object[]{
                        p.getMaPhong(),
                        p.getSoPhong(),
                        p.getTang(),
                        p.getTrangThai()
                });
            }
        }
    }
    private void moChiTietPhieuDat() {

        if (maPhieuDatHienTai == null) {
            JOptionPane.showMessageDialog(this, "Chưa có phiếu đặt");
            return;
        }

        // Tính lại tổng tiền
        double tongTien = tinhTongTienPhieuDat(maPhieuDatHienTai);

        // Cập nhật phiếu đặt
        PhieuDatPhong pd = pdBUS.findById(maPhieuDatHienTai);
        pd.setTienCoc(tongTien);
        pdBUS.update(pd);

        txtTongTien.setText(String.valueOf(tongTien));
        txtTienCoc.setText(String.valueOf(tongTien));

        ChiTietPhieuDatForm form = new ChiTietPhieuDatForm(maPhieuDatHienTai);
        getDesktopPane().add(form);
        form.setVisible(true);

        dispose();
    }
    private double tinhTongTienPhieuDat(int maPhieuDat) {
        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        if (pd == null) return 0;

        long soNgay = (pd.getNgayTraPhong().getTime() - pd.getNgayNhanPhong().getTime())
                / (1000 * 60 * 60 * 24);

        if (soNgay <= 0) soNgay = 1;

        double tongTien = 0;

        for (ChiTietDatPhong ct : ctdpBUS.getByPhieuDat(maPhieuDat)) {

            Phong p = phongBUS.findById(ct.getMaPhong());
            if (p == null) continue;

            LoaiPhong lp = loaiBUS.findById(p.getMaLoaiPhong());
            if (lp == null) continue;

            tongTien += lp.getDonGia() * soNgay;
        }

        return tongTien;
    }
    private boolean kiemTraNgayDat() {

        if (dcNhan.getDate() == null || dcTra.getDate() == null) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn ngày nhận và ngày trả.");
            return false;
        }

        Calendar homNay = Calendar.getInstance();
        homNay.set(Calendar.HOUR_OF_DAY, 0);
        homNay.set(Calendar.MINUTE, 0);
        homNay.set(Calendar.SECOND, 0);
        homNay.set(Calendar.MILLISECOND, 0);

        Calendar ngayNhan = Calendar.getInstance();
        ngayNhan.setTime(dcNhan.getDate());
        ngayNhan.set(Calendar.HOUR_OF_DAY, 0);
        ngayNhan.set(Calendar.MINUTE, 0);
        ngayNhan.set(Calendar.SECOND, 0);
        ngayNhan.set(Calendar.MILLISECOND, 0);

        Calendar ngayTra = Calendar.getInstance();
        ngayTra.setTime(dcTra.getDate());
        ngayTra.set(Calendar.HOUR_OF_DAY, 0);
        ngayTra.set(Calendar.MINUTE, 0);
        ngayTra.set(Calendar.SECOND, 0);
        ngayTra.set(Calendar.MILLISECOND, 0);

        if (ngayNhan.before(homNay)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Ngày nhận không được nhỏ hơn hôm nay.");
            return false;
        }

        if (!ngayTra.after(ngayNhan)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Ngày trả phải lớn hơn ngày nhận ít nhất 1 ngày.");
            return false;
        }

        return true;
    }
    private void datPhong(){
    	if (!kiemTraNgayDat()) {
    	    return;
    	}

        int row = tblPhong.getSelectedRow();
        if(row==-1){
            JOptionPane.showMessageDialog(this, "Chọn phòng");
            return;
        }

        int maPhong = Integer.parseInt(model.getValueAt(row, 0).toString());
        int maPD;

        if(maPhieuDatHienTai == null){
        	
            PhieuDatPhong pd = new PhieuDatPhong();
            pd.setMaNhanVien(Session.taiKhoanDangNhap.getMaNhanVien());
            pd.setMaKhachHang(kh.getMaKhachHang());
            pd.setNgayDat(new Timestamp(System.currentTimeMillis()));
            pd.setNgayNhanPhong(new java.sql.Date(dcNhan.getDate().getTime()));
            pd.setNgayTraPhong(new java.sql.Date(dcTra.getDate().getTime()));
            pd.setTienCoc(Double.parseDouble(txtTienCoc.getText()));
            pd.setGhiChu(txtGhiChu.getText().trim());
            pd.setTrangThai("DA_DAT");

            maPD = pdBUS.insertAndGetId(pd);
            if(maPD <= 0){
                JOptionPane.showMessageDialog(this, "Tạo phiếu đặt thất bại");
                return;
            }
            maPhieuDatHienTai = maPD;
            lblMaPhieuDat.setText("Mã phiếu đặt: " + maPD);
        }else{
            maPD = maPhieuDatHienTai;
        }

        ChiTietDatPhong ct = new ChiTietDatPhong();
        ct.setMaPhieuDat(maPD);
        ct.setMaPhong(maPhong);
        ct.setMaKhachHang(kh.getMaKhachHang());

        if(ctdpBUS.getByPhieuDat(maPD).stream().anyMatch(x -> x.getMaPhong() == maPhong)){
            JOptionPane.showMessageDialog(this, "Phòng này đã nằm trong phiếu đặt");
            return;
        }
        if (ctdpBUS.insert(ct)) {

            // Tính lại tổng tiền của toàn bộ phiếu đặt
            double tongTien = tinhTongTienPhieuDat(maPD);

            // Cập nhật tiền cọc = tổng tiền
            PhieuDatPhong pd = pdBUS.findById(maPD);
            pd.setTienCoc(tongTien);
            pdBUS.update(pd);

            // Hiển thị lên giao diện
            txtTongTien.setText(String.valueOf(tongTien));
            txtTienCoc.setText(String.valueOf(tongTien));

            loadPhongTrong();

            JOptionPane.showMessageDialog(
                    this,
                    "Đã thêm phòng vào phiếu đặt: " + maPhieuDatHienTai
            );
        }
        else {
            JOptionPane.showMessageDialog(this, "Đặt phòng thất bại");
        }
    }
}