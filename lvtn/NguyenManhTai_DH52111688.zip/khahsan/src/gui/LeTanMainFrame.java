package gui;

import javax.swing.*;
import java.awt.*;

public class LeTanMainFrame extends JFrame {

    private JDesktopPane desktopPane;

    public LeTanMainFrame() {
        setTitle("HỆ THỐNG QUẢN LÝ LỄ TÂN KHÁCH SẠN");
        setSize(1420, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Khởi tạo JDesktopPane nền sẫm màu sang trọng giúp các khung Form con nổi bật lên hẳn
        desktopPane = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(236, 240, 241)); // Tạo màu nền xám dịu mắt cho khu vực làm việc
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        add(desktopPane, BorderLayout.CENTER);

        LeTanForm form = new LeTanForm(desktopPane);
        desktopPane.add(form);

        form.setVisible(true);

        // PHÓNG TO FULL MÀN HÌNH FORM LỄ TÂN TRONG DESKTOP PANE
        try {
            form.setMaximum(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }
    }

    public JDesktopPane getDesktopPane() {
        return desktopPane;
    }
}