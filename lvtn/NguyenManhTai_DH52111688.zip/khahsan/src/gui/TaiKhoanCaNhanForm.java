package gui;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import bus.NhanVienBUS;
import bus.TaiKhoanBUS;
import model.NhanVien;
import model.TaiKhoan;
import util.Session;

public class TaiKhoanCaNhanForm extends JInternalFrame {

    JTextField txtTenDangNhap;
    JTextField txtHoTen;
    JTextField txtSDT;
    JTextField txtEmail;
    JTextField txtDiaChi;

    JPasswordField txtMK;

    JButton btnCapNhat;
    JButton btnLamMoi;

    TaiKhoanBUS tkBUS = new TaiKhoanBUS();
    NhanVienBUS nvBUS = new NhanVienBUS();

    // Bảng màu chủ đạo
    private final Color MAU_NEN = new Color(245, 247, 250);
    private final Color MAU_CHINH = new Color(41, 128, 185);
    private final Color MAU_CHINH_HOVER = new Color(52, 152, 219);
    private final Color MAU_LAMMOI = new Color(149, 165, 166);
    private final Color MAU_LAMMOI_HOVER = new Color(127, 140, 141);
    private final Color MAU_VIEN = new Color(210, 214, 220);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font FONT_FIELD = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 20);
    private final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    public TaiKhoanCaNhanForm() {

        super(
                "Tài Khoản Cá Nhân",
                true,   // closable
                true,   // resizable
                true,   // maximizable
                true    // iconifiable
        );

        setSize(520, 480);
        getContentPane().setBackground(MAU_NEN);
        setLayout(new BorderLayout());

        // ===== Panel tiêu đề =====
        JPanel panelTitle = new JPanel();
        panelTitle.setBackground(MAU_CHINH);
        panelTitle.setPreferredSize(new Dimension(0, 60));
        JLabel lblTitle = new JLabel("👤 THÔNG TIN TÀI KHOẢN CÁ NHÂN");
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(Color.WHITE);
        panelTitle.add(lblTitle);
        add(panelTitle, BorderLayout.NORTH);

        // ===== Panel form nhập liệu =====
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(MAU_NEN);
        panelForm.setBorder(new EmptyBorder(25, 35, 10, 35));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtTenDangNhap = taoTextField();
        txtHoTen = taoTextField();
        txtSDT = taoTextField();
        txtEmail = taoTextField();
        txtDiaChi = taoTextField();
        txtMK = new JPasswordField();
        styleField(txtMK);

        // Tên đăng nhập và họ tên không cho sửa
        txtTenDangNhap.setEditable(false);
        txtHoTen.setEditable(false);
        txtTenDangNhap.setBackground(new Color(235, 236, 238));
        txtHoTen.setBackground(new Color(235, 236, 238));

        int row = 0;
        row = themDong(panelForm, gbc, row, "Tên đăng nhập", txtTenDangNhap);
        row = themDong(panelForm, gbc, row, "Họ tên", txtHoTen);
        row = themDong(panelForm, gbc, row, "Mật khẩu", txtMK);
        row = themDong(panelForm, gbc, row, "Số điện thoại", txtSDT);
        row = themDong(panelForm, gbc, row, "Email", txtEmail);
        row = themDong(panelForm, gbc, row, "Địa chỉ", txtDiaChi);

        add(panelForm, BorderLayout.CENTER);

        // ===== Panel nút bấm =====
        JPanel panelButton = new JPanel();
        panelButton.setBackground(MAU_NEN);
        panelButton.setBorder(new EmptyBorder(0, 0, 20, 0));

        btnCapNhat = taoButton("Cập Nhật", MAU_CHINH, MAU_CHINH_HOVER);
        btnLamMoi = taoButton("Làm Mới", MAU_LAMMOI, MAU_LAMMOI_HOVER);

        panelButton.add(btnCapNhat);
        panelButton.add(Box.createHorizontalStrut(15));
        panelButton.add(btnLamMoi);

        add(panelButton, BorderLayout.SOUTH);

        loadThongTin();

        btnCapNhat.addActionListener(e -> capNhat());
        btnLamMoi.addActionListener(e -> loadThongTin());

        setVisible(true);
    }

    // ================== CÁC HÀM HỖ TRỢ GIAO DIỆN ==================

    private JTextField taoTextField() {
        JTextField txt = new JTextField();
        styleField(txt);
        return txt;
    }

    private void styleField(JTextField txt) {
        txt.setFont(FONT_FIELD);
        txt.setPreferredSize(new Dimension(260, 34));
        txt.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(MAU_VIEN, 1, true),
                new EmptyBorder(4, 10, 4, 10)
        ));
    }

    private int themDong(JPanel panel, GridBagConstraints gbc, int row, String nhan, JTextField field) {

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel lbl = new JLabel(nhan);
        lbl.setFont(FONT_LABEL);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(field, gbc);

        return row + 1;
    }

    private JButton taoButton(String text, Color mauNen, Color mauHover) {

        JButton btn = new JButton(text);
        btn.setFont(FONT_BUTTON);
        btn.setForeground(Color.WHITE);
        btn.setBackground(mauNen);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(10, 25, 10, 25));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(mauHover);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(mauNen);
            }
        });

        return btn;
    }

    // ================== LOGIC (GIỮ NGUYÊN) ==================

    private void loadThongTin() {

        TaiKhoan tk = Session.taiKhoanDangNhap;

        if (tk != null) {

            txtTenDangNhap.setText(tk.getTenDangNhap());
            txtMK.setText(tk.getMatKhau());

            NhanVien nv = nvBUS.findByTaiKhoan(tk.getMaTaiKhoan());

            if (nv != null) {

                txtHoTen.setText(nv.getHoTen());
                txtSDT.setText(nv.getSoDienThoai());
                txtEmail.setText(nv.getEmail());
                txtDiaChi.setText(nv.getDiaChi());
            }
        }
    }

    private void capNhat() {

        TaiKhoan tk = Session.taiKhoanDangNhap;

        if (tk == null) {
            return;
        }

        String matKhauMoi = new String(txtMK.getPassword()).trim();
        String sdt = txtSDT.getText().trim();
        String email = txtEmail.getText().trim();
        String diaChi = txtDiaChi.getText().trim();

        // ================= Kiểm tra mật khẩu =================
        if (!kiemTraMatKhau(matKhauMoi)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mật khẩu phải từ 6 ký tự trở lên và gồm cả chữ và số!");

            txtMK.requestFocus();
            return;
        }

        // ================= Kiểm tra SĐT =================
        if (!kiemTraSDT(sdt)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Số điện thoại không hợp lệ!\n"
                    + "Phải gồm 10 số và bắt đầu bằng 0.");

            txtSDT.requestFocus();
            return;
        }

        // ================= Kiểm tra Email =================
        if (!kiemTraEmail(email)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Email không đúng định dạng!");

            txtEmail.requestFocus();
            return;
        }

        // Cập nhật tài khoản
        tk.setMatKhau(matKhauMoi);

        boolean ok1 = tkBUS.update(tk);

        boolean ok2 = nvBUS.updateContactInfo(
                tk.getMaTaiKhoan(),
                sdt,
                email,
                diaChi);

        if (ok1 && ok2) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cập nhật thành công!");

            Session.taiKhoanDangNhap = tk;

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Cập nhật thất bại!");
        }

        loadThongTin();
    }
 // Mật khẩu: tối thiểu 6 ký tự, có cả chữ và số
    private boolean kiemTraMatKhau(String mk) {

        return mk.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,}$");
    }
 // SĐT Việt Nam: 10 số bắt đầu bằng 0
    private boolean kiemTraSDT(String sdt) {

        return sdt.matches("^0\\d{9}$");
    }
 // Email
    private boolean kiemTraEmail(String email) {

        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }
}