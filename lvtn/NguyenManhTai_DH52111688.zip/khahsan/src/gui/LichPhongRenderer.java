package gui;

import model.CellLichPhong;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class LichPhongRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        JLabel lb =
                (JLabel) super.getTableCellRendererComponent(
                        table,
                        value,
                        isSelected,
                        hasFocus,
                        row,
                        column);

        lb.setHorizontalAlignment(JLabel.CENTER);

        lb.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));

        if(column == 0){

            lb.setBackground(new Color(245,245,245));
            lb.setForeground(Color.BLACK);

            return lb;
        }

        lb.setBackground(Color.WHITE);
        lb.setForeground(Color.BLACK);

        if(value instanceof CellLichPhong){

            CellLichPhong cell = (CellLichPhong)value;

            lb.setText(cell.getTenKhach());

            if("DA_DAT".equals(cell.getTrangThai())){

                lb.setBackground(new Color(100,181,246));
                lb.setForeground(Color.WHITE);

            }else if("DANG_THUE".equals(cell.getTrangThai())){

                lb.setBackground(new Color(255,183,77));
                lb.setForeground(Color.BLACK);
            }

        }else{

            lb.setText("");
        }

        return lb;
    }

}