package gui;
import util.Session;
import bus.*;
import model.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.Timestamp;
import java.util.List;

public class QuanLyDichVuPhongForm1 extends JInternalFrame {
	private int maPhieu;
    private JTable tblPhong;
    private JTable tblDichVu;
    private DefaultTableModel modelPhong;
    private DefaultTableModel modelDV;
     private JComboBox<DichVu> cboDichVu;
    private JTextField txtSoLuong;
    private JTextField txtThanhTien;
     private JButton btnThem;
    private JButton btnSua;
    private JButton btnXoa;
    private KhoBUS khoBUS = new KhoBUS();

    private ChiTietThuePhongBUS ctBUS = new ChiTietThuePhongBUS();
    private DichVuBUS dichVuBUS = new DichVuBUS();
    private SuDungDichVuBUS suDungBUS = new SuDungDichVuBUS();

    private List<PhongDangThueDTO> dsPhong;
    private boolean dangLoc = false;
    private List<DichVu> dsDichVu;

    // Định nghĩa bảng màu hiện đại cho giao diện khách sạn
    private final Color PRIMARY_COLOR = new Color(41, 128, 185); // Xanh dương sang trọng
    private final Color BACKGROUND_COLOR = new Color(245, 247, 250); // Xám trắng dịu mắt
    private final Color TEXT_COLOR = new Color(44, 62, 80); // Chữ xám sẫm rõ ràng
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public QuanLyDichVuPhongForm1(int maPhieu) {

        super(" DỊCH VỤ PHÒNG",
                true,true,true,true);

        this.maPhieu = maPhieu;

        setSize(1240,750);

        setLayout(new BorderLayout());

        getContentPane().setBackground(BACKGROUND_COLOR);

          // Tạo layout chia đôi trái - phải
        JSplitPane splitNgang = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitNgang.setDividerLocation(680);
        splitNgang.setBorder(null);

        /* =========================================================================
         * PANEL TRÁI: DỊCH VỤ PHÒNG ĐANG THUÊ
         * ========================================================================= */
        JPanel pnLeft = new JPanel(new BorderLayout(0, 10));
        pnLeft.setBackground(BACKGROUND_COLOR);
        pnLeft.setBorder(new EmptyBorder(10, 10, 10, 5));

        // Thanh tìm kiếm phía trên
        JPanel pnSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        pnSearch.setBackground(Color.WHITE);
        pnSearch.setBorder(new LineBorder(new Color(220, 224, 230), 1, true));

        JLabel lblTim = new JLabel("Số phòng / Khách:");
        lblTim.setFont(MAIN_FONT);
        lblTim.setForeground(TEXT_COLOR);
        
       

        

        // Bảng danh sách phòng bên trái
        modelPhong = new DefaultTableModel();
        modelPhong.addColumn("Mã Phiếu");
        modelPhong.addColumn("Mã Phòng");
        modelPhong.addColumn("Số Phòng");
        modelPhong.addColumn("Khách Hàng");
        modelPhong.addColumn("Trạng Thái");

        tblPhong = new JTable(modelPhong);
        decorTable(tblPhong);
        JScrollPane spPhong = new JScrollPane(tblPhong);
        spPhong.setBorder(new TitledBorder(new LineBorder(new Color(200, 200, 200)), "DANH SÁCH PHÒNG ĐANG THUÊ", TitledBorder.LEFT, TitledBorder.TOP, HEADER_FONT, PRIMARY_COLOR));
        pnLeft.add(spPhong, BorderLayout.CENTER);

        splitNgang.setLeftComponent(pnLeft);

        /* =========================================================================
         * PANEL PHẢI: ĐIỀU KHIỂN & CHỌN DỊCH VỤ
         * ========================================================================= */
        JPanel pnRightOuter = new JPanel(new BorderLayout());
        pnRightOuter.setBackground(BACKGROUND_COLOR);
        pnRightOuter.setBorder(new EmptyBorder(10, 5, 10, 10));

        JPanel pnRight = new JPanel(new GridBagLayout());
        pnRight.setBackground(Color.WHITE);
        pnRight.setBorder(new TitledBorder(new LineBorder(new Color(220, 224, 230), 1, true), "THÔNG TIN ĐẶT DỊCH VỤ", TitledBorder.LEFT, TitledBorder.TOP, HEADER_FONT, PRIMARY_COLOR));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.weightx = 1.0;

        // Combobox Dịch vụ
        JLabel lblDv = new JLabel("Dịch vụ:");
        lblDv.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = 0;
        pnRight.add(lblDv, gbc);

        cboDichVu = new JComboBox<>();
        cboDichVu.setFont(MAIN_FONT);
        cboDichVu.setPreferredSize(new Dimension(200, 32));
        gbc.gridx = 0; gbc.gridy = 1;
        pnRight.add(cboDichVu, gbc);

        // Ô nhập Số lượng
        JLabel lblSl = new JLabel("Số lượng:");
        lblSl.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = 2;
        pnRight.add(lblSl, gbc);

        txtSoLuong = new JTextField();
        txtSoLuong.setFont(MAIN_FONT);
        txtSoLuong.setPreferredSize(new Dimension(200, 32));
        gbc.gridx = 0; gbc.gridy = 3;
        pnRight.add(txtSoLuong, gbc);

        // Ô hiển thị Thành tiền
        JLabel lblTt = new JLabel("Thành tiền (VND):");
        lblTt.setFont(MAIN_FONT);
        gbc.gridx = 0; gbc.gridy = 4;
        pnRight.add(lblTt, gbc);

        txtThanhTien = new JTextField();
        txtThanhTien.setFont(new Font("Segoe UI", Font.BOLD, 15));
        txtThanhTien.setForeground(new Color(192, 57, 43)); // Đỏ sẫm nổi bật tiền bạc
        txtThanhTien.setBackground(new Color(245, 245, 245));
        txtThanhTien.setEditable(false);
        txtThanhTien.setPreferredSize(new Dimension(200, 32));
        gbc.gridx = 0; gbc.gridy = 5;
        pnRight.add(txtThanhTien, gbc);

        // Panel chứa các nút chức năng (Thêm, Sửa, Xóa) phối màu hiện đại
        JPanel pnButton = new JPanel(new GridLayout(1, 3, 8, 0));
        pnButton.setBackground(Color.WHITE);

        btnThem = new JButton("THÊM");
        btnThem.setFont(HEADER_FONT);
        btnThem.setBackground(new Color(46, 204, 113)); // Xanh lá
        btnThem.setForeground(Color.WHITE);
        btnThem.setFocusPainted(false);

        btnSua = new JButton("SỬA");
        btnSua.setFont(HEADER_FONT);
        btnSua.setBackground(new Color(241, 196, 15)); // Vàng cam
        btnSua.setForeground(Color.WHITE);
        btnSua.setFocusPainted(false);

        btnXoa = new JButton("XÓA");
        btnXoa.setFont(HEADER_FONT);
        btnXoa.setBackground(new Color(231, 76, 60)); // Đỏ
        btnXoa.setForeground(Color.WHITE);
        btnXoa.setFocusPainted(false);

        pnButton.add(btnThem);
        pnButton.add(btnSua);
        pnButton.add(btnXoa);

        gbc.gridx = 0; gbc.gridy = 6;
        gbc.insets = new Insets(20, 15, 10, 15);
        pnRight.add(pnButton, gbc);

        pnRightOuter.add(pnRight, BorderLayout.CENTER);
        splitNgang.setRightComponent(pnRightOuter);

        /* =========================================================================
         * PANEL DƯỚI: DANH SÁCH CHI TIẾT DỊCH VỤ ĐÃ DÙNG
         * ========================================================================= */
        JPanel pnBottom = new JPanel(new BorderLayout(0, 5));
        pnBottom.setBackground(BACKGROUND_COLOR);
        pnBottom.setBorder(new EmptyBorder(5, 10, 10, 10));

        modelDV = new DefaultTableModel();
        modelDV.addColumn("Mã SD");
        modelDV.addColumn("Mã Phiếu");
        modelDV.addColumn("Mã Phòng");
        modelDV.addColumn("Số Phòng");
        modelDV.addColumn("Khách Hàng");
        modelDV.addColumn("Tên Dịch Vụ");
        modelDV.addColumn("Số Lượng");
        modelDV.addColumn("Thành Tiền");
        modelDV.addColumn("Ngày sử dụng");

        tblDichVu = new JTable(modelDV);
        decorTable(tblDichVu);
        JScrollPane spDichVu = new JScrollPane(tblDichVu);
        spDichVu.setBorder(new TitledBorder(new LineBorder(new Color(200, 200, 200)), "CHI TIẾT DỊCH VỤ PHÒNG ĐANG SỬ DỤNG", TitledBorder.LEFT, TitledBorder.TOP, HEADER_FONT, PRIMARY_COLOR));
        pnBottom.add(spDichVu, BorderLayout.CENTER);

        // Khu vực Tổng tiền dưới góc phải bàn làm việc
        JPanel pnTong = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        pnTong.setBackground(Color.WHITE);
        pnTong.setBorder(new LineBorder(new Color(220, 224, 230), 1, true));

        JLabel lblTongTien = new JLabel("");
        lblTongTien.setFont(HEADER_FONT);
        lblTongTien.setForeground(TEXT_COLOR);
 

        pnTong.add(lblTongTien);
         pnBottom.add(pnTong, BorderLayout.SOUTH);

        // Khung chia bố cục dọc toàn màn hình
        JSplitPane splitDoc = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitDoc.setBorder(null);
        splitDoc.setTopComponent(splitNgang);
        splitDoc.setBottomComponent(pnBottom);
        splitDoc.setDividerLocation(410);

        add(splitDoc, BorderLayout.CENTER);

        /* =========================================================================
         * KHU VỰC GIỮ NGUYÊN LOGIC XỬ LÝ & EVENT LISTENERS
         * ========================================================================= */
        loadPhong();
        loadDichVu();
        cboDichVu.setEditable(true);
        themTimKiemComboDichVu();

        // Ràng buộc nhập số số lượng
        txtSoLuong.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != '\b') {
                    e.consume();
                }
            }
        });

        txtSoLuong.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { tinhThanhTien(); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { tinhThanhTien(); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { tinhThanhTien(); }
        });

        tblDichVu.getSelectionModel().addListSelectionListener(e -> hienThiThongTinDichVu());
        tblPhong.getSelectionModel().addListSelectionListener(e -> loadBangDichVu());
        cboDichVu.addActionListener(e -> tinhThanhTien());
         btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());

        // Listener đồng bộ dữ liệu dòng được chọn lên Form nhập liệu bên phải
        tblDichVu.getSelectionModel().addListSelectionListener(e -> {
            int row = tblDichVu.getSelectedRow();
            if (row < 0) return;
            txtSoLuong.setText(modelDV.getValueAt(row, 6).toString());
            String tenDV = modelDV.getValueAt(row, 5).toString();
            for (int i = 0; i < cboDichVu.getItemCount(); i++) {
                DichVu dv = cboDichVu.getItemAt(i);
                if (dv.getTenDichVu().equals(tenDV)) {
                    cboDichVu.setSelectedIndex(i);
                    break;
                }
            }
        });
    }

    /**
     * Hàm phụ trợ định dạng lại giao diện các bảng hiển thị hiện đại hơn
     */
    private void decorTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(26);
        table.setSelectionBackground(new Color(52, 152, 219));
        table.setSelectionForeground(Color.WHITE);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 32));
    }

    /* =========================================================================
     * TOÀN BỘ LOGIC NGHIỆP VỤ (HÀM PRIVATE) ĐƯỢC GIỮ NGUYÊN HOÀN TOÀN
     * ========================================================================= */
    private void loadPhong() {

        modelPhong.setRowCount(0);

        dsPhong = ctBUS.getPhongDangThue();

        for (PhongDangThueDTO p : dsPhong) {

            if (p.getMaPhieuThue() != maPhieu)
                continue;

            modelPhong.addRow(new Object[]{

                    p.getMaPhieuThue(),

                    p.getMaPhong(),

                    p.getSoPhong(),

                    p.getTenKhachHang(),

                    p.getTrangThai()

            });

        }

        if(modelPhong.getRowCount()>0){

            tblPhong.setRowSelectionInterval(0,0);

            loadBangDichVu();
        }
    }

    private void loadDichVu() {
        dsDichVu = dichVuBUS.getAll();
        DefaultComboBoxModel<DichVu> model = new DefaultComboBoxModel<>();
        for (DichVu dv : dsDichVu) {
            model.addElement(dv);
        }
        cboDichVu.setModel(model);
    }

    

    private void tinhThanhTien() {
        try {
            if (txtSoLuong.getText().trim().isEmpty()) {
                txtThanhTien.setText("");
                return;
            }
            DichVu dv = (DichVu) cboDichVu.getSelectedItem();
            if (dv == null) return;
            int sl = Integer.parseInt(txtSoLuong.getText().trim());
            txtThanhTien.setText(String.valueOf(sl * dv.getDonGia()));
        } catch (Exception ex) {
            txtThanhTien.setText("");
        }
    }

    private void loadBangDichVu() {
        int row = tblPhong.getSelectedRow();
        if (row < 0) return;
        int maPhieu = Integer.parseInt(modelPhong.getValueAt(row, 0).toString());
        int maPhong = Integer.parseInt(modelPhong.getValueAt(row, 1).toString());
        String soPhong = modelPhong.getValueAt(row, 2).toString();
        String tenKH = modelPhong.getValueAt(row, 3).toString();

        modelDV.setRowCount(0);
        for (SuDungDichVu sd : suDungBUS.timTheoPhong(maPhong)) {
            if (sd.getMaPhieuThue() != maPhieu) continue;
            DichVu dv = dichVuBUS.findById(sd.getMaDichVu());
            modelDV.addRow(new Object[]{
                    sd.getMaSuDung(), sd.getMaPhieuThue(), sd.getMaPhong(), soPhong, tenKH,
                    dv.getTenDichVu(), sd.getSoLuong(), sd.getThanhTien(), sd.getNgaySuDung()
            });
        }
     }

		/*
		 * private void them() { int row = tblPhong.getSelectedRow(); if (row < 0) {
		 * JOptionPane.showMessageDialog(this, "Chọn phòng"); return; } if
		 * (txtSoLuong.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this,
		 * "Vui lòng nhập số lượng"); txtSoLuong.requestFocus(); return; } DichVu dv =
		 * getDichVuDangChon(); if (dv == null) { JOptionPane.showMessageDialog(this,
		 * "Vui lòng chọn dịch vụ hợp lệ"); return; } try { int maPhieu =
		 * Integer.parseInt(modelPhong.getValueAt(row, 0).toString()); int maPhong =
		 * Integer.parseInt(modelPhong.getValueAt(row, 1).toString()); int sl =
		 * Integer.parseInt(txtSoLuong.getText().trim());
		 * 
		 * SuDungDichVu sd = new SuDungDichVu(); sd.setMaPhieuThue(maPhieu);
		 * sd.setMaPhong(maPhong); sd.setMaDichVu(dv.getMaDichVu()); sd.setSoLuong(sl);
		 * sd.setThanhTien(sl * dv.getDonGia()); sd.setNgaySuDung(new
		 * Timestamp(System.currentTimeMillis()));
		 * 
		 * if (suDungBUS.them(sd)) { JOptionPane.showMessageDialog(this,
		 * "Thêm thành công"); loadBangDichVu(); txtSoLuong.setText("");
		 * txtThanhTien.setText(""); } } catch (Exception ex) { ex.printStackTrace();
		 * JOptionPane.showMessageDialog(this, "Lỗi thêm dịch vụ"); } }
		 */
    private void them() {

        int row = tblPhong.getSelectedRow();

        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Chọn phòng");
            return;
        }

        if (txtSoLuong.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số lượng");
            txtSoLuong.requestFocus();
            return;
        }

        DichVu dv = getDichVuDangChon();

        if (dv == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ");
            return;
        }

        Kho kho = null;

        // Chỉ kiểm tra kho nếu dịch vụ có liên kết vật dụng
        if (dv.getMaVatDung() != null) {

            kho = khoBUS.timTheoMa(dv.getMaVatDung());

            if (kho == null) {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy vật dụng trong kho.");
                return;
            }
        }

        try {

            int sl = Integer.parseInt(txtSoLuong.getText().trim());

            if (sl <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Số lượng phải > 0");
                return;
            }

            if (kho != null && kho.getSoLuongTon() < sl) {
                JOptionPane.showMessageDialog(this,
                        "Kho chỉ còn "
                                + kho.getSoLuongTon()
                                + " "
                                + kho.getDonViTinh());
                return;
            }

            int maPhieu =
                    Integer.parseInt(modelPhong.getValueAt(row,0).toString());

            int maPhong =
                    Integer.parseInt(modelPhong.getValueAt(row,1).toString());

            SuDungDichVu sd = new SuDungDichVu();

            sd.setMaPhieuThue(maPhieu);
            sd.setMaPhong(maPhong);
            sd.setMaDichVu(dv.getMaDichVu());
            sd.setSoLuong(sl);
            sd.setThanhTien(sl * dv.getDonGia());
            sd.setNgaySuDung(new Timestamp(System.currentTimeMillis()));
            sd.setMaNhanVien(
                    Session.taiKhoanDangNhap.getMaNhanVien());
            if (suDungBUS.them(sd)) {

                if (kho != null) {
                    khoBUS.capNhatSoLuong(
                            kho.getMaVatDung(),
                            kho.getSoLuongTon() - sl);
                }

                JOptionPane.showMessageDialog(this,
                        "Thêm thành công");

                loadBangDichVu();

                txtSoLuong.setText("");
                txtThanhTien.setText("");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Lỗi thêm dịch vụ");
        }
    }
    private void sua() {

        int rowDV = tblDichVu.getSelectedRow();

        if (rowDV < 0) {
            JOptionPane.showMessageDialog(this,
                    "Chọn dịch vụ cần sửa");
            return;
        }

        int rowPhong = tblPhong.getSelectedRow();

        if (rowPhong < 0) {
            JOptionPane.showMessageDialog(this,
                    "Chọn phòng");
            return;
        }

        if (txtSoLuong.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập số lượng");
            txtSoLuong.requestFocus();
            return;
        }

        DichVu dv = getDichVuDangChon();

        if (dv == null) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn dịch vụ");
            return;
        }

        try {

            int maSD =
                    Integer.parseInt(modelDV.getValueAt(rowDV,0).toString());

            SuDungDichVu cu =
                    suDungBUS.timTheoMa(maSD);

            if (cu == null) {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy dịch vụ");
                return;
            }

            Kho kho = null;

            if (dv.getMaVatDung() != null) {

                kho = khoBUS.timTheoMa(dv.getMaVatDung());

                if (kho == null) {
                    JOptionPane.showMessageDialog(this,
                            "Không tìm thấy vật dụng trong kho");
                    return;
                }
            }

            int soLuongMoi =
                    Integer.parseInt(txtSoLuong.getText().trim());

            if (soLuongMoi <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Số lượng phải > 0");
                return;
            }

            int chenhLech = soLuongMoi - cu.getSoLuong();

            if (kho != null &&
                    chenhLech > 0 &&
                    kho.getSoLuongTon() < chenhLech) {

                JOptionPane.showMessageDialog(this,
                        "Kho chỉ còn "
                                + kho.getSoLuongTon()
                                + " "
                                + kho.getDonViTinh());

                return;
            }

            int maPhieu =
                    Integer.parseInt(modelPhong.getValueAt(rowPhong,0).toString());

            int maPhong =
                    Integer.parseInt(modelPhong.getValueAt(rowPhong,1).toString());

            SuDungDichVu sd = new SuDungDichVu();

            sd.setMaSuDung(maSD);
            sd.setMaPhieuThue(maPhieu);
            sd.setMaPhong(maPhong);
            sd.setMaDichVu(dv.getMaDichVu());
            sd.setSoLuong(soLuongMoi);
            sd.setThanhTien(soLuongMoi * dv.getDonGia());
            sd.setNgaySuDung(new Timestamp(System.currentTimeMillis()));
            sd.setMaNhanVien(
                    Session.taiKhoanDangNhap.getMaNhanVien());
            if (suDungBUS.sua(sd)) {

                if (kho != null) {

                    khoBUS.capNhatSoLuong(
                            kho.getMaVatDung(),
                            kho.getSoLuongTon() - chenhLech);
                }

                JOptionPane.showMessageDialog(this,
                        "Sửa thành công");

                loadBangDichVu();

                txtSoLuong.setText("");
                txtThanhTien.setText("");
            }

        } catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Lỗi cập nhật");
        }
    }

    private DichVu getDichVuDangChon() {
        Object obj = cboDichVu.getSelectedItem();
        if (obj == null) return null;
        if (obj instanceof DichVu) return (DichVu) obj;
        String tenDV = obj.toString().trim();
        for (DichVu dv : dsDichVu) {
            if (dv.getTenDichVu().equalsIgnoreCase(tenDV)) return dv;
        }
        return null;
    }

    private void hienThiThongTinDichVu() {
        int row = tblDichVu.getSelectedRow();
        if (row < 0) return;
        txtSoLuong.setText(modelDV.getValueAt(row, 6).toString());
        String tenDV = modelDV.getValueAt(row, 5).toString();
        for (int i = 0; i < cboDichVu.getItemCount(); i++) {
            DichVu dv = cboDichVu.getItemAt(i);
            if (dv.getTenDichVu().equals(tenDV)) {
                cboDichVu.setSelectedIndex(i);
                break;
            }
        }
    }

    private void themTimKiemComboDichVu() {
        JTextField editor = (JTextField) cboDichVu.getEditor().getEditorComponent();
        editor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { loc(); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { loc(); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { loc(); }

            private void loc() {
                if (dangLoc) return;
                SwingUtilities.invokeLater(() -> {
                    dangLoc = true;
                    String text = editor.getText().trim().toLowerCase();
                    DefaultComboBoxModel<DichVu> model = new DefaultComboBoxModel<>();
                    for (DichVu dv : dsDichVu) {
                        if (dv.getTenDichVu().toLowerCase().contains(text)) {
                            model.addElement(dv);
                        }
                    }
                    String oldText = editor.getText();
                    cboDichVu.setModel(model);
                    editor.setText(oldText);
                    cboDichVu.setPopupVisible(model.getSize() > 0);
                    dangLoc = false;
                });
            }
        });
    }

    private void xoa() {

        int row = tblDichVu.getSelectedRow();

        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    "Chọn dịch vụ cần xóa");
            return;
        }

        int maSD =
                Integer.parseInt(modelDV.getValueAt(row,0).toString());

        SuDungDichVu sd =
                suDungBUS.timTheoMa(maSD);

        if (sd == null) {
            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy dịch vụ");
            return;
        }

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Bạn có chắc muốn xóa dịch vụ này?",
                        "Xác nhận",
                        JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION)
            return;

        DichVu dv =
                dichVuBUS.findById(sd.getMaDichVu());

        Kho kho = null;

        if (dv != null && dv.getMaVatDung() != null) {

            kho = khoBUS.timTheoMa(dv.getMaVatDung());
        }

        if (suDungBUS.xoa(maSD)) {

            if (kho != null) {

                khoBUS.capNhatSoLuong(
                        kho.getMaVatDung(),
                        kho.getSoLuongTon() + sd.getSoLuong());
            }

            JOptionPane.showMessageDialog(this,
                    "Xóa thành công");

            loadBangDichVu();

            txtSoLuong.setText("");
            txtThanhTien.setText("");
        }
    }
}