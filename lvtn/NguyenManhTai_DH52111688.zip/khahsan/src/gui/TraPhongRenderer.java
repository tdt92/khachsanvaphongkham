package gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class TraPhongRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        super.getTableCellRendererComponent(
                table,
                value,
                isSelected,
                hasFocus,
                row,
                column);

        if (isSelected) {
            return this;
        }

        try {

            long soNgay =
                    Long.parseLong(table.getValueAt(row, 5).toString());

            if (soNgay <= 0) {

                setBackground(new Color(255,180,180));
                setForeground(Color.RED);

            } else if (soNgay <= 2) {

                setBackground(new Color(255,245,170));
                setForeground(Color.BLACK);

            } else {

                setBackground(Color.WHITE);
                setForeground(Color.BLACK);

            }

        } catch (Exception e) {

            setBackground(Color.WHITE);
            setForeground(Color.BLACK);

        }

        return this;
    }
}