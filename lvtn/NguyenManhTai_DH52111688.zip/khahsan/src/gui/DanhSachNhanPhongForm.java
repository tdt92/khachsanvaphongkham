package gui;

import bus.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class DanhSachNhanPhongForm extends JInternalFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtTim;
    private JButton btnTim;
    private JButton btnChiTiet;
    private JButton btnLamMoi;

    private PhieuThuePhongBUS ptBUS = new PhieuThuePhongBUS();
    private ChiTietThuePhongBUS ctBUS = new ChiTietThuePhongBUS();
    private KhachHangBUS khBUS = new KhachHangBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private HoaDonBUS hdBUS = new HoaDonBUS();

    // Bảng màu cấu trúc Modern UI phẳng và đồng bộ
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);     // Xanh dương chủ đạo (Tìm kiếm)
    private final Color SECONDARY_COLOR = new Color(26, 188, 156);   // Xanh ngọc lục bảo (Chi tiết)
    private final Color RESET_COLOR = new Color(149, 165, 166);       // Xám hiện đại (Làm mới)
    private final Color BACKGROUND_COLOR = new Color(248, 249, 250);  // Nền xám nhạt dịu mắt
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public DanhSachNhanPhongForm(){
        super("DANH SÁCH NHẬN PHÒNG", true, true, true, true);
        setSize(950, 600);
        initUI();
        loadData();
    }

    private void initUI(){
        setLayout(new BorderLayout(0, 15));
        getContentPane().setBackground(BACKGROUND_COLOR);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));

        // ----------------- PANEL PHÍA TRÊN (THANH TÌM KIẾM) -----------------
        JPanel pnlTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        pnlTop.setBackground(Color.WHITE);
        pnlTop.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 235, 240), 1),
                new EmptyBorder(5, 10, 5, 10)
        ));

        JLabel lblTim = new JLabel("Tìm (Tên hoặc CCCD):");
        lblTim.setFont(MAIN_FONT);

        txtTim = new JTextField(25);
        txtTim.setFont(MAIN_FONT);
        txtTim.setPreferredSize(new Dimension(250, 35));

        btnTim = new JButton("Tìm kiếm");
        btnTim.setFont(HEADER_FONT);
        btnTim.setBackground(PRIMARY_COLOR);
        btnTim.setForeground(Color.WHITE);
        btnTim.setFocusPainted(false);
        btnTim.setPreferredSize(new Dimension(110, 35));
        btnTim.setCursor(new Cursor(Cursor.HAND_CURSOR));

        pnlTop.add(lblTim);
        pnlTop.add(txtTim);
        pnlTop.add(btnTim);

        add(pnlTop, BorderLayout.NORTH);

        // ----------------- PANEL GIỮA (LƯỚI DỮ LIỆU JTABLE) -----------------
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Ngăn chặn việc click đúp sửa text trực tiếp trên table
            }
        };

        model.setColumnIdentifiers(new String[]{
                "Mã phiếu", "Tên khách", "CCCD", "Số phòng", "Ngày nhận", "Ngày trả"
        });

        table = new JTable(model);
        table.setFont(MAIN_FONT);
        table.setRowHeight(35); // Tăng chiều cao hàng thoáng đãng, chuẩn Material Design
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(240, 242, 245));
        table.setShowVerticalLines(false); // Ẩn đường dọc để bảng nhìn sang trọng hơn

        // Tùy biến thanh Header của bảng
        JTableHeader header = table.getTableHeader();
        header.setFont(HEADER_FONT);
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        header.setReorderingAllowed(false); // Khóa không cho kéo đổi vị trí cột

        // Định dạng căn lề cho các cột dữ liệu
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // Mã phiếu
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // Số phòng
        table.getColumnModel().getColumn(4).setCellRenderer(centerRenderer); // Ngày nhận
        table.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); // Ngày trả

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 230)));
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // ----------------- PANEL PHÍA DƯỚI (NÚT HÀNH ĐỘNG) -----------------
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        p.setBackground(BACKGROUND_COLOR);

        btnLamMoi = new JButton("Làm Mới");
        btnLamMoi.setFont(HEADER_FONT);
        btnLamMoi.setBackground(RESET_COLOR);
        btnLamMoi.setForeground(Color.WHITE);
        btnLamMoi.setFocusPainted(false);
        btnLamMoi.setPreferredSize(new Dimension(130, 40));
        btnLamMoi.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnChiTiet = new JButton("Chi Tiết");
        btnChiTiet.setFont(HEADER_FONT);
        btnChiTiet.setBackground(SECONDARY_COLOR);
        btnChiTiet.setForeground(Color.WHITE);
        btnChiTiet.setFocusPainted(false);
        btnChiTiet.setPreferredSize(new Dimension(130, 40));
        btnChiTiet.setCursor(new Cursor(Cursor.HAND_CURSOR));

        p.add(btnLamMoi);
        p.add(btnChiTiet);

        add(p, BorderLayout.SOUTH);

        // 3. ĐĂNG KÝ SỰ KIỆN (LISTENERS) - GIỮ NGUYÊN GỐC LOGIC 100%
        btnTim.addActionListener(e -> timKiem());
        txtTim.addActionListener(e -> timKiem());
        btnLamMoi.addActionListener(e -> {
            txtTim.setText("");
            loadData();
        });
        btnChiTiet.addActionListener(e -> moChiTiet());
    }

    private void loadData(){
        model.setRowCount(0);

        for(PhieuThuePhong pt : ptBUS.getAll()){
            if(!"DANG_THUE".equals(pt.getTrangThai()))
                continue;

            KhachHang kh = khBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                    .findFirst()
                    .orElse(null);

            String soPhong = "";
            List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(pt.getMaPhieuThue());

            if(!ds.isEmpty()){
                Phong p = phongBUS.getAll()
                        .stream()
                        .filter(x -> x.getMaPhong() == ds.get(0).getMaPhong())
                        .findFirst()
                        .orElse(null);

                if(p != null)
                    soPhong = p.getSoPhong();
            }

            model.addRow(new Object[]{
                    pt.getMaPhieuThue(),
                    kh == null ? "" : kh.getHoTen(),
                    kh == null ? "" : kh.getCccd(),
                    soPhong,
                    pt.getNgayNhanPhong(),
                    pt.getNgayTraPhongDuKien()
            });
        }
    }

    private void timKiem() {
        model.setRowCount(0);
        String key = txtTim.getText().trim().toLowerCase();

        for (PhieuThuePhong pt : ptBUS.getAll()) {
            if (!"DANG_THUE".equals(pt.getTrangThai()))
                continue;

            KhachHang kh = khBUS.getAll()
                    .stream()
                    .filter(x -> x.getMaKhachHang() == pt.getMaKhachHang())
                    .findFirst()
                    .orElse(null);

            if (kh == null)
                continue;

            // Lọc theo tên hoặc CCCD
            if (!kh.getHoTen().toLowerCase().contains(key)
                    && !kh.getCccd().contains(key)) {
                continue;
            }

            String soPhong = "";
            List<ChiTietThuePhong> ds = ctBUS.getByPhieuThue(pt.getMaPhieuThue());

            if (!ds.isEmpty()) {
                Phong p = phongBUS.getAll()
                        .stream()
                        .filter(x -> x.getMaPhong() == ds.get(0).getMaPhong())
                        .findFirst()
                        .orElse(null);

                if (p != null)
                    soPhong = p.getSoPhong();
            }

            model.addRow(new Object[]{
                    pt.getMaPhieuThue(),
                    kh.getHoTen(),
                    kh.getCccd(),
                    soPhong,
                    pt.getNgayNhanPhong(),
                    pt.getNgayTraPhongDuKien()
            });
        }

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy kết quả.");
        }
    }

    private void moChiTiet() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một phiếu thuê từ danh sách!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(model.getValueAt(row, 0).toString());
        HoaDon hd = hdBUS.getByPhieuThue(maPhieu);

        if (hd == null) {
            JOptionPane.showMessageDialog(this, "Phiếu thuê này hiện chưa được khởi tạo hóa đơn!", "Thông báo", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDesktopPane desktop = getDesktopPane();
        if (desktop == null)
            return;

        NhanPhongForm2 f = new NhanPhongForm2(hd.getMaHoaDon());
        desktop.add(f);
        f.setVisible(true);

        try {
            f.setSelected(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        dispose();
    }
}