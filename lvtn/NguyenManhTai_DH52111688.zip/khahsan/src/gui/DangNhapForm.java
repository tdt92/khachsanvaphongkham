package gui;

import util.Session;
import bus.TaiKhoanBUS;
import model.TaiKhoan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DangNhapForm extends JFrame {

    JTextField txtUser;
    JPasswordField txtPass;
    JButton btnDangNhap;

    TaiKhoanBUS bus = new TaiKhoanBUS();

    public DangNhapForm() {
         try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
         }

        setTitle("HỆ THỐNG QUẢN LÝ KHÁCH SẠN - ĐĂNG NHẬP");
        setSize(450, 380); // Tăng chiều cao để không gian thoáng và sang trọng hơn
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Bảng màu Khách sạn Luxury (Gold & Dark Blue/Gray)
        Color hotelGold = new Color(212, 175, 55);    // Màu vàng Gold đặc trưng khách sạn
        Color darkText = new Color(44, 62, 80);       // Màu chữ xám xanh lịch lãm
        Font fontTitle = new Font("Segoe UI", Font.BOLD, 22);
        Font fontLabel = new Font("Segoe UI", Font.BOLD, 13);
        Font fontInput = new Font("Segoe UI", Font.PLAIN, 14);

        // Panel chính sử dụng BorderLayout để quản lý khoảng cách tốt hơn
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(new EmptyBorder(20, 35, 25, 35));

     // ==========================================================
     // 1. TIÊU ĐỀ & ICON KHÁCH SẠN (Phần trên) - ĐÃ SỬA LỖI Ô VUÔNG
     // ==========================================================
     JPanel pHeader = new JPanel(new BorderLayout(5, 5));
     pHeader.setBackground(Color.WHITE);

     // Sử dụng chữ cách điệu viết tắt hoặc nhãn chữ thay cho Emoji
     JLabel lblIcon = new JLabel("H O T E L"); 
     lblIcon.setFont(new Font("Segoe UI", Font.BOLD, 28)); // Chữ lớn, phong cách hiện đại
     lblIcon.setHorizontalAlignment(SwingConstants.CENTER);
     lblIcon.setForeground(hotelGold);

     JLabel lblTitle = new JLabel("GRAND MANAGEMENT");
     lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
     lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
     lblTitle.setForeground(darkText);

     pHeader.add(lblIcon, BorderLayout.NORTH);
     pHeader.add(lblTitle, BorderLayout.CENTER);
     mainPanel.add(pHeader, BorderLayout.NORTH);

     // ==========================================================
     // 2. KHU VỰC NHẬP LIỆU (Phần giữa) - ĐÃ XÓA EMOJI BỊ LỖI
     // ==========================================================
     JPanel pCenter = new JPanel(new GridLayout(4, 1, 5, 5));
     pCenter.setBackground(Color.WHITE);
     pCenter.setBorder(new EmptyBorder(15, 0, 15, 0));

     // Thay chữ có emoji thành chữ thường sang trọng
     JLabel lblUser = new JLabel("Tên đăng nhập / Username:");
     lblUser.setFont(fontLabel);
     lblUser.setForeground(darkText);

     txtUser = new JTextField();
     txtUser.setFont(fontInput);
     styleTextField(txtUser);

     JLabel lblPass = new JLabel("Mật khẩu / Password:");
     lblPass.setFont(fontLabel);
     lblPass.setForeground(darkText);

     txtPass = new JPasswordField();
     txtPass.setFont(fontInput);
     styleTextField(txtPass);

        pCenter.add(lblUser);
        pCenter.add(txtUser);
        pCenter.add(lblPass);
        pCenter.add(txtPass);
        
        mainPanel.add(pCenter, BorderLayout.CENTER);

        // ==========================================================
        // 3. NÚT ĐĂNG NHẬP (Phần dưới)
        // ==========================================================
        JPanel pBottom = new JPanel(new BorderLayout());
        pBottom.setBackground(Color.WHITE);

        btnDangNhap = new JButton("ĐĂNG NHẬP HỆ THỐNG");
        btnDangNhap.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDangNhap.setBackground(darkText);
        btnDangNhap.setForeground(Color.WHITE);
        btnDangNhap.setPreferredSize(new Dimension(0, 45));
        btnDangNhap.setFocusPainted(false);
        btnDangNhap.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Tạo viền bo góc giả lập mềm mại cho nút bấm
        btnDangNhap.setBorder(BorderFactory.createLineBorder(darkText.darker(), 1));

        // Hiệu ứng hover đổi màu sang trọng khi rê chuột vào nút đăng nhập
        btnDangNhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDangNhap.setBackground(hotelGold);
                btnDangNhap.setForeground(darkText);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDangNhap.setBackground(darkText);
                btnDangNhap.setForeground(Color.WHITE);
            }
        });

        pBottom.add(btnDangNhap, BorderLayout.CENTER);
        mainPanel.add(pBottom, BorderLayout.SOUTH);

        add(mainPanel);

        // ==========================================================
        // KHU VỰC EVENT (Giữ nguyên logic gốc)
        // ==========================================================
        btnDangNhap.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dangNhap();
            }
        });
        
        // Hỗ trợ nhấn Enter trong ô mật khẩu để đăng nhập nhanh
        txtPass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dangNhap();
            }
        });
    }

    // Hàm bổ trợ style ô nhập liệu đẹp hơn
    private void styleTextField(JTextField textField) {
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(5, 8, 5, 8) // Thêm padding cho chữ không dính sát viền
        ));
    }

    // ==========================================================
    // KHU VỰC LOGIC (Giữ nguyên 100% xử lý ban đầu của bạn)
    // ==========================================================
    private void dangNhap() {

        String user = txtUser.getText();

        String pass =
                String.valueOf(
                        txtPass.getPassword());

        TaiKhoan tk =
                bus.dangNhap(
                        user,
                        pass);

        if (tk == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Sai tài khoản hoặc mật khẩu");

            return;
        }
        if (!tk.isTrangThai()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Tài khoản đã bị khóa!\nVui lòng liên hệ quản trị viên.",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE);

            return;
        }
        Session.taiKhoanDangNhap = tk;

        if (tk.getMaVaiTro() == 1) {

            MainFrame main = new MainFrame();
            main.setVisible(true);
            dispose();

        }
        else if (tk.getMaVaiTro() == 2) {

            LeTanMainFrame main = new LeTanMainFrame();
            main.setVisible(true);
            dispose();

        }
       
        else {

            JOptionPane.showMessageDialog(
                    this,
                    "Tài khoản không có quyền truy cập");
        }
    }

    public static void main(String[] args) {
        new DangNhapForm().setVisible(true);
    }
}