package gui;

import bus.LoaiPhongBUS;
import bus.PhongBUS;
import model.LoaiPhong;
import model.Phong;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyPhongForm extends JInternalFrame {

    JTextField txtSoPhong;
    JTextField txtTang;

    JComboBox<LoaiPhong> cboLoaiPhong;
    JComboBox<String> cboTrangThai;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnLamMoi;

    JTable table;

    DefaultTableModel model;

    PhongBUS bus = new PhongBUS();
    LoaiPhongBUS loaiPhongBUS = new LoaiPhongBUS();

    int selectedMaPhong = -1;

    // Bảng màu giao diện Modern UI (Slate & Cyan Accent)
    private static final Color MAU_CHINH = new Color(14, 116, 144);    // Cyan/Teal đậm chuyên nghiệp
    private static final Color MAU_XOA = new Color(225, 29, 72);       // Đỏ Rose nổi bật cho nút xóa
    private static final Color NEN_XAM = new Color(248, 250, 252);     // Slate 50 làm nền dịu mắt
    private static final Color CHU_DAM = new Color(15, 23, 42);        // Slate 900 cho chữ chính
    private static final Color VIEN_NHE = new Color(226, 232, 240);    // Slate 200 làm đường viền mảnh

    public QuanLyPhongForm() {
        super("QUẢN LÝ PHÒNG", true, true, true, true);

        setSize(1000, 650);
        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);
        
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(NEN_XAM);
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 20, 15, 20));

        // =====================================================================
        // PANEL TOP: KHU VỰC NHẬP LIỆU (GRID LAYOUT THOÁNG ĐÃNG)
        // =====================================================================
        JPanel pTopMaster = new JPanel(new BorderLayout());
        pTopMaster.setBackground(Color.WHITE);
        pTopMaster.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                new EmptyBorder(20, 25, 20, 25)
        ));

        // Tối ưu từ Grid (4, 2) sang Grid (2, 2) để dàn ngang các ô nhập liệu cân đối
        JPanel pTop = new JPanel(new GridLayout(2, 2, 30, 15));
        pTop.setBackground(Color.WHITE);

        txtSoPhong = new JTextField();
        txtTang = new JTextField();
        cboLoaiPhong = new JComboBox<>();
        cboTrangThai = new JComboBox<>(new String[]{"Trong", "Đang thue", "Bao tri"});

        styleTextField(txtSoPhong);
        styleTextField(txtTang);
        styleComboBox(cboLoaiPhong);
        styleComboBox(cboTrangThai);

        loadLoaiPhong();

        // Đóng gói thành các cụm Nhãn trên - Ô nhập dưới trực quan
        pTop.add(taoFormGroup("Số phòng", txtSoPhong));
        pTop.add(taoFormGroup("Loại phòng", cboLoaiPhong));
        pTop.add(taoFormGroup("Tầng", txtTang));
        pTop.add(taoFormGroup("Trạng thái", cboTrangThai));

        pTopMaster.add(pTop, BorderLayout.CENTER);
        add(pTopMaster, BorderLayout.NORTH);

        // =====================================================================
        // PANEL CENTER: KHU VỰC BẢNG DỮ LIỆU HIỂN THỊ
        // =====================================================================
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã phòng", "Số phòng", "Mã loại", "Tầng", "Trạng thái"
        });

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        add(scrollPane, BorderLayout.CENTER);

        // =====================================================================
        // PANEL BOTTOM: KHU VỰC ĐIỀU KHIỂN THAO TÁC
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        pBottom.setBackground(NEN_XAM);

        btnThem = new JButton("THÊM MỚI");
        btnSua = new JButton("CẬP NHẬT");
        btnXoa = new JButton("XÓA PHÒNG");
        btnLamMoi = new JButton("LÀM MỚI FORM");

        styleButton(btnThem, MAU_CHINH);
        styleButton(btnSua, new Color(71, 85, 105)); // Màu xám Slate cho nút sửa
        styleButton(btnXoa, MAU_XOA);
        styleButton(btnLamMoi, Color.WHITE);
        
        btnLamMoi.setForeground(CHU_DAM);
        btnLamMoi.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        pBottom.add(btnLamMoi);

        add(pBottom, BorderLayout.SOUTH);

        // Nạp dữ liệu lên form
        loadData();

        // =====================================================================
        // EVENT TABLE
        // =====================================================================
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedMaPhong = Integer.parseInt(model.getValueAt(row, 0).toString());
                txtSoPhong.setText(model.getValueAt(row, 1).toString());
                txtTang.setText(model.getValueAt(row, 3).toString());
                cboTrangThai.setSelectedItem(model.getValueAt(row, 4).toString());

                int maLoai = Integer.parseInt(model.getValueAt(row, 2).toString());
                for (int i = 0; i < cboLoaiPhong.getItemCount(); i++) {
                    LoaiPhong lp = cboLoaiPhong.getItemAt(i);
                    if (lp.getMaLoaiPhong() == maLoai) {
                        cboLoaiPhong.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });

        // =====================================================================
        // BUTTON EVENT
        // =====================================================================
        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnLamMoi.addActionListener(e -> {
            clearForm();
            loadData();
        });

        setVisible(true);
    }

    // =====================================================================
    // CÁC HÀM TRỢ GIÚP THIẾT KẾ GIAO DIỆN HIỆN ĐẠI
    // =====================================================================
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(CHU_DAM);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
    }

    private void styleComboBox(JComboBox<?> cbo) {
        cbo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbo.setForeground(CHU_DAM);
        cbo.setBackground(Color.WHITE);
        cbo.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
    }

    private void styleButton(JButton btn, Color background) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(background);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32); 
        table.setGridColor(new Color(241, 245, 249)); 
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(232, 240, 254)); 
        table.setSelectionForeground(CHU_DAM);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(new Color(71, 85, 105));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, VIEN_NHE));

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 8, 0, 8));
        table.setDefaultRenderer(Object.class, renderer);
    }

    private JPanel taoFormGroup(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(100, 116, 139)); 
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    // =====================================================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN HOÀN TOÀN THEO MÃ NGUỒN GỐC)
    // =====================================================================
    private void loadLoaiPhong() {
        cboLoaiPhong.removeAllItems();
        for (LoaiPhong lp : loaiPhongBUS.getAll()) {
            cboLoaiPhong.addItem(lp);
        }
    }

    private void loadData() {
        model.setRowCount(0);
        for (Phong p : bus.getAll()) {
            model.addRow(new Object[]{
                    p.getMaPhong(),
                    p.getSoPhong(),
                    p.getMaLoaiPhong(),
                    p.getTang(),
                    p.getTrangThai()
            });
        }
    }

    private void them() {
        try {

            if (!validateForm()) {
                return;
            }
            if (bus.isExistSoPhong(txtSoPhong.getText().trim())) {
                JOptionPane.showMessageDialog(this,
                        "Số phòng đã tồn tại!");
                txtSoPhong.requestFocus();
                return;
            }
            Phong p = new Phong();
            LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();

            p.setSoPhong(txtSoPhong.getText().trim());
            p.setMaLoaiPhong(lp.getMaLoaiPhong());
            p.setTang(Integer.parseInt(txtTang.getText().trim()));
            p.setTrangThai(cboTrangThai.getSelectedItem().toString());

            if (bus.insert(p)) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void sua() {
        try {
            if (selectedMaPhong == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng cần sửa");
                return;
            }

            if (!validateForm()) {
                return;
            }
            if (bus.isExistSoPhong(txtSoPhong.getText().trim(), selectedMaPhong)) {
                JOptionPane.showMessageDialog(this,
                        "Số phòng đã tồn tại!");
                txtSoPhong.requestFocus();
                return;
            }
            Phong p = new Phong();
            LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();

            p.setMaPhong(selectedMaPhong);
            p.setSoPhong(txtSoPhong.getText().trim());
            p.setMaLoaiPhong(lp.getMaLoaiPhong());
            p.setTang(Integer.parseInt(txtTang.getText().trim()));
            p.setTrangThai(cboTrangThai.getSelectedItem().toString());

            if (bus.update(p)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoa() {

        if (selectedMaPhong == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng cần xóa");
            return;
        }

        if (!bus.isPhongTrong(selectedMaPhong)) {
            JOptionPane.showMessageDialog(this,
                    "Không thể xóa phòng vì phòng không ở trạng thái trống!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa phòng này?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (bus.delete(selectedMaPhong)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadData();
                clearForm();
            }
        }
    }
    private boolean validateForm() {

        if (txtSoPhong.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Số phòng không được để trống");
            txtSoPhong.requestFocus();
            return false;
        }

        if (txtTang.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tầng không được để trống");
            txtTang.requestFocus();
            return false;
        }

        if (cboLoaiPhong.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn loại phòng");
            cboLoaiPhong.requestFocus();
            return false;
        }

        if (cboTrangThai.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn trạng thái");
            cboTrangThai.requestFocus();
            return false;
        }

        // Kiểm tra tầng là số
        try {
            int tang = Integer.parseInt(txtTang.getText().trim());
            if (tang <= 0) {
                JOptionPane.showMessageDialog(this, "Tầng phải lớn hơn 0");
                txtTang.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Tầng phải là số");
            txtTang.requestFocus();
            return false;
        }

        return true;
    }
    private void clearForm() {
        txtSoPhong.setText("");
        txtTang.setText("");
        if (cboLoaiPhong.getItemCount() > 0) {
            cboLoaiPhong.setSelectedIndex(0);
        }
        cboTrangThai.setSelectedIndex(0);
        selectedMaPhong = -1;
    }
}