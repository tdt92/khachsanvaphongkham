package gui;
import java.util.Comparator;
import bus.*;
import dao.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class TraCuuHoaDonForm extends JInternalFrame {
	private JTable tblHoaDon;

	private DefaultTableModel model;

	private JTextField txtTimKiem;

	private JLabel lblTongDoanhThu;

	private JButton btnTim;
	private JButton btnChiTiet;
	private JButton btnIn;

	private HoaDonDAO hoaDonDAO =
	        new HoaDonDAO();

	private PhieuThuePhongBUS phieuBUS =
	        new PhieuThuePhongBUS();

	private KhachHangBUS khachBUS =
	        new KhachHangBUS();

	private ChiTietThuePhongDAO ctDAO =
	        new ChiTietThuePhongDAO();

	private SuDungDichVuDAO dvDAO =
	        new SuDungDichVuDAO();

	private DichVuBUS dichVuBUS =
	        new DichVuBUS();

	private PhongBUS phongBUS =
	        new PhongBUS();

	// Bảng màu cấu trúc Modern UI
	private final Color PRIMARY_COLOR = new Color(41, 128, 185);     // Xanh dương thương hiệu
	private final Color SECONDARY_COLOR = new Color(26, 188, 156);   // Xanh ngọc lục bảo
	private final Color BACKGROUND_COLOR = new Color(245, 247, 250);  // Xám nền dịu mắt
	private final Color CARD_BG = new Color(230, 242, 250);          // Màu nền khu vực doanh thu
	private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
	private final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);

	public TraCuuHoaDonForm() {
		super(
		        "Lịch Sử Hóa Đơn",
		        true,
		        true,
		        true,
		        true);

		setSize(1200, 700);
		getContentPane().setBackground(BACKGROUND_COLOR);
		setLayout(new BorderLayout(0, 10));

		// ----------------- PANEL PHÍA TRÊN (THANH CÔNG CỤ & THỐNG KÊ) -----------------
		JPanel topWrapper = new JPanel(new BorderLayout(15, 0));
		topWrapper.setBackground(BACKGROUND_COLOR);
		topWrapper.setBorder(new EmptyBorder(15, 15, 5, 15));

		// Bộ lọc bên trái
		JPanel pnlSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		pnlSearch.setBackground(BACKGROUND_COLOR);
		
		JLabel lblSearchIcon = new JLabel("Từ khóa tìm kiếm:");
		lblSearchIcon.setFont(MAIN_FONT);
		
		txtTimKiem = new JTextField(25);
		txtTimKiem.setFont(MAIN_FONT);
		txtTimKiem.setPreferredSize(new Dimension(250, 35));

		btnTim = new JButton("Tìm Kiếm");
		btnTim.setFont(HEADER_FONT);
		btnTim.setBackground(PRIMARY_COLOR);
		btnTim.setForeground(Color.WHITE);
		btnTim.setFocusPainted(false);
		btnTim.setPreferredSize(new Dimension(110, 35));
		btnTim.setCursor(new Cursor(Cursor.HAND_CURSOR));

		pnlSearch.add(lblSearchIcon);
		pnlSearch.add(txtTimKiem);
		pnlSearch.add(btnTim);

		// Khu vực Doanh thu bên phải (Thiết kế dạng Card)
		JPanel pnlRevenueCard = new JPanel(new GridBagLayout());
		pnlRevenueCard.setBackground(CARD_BG);
		pnlRevenueCard.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(new Color(180, 210, 230), 1, true),
				new EmptyBorder(5, 15, 5, 15)
		));
		
		lblTongDoanhThu = new JLabel();
		lblTongDoanhThu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblTongDoanhThu.setForeground(new Color(23, 105, 170));
		pnlRevenueCard.add(lblTongDoanhThu);

		topWrapper.add(pnlSearch, BorderLayout.WEST);
		topWrapper.add(pnlRevenueCard, BorderLayout.EAST);
		add(topWrapper, BorderLayout.NORTH);

		// ----------------- PANEL GIỮA (LƯỚI DỮ LIỆU JTABLE) -----------------
		JPanel pnlCenter = new JPanel(new BorderLayout());
		pnlCenter.setBackground(BACKGROUND_COLOR);
		pnlCenter.setBorder(new EmptyBorder(5, 15, 5, 15));

		model = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Không cho sửa trực tiếp trên lưới
			}
		};

		model.addColumn("Mã HĐ");
		model.addColumn("Mã Phiếu");
		model.addColumn("Tên Khách");
		model.addColumn("CCCD");
		model.addColumn("Ngày Lập");
		model.addColumn("Tổng Tiền (VNĐ)");

		tblHoaDon = new JTable(model);
		tblHoaDon.setFont(MAIN_FONT);
		tblHoaDon.setRowHeight(32); // Khoảng cách dòng rộng rãi
		tblHoaDon.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblHoaDon.setGridColor(new Color(230, 235, 240));
		tblHoaDon.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo xu hướng UI mới

		// Định dạng Header cho bảng
		JTableHeader header = tblHoaDon.getTableHeader();
		header.setFont(HEADER_FONT);
		header.setBackground(PRIMARY_COLOR);
		header.setForeground(Color.black);
		header.setPreferredSize(new Dimension(header.getWidth(), 38));

		// Cấu hình định dạng căn lề từng loại dữ liệu
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		
		DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
		rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
		rightRenderer.setFont(new Font("Segoe UI", Font.BOLD, 14));

		tblHoaDon.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // Mã HĐ
		tblHoaDon.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Mã Phiếu
		tblHoaDon.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // CCCD
		tblHoaDon.getColumnModel().getColumn(4).setCellRenderer(centerRenderer); // Ngày Lập
		tblHoaDon.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);  // Tổng Tiền

		JScrollPane scrollPane = new JScrollPane(tblHoaDon);
		scrollPane.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 230)));
		pnlCenter.add(scrollPane, BorderLayout.CENTER);
		add(pnlCenter, BorderLayout.CENTER);

		// ----------------- PANEL PHÍA DƯỚI (NÚT TÁC VỤ) -----------------
		JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 12));
		bottom.setBackground(Color.WHITE);
		bottom.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220, 225, 230)));

		btnChiTiet = new JButton("Xem Chi Tiết");
		btnChiTiet.setFont(HEADER_FONT);
		btnChiTiet.setBackground(SECONDARY_COLOR);
		btnChiTiet.setForeground(Color.WHITE);
		btnChiTiet.setFocusPainted(false);
		btnChiTiet.setPreferredSize(new Dimension(150, 40));
		btnChiTiet.setCursor(new Cursor(Cursor.HAND_CURSOR));

		btnIn = new JButton("In Lại Hóa Đơn");
		btnIn.setFont(HEADER_FONT);
		btnIn.setBackground(new Color(127, 140, 141)); // Màu xám tinh tế
		btnIn.setForeground(Color.WHITE);
		btnIn.setFocusPainted(false);
		btnIn.setPreferredSize(new Dimension(160, 40));
		btnIn.setCursor(new Cursor(Cursor.HAND_CURSOR));

		bottom.add(btnChiTiet);
		bottom.add(btnIn);
		add(bottom, BorderLayout.SOUTH);

		// Khởi tạo nạp dữ liệu nền
		loadData();

		// Đăng ký sự kiện (Giữ nguyên gốc cấu trúc logic)
		btnTim.addActionListener(e -> timKiem());
		btnChiTiet.addActionListener(e -> xemChiTiet());
		btnIn.addActionListener(e -> inHoaDon());

		setVisible(true);
	}
	/*
	 * private void loadData() {
	 * 
	 * model.setRowCount(0);
	 * 
	 * double doanhThuHomNay = 0;
	 * 
	 * java.time.LocalDate homNay = java.time.LocalDate.now();
	 * 
	 * List<HoaDon> ds = hoaDonDAO.getAll();
	 * 
	 * for (HoaDon hd : ds) {
	 * 
	 * // =========================== // TÍNH DOANH THU HÔM NAY //
	 * =========================== if (hd.getNgayLap() != null) {
	 * 
	 * java.time.LocalDate ngayLap = hd.getNgayLap() .toLocalDateTime()
	 * .toLocalDate();
	 * 
	 * if (ngayLap.equals(homNay)) { doanhThuHomNay += hd.getTongTien(); } }
	 * 
	 * String tenKhach = ""; String cccd = "";
	 * 
	 * PhieuThuePhong pt = null;
	 * 
	 * for (PhieuThuePhong p : phieuBUS.getAll()) {
	 * 
	 * if (p.getMaPhieuThue() == hd.getMaPhieuThue()) {
	 * 
	 * pt = p; break; } }
	 * 
	 * KhachHang kh = null;
	 * 
	 * if (pt != null) {
	 * 
	 * kh = khachBUS.findById(pt.getMaKhachHang());
	 * 
	 * if (kh != null) {
	 * 
	 * tenKhach = kh.getHoTen();
	 * 
	 * cccd = kh.getCccd(); } }
	 * 
	 * model.addRow(new Object[]{
	 * 
	 * hd.getMaHoaDon(),
	 * 
	 * hd.getMaPhieuThue(),
	 * 
	 * tenKhach,
	 * 
	 * cccd,
	 * 
	 * hd.getNgayLap(),
	 * 
	 * String.format("%,.0f", hd.getTongTien()) }); }
	 * 
	 * lblTongDoanhThu.setText( "Doanh thu hôm nay: " + String.format("%,.0f",
	 * doanhThuHomNay) + " VNĐ"); }
	 */
	private void loadData() {

	    model.setRowCount(0);

	    double doanhThuHomNay = 0;

	    LocalDate homNay = LocalDate.now();

	    List<HoaDon> ds = hoaDonDAO.getAll();

	    // Hóa đơn mới nhất lên trước
	    ds.sort(
	        Comparator.comparing(
	            HoaDon::getNgayLap,
	            Comparator.nullsLast(Comparator.reverseOrder())
	        )
	    );

	    // Lấy danh sách phiếu thuê một lần
	    List<PhieuThuePhong> dsPhieuThue = phieuBUS.getAll();

	    for (HoaDon hd : ds) {

	        // ===========================
	        // TÍNH DOANH THU HÔM NAY
	        // ===========================

	        if (hd.getNgayLap() != null) {

	            LocalDate ngayLap =
	                    hd.getNgayLap()
	                       .toLocalDateTime()
	                       .toLocalDate();

	            if (ngayLap.equals(homNay)) {
	                doanhThuHomNay += hd.getTongTien();
	            }
	        }

	        String tenKhach = "";
	        String cccd = "";

	        PhieuThuePhong pt = null;

	        // Tìm phiếu thuê tương ứng
	        for (PhieuThuePhong p : dsPhieuThue) {

	            if (p.getMaPhieuThue() ==
	                    hd.getMaPhieuThue()) {

	                pt = p;
	                break;
	            }
	        }

	        // Tìm khách hàng
	        if (pt != null) {

	            KhachHang kh =
	                    khachBUS.findById(
	                            pt.getMaKhachHang()
	                    );

	            if (kh != null) {

	                tenKhach = kh.getHoTen();
	                cccd = kh.getCccd();
	            }
	        }

	        // Thêm vào bảng
	        model.addRow(
	                new Object[]{
	                        hd.getMaHoaDon(),
	                        hd.getMaPhieuThue(),
	                        tenKhach,
	                        cccd,
	                        hd.getNgayLap(),
	                        String.format(
	                                "%,.0f",
	                                hd.getTongTien()
	                        )
	                }
	        );
	    }

	    lblTongDoanhThu.setText(
	            "Doanh thu hôm nay: "
	            + String.format(
	                    "%,.0f",
	                    doanhThuHomNay
	            )
	            + " VNĐ"
	    );
	}
	
	/*
	 * private void timKiem() { String key =
	 * txtTimKiem.getText().trim().toLowerCase(); model.setRowCount(0);
	 * 
	 * for (HoaDon hd : hoaDonDAO.getAll()) { PhieuThuePhong pt = null; for
	 * (PhieuThuePhong p : phieuBUS.getAll()) { if (p.getMaPhieuThue() ==
	 * hd.getMaPhieuThue()) { pt = p; break; } }
	 * 
	 * if (pt == null) continue;
	 * 
	 * KhachHang kh = khachBUS.findById(pt.getMaKhachHang()); String tenKhach = "";
	 * String cccd = "";
	 * 
	 * if (kh != null) { tenKhach = kh.getHoTen().toLowerCase(); cccd =
	 * kh.getCccd().toLowerCase(); }
	 * 
	 * boolean match = String.valueOf(hd.getMaHoaDon()).contains(key) ||
	 * String.valueOf(hd.getMaPhieuThue()).contains(key) || tenKhach.contains(key)
	 * || cccd.contains(key);
	 * 
	 * if (match) { model.addRow(new Object[]{ hd.getMaHoaDon(),
	 * hd.getMaPhieuThue(), kh == null ? "" : kh.getHoTen(), kh == null ? "" :
	 * kh.getCccd(), hd.getNgayLap(), String.format("%,.0f", hd.getTongTien()) }); }
	 * } }
	 */
	private void timKiem() {

	    String key =
	            txtTimKiem.getText()
	                    .trim()
	                    .toLowerCase();

	    model.setRowCount(0);

	    List<HoaDon> ds =
	            hoaDonDAO.getAll();

	    // Hóa đơn mới nhất lên trước
	    ds.sort(
	        Comparator.comparing(
	            HoaDon::getNgayLap,
	            Comparator.nullsLast(
	                Comparator.reverseOrder()
	            )
	        )
	    );

	    List<PhieuThuePhong> dsPhieuThue =
	            phieuBUS.getAll();

	    for (HoaDon hd : ds) {

	        PhieuThuePhong pt = null;

	        for (PhieuThuePhong p : dsPhieuThue) {

	            if (p.getMaPhieuThue()
	                    == hd.getMaPhieuThue()) {

	                pt = p;
	                break;
	            }
	        }

	        if (pt == null)
	            continue;

	        KhachHang kh =
	                khachBUS.findById(
	                        pt.getMaKhachHang()
	                );

	        String tenKhach = "";
	        String cccd = "";

	        if (kh != null) {

	            tenKhach =
	                    kh.getHoTen()
	                      .toLowerCase();

	            cccd =
	                    kh.getCccd()
	                        .toLowerCase();
	        }

	        boolean match =
	                String.valueOf(
	                        hd.getMaHoaDon()
	                ).contains(key)

	                || String.valueOf(
	                        hd.getMaPhieuThue()
	                ).contains(key)

	                || tenKhach.contains(key)

	                || cccd.contains(key);

	        if (match) {

	            model.addRow(
	                    new Object[]{
	                            hd.getMaHoaDon(),
	                            hd.getMaPhieuThue(),
	                            kh == null
	                                    ? ""
	                                    : kh.getHoTen(),
	                            kh == null
	                                    ? ""
	                                    : kh.getCccd(),
	                            hd.getNgayLap(),
	                            String.format(
	                                    "%,.0f",
	                                    hd.getTongTien()
	                            )
	                    }
	            );
	        }
	    }
	}
	private void xemChiTiet() {

	    int row = tblHoaDon.getSelectedRow();

	    if (row < 0) {
	        JOptionPane.showMessageDialog(this, "Chọn hóa đơn");
	        return;
	    }

	    int maHoaDon =
	            Integer.parseInt(model.getValueAt(row, 0).toString());

	    HoaDon hoaDon = hoaDonDAO.getById(maHoaDon);

	    if (hoaDon == null) {
	        JOptionPane.showMessageDialog(this, "Không tìm thấy hóa đơn");
	        return;
	    }

	    PhieuThuePhong phieuThue =
	            phieuBUS.getById(hoaDon.getMaPhieuThue());

	    if (phieuThue == null) {
	        JOptionPane.showMessageDialog(this, "Không tìm thấy phiếu thuê");
	        return;
	    }

	    KhachHang kh =
	            khachBUS.findById(phieuThue.getMaKhachHang());

	    //--------------------------------------------------
	    // tính số ngày theo ngày nhận và ngày trả hiện tại
	    //--------------------------------------------------

	    LocalDate ngayNhan =
	            phieuThue.getNgayNhanPhong()
	                     .toLocalDateTime()
	                     .toLocalDate();

	    LocalDate ngayTra =
	            phieuThue.getNgayTraPhongDuKien()
	                     .toLocalDate();

	    long soNgay =
	            ChronoUnit.DAYS.between(ngayNhan, ngayTra);

	    if (soNgay <= 0)
	        soNgay = 1;

	    StringBuilder sb = new StringBuilder();

	    sb.append("=========== HÓA ĐƠN THANH TOÁN ===========\n\n");

	    sb.append("Mã Hóa Đơn: ")
	            .append(hoaDon.getMaHoaDon())
	            .append("\n");

	    sb.append("Mã Phiếu Thuê: ")
	            .append(phieuThue.getMaPhieuThue())
	            .append("\n\n");

	    if (kh != null) {

	        sb.append("Tên Khách Hàng: ")
	                .append(kh.getHoTen())
	                .append("\n");

	        sb.append("CCCD: ")
	                .append(kh.getCccd())
	                .append("\n");

	        sb.append("SĐT: ")
	                .append(kh.getSoDienThoai())
	                .append("\n\n");
	    }

	    sb.append("Ngày Nhận Phòng : ")
	            .append(phieuThue.getNgayNhanPhong())
	            .append("\n");

	    sb.append("Ngày Trả : ")
	            .append(phieuThue.getNgayTraPhongDuKien())
	            .append("\n");

	    sb.append("Số Ngày Thuê : ")
	            .append(soNgay)
	            .append(" ngày\n\n");

	    //--------------------------------------------------
	    // Danh sách phòng
	    //--------------------------------------------------

	    sb.append("========== DANH SÁCH PHÒNG ==========\n");

	    double tienPhong = 0;

	    List<ChiTietThuePhong> dsPhong =
	            ctDAO.getByPhieuThue(phieuThue.getMaPhieuThue());

	    for (ChiTietThuePhong ct : dsPhong) {

	        Phong p =
	                phongBUS.findById(ct.getMaPhong());

	        double thanhTien =
	                ct.getDonGia() * soNgay;

	        sb.append("Phòng ")
	                .append(p.getSoPhong())
	                .append(" : ")
	                .append(String.format("%,.0f", ct.getDonGia()))
	                .append(" x ")
	                .append(soNgay)
	                .append(" = ")
	                .append(String.format("%,.0f", thanhTien))
	                .append(" VNĐ\n");

	        tienPhong += thanhTien;
	    }

	    //--------------------------------------------------
	    // Dịch vụ
	    //--------------------------------------------------

	    sb.append("\n========== DỊCH VỤ ==========\n");

	    double tienDV = 0;

	    List<SuDungDichVu> dsDV =
	            dvDAO.getByPhieuThue(phieuThue.getMaPhieuThue());

	    if (dsDV.isEmpty()) {

	        sb.append("Không sử dụng dịch vụ\n");

	    } else {

	        for (SuDungDichVu sd : dsDV) {

	            DichVu dv =
	                    dichVuBUS.findById(sd.getMaDichVu());

	            sb.append(dv.getTenDichVu())
	                    .append(" x ")
	                    .append(sd.getSoLuong())
	                    .append(" = ")
	                    .append(String.format("%,.0f", sd.getThanhTien()))
	                    .append(" VNĐ\n");

	            tienDV += sd.getThanhTien();
	        }
	    }

	    //--------------------------------------------------
	    // Tổng cộng
	    //--------------------------------------------------

	    sb.append("\n---------------------------------------\n");

	    sb.append("Tiền Phòng : ")
	            .append(String.format("%,.0f", tienPhong))
	            .append(" VNĐ\n");

	    sb.append("Tiền Dịch Vụ : ")
	            .append(String.format("%,.0f", tienDV))
	            .append(" VNĐ\n");

	    sb.append("Tổng Thanh Toán : ")
	            .append(String.format("%,.0f", hoaDon.getTongTien()))
	            .append(" VNĐ\n");

	    sb.append("Tiền Khách Trả : ")
	            .append(String.format("%,.0f", hoaDon.getTienKhachTra()))
	            .append(" VNĐ\n");

	    sb.append("Tiền Còn Lại : ")
	            .append(String.format("%,.0f", hoaDon.getTienConLai()))
	            .append(" VNĐ\n");

	    sb.append("Ngày Lập Hóa Đơn : ")
	            .append(hoaDon.getNgayLap())
	            .append("\n");

	    sb.append("Trạng Thái : ")
	            .append(hoaDon.getTrangThaiThanhToan());

	    JTextArea area = new JTextArea(sb.toString());

	    area.setEditable(false);
	    area.setFont(new Font("Monospaced", Font.PLAIN, 14));

	    JScrollPane sp = new JScrollPane(area);

	    sp.setPreferredSize(new Dimension(700, 520));

	    JOptionPane.showMessageDialog(
	            this,
	            sp,
	            "Chi Tiết Hóa Đơn",
	            JOptionPane.INFORMATION_MESSAGE);
	}

	private void inHoaDon() {
		int row = tblHoaDon.getSelectedRow();
		if(row < 0){
			JOptionPane.showMessageDialog(this, "Chọn hóa đơn");
			return;
		}

		xemChiTiet();

		try {
			JTextArea area = new JTextArea();
			area.setText("HÓA ĐƠN KHÁCH SẠN");
			area.print();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}