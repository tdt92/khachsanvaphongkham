package gui;

import bus.KhachHangBUS;
import model.KhachHang;
import model.NhanVien;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyKhachHangForm extends JInternalFrame {

    JTextField txtHoTen;
    JTextField txtCCCD;
    JTextField txtSDT;
    JTextField txtEmail;
    JTextField txtDiaChi;
    JTextField txtQuocTich;
    JTextField txtTimKiem;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnTimKiem;
    JButton btnLamMoi;

    JTable table;
    DefaultTableModel model;
    KhachHangBUS bus = new KhachHangBUS();
    int selectedMaKH = -1;

    public QuanLyKhachHangForm() {
        super("QUẢN LÝ KHÁCH HÀNG", true, true, true, true);

        setSize(1150, 680);
        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);
        
        // Layout tổng thể dạng BorderLayout với khoảng cách hợp lý
        setLayout(new BorderLayout(15, 15));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));
        getContentPane().setBackground(new Color(245, 246, 250));

        // =====================================================================
        // 1. KHU VỰC NHẬP LIỆU (THIẾT KẾ GRIDBAGLAYOUT ĐẸP VÀ CÂN ĐỐI)
        // =====================================================================
        JPanel pInput = new JPanel(new GridBagLayout());
        pInput.setBackground(Color.WHITE);
        pInput.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(220, 224, 230), 1),
                        " Thông Tin Khách Hàng ", TitledBorder.LEFT, TitledBorder.TOP,
                        new Font("Segoe UI", Font.BOLD, 14), new Color(41, 128, 185)
                ),
                new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.weighty = 0.1;

        // Khởi tạo các ô text field với style chỉn chu
        txtHoTen = createStyledTextField();
        txtCCCD = createStyledTextField();
        txtSDT = createStyledTextField();
        txtEmail = createStyledTextField();
        txtDiaChi = createStyledTextField();
        txtQuocTich = createStyledTextField();

        // Dòng 1: Họ tên & CCCD
        addGridComp(pInput, createStyledLabel("Họ tên *"), gbc, 0, 0, 1, 0.1);
        addGridComp(pInput, txtHoTen, gbc, 1, 0, 1, 0.4);
        addGridComp(pInput, createStyledLabel("CCCD/Passport"), gbc, 2, 0, 1, 0.1);
        addGridComp(pInput, txtCCCD, gbc, 3, 0, 1, 0.4);

        // Dòng 2: SĐT & Email
        addGridComp(pInput, createStyledLabel("SĐT"), gbc, 0, 1, 1, 0.1);
        addGridComp(pInput, txtSDT, gbc, 1, 1, 1, 0.4);
        addGridComp(pInput, createStyledLabel("Email"), gbc, 2, 1, 1, 0.1);
        addGridComp(pInput, txtEmail, gbc, 3, 1, 1, 0.4);

        // Dòng 3: Địa chỉ & Quốc tịch
        addGridComp(pInput, createStyledLabel("Địa chỉ"), gbc, 0, 2, 1, 0.1);
        addGridComp(pInput, txtDiaChi, gbc, 1, 2, 1, 0.4);
        addGridComp(pInput, createStyledLabel("Quốc tịch"), gbc, 2, 2, 1, 0.1);
        addGridComp(pInput, txtQuocTich, gbc, 3, 2, 1, 0.4);

        add(pInput, BorderLayout.NORTH);

        // =====================================================================
        // 2. KHU VỰC THANH CÔNG CỤ TÌM KIẾM & BẢNG DỮ LIỆU (CENTER)
        // =====================================================================
        JPanel pCenter = new JPanel(new BorderLayout(10, 10));
        pCenter.setBackground(new Color(245, 246, 250));

        // Thanh công cụ tìm kiếm gọn gàng phía trên Table
        JPanel pSearchTool = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        pSearchTool.setBackground(Color.WHITE);
        pSearchTool.setBorder(BorderFactory.createLineBorder(new Color(230, 233, 240), 1));

        txtTimKiem = createStyledTextField();
        txtTimKiem.setPreferredSize(new Dimension(280, 35));
        
        btnTimKiem = createStyledButton("TÌM KIẾM", new Color(41, 128, 185));
        btnLamMoi = createStyledButton("LÀM MỚI", new Color(127, 140, 141));

        pSearchTool.add(createStyledLabel(" Nhập từ khóa:"));
        pSearchTool.add(txtTimKiem);
        pSearchTool.add(btnTimKiem);
        pSearchTool.add(btnLamMoi);

        pCenter.add(pSearchTool, BorderLayout.NORTH);

        // Khởi tạo bảng dữ liệu cấu trúc hiện đại
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã KH", "Họ tên", "CCCD/Passport", "SĐT", "Email", "Địa chỉ", "Quốc tịch"
        });

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 230)));
        pCenter.add(scrollPane, BorderLayout.CENTER);

        add(pCenter, BorderLayout.CENTER);

        // =====================================================================
        // 3. KHU VỰC THAO TÁC NÚT BẤM CHỨC NĂNG (SOUTH)
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        pBottom.setBackground(new Color(245, 246, 250));

        btnThem = createStyledButton("THÊM KHÁCH HÀNG", new Color(46, 204, 113));
        btnSua = createStyledButton("CẬP NHẬT (SỬA)", new Color(52, 152, 219));
        btnXoa = createStyledButton("XÓA HỒ SƠ", new Color(231, 76, 60));

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);

        add(pBottom, BorderLayout.SOUTH);

        // =====================================================================
        // 4. TOÀN BỘ LOGIC SỰ KIỆN GỐC (GIỮ NGUYÊN 100% HOẠT ĐỘNG)
        // =====================================================================
        loadData();

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedMaKH = Integer.parseInt(model.getValueAt(row, 0).toString());
                txtHoTen.setText(model.getValueAt(row, 1).toString());
                txtCCCD.setText(model.getValueAt(row, 2).toString());
                txtSDT.setText(model.getValueAt(row, 3).toString());
                txtEmail.setText(model.getValueAt(row, 4).toString());
                txtDiaChi.setText(model.getValueAt(row, 5).toString());
                txtQuocTich.setText(model.getValueAt(row, 6).toString());
            }
        });

        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnTimKiem.addActionListener(e -> timKiem());
        btnLamMoi.addActionListener(e -> {
            loadData();
            clearForm();
        });

        setVisible(true);
    }

    // --- CÁC HÀM XỬ LÝ LOGIC NGHIỆP VỤ GỐC (GIỮ NGUYÊN 100%) ---
    private void loadData() {
        model.setRowCount(0);
        for (KhachHang kh : bus.getAll()) {
            model.addRow(new Object[]{
                    kh.getMaKhachHang(), kh.getHoTen(), kh.getCccd(),
                    kh.getSoDienThoai(), kh.getEmail(), kh.getDiaChi(), kh.getQuocTich()
            });
        }
    }

    private void timKiem() {
        model.setRowCount(0);
        String keyword = txtTimKiem.getText().trim();
        for (KhachHang kh : bus.search(keyword)) {
            model.addRow(new Object[]{
                    kh.getMaKhachHang(), kh.getHoTen(), kh.getCccd(),
                    kh.getSoDienThoai(), kh.getEmail(), kh.getDiaChi(), kh.getQuocTich()
            });
        }
    }

    private void them() {
        try {
            if (txtHoTen.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập họ tên");
                txtHoTen.requestFocus();
                return;
            }

            if (txtCCCD.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập CCCD/Passport");
                txtCCCD.requestFocus();
                return;
            }

            String giayTo = txtCCCD.getText().trim();

            if (!giayTo.matches("^[A-Za-z0-9]{6,12}$")) {
                JOptionPane.showMessageDialog(this,
                        "CCCD/Passport phải từ 6 đến 12 ký tự, chỉ gồm chữ và số.");
                txtCCCD.requestFocus();
                return;
            }

            if (txtSDT.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập số điện thoại");
                txtSDT.requestFocus();
                return;
            }

            if (!txtSDT.getText().trim().matches("\\d{10}")) {
                JOptionPane.showMessageDialog(this, "Số điện thoại phải gồm 10 số");
                txtSDT.requestFocus();
                return;
            }

            if (txtQuocTich.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập quốc tịch");
                txtQuocTich.requestFocus();
                return;
            }

            if (bus.existsCCCD(txtCCCD.getText().trim())) {
                JOptionPane.showMessageDialog(this, "CCCD/Passport đã tồn tại trong hệ thống");
                txtCCCD.requestFocus();
                return;
            }

            KhachHang kh = new KhachHang();
            kh.setHoTen(txtHoTen.getText().trim());
            kh.setCccd(txtCCCD.getText().trim());
            kh.setSoDienThoai(txtSDT.getText().trim());
            kh.setEmail(txtEmail.getText().trim());
            kh.setDiaChi(txtDiaChi.getText().trim());
            kh.setQuocTich(txtQuocTich.getText().trim());

            if (bus.insert(kh)) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void sua() {
        try {
            if (selectedMaKH == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng");
                return;
            }

            if (txtHoTen.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập họ tên");
                txtHoTen.requestFocus();
                return;
            }

            if (txtCCCD.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập CCCD/Passport");
                txtCCCD.requestFocus();
                return;
            }

            String giayTo = txtCCCD.getText().trim();

            if (!giayTo.matches("^[A-Za-z0-9]{6,12}$")) {
                JOptionPane.showMessageDialog(this,
                        "CCCD/Passport phải từ 6 đến 12 ký tự, chỉ gồm chữ và số.");
                txtCCCD.requestFocus();
                return;
            }

            if (txtSDT.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập số điện thoại");
                txtSDT.requestFocus();
                return;
            }

            if (!txtSDT.getText().trim().matches("\\d{10}")) {
                JOptionPane.showMessageDialog(this, "Số điện thoại phải gồm 10 số");
                txtSDT.requestFocus();
                return;
            }

            if (txtQuocTich.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập quốc tịch");
                txtQuocTich.requestFocus();
                return;
            }

            if (bus.existsCCCD(txtCCCD.getText().trim(), selectedMaKH)) {
                JOptionPane.showMessageDialog(this, "CCCD/Passport đã tồn tại trong hệ thống");
                txtCCCD.requestFocus();
                return;
            }

            KhachHang kh = new KhachHang();
            kh.setMaKhachHang(selectedMaKH);
            kh.setHoTen(txtHoTen.getText().trim());
            kh.setCccd(txtCCCD.getText().trim());
            kh.setSoDienThoai(txtSDT.getText().trim());
            kh.setEmail(txtEmail.getText().trim());
            kh.setDiaChi(txtDiaChi.getText().trim());
            kh.setQuocTich(txtQuocTich.getText().trim());

            if (bus.update(kh)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoa() {
        if (selectedMaKH == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng");
            return;
        }
        if (bus.delete(selectedMaKH)) {
            JOptionPane.showMessageDialog(this, "Xóa thành công");
            loadData();
            clearForm();
        }
    }

    private void clearForm() {
        txtHoTen.setText("");
        txtCCCD.setText("");
        txtSDT.setText("");
        txtEmail.setText("");
        txtDiaChi.setText("");
        txtQuocTich.setText("");
        txtTimKiem.setText("");
        selectedMaKH = -1;
    }

    // =====================================================================
    // HÀM PHỤ TRỢ THIẾT KẾ UI ĐỒNG BỘ
    // =====================================================================
    private JTextField createStyledTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 208, 214), 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return field;
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(44, 62, 80));
        return label;
    }

    private JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor);
            }
        });
        return btn;
    }

    private void styleTable(JTable t) {
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setRowHeight(30);
        t.setGridColor(new Color(230, 233, 240));
        t.setSelectionBackground(new Color(52, 152, 219, 40));
        t.setSelectionForeground(new Color(44, 62, 80));

        JTableHeader header = t.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(41, 128, 185));
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        t.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
    }

    private void addGridComp(JPanel p, Component comp, GridBagConstraints gbc, int x, int y, int width, double weightX) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        gbc.weightx = weightX;
        p.add(comp, gbc);
    }
}