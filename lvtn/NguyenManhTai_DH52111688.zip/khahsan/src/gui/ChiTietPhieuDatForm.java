package gui;

import bus.*;
import model.*;
import util.EmailUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.util.List;

public class ChiTietPhieuDatForm extends JInternalFrame {

    private int maPhieuDat;

    private JLabel lblMaPhieuDat;
    private JTextField txtKhachHang;
    private JTextField txtTongTien;
    private JTextField txtTienCoc;
    private JTextArea txtGhiChu;

    private JDateChooser dcNhan;
    private JDateChooser dcTra;

    private JComboBox<LoaiPhong> cboLoaiPhong;
    private JComboBox<Phong> cboPhong;

    private JTable tblPhong;
    private DefaultTableModel model;
    private JButton btnXemBill;
    private JButton btnThemPhong;
    private JButton btnDoiPhong;
    private JButton btnCapNhat;
    private JButton btnXoa;
    private JButton btnInBill;
    
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();
    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private LoaiPhongBUS loaiBUS = new LoaiPhongBUS();
    private KhachHangBUS khBUS = new KhachHangBUS();

    // BẢNG MÀU PHẲNG HIỆN ĐẠI (FLAT UI PANEL)
    private static final Color MAU_NEN_FORM = new Color(248, 250, 252);     // Slate 50 sáng sủa, sang trọng
    private static final Color MAU_TEXT_CHINH = new Color(30, 41, 59);     // Slate 800 hiển thị chữ cực rõ nét
    private static final Color MAU_VIEN_NHẸ = new Color(226, 232, 240);     // Slate 200 cho viền mảnh tinh tế
    private static final Color MAU_NEN_COMP_KHOA = new Color(241, 245, 249);// Slate 100 dành cho textfield read-only
    private static final Color MAU_TIEU_DE_BANG = new Color(71, 85, 105);   // Slate 600 thanh lịch

    public ChiTietPhieuDatForm(int maPhieuDat) {
        this.maPhieuDat = maPhieuDat;

        setTitle("CHI TIẾT PHIẾU ĐẶT CHÍNH XÁC");
        setSize(1250, 780);

        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);

        initUI();
        loadLoaiPhong();
        loadData();
    }

    private void initUI() {
        Font plainFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font boldFont = new Font("Segoe UI", Font.BOLD, 14);

        setLayout(new BorderLayout(15, 15));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(20, 20, 20, 20));
        getContentPane().setBackground(MAU_NEN_FORM);

        // ==========================================
        // 1. VÙNG THÔNG TIN (NORTH PANEL)
        // ==========================================
        JPanel pnlTop = new JPanel(new GridBagLayout());
        pnlTop.setBackground(Color.WHITE);
        pnlTop.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(MAU_VIEN_NHẸ, 1, true),
                " Thông Tin Phiếu Đặt & Phòng ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 15),
                MAU_TEXT_CHINH
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        lblMaPhieuDat = new JLabel();
        lblMaPhieuDat.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMaPhieuDat.setForeground(new Color(239, 68, 68)); // Đỏ thẫm nổi bật mã phiếu

        txtKhachHang = new JTextField();
        txtTongTien = new JTextField();
        txtTienCoc = new JTextField();
        
        txtGhiChu = new JTextArea(3, 20);
        txtGhiChu.setFont(plainFont);
        txtGhiChu.setForeground(MAU_TEXT_CHINH);
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        txtGhiChu.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(MAU_VIEN_NHẸ),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));

        JTextField[] fields = {txtKhachHang, txtTongTien, txtTienCoc};
        for (JTextField field : fields) {
            field.setFont(boldFont);
            field.setForeground(MAU_TEXT_CHINH);
            field.setDisabledTextColor(MAU_TEXT_CHINH);
            field.setEditable(false);
            field.setPreferredSize(new Dimension(200, 36));
            field.setBackground(MAU_NEN_COMP_KHOA);
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(MAU_VIEN_NHẸ, 1, true),
                    BorderFactory.createEmptyBorder(5, 10, 5, 10)
            ));
        }

        dcNhan = new JDateChooser();
        dcTra = new JDateChooser();
        JDateChooser[] choosers = {dcNhan, dcTra};
        for (JDateChooser chooser : choosers) {
            chooser.setPreferredSize(new Dimension(200, 36));
            chooser.setFont(plainFont);
            chooser.setBackground(Color.WHITE);
            chooser.setBorder(BorderFactory.createLineBorder(MAU_VIEN_NHẸ, 1, true));
            chooser.getDateEditor().getUiComponent().setFont(plainFont);
            chooser.getDateEditor().getUiComponent().setForeground(MAU_TEXT_CHINH);
            if (chooser.getDateEditor().getUiComponent() instanceof JTextField) {
                ((JTextField) chooser.getDateEditor().getUiComponent()).setDisabledTextColor(MAU_TEXT_CHINH);
                ((JTextField) chooser.getDateEditor().getUiComponent()).setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
            }
        }

        dcNhan.getDateEditor().addPropertyChangeListener(e -> loadPhongTheoLoai());
        dcTra.getDateEditor().addPropertyChangeListener(e -> loadPhongTheoLoai());

        cboLoaiPhong = new JComboBox<>();
        cboPhong = new JComboBox<>();
        JComboBox<?>[] combos = {cboLoaiPhong, cboPhong};
        for (JComboBox<?> combo : combos) {
            combo.setPreferredSize(new Dimension(200, 36));
            combo.setFont(plainFont);
            combo.setForeground(MAU_TEXT_CHINH);
            combo.setBackground(Color.WHITE);
            combo.setBorder(BorderFactory.createLineBorder(MAU_VIEN_NHẸ, 1, true));
        }

        // Đổ layout ma trận dòng cột phẳng bọc thông tin
        gbc.gridx = 0; gbc.gridy = 0; pnlTop.add(createFormLabel("Mã phiếu đặt:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 1; pnlTop.add(lblMaPhieuDat, gbc);
        gbc.gridx = 2; gbc.gridy = 0; pnlTop.add(createFormLabel("Khách hàng:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 3; pnlTop.add(txtKhachHang, gbc);

        gbc.gridx = 0; gbc.gridy = 1; pnlTop.add(createFormLabel("Ngày nhận:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 1; pnlTop.add(dcNhan, gbc);
        gbc.gridx = 2; gbc.gridy = 1; pnlTop.add(createFormLabel("Ngày trả:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 3; pnlTop.add(dcTra, gbc);

        gbc.gridx = 0; gbc.gridy = 2; pnlTop.add(createFormLabel("Loại phòng trống:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 1; pnlTop.add(cboLoaiPhong, gbc);
        gbc.gridx = 2; gbc.gridy = 2; pnlTop.add(createFormLabel("Phòng trống:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 3; pnlTop.add(cboPhong, gbc);

        gbc.gridx = 0; gbc.gridy = 3; pnlTop.add(createFormLabel("Tổng tiền (VND):", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 1; pnlTop.add(txtTongTien, gbc);
        gbc.gridx = 2; gbc.gridy = 3; pnlTop.add(createFormLabel("Thanh toán:", boldFont, MAU_TEXT_CHINH), gbc);
        gbc.gridx = 3; pnlTop.add(txtTienCoc, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        pnlTop.add(createFormLabel("Yêu cầu đặc biệt:", boldFont, MAU_TEXT_CHINH), gbc);

        gbc.gridx = 1; gbc.gridwidth = 3;
        JScrollPane spGhiChu = new JScrollPane(txtGhiChu);
        spGhiChu.setPreferredSize(new Dimension(500, 70));
        spGhiChu.setBorder(BorderFactory.createLineBorder(MAU_VIEN_NHẸ));
        pnlTop.add(spGhiChu, gbc);

        gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.CENTER; // Reset anchor
        add(pnlTop, BorderLayout.NORTH);

        // ==========================================
        // 2. VÙNG DANH SÁCH BẢNG (CENTER PANEL)
        // ==========================================
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã phòng", "Số phòng", "Loại phòng", "Tầng", "Ngày nhận", "Ngày trả"
        });
        tblPhong = new JTable(model);
        
        tblPhong.setFont(plainFont);
        tblPhong.setForeground(MAU_TEXT_CHINH);
        tblPhong.setRowHeight(36); // Tăng độ cao dòng để thoáng dữ liệu
        tblPhong.setSelectionBackground(new Color(239, 246, 255)); // Màu xanh sáng dịu khi chọn dòng
        tblPhong.setSelectionForeground(MAU_TEXT_CHINH);
        tblPhong.setShowGrid(true);
        tblPhong.setGridColor(MAU_VIEN_NHẸ);

        // Custom Header Bảng sắc nét, độ tương phản cao
        JTableHeader header = tblPhong.getTableHeader();
        header.setFont(boldFont);
        header.setBackground(MAU_TIEU_DE_BANG);
        header.setForeground(Color.blue); // Chữ trắng trên nền xám đậm
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, MAU_VIEN_NHẸ));

        // Căn giữa và định màu đồng bộ dữ liệu ô bảng
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(JLabel.CENTER);
                setForeground(MAU_TEXT_CHINH);

                if (isSelected) {
                    setBackground(new Color(219, 234, 254));
                } else {
                    setBackground(row % 2 == 0 ? Color.WHITE : new Color(250, 251, 252)); // Hàng xen kẽ nhẹ
                }
                return c;
            }
        };

        tblPhong.setDefaultRenderer(Object.class, centerRenderer);
        JScrollPane scrollPane = new JScrollPane(tblPhong);
        scrollPane.setBackground(Color.WHITE);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(MAU_VIEN_NHẸ, 1, true),
                " Danh Sách Phòng Đã Chọn ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 14),
                MAU_TEXT_CHINH
        ));
        add(scrollPane, BorderLayout.CENTER);

        // ==========================================
        // 3. VÙNG CHỨC NĂNG NÚT BẤM (SOUTH PANEL)
        // ==========================================
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 12));
        pnlBottom.setBackground(MAU_NEN_FORM);

        btnThemPhong = createStyledButton("THÊM PHÒNG", new Color(16, 185, 129), Color.WHITE, boldFont); // Emerald Green
        btnDoiPhong = createStyledButton("ĐỔI PHÒNG", new Color(245, 158, 11), MAU_TEXT_CHINH, boldFont); // Amber 500
        btnCapNhat = createStyledButton("CẬP NHẬT PHIẾU", new Color(59, 130, 246), Color.WHITE, boldFont); // Blue 500
        btnXoa = createStyledButton("XÓA PHÒNG", new Color(239, 68, 68), Color.WHITE, boldFont);      // Red 500
        btnXemBill = createStyledButton("XEM BILL", new Color(6, 182, 212), Color.WHITE, boldFont);     // Cyan 500
        btnInBill = createStyledButton("IN BILL", new Color(100, 116, 139), Color.WHITE, boldFont);     // Slate 500

        pnlBottom.add(btnThemPhong);
        pnlBottom.add(btnDoiPhong);
        pnlBottom.add(btnCapNhat);
        pnlBottom.add(btnXoa);
        pnlBottom.add(btnXemBill);
        pnlBottom.add(btnInBill);

        add(pnlBottom, BorderLayout.SOUTH);

        // ĐĂNG KÝ LISTENERS (GIỮ NGUYÊN 100% HOẠT ĐỘNG LOGIC)
        cboLoaiPhong.addActionListener(e -> loadPhongTheoLoai());
        btnThemPhong.addActionListener(e -> themPhong());
        btnDoiPhong.addActionListener(e -> doiPhong());
        btnCapNhat.addActionListener(e -> capNhatPhieu());
        btnXoa.addActionListener(e -> xoaPhong());
        btnXemBill.addActionListener(e -> xemBill());
        btnInBill.addActionListener(e -> inBill());
        tblPhong.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            chonDongPhong();
        });
    }

    private JLabel createFormLabel(String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }

    private JButton createStyledButton(String text, Color bg, Color fg, Font font) {
        JButton btn = new JButton(text);
        btn.setFont(font);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(170, 42));
        btn.setBorder(BorderFactory.createLineBorder(bg.darker(), 1, true));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // =========================================================================
    // TOÀN BỘ LOGIC NGHIỆP VỤ BÊN DƯỚI ĐƯỢC GIỮ NGUYÊN HOÀN TOÀN KHÔNG THAY ĐỔI
    // =========================================================================
    private void loadData() {
        model.setRowCount(0);
        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        if (pd == null) return;

        KhachHang kh = khBUS.findById(pd.getMaKhachHang());
        if (kh != null) {
            txtKhachHang.setText(kh.getHoTen());
        }
        lblMaPhieuDat.setText(String.valueOf(pd.getMaPhieuDat()));
        dcNhan.setDate(pd.getNgayNhanPhong());
        dcTra.setDate(pd.getNgayTraPhong());
        txtTienCoc.setText(String.valueOf(pd.getTienCoc()));
        txtGhiChu.setText(pd.getGhiChu());
        double tongTien = 0;
        List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(maPhieuDat);

        for (ChiTietDatPhong ct : ds) {
            Phong p = phongBUS.findById(ct.getMaPhong());
            if (p == null) continue;

            LoaiPhong lp = loaiBUS.findById(p.getMaLoaiPhong());
            if (lp == null) continue;

            long soNgay = (pd.getNgayTraPhong().getTime() - pd.getNgayNhanPhong().getTime()) / (1000 * 60 * 60 * 24);
            if (soNgay <= 0) soNgay = 1;

            tongTien += lp.getDonGia() * soNgay;
            model.addRow(new Object[]{
                    p.getMaPhong(),
                    p.getSoPhong(),
                    lp.getTenLoaiPhong(),
                    p.getTang(),
                    pd.getNgayNhanPhong(),
                    pd.getNgayTraPhong()
            });
        }
        txtTongTien.setText(String.valueOf(tongTien));
    }

    private void loadLoaiPhong() {
        cboLoaiPhong.removeAllItems();
        for (LoaiPhong lp : loaiBUS.getAll()) {
            cboLoaiPhong.addItem(lp);
        }
    }

    private void loadPhongTheoLoai() {
        cboPhong.removeAllItems();
        LoaiPhong lp = (LoaiPhong) cboLoaiPhong.getSelectedItem();
        if (lp == null) return;
        if (dcNhan.getDate() == null || dcTra.getDate() == null) return;

        java.sql.Date ngayNhan = new java.sql.Date(dcNhan.getDate().getTime());
        java.sql.Date ngayTra = new java.sql.Date(dcTra.getDate().getTime());

        for (Phong p : phongBUS.getAll()) {
            if (p.getMaLoaiPhong() != lp.getMaLoaiPhong()) continue;

            boolean trong = ctdpBUS.isPhongTrong(p.getMaPhong(), ngayNhan, ngayTra, maPhieuDat);
            if (trong) {
                cboPhong.addItem(p);
            }
        }
    }

    private void themPhong() {
        if (dcNhan.getDate() == null || dcTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn ngày nhận và ngày trả");
            return;
        }
        if (!dcTra.getDate().after(dcNhan.getDate())) {
            JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn ngày nhận");
            return;
        }
        Phong p = (Phong) cboPhong.getSelectedItem();
        if (p == null) return;

        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        boolean trong = ctdpBUS.isPhongTrong(p.getMaPhong(), pd.getNgayNhanPhong(), pd.getNgayTraPhong(), maPhieuDat);
        if (!trong) {
            JOptionPane.showMessageDialog(this, "Phòng đã được đặt trong khoảng thời gian này");
            return;
        }

        boolean daTonTai = ctdpBUS.getByPhieuDat(maPhieuDat).stream()
                .anyMatch(x -> x.getMaPhong() == p.getMaPhong());
        if (daTonTai) {
            JOptionPane.showMessageDialog(this, "Phòng đã có trong phiếu đặt");
            return;
        }

        ChiTietDatPhong ct = new ChiTietDatPhong();
        ct.setMaPhieuDat(maPhieuDat);
        ct.setMaPhong(p.getMaPhong());

        if (ctdpBUS.insert(ct)) {
            capNhatTienCoc();
            JOptionPane.showMessageDialog(this, "Thêm phòng thành công");
            loadData();
            loadPhongTheoLoai();
        }
    }

    private void doiPhong() {
        if (dcNhan.getDate() == null || dcTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Chọn ngày nhận và ngày trả");
            return;
        }
        if (!dcTra.getDate().after(dcNhan.getDate())) {
            JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn ngày nhận");
            return;
        }
        int row = tblPhong.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn phòng cần đổi");
            return;
        }

        int maPhongCu = Integer.parseInt(model.getValueAt(row, 0).toString());
        Phong pMoi = (Phong) cboPhong.getSelectedItem();
        if (pMoi == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng mới");
            return;
        }

        ChiTietDatPhong ct = new ChiTietDatPhong();
        ct.setMaPhieuDat(maPhieuDat);
        ct.setMaPhong(pMoi.getMaPhong());

        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        boolean trong = ctdpBUS.isPhongTrong(pMoi.getMaPhong(), pd.getNgayNhanPhong(), pd.getNgayTraPhong(), maPhieuDat);
        if (!trong) {
            JOptionPane.showMessageDialog(this, "Phòng đã được đặt");
            return;
        }

        if (maPhongCu == pMoi.getMaPhong()) {
            JOptionPane.showMessageDialog(this, "Bạn đang chọn đúng phòng hiện tại");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận đổi phòng ?", "Đổi phòng", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        boolean tonTai = ctdpBUS.getByPhieuDat(maPhieuDat).stream()
                .anyMatch(x -> x.getMaPhong() == pMoi.getMaPhong());
        if (tonTai) {
            JOptionPane.showMessageDialog(this, "Phòng đã có trong phiếu đặt");
            return;
        }

        boolean them = ctdpBUS.insert(ct);
        if (!them) {
            JOptionPane.showMessageDialog(this, "Đổi phòng thất bại");
            return;
        }

        JOptionPane.showMessageDialog(this, "Đổi phòng thành công");
        boolean xoa = ctdpBUS.delete(maPhieuDat, maPhongCu);
        if (!xoa) {
            JOptionPane.showMessageDialog(this, "Không thể xóa phòng cũ");
            return;
        }
        capNhatTienCoc();
        loadData();
        loadPhongTheoLoai();
    }

    private void xoaPhong() {
        int row = tblPhong.getSelectedRow();
        if (row == -1) return;

        int maPhong = Integer.parseInt(model.getValueAt(row, 0).toString());
        int c = JOptionPane.showConfirmDialog(this, "Xóa phòng này ?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (c != JOptionPane.YES_OPTION) return;

        if (ctdpBUS.getByPhieuDat(maPhieuDat).size() == 1) {
            JOptionPane.showMessageDialog(this, "Phiếu đặt phải có ít nhất 1 phòng");
            return;
        }
        if (ctdpBUS.delete(maPhieuDat, maPhong)) {
            capNhatTienCoc();
            loadData();
            loadPhongTheoLoai();
        }
    }

    private void inBill() {
        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        if (pd == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy phiếu đặt");
            return;
        }

        KhachHang kh = khBUS.findById(pd.getMaKhachHang());
        StringBuilder sb = new StringBuilder();

        sb.append("============== HOTEL BILL ==============\n\n");
        sb.append("Mã phiếu đặt : ").append(pd.getMaPhieuDat()).append("\n");
        sb.append("Khách hàng : ").append(kh == null ? "" : kh.getHoTen()).append("\n");
        sb.append("Ngày nhận : ").append(pd.getNgayNhanPhong()).append("\n");
        sb.append("Ngày trả : ").append(pd.getNgayTraPhong()).append("\n\n");
        
        if (pd.getGhiChu() != null && !pd.getGhiChu().trim().isEmpty()) {
            sb.append("Ghi chú : ").append(pd.getGhiChu()).append("\n\n");
        }
        sb.append("----------------------------------------\n");
        sb.append(String.format("%-10s %-15s %-12s\n", "Phòng", "Loại", "Đơn giá"));
        sb.append("----------------------------------------\n");

        long soNgay = (pd.getNgayTraPhong().getTime() - pd.getNgayNhanPhong().getTime()) / (1000 * 60 * 60 * 24);
        if (soNgay <= 0) soNgay = 1;

        double tongTien = 0;
        List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(maPhieuDat);

        for (ChiTietDatPhong ct : ds) {
            Phong p = phongBUS.findById(ct.getMaPhong());
            if (p == null) continue;

            LoaiPhong lp = loaiBUS.findById(p.getMaLoaiPhong());
            if (lp == null) continue;

            double tien = lp.getDonGia() * soNgay;
            tongTien += tien;

            sb.append(String.format("%-10s %-15s %,.0f\n", p.getSoPhong(), lp.getTenLoaiPhong(), tien));
        }

        sb.append("----------------------------------------\n");
        sb.append("Số ngày ở : ").append(soNgay).append("\n");
        sb.append("Tổng tiền : ").append(String.format("%,.0f", tongTien)).append(" VNĐ\n");
        sb.append("Thanh toán : ").append(String.format("%,.0f", pd.getTienCoc())).append(" VNĐ\n\n");
        sb.append("========================================");

        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));

        try {
            boolean done = area.print();
            if (done) {
                JOptionPane.showMessageDialog(this, "Đã gửi Bill tới máy in");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Không thể in bill");
        }
    }

    private double tinhTongTien(PhieuDatPhong pd) {
        double tongTien = 0;
        long soNgay = (pd.getNgayTraPhong().getTime() - pd.getNgayNhanPhong().getTime()) / (1000 * 60 * 60 * 24);
        if (soNgay <= 0) soNgay = 1;

        List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
        for (ChiTietDatPhong ct : ds) {
            Phong p = phongBUS.findById(ct.getMaPhong());
            if (p == null) continue;

            LoaiPhong lp = loaiBUS.findById(p.getMaLoaiPhong());
            if (lp == null) continue;

            tongTien += lp.getDonGia() * soNgay;
        }
        return tongTien;
    }

    private String taoNoiDungBill() {

        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);

        if (pd == null) {
            return "Không tìm thấy phiếu đặt.";
        }

        KhachHang kh = khBUS.findById(pd.getMaKhachHang());

        StringBuilder sb = new StringBuilder();

        sb.append("============================================================\n");
        sb.append("                 LUXURY HOTEL BOOKING BILL                  \n");
        sb.append("============================================================\n\n");

        sb.append(String.format("Mã phiếu đặt : %d\n", pd.getMaPhieuDat()));
        sb.append(String.format("Khách hàng   : %s\n",
                kh == null ? "Khách vãng lai" : kh.getHoTen()));

        if (kh != null) {
            sb.append(String.format("SĐT          : %s\n",
                    kh.getSoDienThoai() == null ? "" : kh.getSoDienThoai()));

            sb.append(String.format("Email        : %s\n",
                    kh.getEmail() == null ? "" : kh.getEmail()));
        }

        sb.append(String.format("Ngày nhận    : %s\n", pd.getNgayNhanPhong()));
        sb.append(String.format("Ngày trả     : %s\n", pd.getNgayTraPhong()));
        sb.append(String.format("Tiền cọc     : %,.0f VNĐ\n", pd.getTienCoc()));

        sb.append("\n");

        if (pd.getGhiChu() != null && !pd.getGhiChu().trim().isEmpty()) {

            sb.append("------------------------------------------------------------\n");
            sb.append("YÊU CẦU ĐẶC BIỆT CỦA KHÁCH \n");
            sb.append("------------------------------------------------------------\n");
            sb.append(pd.getGhiChu()).append("\n\nMọi yêu cầu đặc biệt đều tùy thuộc vào tình trạng sẵn có khi đến nơi.\n");
        }

        long soNgay =
                (pd.getNgayTraPhong().getTime()
                        - pd.getNgayNhanPhong().getTime())
                        / (1000 * 60 * 60 * 24);

        if (soNgay <= 0) {
            soNgay = 1;
        }

        double tongTien = 0;

        sb.append("============================================================\n");
        sb.append("                 THÔNG TIN PHÒNG ĐẶT                        \n");
        sb.append("============================================================\n");

        int stt = 1;

        for (ChiTietDatPhong ct : ctdpBUS.getByPhieuDat(maPhieuDat)) {

            Phong phong = phongBUS.findById(ct.getMaPhong());

            if (phong == null)
                continue;

            LoaiPhong loai =
                    loaiBUS.findById(phong.getMaLoaiPhong());

            if (loai == null)
                continue;

            double tienPhong = loai.getDonGia() * soNgay;

            tongTien += tienPhong;

            sb.append("Phòng ").append(stt++).append("\n");
            sb.append("----------------------------------------\n");
            sb.append(String.format("Số phòng           : %s\n",
                    phong.getSoPhong()));

            sb.append(String.format("Loại phòng         : %s\n",
                    loai.getTenLoaiPhong()));

            sb.append(String.format("Sức chứa tối đa    : %d người\n",
                    loai.getSoNguoiToiDa()));

            sb.append(String.format("Đơn giá            : %,.0f VNĐ / đêm\n",
                    loai.getDonGia()));

            sb.append(String.format("Số đêm             : %d\n",
                    soNgay));

            sb.append(String.format("Thành tiền         : %,.0f VNĐ\n",
                    tienPhong));

            sb.append("Mô tả phòng        : ");

            if (loai.getMoTa() == null || loai.getMoTa().trim().isEmpty()) {
                sb.append("Không có");
            } else {
                sb.append(loai.getMoTa());
            }

            sb.append("\n\n");
        }

        sb.append("============================================================\n");
        sb.append("                 TỔNG THANH TOÁN                            \n");
        sb.append("============================================================\n");

        sb.append(String.format("Số đêm lưu trú : %d\n", soNgay));
        sb.append(String.format("Tổng tiền      : %,.0f VNĐ\n", tongTien));
        sb.append(String.format("Tiền cọc       : %,.0f VNĐ\n", pd.getTienCoc()));

        double conLai = tongTien - pd.getTienCoc();

        if (conLai < 0) {
            conLai = 0;
        }

        sb.append(String.format("Còn phải trả   : %,.0f VNĐ\n", conLai));

        sb.append("Phụ phí có thể áp dụng khi bổ sung thêm khách, giới hạn ở sức chứa tối đa.\n");
        sb.append("============================================================\n");
        sb.append("        CẢM ƠN QUÝ KHÁCH ĐÃ LỰA CHỌN LUXURY HOTEL            \n");
        sb.append("============================================================ \n");
        sb.append("        HỦY PHÒNG TRƯỚC NGÀY NHẬN 7 NGÀY ĐỂ ĐƯỢC HOÀN TIỀN           \n");


        return sb.toString();
    }

    // Hàm bổ trợ 1: Tự động căn trái và bù khoảng trắng chuẩn xác theo ký tự tiếng Việt
    private String padRight(String s, int n) {
        if (s == null) s = "";
        if (s.length() >= n) return s.substring(0, n);
        return s + " ".repeat(n - s.length());
    }

    // Hàm bổ trợ 2: Tự động căn phải và bù khoảng trắng trước chuỗi (Dành cho hiển thị tiền)
    private String padLeft(String s, int n) {
        if (s == null) s = "";
        if (s.length() >= n) return s.substring(0, n);
        return " ".repeat(n - s.length()) + s;
    }

    private void xemBill() {

        JTextArea txt = new JTextArea(taoNoiDungBill());

        txt.setEditable(false);
        txt.setFont(new Font("Monospaced", Font.PLAIN, 14));

        JScrollPane sp = new JScrollPane(txt);

        JButton btnGui =
                new JButton("Xác nhận");

        JButton btnDong =
                new JButton("Đóng");

        JPanel pnlBtn = new JPanel();

        pnlBtn.add(btnGui);
        pnlBtn.add(btnDong);

        JDialog dialog =
                new JDialog(
                        (Frame) SwingUtilities.getWindowAncestor(this),
                        "Chi tiết Bill",
                        true);

        dialog.setLayout(new BorderLayout());

        dialog.add(sp, BorderLayout.CENTER);

        dialog.add(pnlBtn, BorderLayout.SOUTH);

        dialog.setSize(700,550);

        dialog.setLocationRelativeTo(this);

        btnDong.addActionListener(e ->
                dialog.dispose());

        btnGui.addActionListener(e -> guiBillQuaMail());

        dialog.setVisible(true);
    }
    private void guiBillQuaMail() {

        PhieuDatPhong pd =
                pdBUS.findById(maPhieuDat);

        if (pd == null)
            return;

        KhachHang kh =
                khBUS.findById(pd.getMaKhachHang());

        if (kh == null) {

            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy khách hàng.");

            return;
        }

        if (kh.getEmail() == null ||
                kh.getEmail().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Khách hàng chưa có Email.");

            return;
        }

        try {

            EmailUtil.guiMail(

                    kh.getEmail(),

                    "Xác nhận đặt phòng - Benefit Hotel",

                    taoNoiDungBill()

            );

            JOptionPane.showMessageDialog(this,
                    "Đã gửi Bill tới Email khách hàng.");

        } catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Gửi Email thất bại.");
        }

    }

    private void chonDongPhong() {
        int row = tblPhong.getSelectedRow();
        if (row == -1) return;

        int maPhong = Integer.parseInt(model.getValueAt(row, 0).toString());
        Phong p = phongBUS.findById(maPhong);
        if (p == null) return;

        for (int i = 0; i < cboLoaiPhong.getItemCount(); i++) {
            LoaiPhong lp = cboLoaiPhong.getItemAt(i);
            if (lp.getMaLoaiPhong() == p.getMaLoaiPhong()) {
                cboLoaiPhong.setSelectedIndex(i);
                break;
            }
        }

        loadPhongTheoLoai();

        for (int i = 0; i < cboPhong.getItemCount(); i++) {
            Phong phong = cboPhong.getItemAt(i);
            if (phong.getMaPhong() == p.getMaPhong()) {
                cboPhong.setSelectedIndex(i);
                break;
            }
        }
    }

    private void capNhatPhieu() {
        if (dcNhan.getDate() == null || dcTra.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ngày nhận và ngày trả");
            return;
        }
        if (!dcTra.getDate().after(dcNhan.getDate())) {
            JOptionPane.showMessageDialog(this, "Ngày trả phải lớn hơn ngày nhận");
            return;
        }

        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        if (pd == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy phiếu đặt");
            return;
        }

        java.sql.Date ngayNhanMoi = new java.sql.Date(dcNhan.getDate().getTime());
        java.sql.Date ngayTraMoi = new java.sql.Date(dcTra.getDate().getTime());

        List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(maPhieuDat);
        for (ChiTietDatPhong ct : ds) {
            boolean trong = ctdpBUS.isPhongTrong(ct.getMaPhong(), ngayNhanMoi, ngayTraMoi, maPhieuDat);
            if (!trong) {
                JOptionPane.showMessageDialog(this, "Phòng " + ct.getMaPhong() + " đã được đặt trong khoảng thời gian mới");
                return;
            }
        }

        pd.setNgayNhanPhong(ngayNhanMoi);
        pd.setNgayTraPhong(ngayTraMoi);
        pd.setGhiChu(txtGhiChu.getText().trim());
        double tongTien = tinhTongTienTheoNgay(pd, ngayNhanMoi, ngayTraMoi);
        pd.setTienCoc(tongTien);

        if (pdBUS.update(pd)) {
            txtTongTien.setText(String.valueOf(tongTien));
            txtTienCoc.setText(String.valueOf(tongTien));
            JOptionPane.showMessageDialog(this, "Cập nhật thành công");
            loadData();
            loadPhongTheoLoai();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại");
        }
    }

    private void capNhatTienCoc() {
        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        if (pd == null) return;

        double tongTien = tinhTongTien(pd);
        pd.setTienCoc(tongTien);
        pd.setGhiChu(txtGhiChu.getText().trim());
        if (pdBUS.update(pd)) {
            txtTongTien.setText(String.valueOf(tongTien));
            txtTienCoc.setText(String.valueOf(tongTien));
        }
    }

    private double tinhTongTienTheoNgay(PhieuDatPhong pd, java.sql.Date ngayNhan, java.sql.Date ngayTra) {
        double tongTien = 0;
        long soNgay = (ngayTra.getTime() - ngayNhan.getTime()) / (1000 * 60 * 60 * 24);
        if (soNgay <= 0) soNgay = 1;

        List<ChiTietDatPhong> ds = ctdpBUS.getByPhieuDat(pd.getMaPhieuDat());
        for (ChiTietDatPhong ct : ds) {
            Phong p = phongBUS.findById(ct.getMaPhong());
            if (p == null) continue;

            LoaiPhong lp = loaiBUS.findById(p.getMaLoaiPhong());
            if (lp == null) continue;

            tongTien += lp.getDonGia() * soNgay;
        }
        return tongTien;
    }
}