package gui;

import bus.*;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.Timestamp;

public class NhanPhongTuDatForm extends JInternalFrame {

    private int maPhieuDat;
    private JDesktopPane desktop;
    private JTable tbl;

    private DefaultTableModel model;
    private JButton btnLamMoi;
    private JButton btnNhanPhong;
    private JButton btnHoanThanh;
    
    private ChiTietDatPhongBUS ctdpBUS = new ChiTietDatPhongBUS();
    private PhongBUS phongBUS = new PhongBUS();
    private PhieuDatPhongBUS pdBUS = new PhieuDatPhongBUS();
    private PhieuThuePhongBUS ptBUS = new PhieuThuePhongBUS();
    private ChiTietThuePhongBUS cttpBUS = new ChiTietThuePhongBUS();

    // Bảng màu cấu trúc Modern UI đồng bộ hệ thống
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);     // Xanh dương (Thao tác chính)
    private final Color SUCCESS_COLOR = new Color(46, 204, 113);     // Xanh lá (Hoàn thành)
    private final Color RESET_COLOR = new Color(149, 165, 166);       // Xám hiện đại (Làm mới)
    private final Color BACKGROUND_COLOR = new Color(245, 246, 250);  // Nền form xám nhạt dịu mắt

    public NhanPhongTuDatForm(int maPhieuDat, JDesktopPane desktop) {
        super(
                "NHẬN PHÒNG",
                true,
                true,
                true,
                true);

        this.maPhieuDat = maPhieuDat;
        this.desktop = desktop;

        initUI();
        loadData();
    }

    private void initUI() {
        setSize(800, 500);
        setLayout(new BorderLayout(0, 15));
        
        // Cấu hình không gian đệm xung quanh form chính
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));
        getContentPane().setBackground(BACKGROUND_COLOR);

        // ----------------- KHU VỰC BẢNG HIỂN THỊ (CENTER) -----------------
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Chặn chỉnh sửa trực tiếp trên ô lưới dữ liệu
            }
        };

        model.setColumnIdentifiers(new String[]{
                "Mã Phòng", "Số Phòng"
        });

        tbl = new JTable(model);
        tbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tbl.setRowHeight(35); // Chiều cao hàng thoáng đãng, dễ tương tác track-row
        tbl.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tbl.setGridColor(new Color(240, 242, 245));
        tbl.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo style Modern Grid

        // Tùy biến thanh tiêu đề của bảng (JTableHeader)
        JTableHeader header = tbl.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.black);
        header.setPreferredSize(new Dimension(header.getWidth(), 38));
        header.setReorderingAllowed(false);

        // Định dạng căn lề giữa cho toàn bộ dữ liệu hiển thị
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tbl.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tbl.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(tbl);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 230)));
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // ----------------- THANH ĐIỀU HƯỚNG NÚT BẤM (SOUTH) -----------------
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        pBottom.setBackground(BACKGROUND_COLOR);

        btnLamMoi = createStyledButton("Làm Mới", RESET_COLOR);
        btnNhanPhong = createStyledButton("Nhận Phòng", PRIMARY_COLOR);
        btnHoanThanh = createStyledButton("Hoàn Thành", SUCCESS_COLOR);

        pBottom.add(btnLamMoi);
        pBottom.add(btnNhanPhong);
        pBottom.add(btnHoanThanh);

        add(pBottom, BorderLayout.SOUTH);

        // ĐĂNG KÝ CÁC SỰ KIỆN ACTIONS (GIỮ NGUYÊN 100% HOẠT ĐỘNG LOGIC GỐC)
        btnLamMoi.addActionListener(e -> {
            loadData();
        });
        btnNhanPhong.addActionListener(e -> nhanPhong());
        btnHoanThanh.addActionListener(e -> hoanThanh());
    }

    // --- CÁC HÀM XỬ LÝ LOGIC NGHIỆP VỤ GỐC (GIỮ NGUYÊN 100%) ---
    private void loadData() {
        model.setRowCount(0);

        for(ChiTietDatPhong ct : ctdpBUS.getByPhieuDat(maPhieuDat)) {
            boolean daNhan = false;

            for(PhongDangThueDTO p : cttpBUS.getPhongDangThue()) {
                if(p.getMaPhong() == ct.getMaPhong()) {
                    daNhan = true;
                    break;
                }
            }

            if(!daNhan) {
                Phong phong = phongBUS.findById(ct.getMaPhong());

                model.addRow(new Object[]{
                                ct.getMaPhong(),
                                phong == null ? "" : phong.getSoPhong()
                        });
            }
        }
    }

    private void hoanThanh() {
        PhieuDatPhong pd = pdBUS.findById(maPhieuDat);
        
        if(!daNhanHetPhong()){
            JOptionPane.showMessageDialog(this, "Vẫn còn phòng chưa nhận");
            return;
        }
        if(pd == null){
            JOptionPane.showMessageDialog(this, "Không tìm thấy phiếu đặt");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                        this,
                        "Xác nhận hoàn tất nhận phòng?",
                        "Thông báo",
                        JOptionPane.YES_NO_OPTION);

        if(confirm != JOptionPane.YES_OPTION){
            return;
        }

        pd.setTrangThai("DA_NHAN");
        boolean kq = pdBUS.update(pd);

        if(kq){
            JOptionPane.showMessageDialog(this, "Đã cập nhật trạng thái DA_NHAN");
            dispose();
        }else{
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại");
        }
    }

    private boolean daNhanHetPhong() {
        for(ChiTietDatPhong ct : ctdpBUS.getByPhieuDat(maPhieuDat)) {
            boolean daNhan = false;

            for(PhongDangThueDTO p : cttpBUS.getPhongDangThue()) {
                if(p.getMaPhong() == ct.getMaPhong()) {
                    daNhan = true;
                    break;
                }
            }

            if(!daNhan){
                return false;
            }
        }
        return true;
    }

    private void nhanPhong() {
        int row = tbl.getSelectedRow();

        if(row == -1){
            JOptionPane.showMessageDialog(this, "Chọn phòng");
            return;
        }

        int maPhong = Integer.parseInt(model.getValueAt(row, 0).toString());

        KhachNhanPhongForm f = new KhachNhanPhongForm(maPhieuDat, maPhong);
        desktop.add(f);
        f.setVisible(true);

        try{
            f.setSelected(true);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    // Hàm phụ trợ khởi tạo thiết kế nút bấm phẳng có hiệu ứng đổi màu hover nhẹ
    private JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(130, 40));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor.brighter());
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor);
            }
        });
        return btn;
    }
}