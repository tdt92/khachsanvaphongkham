package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyVetoException;

public class QuanLyForm extends JInternalFrame {

    private JDesktopPane desktopPane;
    JButton btnThongKe;
    JButton btnNhanSu;
    JButton btnTaiKhoan;
    JButton btnLoaiPhong;
    JButton btnPhong;
    JButton btnKhachHang;
    JButton btnDichVu;
    JButton btnPhanCong;
	/*
	 * JButton btnDatPhong; JButton btnThuePhong;
	 */

    // Hàm tiện ích giúp tùy biến nút bấm đẹp mắt và hiện đại hơn
    private void styleButton(JButton btn) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(30, 41, 59)); // Màu Slate Dark sang trọng, đồng bộ với Header
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(71, 85, 105), 1),
            BorderFactory.createEmptyBorder(15, 25, 15, 25)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hiệu ứng Hover mượt mà
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(14, 116, 144)); // Chuyển sang tông xanh Teal nổi bật khi hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(30, 41, 59));
            }
        });
    }

    // Hàm bổ trợ giúp hiển thị Form lên trước mặt và phóng to Toàn màn hình
    private void hienThiFormFull(JInternalFrame f) {
        desktopPane.add(f);
        f.setVisible(true);
        try {
            f.setSelected(true);  // Đưa form lên phía trước (Front)
            f.setMaximum(true);   // Mở full màn hình bên trong DesktopPane
        } catch (PropertyVetoException ex) {
            ex.printStackTrace();
        }
    }

    public QuanLyForm(JDesktopPane desktopPane) {
        super("QUẢN LÝ KHÁCH SẠN", true, true, true, true);
        setClosable(false);
        setResizable(false);
        setMaximizable(false);
        setIconifiable(false);
        this.desktopPane = desktopPane;
        setSize(1100, 680);
        getContentPane().setBackground(new Color(248, 250, 252)); // Nền xám trắng nhẹ dịu mắt
        setLayout(new BorderLayout());

        // --- 1. TẠO HEADER PANEL ---
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(15, 23, 42)); // Tông màu tối sâu (Deep Navy)
        headerPanel.setBorder(new EmptyBorder(20, 40, 20, 40));
        
        JLabel lblTitle = new JLabel("BÀN LÀM VIỆC BAN QUẢN LÝ");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        
        JLabel lblSub = new JLabel("Hệ thống điều hành phân hệ cốt lõi");
        lblSub.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSub.setForeground(new Color(148, 163, 184));
        
        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(lblSub, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // --- 2. TẠO GRID PANEL CHỨA NÚT ---
        // Thay đổi từ (6, 2) thành (4, 2) vì bạn có chính xác 8 nút, tránh ô trống thừa phía dưới
        JPanel p = new JPanel(new GridLayout(5, 2, 25, 25));
        p.setBackground(new Color(248, 250, 252));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		/*
		 * btnDatPhong = new JButton("QUẢN LÝ ĐẶT PHÒNG"); btnThuePhong = new
		 * JButton("QUẢN LÝ THUÊ PHÒNG");
		 */
        btnThongKe = new JButton("THỐNG KÊ DOANH THU");
        btnNhanSu = new JButton("QUẢN LÝ NHÂN SỰ");
        btnTaiKhoan = new JButton("QUẢN LÝ TÀI KHOẢN");
        btnLoaiPhong = new JButton("QUẢN LÝ LOẠI PHÒNG");
        btnPhong = new JButton("QUẢN LÝ PHÒNG");
        btnKhachHang = new JButton("QUẢN LÝ KHÁCH HÀNG");
        btnDichVu = new JButton("QUẢN LÝ DỊCH VỤ");
        btnPhanCong = new JButton("PHÂN CÔNG NHÂN VIÊN");
      
        // Áp dụng style đồng bộ
        styleButton(btnThongKe);
        styleButton(btnNhanSu);
        styleButton(btnTaiKhoan);
        styleButton(btnLoaiPhong);
        styleButton(btnPhong);
        styleButton(btnKhachHang);
        styleButton(btnDichVu);
        styleButton(btnPhanCong);
		/*
		 * styleButton(btnDatPhong); styleButton(btnThuePhong);
		 */
        // Kích thước chuẩn cho GridBagLayout co giãn
        Dimension size = new Dimension(300, 70);
        btnThongKe.setPreferredSize(size);
        btnNhanSu.setPreferredSize(size);
        btnTaiKhoan.setPreferredSize(size);
        btnLoaiPhong.setPreferredSize(size);
        btnPhong.setPreferredSize(size);
        btnKhachHang.setPreferredSize(size);
        btnDichVu.setPreferredSize(size);
        btnPhanCong.setPreferredSize(size);
		/*
		 * btnDatPhong.setPreferredSize(size); btnThuePhong.setPreferredSize(size);
		 */
        p.add(btnThongKe);
        p.add(btnNhanSu);
        p.add(btnTaiKhoan);
        p.add(btnLoaiPhong);
        p.add(btnPhong);
        p.add(btnKhachHang);
        p.add(btnDichVu);
        p.add(btnPhanCong);
		/*
		 * p.add(btnDatPhong); p.add(btnThuePhong);
		 */
        // Bọc vào GridBagLayout để giữ cụm nút luôn ở trung tâm màn hình, không bị kéo dãn méo mó
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(new Color(248, 250, 252));
        centerWrapper.add(p);
        add(centerWrapper, BorderLayout.CENTER);

        // =====================================================================
        // XỬ LÝ SỰ KIỆN: HIỂN THỊ PHÍA TRƯỚC VÀ MỞ FULL MÀN HÌNH
        // =====================================================================
        btnNhanSu.addActionListener(e -> {
            QuanLyNhanVienForm f = new QuanLyNhanVienForm();
            hienThiFormFull(f);
        });

        btnTaiKhoan.addActionListener(e -> {
            QuanLyTaiKhoanForm f = new QuanLyTaiKhoanForm();
            hienThiFormFull(f);
        });

        btnThongKe.addActionListener(e -> {
            ThongKeForm f = new ThongKeForm();
            hienThiFormFull(f);
        });

        btnLoaiPhong.addActionListener(e -> {
            QuanLyLoaiPhongForm f = new QuanLyLoaiPhongForm();
            hienThiFormFull(f);
        });

        btnPhong.addActionListener(e -> {
            QuanLyPhongForm f = new QuanLyPhongForm();
            hienThiFormFull(f);
        });

        btnKhachHang.addActionListener(e -> {
            QuanLyKhachHangForm f = new QuanLyKhachHangForm();
            hienThiFormFull(f);
        });

        btnDichVu.addActionListener(e -> {
            QuanLyDichVuForm f = new QuanLyDichVuForm();
            hienThiFormFull(f);
        });
		/*
		 * btnDatPhong.addActionListener(e -> {
		 * 
		 * DatPhongForm f = new DatPhongForm();
		 * 
		 * hienThiFormFull(f);
		 * 
		 * });
		 * 
		 * btnThuePhong.addActionListener(e -> {
		 * 
		 * NhanPhongForm f = new NhanPhongForm();
		 * 
		 * hienThiFormFull(f);
		 * 
		 * });
		 */
        btnPhanCong.addActionListener(e -> {
            QuanLyPhanCongForm f = new QuanLyPhanCongForm();
            hienThiFormFull(f);
        });
    }
}