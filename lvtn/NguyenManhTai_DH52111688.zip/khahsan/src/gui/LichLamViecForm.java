package gui;

import bus.PhanCongBUS;
import dao.NhanVienDAO;
import model.NhanVien;
import model.PhanCong;
import model.TaiKhoan;
import util.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class LichLamViecForm extends JInternalFrame {

    private JTable table;
    private DefaultTableModel model;

    // Màu giao diện
    private static final Color MAU_CHINH = new Color(14, 116, 144);
    private static final Color MAU_HEADER = new Color(15, 23, 42);
    private static final Color NEN_NHE = new Color(248, 250, 252);
    private static final Color MAU_VIEN = new Color(226, 232, 240);

    private JLabel lblNhanVien;
    private JLabel lblVaiTro;

    public LichLamViecForm() {

        super(
                "LỊCH LÀM VIỆC",
                true,   // closable
                true,   // resizable
                true,   // maximizable
                true    // iconifiable
        );

        setSize(850, 550);
        setMinimumSize(new Dimension(700, 450));

        initUI();
        loadData();

        setVisible(true);
    }

    // =========================================================
    // KHỞI TẠO GIAO DIỆN
    // =========================================================

    private void initUI() {

        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(NEN_NHE);

        // -----------------------------------------------------
        // HEADER
        // -----------------------------------------------------

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(MAU_HEADER);
        header.setBorder(
                new EmptyBorder(15, 25, 15, 25)
        );

        JLabel lblTitle = new JLabel("LỊCH LÀM VIỆC");

        lblTitle.setFont(
                new Font("Segoe UI", Font.BOLD, 20)
        );

        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubTitle =
                new JLabel("Theo dõi lịch phân công và thời gian làm việc");

        lblSubTitle.setFont(
                new Font("Segoe UI", Font.ITALIC, 12)
        );

        lblSubTitle.setForeground(
                new Color(148, 163, 184)
        );

        header.add(
                lblTitle,
                BorderLayout.WEST
        );

        header.add(
                lblSubTitle,
                BorderLayout.EAST
        );

        // -----------------------------------------------------
        // THÔNG TIN NHÂN VIÊN
        // -----------------------------------------------------

        JPanel infoPanel =
                new JPanel(new GridLayout(1, 2, 20, 0));

        infoPanel.setBackground(Color.WHITE);

        infoPanel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(
                                0, 0, 1, 0,
                                MAU_VIEN
                        ),
                        new EmptyBorder(
                                12, 25, 12, 25
                        )
                )
        );

        lblNhanVien =
                taoLabelThongTin("Nhân viên: Đang tải...");

        lblVaiTro =
                taoLabelThongTin("Vai trò: Đang tải...");

        infoPanel.add(lblNhanVien);
        infoPanel.add(lblVaiTro);

        // -----------------------------------------------------
        // BẢNG
        // -----------------------------------------------------

        model = new DefaultTableModel(
                new Object[]{
                        "Ngày",
                        "Bắt đầu",
                        "Kết thúc",
                        "Vai trò"
                },
                0
        ) {

            @Override
            public boolean isCellEditable(
                    int row,
                    int column
            ) {
                return false;
            }
        };

        table = new JTable(model);

        styleTable();

        JScrollPane scrollPane =
                new JScrollPane(table);

        scrollPane.setBorder(
                BorderFactory.createCompoundBorder(
                        new EmptyBorder(
                                20, 25, 15, 25
                        ),
                        BorderFactory.createLineBorder(
                                MAU_VIEN
                        )
                )
        );

        scrollPane.getViewport()
                .setBackground(Color.WHITE);

        // -----------------------------------------------------
        // FOOTER
        // -----------------------------------------------------

        JPanel footer =
                new JPanel(new BorderLayout());

        footer.setBackground(Color.WHITE);

        footer.setBorder(
                new EmptyBorder(
                        8, 25, 12, 25
                )
        );

        JLabel lblHuongDan =
                new JLabel(
                        "Lịch làm việc được cập nhật theo phân công của quản lý."
                );

        lblHuongDan.setFont(
                new Font("Segoe UI", Font.ITALIC, 11)
        );

        lblHuongDan.setForeground(
                new Color(100, 116, 139)
        );

        JButton btnLamMoi =
                new JButton("LÀM MỚI");

        styleButton(btnLamMoi);

        btnLamMoi.addActionListener(
                e -> loadData()
        );

        footer.add(
                lblHuongDan,
                BorderLayout.WEST
        );

        footer.add(
                btnLamMoi,
                BorderLayout.EAST
        );

        // -----------------------------------------------------
        // ADD COMPONENT
        // -----------------------------------------------------

        JPanel center =
                new JPanel(new BorderLayout());

        center.setBackground(NEN_NHE);

        center.add(
                infoPanel,
                BorderLayout.NORTH
        );

        center.add(
                scrollPane,
                BorderLayout.CENTER
        );

        getContentPane().add(
                header,
                BorderLayout.NORTH
        );

        getContentPane().add(
                center,
                BorderLayout.CENTER
        );

        getContentPane().add(
                footer,
                BorderLayout.SOUTH
        );
    }

    // =========================================================
    // STYLE LABEL
    // =========================================================

    private JLabel taoLabelThongTin(String text) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                new Color(51, 65, 85)
        );

        return label;
    }

    // =========================================================
    // STYLE TABLE
    // =========================================================

    private void styleTable() {

        table.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        table.setRowHeight(32);

        table.setGridColor(
                new Color(241, 245, 249)
        );

        table.setShowVerticalLines(false);

        table.setShowHorizontalLines(true);

        table.setSelectionBackground(
                new Color(224, 242, 254)
        );

        table.setSelectionForeground(
                new Color(15, 23, 42)
        );

        table.setAutoCreateRowSorter(true);

        // Header
        JTableHeader header =
                table.getTableHeader();

        header.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        header.setBackground(
                new Color(241, 245, 249)
        );

        header.setForeground(
                new Color(51, 65, 85)
        );

        header.setPreferredSize(
                new Dimension(
                        header.getWidth(),
                        36
                )
        );

        header.setReorderingAllowed(false);

        header.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 1, 0,
                        MAU_VIEN
                )
        );

        // Renderer mặc định
        DefaultTableCellRenderer renderer =
                new DefaultTableCellRenderer() {

                    @Override
                    public Component getTableCellRendererComponent(
                            JTable table,
                            Object value,
                            boolean isSelected,
                            boolean hasFocus,
                            int row,
                            int column
                    ) {

                        Component c =
                                super.getTableCellRendererComponent(
                                        table,
                                        value,
                                        isSelected,
                                        hasFocus,
                                        row,
                                        column
                                );

                        setBorder(
                                new EmptyBorder(
                                        0, 10, 0, 10
                                )
                        );

                        if (!isSelected) {

                            if (row % 2 == 0) {
                                c.setBackground(Color.WHITE);
                            } else {
                                c.setBackground(
                                        new Color(
                                                248,
                                                250,
                                                252
                                        )
                                );
                            }
                        }

                        return c;
                    }
                };

        table.setDefaultRenderer(
                Object.class,
                renderer
        );

        // Căn giữa các cột
        DefaultTableCellRenderer centerRenderer =
                new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        centerRenderer.setBorder(
                new EmptyBorder(
                        0, 10, 0, 10
                )
        );

        table.getColumnModel()
                .getColumn(0)
                .setCellRenderer(centerRenderer);

        table.getColumnModel()
                .getColumn(1)
                .setCellRenderer(centerRenderer);

        table.getColumnModel()
                .getColumn(2)
                .setCellRenderer(centerRenderer);

        table.getColumnModel()
                .getColumn(3)
                .setCellRenderer(centerRenderer);

        // Độ rộng cột
        table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(180);

        table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(150);

        table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(150);

        table.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(180);
    }

    // =========================================================
    // STYLE BUTTON
    // =========================================================

    private void styleButton(JButton button) {

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(Color.WHITE);

        button.setBackground(MAU_CHINH);

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        7, 15, 7, 15
                )
        );

        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
    }

    // =========================================================
    // LOAD DATA
    // =========================================================

    private void loadData() {

        model.setRowCount(0);

        TaiKhoan tk =
                Session.taiKhoanDangNhap;

        if (tk == null) {

            lblNhanVien.setText(
                    "Nhân viên: Chưa đăng nhập"
            );

            lblVaiTro.setText(
                    "Vai trò: ---"
            );

            themDongTrong();

            return;
        }

        NhanVienDAO nvDAO =
                new NhanVienDAO();

        NhanVien nv =
                nvDAO.findByTaiKhoan(
                        tk.getMaTaiKhoan()
                );

        if (nv == null) {

            lblNhanVien.setText(
                    "Nhân viên: Không tìm thấy"
            );

            lblVaiTro.setText(
                    "Vai trò: ---"
            );

            themDongTrong();

            return;
        }

        // Hiển thị tên nhân viên
        lblNhanVien.setText(
                "Nhân viên: " + nv.getHoTen()
        );

        PhanCongBUS bus =
                new PhanCongBUS();

        java.util.List<PhanCong> ds =
                bus.getByNhanVien(
                        nv.getMaNhanVien()
                );

        if (ds == null || ds.isEmpty()) {

            lblVaiTro.setText(
                    "Vai trò: Chưa có lịch phân công"
            );

            themDongTrong();

            return;
        }

        // Lấy vai trò đầu tiên để hiển thị
        String vaiTro =
                ds.get(0).getTenVaiTro();

        lblVaiTro.setText(
                "Vai trò: " +
                (vaiTro == null
                        ? "---"
                        : vaiTro)
        );

        // Đổ dữ liệu
        for (PhanCong pc : ds) {

            model.addRow(
                    new Object[]{
                            pc.getNgayPhanCong(),
                            pc.getGioBatDau(),
                            pc.getGioKetThuc(),
                            pc.getTenVaiTro()
                    }
            );
        }
    }

    // =========================================================
    // HIỂN THỊ KHI KHÔNG CÓ DỮ LIỆU
    // =========================================================

    private void themDongTrong() {

        model.addRow(
                new Object[]{
                        "",
                        "",
                        "",
                        "Chưa có lịch làm việc"
                }
        );
    }
}