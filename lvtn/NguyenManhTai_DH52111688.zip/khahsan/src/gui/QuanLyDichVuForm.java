package gui;

import bus.DichVuBUS;
import model.DichVu;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyDichVuForm extends JInternalFrame {

    JTextField txtTenDV;
    JTextField txtDonGia;
    JTextField txtSoLuong;  
    JTextField txtDonViTinh;
    JTextField txtGhiChu;
    JTextField txtTimKiem;

    JButton btnThem;
    JButton btnSua;
    JButton btnXoa;
    JButton btnTimKiem;
    JButton btnLamMoi;

    JTable table;
    DefaultTableModel model;
    DichVuBUS bus = new DichVuBUS();
    int selectedMaDV = -1;

    // Hệ màu Flat Modern UI đồng bộ (Slate & Cyan/Blue Accent)
    private static final Color MAU_CHINH = new Color(14, 116, 144);    // Cyan/Teal đậm chuyên nghiệp
    private static final Color MAU_XANH_LA = new Color(16, 185, 129);  // Xanh Emerald cho nút Thêm
    private static final Color MAU_CAM = new Color(245, 158, 11);      // Cam Amber cho nút Sửa
    private static final Color MAU_DO = new Color(225, 29, 72);        // Đỏ Rose nổi bật cho nút Xóa
    private static final Color NEN_XAM = new Color(248, 250, 252);     // Slate 50 làm nền dịu mắt
    private static final Color CHU_DAM = new Color(15, 23, 42);        // Slate 900 cho chữ chính
    private static final Color VIEN_NHE = new Color(226, 232, 240);    // Slate 200 làm đường viền mảnh

    public QuanLyDichVuForm(){
        // Bỏ đoạn cấu hình LookAndFeel Nimbus thủ công để tránh xung đột giao diện phẳng và lỗi vỡ khung
        
        setTitle("QUẢN LÝ DỊCH VỤ");
        setSize(1150, 680); 
        setClosable(true);
        setMaximizable(true);
        setIconifiable(true);
        setResizable(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        
        getContentPane().setBackground(NEN_XAM);
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(15, 20, 15, 20));

        // =====================================================================
        // 1. KHU VỰC TRÊN (pTop): KHỐI NHẬP LIỆU & TÌM KIẾM FLAT UI
        // =====================================================================
        JPanel pTop = new JPanel(new BorderLayout(15, 15));
        pTop.setBackground(NEN_XAM);
        
        // Khối nhập liệu container nền trắng có bo góc/viền nhẹ chỉn chu
        JPanel pInputMaster = new JPanel(new BorderLayout());
        pInputMaster.setBackground(Color.WHITE);
        pInputMaster.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                new EmptyBorder(20, 25, 20, 25)
        ));

        // Layout dạng lưới 2 dòng, 4 cột thông thoáng cho các trường nhập liệu
        JPanel pInput = new JPanel(new GridLayout(2, 4, 25, 15));
        pInput.setBackground(Color.WHITE);
        
        txtTenDV = new JTextField();
        txtDonGia = new JTextField();
        txtDonViTinh = new JTextField();
        txtGhiChu = new JTextField();
        txtSoLuong = new JTextField(); // Giữ nguyên để tránh lỗi NullPointer khi gọi clearForm()

        styleTextField(txtTenDV);
        styleTextField(txtDonGia);
        styleTextField(txtDonViTinh);
        styleTextField(txtGhiChu);

        // Đóng gói nhãn phụ nhỏ phía trên và trường text nhập liệu ngay phía dưới
        pInput.add(taoFormGroup("Tên dịch vụ", txtTenDV));
        pInput.add(taoFormGroup("Đơn giá (VNĐ)", txtDonGia));
        pInput.add(taoFormGroup("Đơn vị tính", txtDonViTinh));
        pInput.add(taoFormGroup("Ghi chú", txtGhiChu));

        pInputMaster.add(pInput, BorderLayout.CENTER);

        // Thanh tìm kiếm thiết lập nằm ngang, tinh tế phía dưới khối nhập liệu
        JPanel pSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        pSearch.setBackground(NEN_XAM);
        
        txtTimKiem = new JTextField();
        styleTextField(txtTimKiem);
        txtTimKiem.setPreferredSize(new Dimension(280, 36));
        
        btnTimKiem = new JButton("TÌM KIẾM");
        btnLamMoi = new JButton("LÀM MỚI FORM");
        
        styleButton(btnTimKiem, new Color(71, 85, 105)); // Xám Slate đậm cho nút phụ tìm kiếm
        styleButton(btnLamMoi, Color.WHITE);
        btnLamMoi.setForeground(CHU_DAM);
        btnLamMoi.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        
        JLabel lblTimKiem = new JLabel("Tìm kiếm tên dịch vụ:");
        lblTimKiem.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTimKiem.setForeground(new Color(100, 116, 139));

        pSearch.add(lblTimKiem);
        pSearch.add(txtTimKiem);
        pSearch.add(btnTimKiem);
        pSearch.add(btnLamMoi);

        pTop.add(pInputMaster, BorderLayout.CENTER);
        pTop.add(pSearch, BorderLayout.SOUTH);
        add(pTop, BorderLayout.NORTH);

        // =====================================================================
        // 2. KHU VỰC GIỮA: BẢNG DỮ LIỆU CẢI TIẾN THOÁNG MẮT (JTable)
        // =====================================================================
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Mã DV", "Tên DV", "Đơn giá", "ĐVT", "Ghi chú"
        });

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(VIEN_NHE, 1, true));
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // =====================================================================
        // 3. KHU VỰC DƯỚI (pBottom): CÁC NÚT CHỨC NĂNG CHÍNH
        // =====================================================================
        JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        pBottom.setBackground(NEN_XAM);
        
        btnThem = new JButton("THÊM MỚI");
        btnSua = new JButton("SỬA THÔNG TIN");
        btnXoa = new JButton("XÓA DỊCH VỤ");

        styleButton(btnThem, MAU_XANH_LA);
        styleButton(btnSua, MAU_CAM);
        styleButton(btnXoa, MAU_DO);

        pBottom.add(btnThem);
        pBottom.add(btnSua);
        pBottom.add(btnXoa);
        add(pBottom, BorderLayout.SOUTH);

        // Tải dữ liệu ban đầu lên bảng
        loadData();

        // =====================================================================
        // LOGIC EVENTS (Giữ nguyên 100% logic cấu trúc gốc)
        // =====================================================================
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if(row >= 0){
                selectedMaDV = Integer.parseInt(model.getValueAt(row,0).toString());
                txtTenDV.setText(model.getValueAt(row,1).toString());
                txtDonGia.setText(model.getValueAt(row,2).toString());
                
                if(model.getColumnCount() > 5 && model.getValueAt(row,3) != null) {
                    txtSoLuong.setText(model.getValueAt(row,3).toString());
                }
                
                txtDonViTinh.setText(model.getValueAt(row,3).toString());
                txtGhiChu.setText(model.getValueAt(row,4).toString());
            }
        });

        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnTimKiem.addActionListener(e -> timKiem());
        btnLamMoi.addActionListener(e -> {
            loadData();
            clearForm();
        });

        setVisible(true);
    }

    // =====================================================================
    // CÁC HÀM TRỢ GIÚP ĐỔI MỚI GIAO DIỆN (UI MODERNIZATION TOOLKIT)
    // =====================================================================
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(CHU_DAM);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(VIEN_NHE, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
    }

    private void styleButton(JButton btn, Color background) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setBackground(background);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(34); // Tăng chiều cao dòng cho dữ liệu thoáng đáng
        table.setGridColor(new Color(241, 245, 249)); 
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false); // Ẩn đường lưới dọc theo chuẩn UI hiện đại
        table.setSelectionBackground(new Color(232, 240, 254)); 
        table.setSelectionForeground(CHU_DAM);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(new Color(71, 85, 105));
        header.setPreferredSize(new Dimension(100, 38));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, VIEN_NHE));

        // Renderer để thiết lập padding lề trái/phải và căn giữa cột dữ liệu
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 8, 0, 8));
                return this;
            }
        };
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        };
        leftRenderer.setHorizontalAlignment(JLabel.LEFT);

        // Chỉ định cách căn dòng cho từng cột
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // Mã DV căn giữa
        table.getColumnModel().getColumn(1).setCellRenderer(leftRenderer);   // Tên DV căn trái
        table.getColumnModel().getColumn(2).setCellRenderer(leftRenderer);   // Đơn giá căn trái
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // ĐVT căn giữa
        table.getColumnModel().getColumn(4).setCellRenderer(leftRenderer);   // Ghi chú căn trái
        
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
    }

    private JPanel taoFormGroup(String labelText, JComponent component) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(100, 116, 139)); // Màu chữ nhãn phụ Slate nhẹ dịu
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    // =====================================================================
    // LOGIC METHODS (Giữ nguyên hoàn toàn mã xử lý nghiệp vụ của bạn)
    // =====================================================================
    private void loadData(){
        model.setRowCount(0);
        for(DichVu dv : bus.getAll()){
            model.addRow(new Object[]{
                    dv.getMaDichVu(),
                    dv.getTenDichVu(),
                    dv.getDonGia(),
                    dv.getDonViTinh(),
                    dv.getGhiChu()
            });
        }
    }

    private void timKiem(){
        String keyword = txtTimKiem.getText().trim().toLowerCase();
        model.setRowCount(0);
        for(DichVu dv : bus.getAll()){
            if(dv.getTenDichVu().toLowerCase().contains(keyword)){
                model.addRow(new Object[]{
                        dv.getMaDichVu(),
                        dv.getTenDichVu(),
                        dv.getDonGia(),
                        dv.getDonViTinh(),
                        dv.getGhiChu()
                });
            }
        }
    }

    private void them() {
        try {

            if (!validateForm()) return;

            DichVu dv = new DichVu();
            dv.setTenDichVu(txtTenDV.getText().trim());
            dv.setDonGia(Double.parseDouble(txtDonGia.getText().trim()));
            dv.setDonViTinh(txtDonViTinh.getText().trim());
            dv.setGhiChu(txtGhiChu.getText().trim());

            if (bus.insert(dv)) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadData();
                clearForm();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void sua() {
        try {

            if (selectedMaDV == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ cần sửa");
                return;
            }

            if (!validateForm()) return;

            DichVu dv = new DichVu();
            dv.setMaDichVu(selectedMaDV);
            dv.setTenDichVu(txtTenDV.getText().trim());
            dv.setDonGia(Double.parseDouble(txtDonGia.getText().trim()));
            dv.setDonViTinh(txtDonViTinh.getText().trim());
            dv.setGhiChu(txtGhiChu.getText().trim());

            if (bus.update(dv)) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadData();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void xoa(){
        if(selectedMaDV == -1) return;
        if(bus.delete(selectedMaDV)){
            JOptionPane.showMessageDialog(this, "Xóa thành công");
            loadData();
            clearForm();
        }
    }
    private boolean validateForm() {

        if (txtTenDV.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên dịch vụ không được để trống");
            txtTenDV.requestFocus();
            return false;
        }

        if (txtDonGia.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Đơn giá không được để trống");
            txtDonGia.requestFocus();
            return false;
        }

        if (txtDonViTinh.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Đơn vị tính không được để trống");
            txtDonViTinh.requestFocus();
            return false;
        }

        // Kiểm tra đơn giá là số
        try {
            double gia = Double.parseDouble(txtDonGia.getText().trim());

            if (gia <= 0) {
                JOptionPane.showMessageDialog(this, "Đơn giá phải lớn hơn 0");
                txtDonGia.requestFocus();
                return false;
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Đơn giá phải là số");
            txtDonGia.requestFocus();
            return false;
        }

        return true;
    }
    private void clearForm(){
        txtTenDV.setText("");
        txtDonGia.setText("");
        txtSoLuong.setText("");
        txtDonViTinh.setText("");
        txtGhiChu.setText("");
        txtTimKiem.setText("");
        selectedMaDV = -1;
        table.clearSelection();
    }
}