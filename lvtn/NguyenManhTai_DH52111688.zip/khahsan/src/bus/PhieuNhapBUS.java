package bus;

import dao.PhieuNhapDAO;
import model.PhieuNhap;

import java.util.List;

public class PhieuNhapBUS {

    private PhieuNhapDAO dao = new PhieuNhapDAO();

    public List<PhieuNhap> getAll() {
        return dao.getAll();
    }

    public boolean them(PhieuNhap pn) {
        return dao.insert(pn);
    }

    public boolean sua(PhieuNhap pn) {
        return dao.update(pn);
    }

    public boolean xoa(int maPhieuNhap) {
        return dao.delete(maPhieuNhap);
    }

    public List<PhieuNhap> timKiem(String keyword) {
        return dao.search(keyword);
    }
    public List<PhieuNhap> getPhieuNhapHomNayTheoNhanVien(int maNhanVien){

        return dao.getPhieuNhapHomNayTheoNhanVien(maNhanVien);
    }
}