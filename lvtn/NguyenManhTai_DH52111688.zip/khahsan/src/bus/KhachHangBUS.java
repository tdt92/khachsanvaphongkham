package bus;

import dao.KhachHangDAO;
import model.KhachHang;
import model.NhanVien;

import java.util.List;

public class KhachHangBUS {

    KhachHangDAO dao = new KhachHangDAO();

    public List<KhachHang> getAll() {
        return dao.getAll();
    }
    public List<KhachHang> search(String keyword){

        return dao.search(keyword);
    }
    public boolean insert(KhachHang kh) {
        return dao.insert(kh);
    }
    public KhachHang findById(int maKH){

        for(KhachHang kh : getAll()){

            if(kh.getMaKhachHang()==maKH){

                return kh;
            }
        }

        return null;
    }
    public boolean update(KhachHang kh) {
        return dao.update(kh);
    }
    public boolean existsCCCD(String cccd) {

        return dao.existsCCCD(cccd);
    }
    public boolean existsCCCD(String cccd, int maKhachHang) {
        return dao.existsCCCD(cccd, maKhachHang);
    }
    public boolean delete(int maKH) {
        return dao.delete(maKH);
    }
}