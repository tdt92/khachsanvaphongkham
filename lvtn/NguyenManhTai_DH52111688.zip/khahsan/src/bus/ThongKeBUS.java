package bus;

import dao.HoaDonDAO;
import dao.PhongDAO;
import dao.SuDungDichVuDAO;
import model.HoaDon;
import model.Phong;
import model.SuDungDichVu;

import java.util.*;
import java.util.stream.Collectors;

public class ThongKeBUS {

    private HoaDonDAO hoaDonDAO = new HoaDonDAO();
    private PhongDAO phongDAO = new PhongDAO();
    private SuDungDichVuDAO dvDAO = new SuDungDichVuDAO();

    // ================= DOANH THU THEO TIME =================

    public Map<String, Double> doanhThuTheoThang() {

        Map<String, Double> map = new LinkedHashMap<>();

        for (int i = 1; i <= 12; i++) map.put("T" + i, 0.0);

        for (HoaDon hd : hoaDonDAO.getAll()) {

            Calendar c = Calendar.getInstance();
            c.setTime(hd.getNgayLap());

            String key = "T" + (c.get(Calendar.MONTH) + 1);

            map.put(key, map.get(key) + hd.getTongTien());
        }

        return map;
    }

    public Map<String, Double> doanhThuTheoNgayTrongTuan() {

        Map<String, Double> map = new LinkedHashMap<>();

        map.put("T2", 0.0);
        map.put("T3", 0.0);
        map.put("T4", 0.0);
        map.put("T5", 0.0);
        map.put("T6", 0.0);
        map.put("T7", 0.0);
        map.put("CN", 0.0);

        for (HoaDon hd : hoaDonDAO.getAll()) {

            Calendar c = Calendar.getInstance();
            c.setTime(hd.getNgayLap());

            int d = c.get(Calendar.DAY_OF_WEEK);

            String key = switch (d) {
                case Calendar.MONDAY -> "T2";
                case Calendar.TUESDAY -> "T3";
                case Calendar.WEDNESDAY -> "T4";
                case Calendar.THURSDAY -> "T5";
                case Calendar.FRIDAY -> "T6";
                case Calendar.SATURDAY -> "T7";
                default -> "CN";
            };

            map.put(key, map.get(key) + hd.getTongTien());
        }

        return map;
    }

    // ================= DOANH THU =================

    public double doanhThuTatCa() {
        return hoaDonDAO.getAll()
                .stream()
                .mapToDouble(HoaDon::getTongTien)
                .sum();
    }

    public double doanhThuDichVu() {
        return dvDAO.getAll()
                .stream()
                .mapToDouble(SuDungDichVu::getThanhTien)
                .sum();
    }

    // ================= HÓA ĐƠN =================

    public int tongHoaDon() {
        return hoaDonDAO.getAll().size();
    }

    public double hoaDonTB() {
        return hoaDonDAO.getAll()
                .stream()
                .mapToDouble(HoaDon::getTongTien)
                .average()
                .orElse(0);
    }

    // ================= PHÒNG =================

    public Map<String, Integer> thongKePhong() {

        List<Phong> ds = phongDAO.getAll();

        Map<String, Integer> m = new LinkedHashMap<>();

        m.put("TONG", ds.size());
        m.put("DANG_THUE", (int) ds.stream().filter(p -> "DANG_THUE".equals(p.getTrangThai())).count());
        m.put("TRONG", (int) ds.stream().filter(p -> "TRONG".equals(p.getTrangThai())).count());
        m.put("DANG_DON", (int) ds.stream().filter(p -> "DANG_DON".equals(p.getTrangThai())).count());
        m.put("BAO_TRI", (int) ds.stream().filter(p -> "BAO_TRI".equals(p.getTrangThai())).count());

        return m;
    }

    public double occupancy() {
        Map<String, Integer> m = thongKePhong();
        return m.get("TONG") == 0 ? 0 : (double) m.get("DANG_THUE") / m.get("TONG");
    }

    public double ADR() {
        return hoaDonDAO.getAll().isEmpty()
                ? 0
                : doanhThuTatCa() / hoaDonDAO.getAll().size();
    }

    public double RevPAR() {
        Map<String, Integer> m = thongKePhong();
        return m.get("TONG") == 0 ? 0 : doanhThuTatCa() / m.get("TONG");
    }

    // ================= TOP DỊCH VỤ =================

    public Map<String, Double> topDichVu() {

        return dvDAO.getAll()
                .stream()
                .collect(Collectors.groupingBy(
                        SuDungDichVu::getMaDichVu,
                        Collectors.summingDouble(SuDungDichVu::getThanhTien)
                ))
                .entrySet()
                .stream()
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                .limit(5)
                .collect(Collectors.toMap(
                        e -> "DV " + e.getKey(),
                        Map.Entry::getValue,
                        (a, b) -> a,
                        LinkedHashMap::new
                ));
    }
}