package bus;

import dao.NhanVienDAO;
import model.NhanVien;

import java.util.List;

public class NhanVienBUS {

    NhanVienDAO dao = new NhanVienDAO();

    public List<NhanVien> getAll() {
        return dao.getAll();
    }

    public boolean insert(NhanVien nv) {
        return dao.insert(nv);
    }

    public boolean update(NhanVien nv) {
        return dao.update(nv);
    }

    public boolean delete(int maNV) {
        return dao.delete(maNV);
    }
    public NhanVien findById(int maNV){

        return dao.findById(maNV);
    }
    public NhanVien findByTaiKhoan(int maTaiKhoan){

        return dao.findByTaiKhoan(maTaiKhoan);
    }
    public boolean updateContactInfo(int maTaiKhoan, String sdt, String email, String diaChi) {

        return dao.updateContactInfo(maTaiKhoan, sdt, email, diaChi);
    }
    public NhanVien getByMaTaiKhoan(int maTaiKhoan) {
        return dao.getByMaTaiKhoan(maTaiKhoan);
    }
    public List<NhanVien> search(String keyword){

        return dao.search(keyword);
    }
    public NhanVien findByMaTaiKhoan(int maTaiKhoan){

        return dao.findByMaTaiKhoan(maTaiKhoan);
    }
}