package bus;

import dao.KhoDAO;
import model.Kho;

import java.util.List;

public class KhoBUS {

    private KhoDAO dao = new KhoDAO();

    public List<Kho> getAll() {
        return dao.getAll();
    }
    public boolean capNhatSoLuong(int maVatDung, int soLuongMoi) {

        if (soLuongMoi < 0) {
            return false;
        }

        return dao.updateSoLuong(maVatDung, soLuongMoi);
    }
    public boolean them(Kho kho) {
        return dao.insert(kho);
    }

    public boolean sua(Kho kho) {
        return dao.update(kho);
    }

    public boolean xoa(int maVatDung) {
        return dao.delete(maVatDung);
    }

    public List<Kho> timKiem(String keyword) {
        return dao.search(keyword);
    }

    public Kho timTheoMa(int maVatDung) {
        return dao.findById(maVatDung);
    }
}