package bus;

import dao.ChiTietDatPhongDAO;
import dao.ChiTietThuePhongDAO;
import dao.PhieuDatPhongDAO;
import dao.PhieuThuePhongDAO;
import model.ChiTietDatPhong;
import model.ChiTietThuePhong;
import model.PhieuDatPhong;
import model.PhieuThuePhong;

import java.sql.Date;
import java.util.List;

public class ChiTietDatPhongBUS {

    private ChiTietDatPhongDAO dao =
            new ChiTietDatPhongDAO();

    private PhieuDatPhongDAO pdDAO =
            new PhieuDatPhongDAO();
    

    private PhieuThuePhongDAO ptDAO =
            new PhieuThuePhongDAO();

    private ChiTietThuePhongDAO ctThueDAO =
            new ChiTietThuePhongDAO();
 
    public List<ChiTietDatPhong> getAll() {

        return dao.getAll();
    }

   
    public List<ChiTietDatPhong> getByPhieuDat(
            int maPhieuDat) {

        return dao.getByPhieuDat(maPhieuDat);
    }

    
    public boolean insert(
            ChiTietDatPhong ct) {

        if (ct == null) {
            return false;
        }

        if (ct.getMaPhieuDat() <= 0
                || ct.getMaPhong() <= 0) {

            return false;
        }

        return dao.insert(ct);
    }
    public boolean isPhongTrong(
            int maPhong,
            Date ngayNhan,
            Date ngayTra,
            Integer excludeMaPhieuDat) {

        List<ChiTietDatPhong> ds = dao.getAll();

        for (ChiTietDatPhong ct : ds) {

            if (ct.getMaPhong() != maPhong)
                continue;

            if (excludeMaPhieuDat != null
                    && ct.getMaPhieuDat() == excludeMaPhieuDat) {
                continue;
            }

            PhieuDatPhong pd =
                    pdDAO.findById(ct.getMaPhieuDat());

            if (pd == null)
                continue;

            Date bd = pd.getNgayNhanPhong();
            Date kt = pd.getNgayTraPhong();

            if (!(ngayTra.before(bd)
                    || ngayNhan.after(kt))) {

                return false;
            }
        }

        return true;
    }
    
    public boolean delete(
            int maPhieuDat,
            int maPhong) {

        return dao.delete(
                maPhieuDat,
                maPhong);
    }
    public boolean isPhongTrong(
            int maPhong,
            Date ngayNhan,
            Date ngayTra) {

        // ===== KIỂM TRA PHIẾU ĐẶT =====
        List<ChiTietDatPhong> dsDat =
                dao.getAll();

        for (ChiTietDatPhong ct : dsDat) {

            if (ct.getMaPhong() != maPhong) {
                continue;
            }

            PhieuDatPhong pd =
                    pdDAO.findById(
                            ct.getMaPhieuDat());

            if (pd == null) {
                continue;
            }

            Date bd = pd.getNgayNhanPhong();
            Date kt = pd.getNgayTraPhong();

            if (!(ngayTra.before(bd)
                    || ngayNhan.after(kt))) {

                return false;
            }
        }

        // ===== KIỂM TRA PHIẾU THUÊ =====
        List<PhieuThuePhong> dsThue =
                ptDAO.getAll();

        for (PhieuThuePhong pt : dsThue) {

            Date bd =
                    new Date(
                            pt.getNgayNhanPhong().getTime());

            Date kt =
                    pt.getNgayTraPhongDuKien();

            List<ChiTietThuePhong> dsCT =
                    ctThueDAO.getByPhieuThue(
                            pt.getMaPhieuThue());

            for (ChiTietThuePhong ct : dsCT) {

                if (ct.getMaPhong() != maPhong) {
                    continue;
                }

                if (ngayNhan.before(kt) && ngayTra.after(bd)) {
                    return false;
                }
            }
        }

        return true;
    }
   
	/*
	 * public boolean isPhongTrong(int maPhong, Date ngayNhan, Date ngayTra) {
	 * 
	 * List<ChiTietDatPhong> dsCT = dao.getAll();
	 * 
	 * for (ChiTietDatPhong ct : dsCT) {
	 * 
	 * if (ct.getMaPhong() != maPhong) { continue; }
	 * 
	 * PhieuDatPhong pd = pdDAO.findById(ct.getMaPhieuDat());
	 * 
	 * if (pd == null) { continue; }
	 * 
	 * Date bd = pd.getNgayNhanPhong(); Date kt = pd.getNgayTraPhong();
	 * 
	 * if (ngayNhan.before(kt) && ngayTra.after(bd)) { return false; } }
	 * 
	 * return true; }
	 */
}