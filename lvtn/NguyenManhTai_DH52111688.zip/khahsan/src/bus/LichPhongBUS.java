package bus;

import dao.LichPhongDAO;
import model.LichPhongDTO;

import java.util.List;

public class LichPhongBUS {

    private LichPhongDAO dao =
            new LichPhongDAO();

    public List<LichPhongDTO> getAll() {

        return dao.getAll();

    }

}