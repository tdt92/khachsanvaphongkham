package bus;

import dao.CT_PhieuNhapDAO;
import model.CT_PhieuNhap;

import java.util.List;

public class CT_PhieuNhapBUS {

    private CT_PhieuNhapDAO dao = new CT_PhieuNhapDAO();

    public List<CT_PhieuNhap> getAll() {
        return dao.getAll();
    }
    public List<CT_PhieuNhap> getByPhieuNhap(int maPhieuNhap){

        return dao.getByPhieuNhap(maPhieuNhap);
    }
    public boolean them(CT_PhieuNhap ct) {
        return dao.insert(ct);
    }

    public boolean sua(CT_PhieuNhap ct) {
        return dao.update(ct);
    }

    public boolean xoa(int maCT) {
        return dao.delete(maCT);
    }

    public List<CT_PhieuNhap> timKiem(String keyword) {
        return dao.search(keyword);
    }
}