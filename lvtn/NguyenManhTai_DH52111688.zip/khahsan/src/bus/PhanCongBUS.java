package bus;

import dao.PhanCongDAO;
import model.PhanCong;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

public class PhanCongBUS {

    PhanCongDAO dao = new PhanCongDAO();

     public List<PhanCong> getAll() {
        return dao.getAll();
    }

     public boolean insert(PhanCong pc) {
        return dao.insert(pc);
    }

     public boolean update(PhanCong pc) {
        return dao.update(pc);
    }
    public List<PhanCong> getByNhanVien(int maNV){

        return dao.getByNhanVien(maNV);
    }
     public boolean delete(int maPhanCong) {
        return dao.delete(maPhanCong);
    }
     public boolean isTrungVaiTro(
    	        int maNhanVien,
    	        String vaiTro,
    	        Date ngay,
    	        Time bd,
    	        Time kt,
    	        int excludeMaPC){

    	    return dao.isTrungVaiTro(
    	            maNhanVien,
    	            vaiTro,
    	            ngay,
    	            bd,
    	            kt,
    	            excludeMaPC);
    	}
     public boolean isTrungLich(int maNV,
             Date ngay,
             Time bd,
             Time kt,
             int exclude){

return dao.isTrungLich(maNV,ngay,bd,kt,exclude);
}
     public List<PhanCong> search(String keyword) {
        return dao.search(keyword);
    }
}