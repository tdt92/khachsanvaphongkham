package bus;

import dao.TaiKhoanDAO;
import model.TaiKhoan;

import java.util.List;

public class TaiKhoanBUS {

    TaiKhoanDAO dao = new TaiKhoanDAO();

   
    public TaiKhoan dangNhap(String tenDangNhap, String matKhau) {

        if (tenDangNhap.trim().isEmpty()
                || matKhau.trim().isEmpty()) {

            return null;
        }

        return dao.dangNhap(tenDangNhap, matKhau);
    }

     
    public List<TaiKhoan> getAll() {

        return dao.getAll();
    }

     
    public boolean insert(TaiKhoan tk) {

        if (tk.getTenDangNhap().trim().isEmpty()
                || tk.getMatKhau().trim().isEmpty()) {

            return false;
        }

        return dao.insert(tk);
    }

     
    public boolean update(TaiKhoan tk) {

        if (tk.getTenDangNhap().trim().isEmpty()
                || tk.getMatKhau().trim().isEmpty()) {

            return false;
        }

        return dao.update(tk);
    }

     
    public boolean delete(int maTaiKhoan) {

        return dao.delete(maTaiKhoan);
    }
    public TaiKhoan getLast(){

        return dao.getLast();
    }
    
    public TaiKhoan findById(int maTaiKhoan){

        return dao.findById(maTaiKhoan);
    }
}