package bus;

import dao.LoaiPhongDAO;
import model.LoaiPhong;

import java.util.List;

public class LoaiPhongBUS {

    private LoaiPhongDAO dao = new LoaiPhongDAO();

    public List<LoaiPhong> getAll() {
        return dao.getAll();
    }

    public boolean insert(LoaiPhong lp) {
        return dao.insert(lp);
    }

    public boolean update(LoaiPhong lp) {
        return dao.update(lp);
    }

    public boolean delete(int maLoaiPhong) {
        return dao.delete(maLoaiPhong);
    }
    public LoaiPhong findById(int maLoaiPhong){

        for(LoaiPhong lp : getAll()){

            if(lp.getMaLoaiPhong() == maLoaiPhong){
                return lp;
            }
        }

        return null;
    }
}