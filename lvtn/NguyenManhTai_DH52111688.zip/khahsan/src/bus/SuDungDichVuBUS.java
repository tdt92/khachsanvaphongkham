package bus;

import dao.SuDungDichVuDAO;
import model.SuDungDichVu;

import java.util.ArrayList;

public class SuDungDichVuBUS {

    private SuDungDichVuDAO dao = new SuDungDichVuDAO();

    public ArrayList<SuDungDichVu> getAll() {
        return dao.getAll();
    }

    public boolean them(SuDungDichVu sd) {
        return dao.insert(sd);
    }
    public double tinhTienTheoPhong(int maPhong){

        return dao.tinhTienTheoPhong(maPhong);
    }
    public boolean sua(SuDungDichVu sd) {
        return dao.update(sd);
    }
    public ArrayList<SuDungDichVu> timTheoPhieuThue1(int maPhieuThue) {
        return dao.getByPhieuThue(maPhieuThue);
    }
    public boolean xoa(int maSuDung) {
        return dao.delete(maSuDung);
    }

    public SuDungDichVu timTheoMa(int maSuDung) {
        return dao.findById(maSuDung);
    }

    public ArrayList<SuDungDichVu> timTheoPhieuThue(int maPhieu) {
        return dao.timTheoPhieuThue(maPhieu);
    }

    public ArrayList<SuDungDichVu> timTheoPhong(int maPhong) {
        return dao.timTheoPhong(maPhong);
    }

    public double tinhTienDichVu(int maPhieu) {
        return dao.tinhTienDichVu(maPhieu);
    }
}