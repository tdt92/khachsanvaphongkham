package bus;

import dao.PhieuThuePhongDAO;
import model.PhieuThuePhong;

import java.util.List;

public class PhieuThuePhongBUS {

    private PhieuThuePhongDAO dao =
            new PhieuThuePhongDAO();

     
    public List<PhieuThuePhong> getAll() {

        return dao.getAll();
    }

    public boolean updateNgayTra(
            int maPhieuThue,
            java.sql.Date ngayTra){

        return dao.updateNgayTra(
                maPhieuThue,
                ngayTra);
    }
    public boolean insert(
            PhieuThuePhong pt) {

        if (pt == null) {
            return false;
        }

        if (pt.getMaKhachHang() <= 0
                || pt.getMaNhanVien() <= 0) {

            return false;
        }

        return dao.insert(pt);
    }

    
    public boolean update(
            PhieuThuePhong pt) {

        if (pt == null) {
            return false;
        }

        if (pt.getMaPhieuThue() <= 0) {
            return false;
        }

        return dao.update(pt);
    }
    public PhieuThuePhong getLastInserted(){

        return dao.getLastInserted();
    }
    public PhieuThuePhong getById(int maPhieuThue) {

        return dao.getById(maPhieuThue);
    }
    
    public boolean delete(
            int maPhieuThue) {

        return dao.delete(maPhieuThue);
    }
    public boolean exists(
            int maPhieuThue,
            int maPhong){

        return dao.exists(
                maPhieuThue,
                maPhong);
    }
    public int insertAndGetId(
            PhieuThuePhong pt){

        return dao.insertAndGetId(pt);
    }
    public List<PhieuThuePhong> getDangThueSapHetHan() {
        return dao.getDangThueSapHetHan();
    }
}