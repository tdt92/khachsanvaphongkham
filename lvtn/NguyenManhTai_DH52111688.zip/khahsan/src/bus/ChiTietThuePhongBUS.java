package bus;

import dao.ChiTietThuePhongDAO;
import model.ChiTietThuePhong;
import model.PhongDangThueDTO;

import java.util.List;

public class ChiTietThuePhongBUS {

    private ChiTietThuePhongDAO dao =
            new ChiTietThuePhongDAO();

   
    public List<ChiTietThuePhong>
    getByPhieuThue(int maPhieuThue) {

        return dao.getByPhieuThue(
                maPhieuThue);
    }

     
    public boolean insert(
            ChiTietThuePhong ct) {

        if (ct == null) {
            return false;
        }

        if (ct.getMaPhieuThue() <= 0
                || ct.getMaPhong() <= 0) {

            return false;
        }

        return dao.insert(ct);
    }
    public boolean update(ChiTietThuePhong ct) {

        if (ct == null) {
            return false;
        }

        return dao.update(ct);
    }
    
    public List<PhongDangThueDTO>
    getPhongDangThue(){

        return dao.getPhongDangThue();
    }
 
    public boolean dangThuePhong(int maKhachHang) {
        return dao.dangThuePhong(maKhachHang);
    }
    public boolean exists(
            int maPhieuThue,
            int maPhong){

        return dao.exists(
                maPhieuThue,
                maPhong);
    }
    public boolean daNhanPhong(int maPhong){

        return dao.daNhanPhong(maPhong);
    }
    
    public boolean delete(
            int maPhieuThue,
            int maPhong) {

        return dao.delete(
                maPhieuThue,
                maPhong);
    }
}