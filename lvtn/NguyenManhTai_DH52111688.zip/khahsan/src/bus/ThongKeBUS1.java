package bus;

import dao.ThongKeDAO;
import model.ThongKeDiemDTO;
import model.ThongKePhongDTO;

import java.sql.Date;
import java.util.List;

public class ThongKeBUS1 {

    private ThongKeDAO dao = new ThongKeDAO();

    // ----- Doanh thu theo thời gian -----
    public List<ThongKeDiemDTO> doanhThuTheoNgay(Date tu, Date den) {
        return dao.getDoanhThuTheoNgay(tu, den);
    }

    public List<ThongKeDiemDTO> doanhThuTheoTuan(Date tu, Date den) {
        return dao.getDoanhThuTheoTuan(tu, den);
    }

    public List<ThongKeDiemDTO> doanhThuTheoThang(int nam) {
        return dao.getDoanhThuTheoThang(nam);
    }

    public List<ThongKeDiemDTO> doanhThuTheoNam() {
        return dao.getDoanhThuTheoNam();
    }

    // ----- Doanh thu theo cơ cấu -----
    public List<ThongKeDiemDTO> doanhThuTheoLoaiPhong(Date tu, Date den) {
        return dao.getDoanhThuTheoLoaiPhong(tu, den);
    }

    public List<ThongKeDiemDTO> doanhThuTheoDichVu(Date tu, Date den) {
        return dao.getDoanhThuTheoDichVu(tu, den);
    }

    public List<ThongKeDiemDTO> thongKeHinhThucThanhToan(Date tu, Date den) {
        return dao.getThongKeHinhThucThanhToan(tu, den);
    }

    // ----- Chỉ số hoá đơn -----
    public int tongSoHoaDon(Date tu, Date den) {
        return dao.getTongSoHoaDon(tu, den);
    }

    public double giaTriHoaDonTrungBinh(Date tu, Date den) {
        return dao.getGiaTriHoaDonTrungBinh(tu, den);
    }

    public double tongDoanhThu(Date tu, Date den) {
        return dao.getTongDoanhThu(tu, den);
    }

    // ----- Phòng -----
    public ThongKePhongDTO thongKePhong(int soNgayCanhBao) {
        return dao.getThongKePhong(soNgayCanhBao);
    }

    // ----- RevPAR / ADR / Occupancy -----
    // RevPAR = Doanh thu phòng / Tổng số phòng
    // ADR    = Doanh thu phòng / Số lượt phòng đã bán
    // Occupancy (đơn giản hoá theo kỳ) = Số lượt phòng đã bán / Tổng số phòng
    public double[] tinhRevPAR(Date tu, Date den) {

        double doanhThuPhong = dao.getDoanhThuPhongTrongKy(tu, den);
        int soLuotThue = dao.getSoLuotThuePhong(tu, den);
        int tongSoPhong = dao.getTongSoPhong();

        double revPAR = tongSoPhong > 0 ? doanhThuPhong / tongSoPhong : 0;
        double adr = soLuotThue > 0 ? doanhThuPhong / soLuotThue : 0;
        double occupancy = tongSoPhong > 0 ? (double) soLuotThue / tongSoPhong : 0;

        return new double[]{revPAR, adr, occupancy, doanhThuPhong, soLuotThue, tongSoPhong};
    }

    // ----- Heatmap công suất phòng theo ngày trong tháng -----
    public List<ThongKeDiemDTO> congSuatTheoNgayTrongThang(int nam, int thang) {
        return dao.getCongSuatPhongTheoNgay(nam, thang);
    }
}