package bus;

import dao.HoaDonDAO;
import model.HoaDon;

import java.util.ArrayList;

public class HoaDonBUS {

    HoaDonDAO dao = new HoaDonDAO();

    public ArrayList<HoaDon> getAll() {
        return dao.getAll();
    }
    public HoaDon getByPhieuThue(int maPhieuThue) {
        return dao.getByPhieuThue(maPhieuThue);
    }
    public HoaDon getById(int maHD) {
        return dao.getById(maHD);
    }
    public boolean update(HoaDon hd){
        return dao.update(hd);
    }
    public int insertAndGetId(HoaDon hd) {
        return dao.insertAndGetId(hd);
    }

    public boolean sua(HoaDon hd) {
        return dao.update(hd);
    }

    public boolean xoa(int maHD) {
        return dao.delete(maHD);
    }

    public boolean xacNhanThanhToan(int maHoaDon,
                                    double tienKhachTra,
                                    double tienConLai) {

        return dao.xacNhanThanhToan(
                maHoaDon,
                tienKhachTra,
                tienConLai);
    }
}