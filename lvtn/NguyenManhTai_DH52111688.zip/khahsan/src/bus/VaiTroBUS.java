package bus;

import dao.VaiTroDAO;
import model.VaiTro;

import java.util.List;

public class VaiTroBUS {

    VaiTroDAO vaiTroDAO = new VaiTroDAO();

     
    public List<VaiTro> getAll() {
        return vaiTroDAO.getAll();
    }

   
    public boolean insert(VaiTro vt) {

        if (vt.getTenVaiTro().trim().isEmpty()) {
            return false;
        }

        return vaiTroDAO.insert(vt);
    }

    
    public boolean update(VaiTro vt) {

        if (vt.getTenVaiTro().trim().isEmpty()) {
            return false;
        }

        return vaiTroDAO.update(vt);
    }

     
    public boolean delete(int maVaiTro) {
        return vaiTroDAO.delete(maVaiTro);
    }

     
    public VaiTro findById(int maVaiTro) {
        return vaiTroDAO.findById(maVaiTro);
    }
}