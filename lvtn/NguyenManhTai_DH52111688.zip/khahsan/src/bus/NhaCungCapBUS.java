package bus;

import dao.NhaCungCapDAO;
import model.NhaCungCap;

import java.util.List;

public class NhaCungCapBUS {

    private NhaCungCapDAO dao = new NhaCungCapDAO();

    public List<NhaCungCap> getAll() {
        return dao.getAll();
    }

    public boolean them(NhaCungCap ncc) {
        return dao.insert(ncc);
    }
    public List<Object[]> getHangHoaTheoNCC(int maNCC) {
        return dao.getHangHoaTheoNCC(maNCC);
    }
    public boolean sua(NhaCungCap ncc) {
        return dao.update(ncc);
    }

    public boolean xoa(int maNCC) {
        return dao.delete(maNCC);
    }

    public List<NhaCungCap> timKiem(String keyword) {
        return dao.search(keyword);
    }
}