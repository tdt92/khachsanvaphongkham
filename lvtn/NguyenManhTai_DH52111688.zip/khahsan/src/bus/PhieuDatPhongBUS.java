package bus;

import dao.PhieuDatPhongDAO;
import model.DatPhongDTO;
import model.PhieuDatPhong;

import java.util.List;

public class PhieuDatPhongBUS {

    private PhieuDatPhongDAO dao;

    public PhieuDatPhongBUS() {
        dao = new PhieuDatPhongDAO();
    }

     public List<PhieuDatPhong> getAll() {
        return dao.getAll();
    }
    public int insertAndGetId(
            PhieuDatPhong pd){

        return dao.insertAndGetId(pd);
    }
     public boolean insert(PhieuDatPhong pd) {

        if (pd == null) {
            return false;
        }

        if (pd.getMaKhachHang() <= 0) {
            return false;
        }

        return dao.insert(pd);
    }

     public boolean update(PhieuDatPhong pd) {

        if (pd == null) {
            return false;
        }

        if (pd.getMaPhieuDat() <= 0) {
            return false;
        }

        return dao.update(pd);
    }

     public boolean delete(int maPhieuDat) {
        return dao.delete(maPhieuDat);
    }

     public PhieuDatPhong findById(int maPhieuDat) {

        for (PhieuDatPhong pd : getAll()) {

            if (pd.getMaPhieuDat() == maPhieuDat) {
                return pd;
            }
        }

        return null;
    }
     public List<DatPhongDTO> getDanhSachDatPhong() {

    	    return dao.getDanhSachDatPhong();
    	}
     public boolean updateMaPhieuThue(int maPhieuDat, int maPhieuThue) {
    	    return dao.updateMaPhieuThue(maPhieuDat, maPhieuThue);
    	}
     
    public PhieuDatPhong getLastInserted() {

        List<PhieuDatPhong> list = dao.getAll();

        if(list.isEmpty()) {
            return null;
        }

        return list.get(list.size() - 1);
    }
}