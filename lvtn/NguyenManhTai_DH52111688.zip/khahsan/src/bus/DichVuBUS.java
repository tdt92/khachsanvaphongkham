package bus;

import dao.DichVuDAO;
import model.DichVu;

import java.util.List;

public class DichVuBUS {

    DichVuDAO dao = new DichVuDAO();

    public List<DichVu> getAll() {
        return dao.getAll();
    }

    public boolean insert(DichVu dv) {
        return dao.insert(dv);
    }
    public DichVu findById(int maDV){
        return dao.findById(maDV);
    }
    public boolean update(DichVu dv) {
        return dao.update(dv);
    }

    public boolean delete(int maDV) {
        return dao.delete(maDV);
    }
}