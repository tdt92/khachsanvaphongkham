package bus;

import dao.PhongDAO;
import model.Phong;

import java.util.List;

public class PhongBUS {

    private PhongDAO dao = new PhongDAO();

    public List<Phong> getAll() {
        return dao.getAll();
    }

    public boolean insert(Phong p) {
        return dao.insert(p);
    }

    public boolean update(Phong p) {
        return dao.update(p);
    }
    public Phong findById(int maPhong){

        for(Phong p : getAll()){

            if(p.getMaPhong()==maPhong){

                return p;
            }
        }

        return null;
    }
    public boolean isExistSoPhong(String soPhong) {
        for (Phong p : getAll()) {
            if (p.getSoPhong().equalsIgnoreCase(soPhong.trim())) {
                return true;
            }
        }
        return false;
    }
    public boolean isExistSoPhong(String soPhong, int maPhong) {
        for (Phong p : getAll()) {
            if (p.getSoPhong().equalsIgnoreCase(soPhong.trim())
                    && p.getMaPhong() != maPhong) {
                return true;
            }
        }
        return false;
    }
    public boolean isPhongTrong(int maPhong) {
        return dao.isPhongTrong(maPhong);
    }
    public boolean hasPhongByLoaiPhong(int maLoaiPhong) {
        return dao.hasPhongByLoaiPhong(maLoaiPhong);
    }
    public boolean updateTrangThai(
            int maPhong,
            String trangThai) {

        return dao.updateTrangThai(
                maPhong,
                trangThai);
    }
    public boolean delete(int maPhong) {
        return dao.delete(maPhong);
    }
}