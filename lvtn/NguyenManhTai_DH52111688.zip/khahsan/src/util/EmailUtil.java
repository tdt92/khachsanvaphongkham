package util;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

 
 

public class EmailUtil {

    private static final String USER =
            "taimanh920@gmail.com";

    private static final String PASSWORD =
            "kifm eaob eahc xrti";

    public static void guiMail(String to,
                               String subject,
                               String content)
            throws Exception {

        Properties props = new Properties();

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session =
                Session.getInstance(props,
                        new Authenticator() {

                            @Override
                            protected PasswordAuthentication
                            getPasswordAuthentication() {

                                return new PasswordAuthentication(
                                        USER,
                                        PASSWORD);
                            }
                        });

        Message message =
                new MimeMessage(session);

        message.setFrom(new InternetAddress(USER));

        message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(to));

        message.setSubject(subject);

        message.setText(content);

        Transport.send(message);
    }
}