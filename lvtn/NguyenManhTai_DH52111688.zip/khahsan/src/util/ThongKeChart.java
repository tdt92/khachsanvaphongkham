package util;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import java.util.Map;

public class ThongKeChart {

    public static JFreeChart lineChart(Map<String, Double> data, String title) {

        DefaultCategoryDataset ds = new DefaultCategoryDataset();

        data.forEach((k, v) -> ds.addValue(v, "Doanh thu", k));

        return ChartFactory.createLineChart(
                title,
                "Thời gian",
                "VNĐ",
                ds
        );
    }

    public static JFreeChart barChart(Map<String, Double> data, String title) {

        DefaultCategoryDataset ds = new DefaultCategoryDataset();

        data.forEach((k, v) -> ds.addValue(v, "Giá trị", k));

        return ChartFactory.createBarChart(
                title,
                "Danh mục",
                "VNĐ",
                ds
        );
    }
}