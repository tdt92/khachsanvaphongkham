package dao;

import connect.DBConnect;
import model.PhieuNhap;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PhieuNhapDAO {

    public List<PhieuNhap> getAll() {

        List<PhieuNhap> list = new ArrayList<>();

        String sql = "SELECT * FROM PhieuNhap";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                PhieuNhap pn = new PhieuNhap();

                pn.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
                pn.setMaNCC(rs.getInt("MaNCC"));
                pn.setMaNhanVien(rs.getInt("MaNhanVien"));
                pn.setNgayNhap(rs.getTimestamp("NgayNhap"));
                pn.setTongTien(rs.getDouble("TongTien"));
                pn.setGhiChu(rs.getString("GhiChu"));

                list.add(pn);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(PhieuNhap pn) {

        String sql = """
                INSERT INTO PhieuNhap
                (MaNCC, MaNhanVien, NgayNhap, TongTien, GhiChu)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, pn.getMaNCC());
            ps.setInt(2, pn.getMaNhanVien());
            ps.setTimestamp(3, pn.getNgayNhap());
            ps.setDouble(4, pn.getTongTien());
            ps.setString(5, pn.getGhiChu());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(PhieuNhap pn) {

        String sql = """
                UPDATE PhieuNhap
                SET MaNCC=?,
                    MaNhanVien=?,
                    NgayNhap=?,
                    TongTien=?,
                    GhiChu=?
                WHERE MaPhieuNhap=?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, pn.getMaNCC());
            ps.setInt(2, pn.getMaNhanVien());
            ps.setTimestamp(3, pn.getNgayNhap());
            ps.setDouble(4, pn.getTongTien());
            ps.setString(5, pn.getGhiChu());
            ps.setInt(6, pn.getMaPhieuNhap());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int maPhieuNhap) {

        String sql = "DELETE FROM PhieuNhap WHERE MaPhieuNhap=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maPhieuNhap);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<PhieuNhap> search(String keyword) {

        List<PhieuNhap> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM PhieuNhap
                WHERE CAST(MaPhieuNhap AS CHAR) LIKE ?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                PhieuNhap pn = new PhieuNhap();

                pn.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
                pn.setMaNCC(rs.getInt("MaNCC"));
                pn.setMaNhanVien(rs.getInt("MaNhanVien"));
                pn.setNgayNhap(rs.getTimestamp("NgayNhap"));
                pn.setTongTien(rs.getDouble("TongTien"));
                pn.setGhiChu(rs.getString("GhiChu"));

                list.add(pn);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public List<PhieuNhap> getPhieuNhapHomNayTheoNhanVien(int maNhanVien){

        List<PhieuNhap> list = new ArrayList<>();

        String sql =
                "SELECT * FROM PhieuNhap "
              + "WHERE MaNhanVien=? "
              + "AND DATE(NgayNhap)=CURDATE()";

        try(

            Connection con =
                    DBConnect.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)
        ){

            ps.setInt(1, maNhanVien);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                PhieuNhap pn = new PhieuNhap();

                pn.setMaPhieuNhap(
                        rs.getInt("MaPhieuNhap"));

                pn.setMaNCC(
                        rs.getInt("MaNCC"));

                pn.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                pn.setNgayNhap(
                        rs.getTimestamp("NgayNhap"));

                pn.setTongTien(
                        rs.getDouble("TongTien"));

                pn.setGhiChu(
                        rs.getString("GhiChu"));

                list.add(pn);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
}