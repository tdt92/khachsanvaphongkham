package dao;

import connect.DBConnect;
import model.ThongKeDiemDTO;
import model.ThongKePhongDTO;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class ThongKeDAO {

    // =========================================================
    // 1. DOANH THU THEO NGÀY / TUẦN / THÁNG / NĂM
    // =========================================================

    public List<ThongKeDiemDTO> getDoanhThuTheoNgay(Date tuNgay, Date denNgay) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT DATE(NgayLap) Ngay, SUM(TongTien) Tong, COUNT(*) SoHD " +
                "FROM HoaDon " +
                "WHERE DATE(NgayLap) BETWEEN ? AND ? " +
                "GROUP BY DATE(NgayLap) " +
                "ORDER BY Ngay";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {

                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");

                while (rs.next()) {
                    LocalDate d = rs.getDate("Ngay").toLocalDate();
                    ds.add(new ThongKeDiemDTO(d.format(fmt),
                            rs.getDouble("Tong"), rs.getInt("SoHD")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    public List<ThongKeDiemDTO> getDoanhThuTheoTuan(Date tuNgay, Date denNgay) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT YEARWEEK(NgayLap,1) Tuan, MIN(DATE(NgayLap)) NgayDauTuan, " +
                "SUM(TongTien) Tong, COUNT(*) SoHD " +
                "FROM HoaDon " +
                "WHERE DATE(NgayLap) BETWEEN ? AND ? " +
                "GROUP BY YEARWEEK(NgayLap,1) " +
                "ORDER BY Tuan";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {

                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM");

                while (rs.next()) {
                    LocalDate d = rs.getDate("NgayDauTuan").toLocalDate();
                    ds.add(new ThongKeDiemDTO("Tuần " + d.format(fmt),
                            rs.getDouble("Tong"), rs.getInt("SoHD")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    public List<ThongKeDiemDTO> getDoanhThuTheoThang(int nam) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT MONTH(NgayLap) Thang, SUM(TongTien) Tong, COUNT(*) SoHD " +
                "FROM HoaDon " +
                "WHERE YEAR(NgayLap) = ? " +
                "GROUP BY MONTH(NgayLap) " +
                "ORDER BY Thang";

        // Khởi tạo sẵn 12 tháng để biểu đồ luôn đủ trục X kể cả tháng không có doanh thu
        Map<Integer, ThongKeDiemDTO> map = new LinkedHashMap<>();
        for (int i = 1; i <= 12; i++) {
            map.put(i, new ThongKeDiemDTO("Th." + i, 0, 0));
        }

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nam);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    int thang = rs.getInt("Thang");
                    map.put(thang, new ThongKeDiemDTO("Th." + thang,
                            rs.getDouble("Tong"), rs.getInt("SoHD")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        ds.addAll(map.values());
        return ds;
    }

    public List<ThongKeDiemDTO> getDoanhThuTheoNam() {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT YEAR(NgayLap) Nam, SUM(TongTien) Tong, COUNT(*) SoHD " +
                "FROM HoaDon " +
                "GROUP BY YEAR(NgayLap) " +
                "ORDER BY Nam";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ds.add(new ThongKeDiemDTO(String.valueOf(rs.getInt("Nam")),
                        rs.getDouble("Tong"), rs.getInt("SoHD")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    // =========================================================
    // 2. DOANH THU THEO LOẠI PHÒNG / THEO DỊCH VỤ
    // =========================================================

    public List<ThongKeDiemDTO> getDoanhThuTheoLoaiPhong(Date tuNgay, Date denNgay) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT lp.TenLoaiPhong Ten, SUM(ct.DonGia) Tong, COUNT(*) SoLuot " +
                "FROM ChiTietThuePhong ct " +
                "JOIN Phong p ON ct.MaPhong = p.MaPhong " +
                "JOIN LoaiPhong lp ON p.MaLoaiPhong = lp.MaLoaiPhong " +
                "JOIN PhieuThuePhong pt ON ct.MaPhieuThue = pt.MaPhieuThue " +
                "WHERE DATE(pt.NgayNhanPhong) BETWEEN ? AND ? " +
                "GROUP BY lp.TenLoaiPhong " +
                "ORDER BY Tong DESC";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    ds.add(new ThongKeDiemDTO(rs.getString("Ten"),
                            rs.getDouble("Tong"), rs.getInt("SoLuot")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    public List<ThongKeDiemDTO> getDoanhThuTheoDichVu(Date tuNgay, Date denNgay) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT dv.TenDichVu Ten, SUM(sd.ThanhTien) Tong, SUM(sd.SoLuong) SoLuong " +
                "FROM SuDungDichVu sd " +
                "JOIN DichVu dv ON sd.MaDichVu = dv.MaDichVu " +
                "WHERE DATE(sd.NgaySuDung) BETWEEN ? AND ? " +
                "GROUP BY dv.TenDichVu " +
                "ORDER BY Tong DESC";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    ds.add(new ThongKeDiemDTO(rs.getString("Ten"),
                            rs.getDouble("Tong"), rs.getInt("SoLuong")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    /** Phương thức thanh toán -> dùng cho biểu đồ tròn */
    public List<ThongKeDiemDTO> getThongKeHinhThucThanhToan(Date tuNgay, Date denNgay) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        String sql =
                "SELECT IFNULL(HinhThucThanhToan,'Khác') HTTT, " +
                "COUNT(*) SoHD, SUM(TongTien) Tong " +
                "FROM HoaDon " +
                "WHERE DATE(NgayLap) BETWEEN ? AND ? " +
                "GROUP BY HTTT";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    ds.add(new ThongKeDiemDTO(rs.getString("HTTT"),
                            rs.getDouble("Tong"), rs.getInt("SoHD")));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    // =========================================================
    // 3. TỔNG SỐ HOÁ ĐƠN / GIÁ TRỊ TRUNG BÌNH
    // =========================================================

    public int getTongSoHoaDon(Date tuNgay, Date denNgay) {

        String sql = "SELECT COUNT(*) SL FROM HoaDon WHERE DATE(NgayLap) BETWEEN ? AND ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("SL");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public double getGiaTriHoaDonTrungBinh(Date tuNgay, Date denNgay) {

        String sql = "SELECT IFNULL(AVG(TongTien),0) TB FROM HoaDon WHERE DATE(NgayLap) BETWEEN ? AND ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("TB");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public double getTongDoanhThu(Date tuNgay, Date denNgay) {

        String sql = "SELECT IFNULL(SUM(TongTien),0) T FROM HoaDon WHERE DATE(NgayLap) BETWEEN ? AND ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("T");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    // =========================================================
    // 4. THỐNG KÊ PHÒNG (tình trạng, sắp check-in/out)
    // =========================================================

    public ThongKePhongDTO getThongKePhong(int soNgayCanhBao) {

        ThongKePhongDTO dto = new ThongKePhongDTO();

        try (Connection con = DBConnect.getConnection()) {

            // Tổng số phòng
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) SL FROM Phong");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) dto.setTongSoPhong(rs.getInt("SL"));
            }

            // Số phòng theo từng trạng thái (lấy nguyên giá trị TrangThai trong DB)
            Map<String, Integer> map = new LinkedHashMap<>();
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT TrangThai, COUNT(*) SL FROM Phong GROUP BY TrangThai");
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    map.put(rs.getString("TrangThai"), rs.getInt("SL"));
                }
            }
            dto.setTheoTrangThai(map);

            // Phòng sắp check-in: phiếu đặt phòng có ngày nhận trong N ngày tới, chưa huỷ, chưa nhận phòng
            String sqlCheckIn =
                    "SELECT COUNT(*) SL FROM PhieuDatPhong " +
                    "WHERE NgayNhanPhong BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY) " +
                    "AND (TrangThai IS NULL OR TrangThai NOT LIKE '%HUY%') " +
                    "AND MaPhieuThue IS NULL";

            try (PreparedStatement ps = con.prepareStatement(sqlCheckIn)) {
                ps.setInt(1, soNgayCanhBao);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) dto.setSoPhongSapCheckIn(rs.getInt("SL"));
                }
            }

            // Phòng sắp check-out: phiếu thuê đang ở, có ngày trả dự kiến trong N ngày tới
            String sqlCheckOut =
                    "SELECT COUNT(*) SL FROM PhieuThuePhong " +
                    "WHERE TrangThai LIKE '%DANG%' " +
                    "AND NgayTraPhongDuKien BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)";

            try (PreparedStatement ps = con.prepareStatement(sqlCheckOut)) {
                ps.setInt(1, soNgayCanhBao);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) dto.setSoPhongSapCheckOut(rs.getInt("SL"));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dto;
    }

    // =========================================================
    // 5. REVPAR / ADR / OCCUPANCY (đơn giản hoá theo kỳ báo cáo)
    // =========================================================

    /** Doanh thu phòng thuần trong kỳ (không tính dịch vụ) */
    public double getDoanhThuPhongTrongKy(Date tuNgay, Date denNgay) {

        String sql =
                "SELECT IFNULL(SUM(ct.DonGia),0) T " +
                "FROM ChiTietThuePhong ct " +
                "JOIN PhieuThuePhong pt ON ct.MaPhieuThue = pt.MaPhieuThue " +
                "WHERE DATE(pt.NgayNhanPhong) BETWEEN ? AND ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("T");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    /** Số lượt phòng đã bán (mỗi dòng ChiTietThuePhong = 1 lượt) trong kỳ */
    public int getSoLuotThuePhong(Date tuNgay, Date denNgay) {

        String sql =
                "SELECT COUNT(*) SL " +
                "FROM ChiTietThuePhong ct " +
                "JOIN PhieuThuePhong pt ON ct.MaPhieuThue = pt.MaPhieuThue " +
                "WHERE DATE(pt.NgayNhanPhong) BETWEEN ? AND ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("SL");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int getTongSoPhong() {

        String sql = "SELECT COUNT(*) SL FROM Phong";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt("SL");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    // =========================================================
    // 6. HEATMAP CÔNG SUẤT PHÒNG THEO NGÀY TRONG THÁNG
    // =========================================================

    /**
     * Trả về danh sách 28-31 điểm, mỗi điểm là 1 ngày trong tháng với
     * giá trị = số phòng đang có khách / tổng số phòng (0..1).
     */
    public List<ThongKeDiemDTO> getCongSuatPhongTheoNgay(int nam, int thang) {

        List<ThongKeDiemDTO> ds = new ArrayList<>();

        int tongSoPhong = getTongSoPhong();

        if (tongSoPhong <= 0) {
            return ds;
        }

        LocalDate firstDay = LocalDate.of(nam, thang, 1);
        int soNgay = firstDay.lengthOfMonth();

        String sql =
                "SELECT COUNT(DISTINCT ct.MaPhong) AS SL " +
                "FROM ChiTietThuePhong ct " +
                "INNER JOIN PhieuThuePhong pt " +
                "ON ct.MaPhieuThue = pt.MaPhieuThue " +
                "WHERE ? BETWEEN DATE(pt.NgayNhanPhong) " +
                "AND DATE(pt.NgayTraPhongDuKien)";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            for (int d = 1; d <= soNgay; d++) {

                LocalDate ngay = LocalDate.of(nam, thang, d);

                ps.setDate(1, Date.valueOf(ngay));

                int soPhongCoKhach = 0;

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        soPhongCoKhach = rs.getInt("SL");
                    }
                }

                // LineChartPanel yêu cầu giá trị 0 -> 1
                double congSuat = (double) soPhongCoKhach / tongSoPhong;

                System.out.printf(
                        "%s | %d/%d phòng | %.2f%%%n",
                        ngay,
                        soPhongCoKhach,
                        tongSoPhong,
                        congSuat * 100
                );

                ds.add(new ThongKeDiemDTO(
                        String.valueOf(d),
                        congSuat,
                        soPhongCoKhach
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }
	/*
	 * public List<ThongKeDiemDTO> getCongSuatPhongTheoNgay(int nam, int thang) {
	 * 
	 * List<ThongKeDiemDTO> ds = new ArrayList<>();
	 * 
	 * int tongSoPhong = getTongSoPhong(); if (tongSoPhong == 0) tongSoPhong = 1; //
	 * tránh chia 0
	 * 
	 * LocalDate first = LocalDate.of(nam, thang, 1); int soNgay =
	 * first.lengthOfMonth();
	 * 
	 * String sql = "SELECT COUNT(DISTINCT ct.MaPhong) SL " +
	 * "FROM ChiTietThuePhong ct " +
	 * "JOIN PhieuThuePhong pt ON ct.MaPhieuThue = pt.MaPhieuThue " +
	 * "WHERE DATE(pt.NgayNhanPhong) <= ? " +
	 * "AND (pt.TrangThai LIKE '%DANG%' OR DATE(pt.NgayTraPhongDuKien) >= ?)";
	 * 
	 * try (Connection con = DBConnect.getConnection(); PreparedStatement ps =
	 * con.prepareStatement(sql)) {
	 * 
	 * for (int d = 1; d <= soNgay; d++) {
	 * 
	 * LocalDate ngay = LocalDate.of(nam, thang, d); Date sqlDate =
	 * Date.valueOf(ngay);
	 * 
	 * ps.setDate(1, sqlDate); ps.setDate(2, sqlDate);
	 * 
	 * int soPhongCoKhach = 0; try (ResultSet rs = ps.executeQuery()) { if
	 * (rs.next()) soPhongCoKhach = rs.getInt("SL"); }
	 * 
	 * double congSuat = (double) soPhongCoKhach / tongSoPhong; ds.add(new
	 * ThongKeDiemDTO(String.valueOf(d), congSuat, soPhongCoKhach)); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return ds; }
	 */
}