package dao;

import connect.DBConnect;
import model.NhanVien;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    public List<NhanVien> getAll() {

        List<NhanVien> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM NhanVien";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                NhanVien nv = new NhanVien();

                nv.setMaNhanVien(rs.getInt("MaNhanVien"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setCccd(rs.getLong("CCCD"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setSoDienThoai(rs.getString("SoDienThoai"));
                nv.setEmail(rs.getString("Email"));
                nv.setDiaChi(rs.getString("DiaChi"));
                nv.setChucVu(rs.getString("ChucVu"));
                nv.setNgayVaoLam(rs.getDate("NgayVaoLam"));
                Object maTK = rs.getObject("MaTaiKhoan");

                if(maTK != null){

                    nv.setMaTaiKhoan(rs.getInt("MaTaiKhoan"));

                }else{

                    nv.setMaTaiKhoan(null);
                }
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(NhanVien nv) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "INSERT INTO NhanVien("
                  + "HoTen,GioiTinh,NgaySinh,"
                  + "SoDienThoai,Email,DiaChi,"
                  + "ChucVu,NgayVaoLam,CCCD,MaTaiKhoan)"
                  + " VALUES(?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nv.getHoTen());
            ps.setString(2, nv.getGioiTinh());
            ps.setDate(3, nv.getNgaySinh());
            ps.setString(4, nv.getSoDienThoai());
            ps.setString(5, nv.getEmail());
            ps.setString(6, nv.getDiaChi());
            ps.setString(7, nv.getChucVu());
            ps.setDate(8, nv.getNgayVaoLam());
            ps.setLong(9, nv.getCccd());
            if(nv.getMaTaiKhoan() == null){

                ps.setNull(10, java.sql.Types.INTEGER);

            }else{

                ps.setInt(10, nv.getMaTaiKhoan());
            }
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(NhanVien nv) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "UPDATE NhanVien SET "
                    + "HoTen=?, "
                    + "GioiTinh=?, "
                    + "NgaySinh=?, "
                    + "SoDienThoai=?, "
                    + "Email=?, "
                    + "DiaChi=?, "
                    + "ChucVu=?, "
                    + "NgayVaoLam=?, "
                    + "CCCD=?, "
                    + "MaTaiKhoan=? "
                    + "WHERE MaNhanVien=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nv.getHoTen());

            ps.setString(2, nv.getGioiTinh());

            ps.setDate(3, nv.getNgaySinh());

            ps.setString(4, nv.getSoDienThoai());

            ps.setString(5, nv.getEmail());

            ps.setString(6, nv.getDiaChi());

            ps.setString(7, nv.getChucVu());

            ps.setDate(8, nv.getNgayVaoLam());

             if(nv.getCccd() == null){

                ps.setNull(9, java.sql.Types.BIGINT);

            }else{

                ps.setLong(9, nv.getCccd());
            }

             if(nv.getMaTaiKhoan() == null){

                ps.setNull(10, java.sql.Types.INTEGER);

            }else{

                ps.setInt(10, nv.getMaTaiKhoan());
            }

            ps.setInt(11, nv.getMaNhanVien());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int maNV) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "DELETE FROM NhanVien WHERE MaNhanVien=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, maNV);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public NhanVien findById(int maNV){

        NhanVien nv = null;

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM NhanVien WHERE MaNhanVien=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maNV);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                nv = new NhanVien();

                nv.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                nv.setHoTen(
                        rs.getString("HoTen"));

                nv.setGioiTinh(
                        rs.getString("GioiTinh"));

                nv.setNgaySinh(
                        rs.getDate("NgaySinh"));

                nv.setSoDienThoai(
                        rs.getString("SoDienThoai"));

                nv.setEmail(
                        rs.getString("Email"));

                nv.setDiaChi(
                        rs.getString("DiaChi"));

                nv.setChucVu(
                        rs.getString("ChucVu"));

                nv.setNgayVaoLam(
                        rs.getDate("NgayVaoLam"));

                 Object cccd = rs.getObject("CCCD");

                if(cccd != null){

                    nv.setCccd(
                            rs.getLong("CCCD"));
                }

                 Object maTK =
                        rs.getObject("MaTaiKhoan");

                if(maTK != null){

                    nv.setMaTaiKhoan(
                            rs.getInt("MaTaiKhoan"));
                }
            }

        }catch (Exception e){

            e.printStackTrace();
        }

        return nv;
    }
    public NhanVien findByMaTaiKhoan(int maTaiKhoan){

        NhanVien nv = null;

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM NhanVien WHERE MaTaiKhoan=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maTaiKhoan);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                nv = new NhanVien();

                nv.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                nv.setHoTen(
                        rs.getString("HoTen"));
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return nv;
    }
    public List<NhanVien> search(String keyword){

        List<NhanVien> list = new ArrayList<>();

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM NhanVien "
                  + "WHERE HoTen = ? "  
                   ;

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1,  keyword );

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                NhanVien nv = new NhanVien();

                nv.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                nv.setHoTen(
                        rs.getString("HoTen"));

                nv.setGioiTinh(
                        rs.getString("GioiTinh"));

                nv.setNgaySinh(
                        rs.getDate("NgaySinh"));

                nv.setSoDienThoai(
                        rs.getString("SoDienThoai"));

                nv.setEmail(
                        rs.getString("Email"));

                nv.setDiaChi(
                        rs.getString("DiaChi"));

                nv.setChucVu(
                        rs.getString("ChucVu"));

                nv.setNgayVaoLam(
                        rs.getDate("NgayVaoLam"));

                nv.setCccd(
                        rs.getLong("CCCD"));

                Object maTK =
                        rs.getObject("MaTaiKhoan");

                if(maTK != null){

                    nv.setMaTaiKhoan(
                            rs.getInt("MaTaiKhoan"));
                }

                list.add(nv);
            }

        }catch (Exception e){

            e.printStackTrace();
        }

        return list;
    }
    public boolean updateContactInfo(int maTaiKhoan, String sdt, String email, String diaChi) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "UPDATE NhanVien SET "
                    + "SoDienThoai=?, "
                    + "Email=?, "
                    + "DiaChi=? "
                    + "WHERE MaTaiKhoan=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, sdt);
            ps.setString(2, email);
            ps.setString(3, diaChi);
            ps.setInt(4, maTaiKhoan);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public NhanVien getByMaTaiKhoan(int maTaiKhoan) {

        String sql = "SELECT * FROM NhanVien WHERE MaTaiKhoan=?";

        try (
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, maTaiKhoan);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                NhanVien nv = new NhanVien();

                nv.setMaNhanVien(rs.getInt("MaNhanVien"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setMaTaiKhoan(rs.getInt("MaTaiKhoan"));

                return nv;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    public NhanVien findByTaiKhoan(int maTaiKhoan){

        NhanVien nv = null;

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM NhanVien "
                  + "WHERE MaTaiKhoan=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maTaiKhoan);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                nv = new NhanVien();

                nv.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                nv.setHoTen(
                        rs.getString("HoTen"));

                nv.setSoDienThoai(
                        rs.getString("SoDienThoai"));

                nv.setEmail(
                        rs.getString("Email"));

                nv.setDiaChi(
                        rs.getString("DiaChi"));
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return nv;
    }
}


