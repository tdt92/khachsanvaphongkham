package dao;

import connect.DBConnect;
import model.LichPhongDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LichPhongDAO {

    public List<LichPhongDTO> getAll() {

        List<LichPhongDTO> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =

                    "SELECT p.SoPhong, " +
                    "kh.HoTen, " +
                    "pd.NgayNhanPhong, " +
                    "pd.NgayTraPhong, " +
                    "'DA_DAT' TrangThai " +
                    "FROM PhieuDatPhong pd " +
                    "JOIN ChiTietDatPhong ct " +
                    "ON pd.MaPhieuDat=ct.MaPhieuDat " +
                    "JOIN Phong p " +
                    "ON ct.MaPhong=p.MaPhong " +
                    "JOIN KhachHang kh " +
                    "ON kh.MaKhachHang=pd.MaKhachHang " +
                    "WHERE pd.TrangThai='DA_DAT' " +

                    "UNION ALL " +

                    "SELECT p.SoPhong, " +
                    "kh.HoTen, " +
                    "DATE(pt.NgayNhanPhong), " +
                    "pt.NgayTraPhongDuKien, " +
                    "'DANG_THUE' TrangThai " +
                    "FROM PhieuThuePhong pt " +
                    "JOIN ChiTietThuePhong ct " +
                    "ON pt.MaPhieuThue=ct.MaPhieuThue " +
                    "JOIN Phong p " +
                    "ON ct.MaPhong=p.MaPhong " +
                    "JOIN KhachHang kh " +
                    "ON kh.MaKhachHang=pt.MaKhachHang " +
                    "WHERE pt.TrangThai='DANG_THUE' " +

                    "ORDER BY SoPhong, NgayNhanPhong";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                LichPhongDTO dto = new LichPhongDTO();

                dto.setSoPhong(rs.getString(1));
                dto.setTenKhach(rs.getString(2));
                dto.setNgayNhan(rs.getDate(3));
                dto.setNgayTra(rs.getDate(4));
                dto.setTrangThai(rs.getString(5));

                list.add(dto);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;

    }

}