package dao;

import connect.DBConnect;
import model.KhachHang;
import model.NhanVien;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KhachHangDAO {

     
    public List<KhachHang> getAll() {

        List<KhachHang> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM KhachHang";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                KhachHang kh = new KhachHang();

                kh.setMaKhachHang(rs.getInt("MaKhachHang"));
                kh.setHoTen(rs.getString("HoTen"));
                kh.setCccd(rs.getString("CCCD"));
                kh.setSoDienThoai(rs.getString("SoDienThoai"));
                kh.setEmail(rs.getString("Email"));
                kh.setDiaChi(rs.getString("DiaChi"));
                kh.setQuocTich(rs.getString("QuocTich"));

                list.add(kh);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    
    public boolean insert(KhachHang kh) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "INSERT INTO KhachHang(HoTen, CCCD, SoDienThoai, Email, DiaChi, QuocTich) VALUES(?,?,?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, kh.getHoTen());
            ps.setString(2, kh.getCccd());
            ps.setString(3, kh.getSoDienThoai());
            ps.setString(4, kh.getEmail());
            ps.setString(5, kh.getDiaChi());
            ps.setString(6, kh.getQuocTich());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public boolean update(KhachHang kh) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "UPDATE KhachHang SET HoTen=?, CCCD=?, SoDienThoai=?, Email=?, DiaChi=?, QuocTich=? WHERE MaKhachHang=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, kh.getHoTen());
            ps.setString(2, kh.getCccd());
            ps.setString(3, kh.getSoDienThoai());
            ps.setString(4, kh.getEmail());
            ps.setString(5, kh.getDiaChi());
            ps.setString(6, kh.getQuocTich());
            ps.setInt(7, kh.getMaKhachHang());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public List<KhachHang> search(String keyword) {

        List<KhachHang> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM KhachHang " +
                    "WHERE HoTen LIKE ? " +
                    "OR Cccd LIKE ?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                KhachHang kh = new KhachHang();

                kh.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                kh.setHoTen(
                        rs.getString("HoTen"));

                

                kh.setSoDienThoai(
                        rs.getString("SoDienThoai"));

                kh.setEmail(
                        rs.getString("Email"));

                kh.setDiaChi(
                        rs.getString("DiaChi"));

                kh.setCccd(
                        rs.getString("CCCD"));

                list.add(kh);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return list;
    }
    public boolean existsCCCD(String cccd) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT COUNT(*) FROM KhachHang WHERE CCCD = ?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, cccd);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }
    public boolean existsCCCD(String cccd, int maKhachHang) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT COUNT(*) FROM KhachHang "
                       + "WHERE CCCD = ? AND MaKhachHang <> ?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, cccd);
            ps.setInt(2, maKhachHang);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean delete(int maKH) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "DELETE FROM KhachHang WHERE MaKhachHang=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maKH);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}