package dao;

import connect.DBConnect;
import model.LoaiPhong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LoaiPhongDAO {

   
    public List<LoaiPhong> getAll() {

        List<LoaiPhong> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM LoaiPhong";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                LoaiPhong lp = new LoaiPhong();

                lp.setMaLoaiPhong(rs.getInt("MaLoaiPhong"));
                lp.setTenLoaiPhong(rs.getString("TenLoaiPhong"));
                lp.setDonGia(rs.getDouble("DonGia"));
                lp.setSoNguoiToiDa(rs.getInt("SoNguoiToiDa"));
                lp.setMoTa(rs.getString("MoTa"));

                list.add(lp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

   
    public boolean insert(LoaiPhong lp) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "INSERT INTO LoaiPhong(TenLoaiPhong, DonGia, SoNguoiToiDa, MoTa) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, lp.getTenLoaiPhong());
            ps.setDouble(2, lp.getDonGia());
            ps.setInt(3, lp.getSoNguoiToiDa());
            ps.setString(4, lp.getMoTa());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public boolean update(LoaiPhong lp) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "UPDATE LoaiPhong SET TenLoaiPhong=?, DonGia=?, SoNguoiToiDa=?, MoTa=? WHERE MaLoaiPhong=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, lp.getTenLoaiPhong());
            ps.setDouble(2, lp.getDonGia());
            ps.setInt(3, lp.getSoNguoiToiDa());
            ps.setString(4, lp.getMoTa());
            ps.setInt(5, lp.getMaLoaiPhong());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

  
    public boolean delete(int maLoaiPhong) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "DELETE FROM LoaiPhong WHERE MaLoaiPhong=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maLoaiPhong);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}