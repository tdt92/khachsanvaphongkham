package dao;

import connect.DBConnect;
import model.HoaDon;

import java.sql.*;
import java.util.ArrayList;

public class HoaDonDAO {

    public ArrayList<HoaDon> getAll() {

        ArrayList<HoaDon> ds = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM HoaDon";

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                HoaDon hd = new HoaDon();

                hd.setMaHoaDon(rs.getInt("MaHoaDon"));
                hd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                hd.setMaNhanVien(rs.getInt("MaNhanVien"));
                hd.setNgayLap(rs.getTimestamp("NgayLap"));

                hd.setTongTien(rs.getDouble("TongTien"));
                hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
                hd.setTienConLai(rs.getDouble("TienConLai"));

                hd.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
                hd.setTrangThaiThanhToan(rs.getString("TrangThaiThanhToan"));
                hd.setGhiChu(rs.getString("GhiChu"));

                ds.add(hd);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    public HoaDon getById(int maHoaDon) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM HoaDon WHERE MaHoaDon=?";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setInt(1, maHoaDon);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                HoaDon hd = new HoaDon();

                hd.setMaHoaDon(rs.getInt("MaHoaDon"));
                hd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                hd.setMaNhanVien(rs.getInt("MaNhanVien"));
                hd.setNgayLap(rs.getTimestamp("NgayLap"));

                hd.setTongTien(rs.getDouble("TongTien"));
                hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
                hd.setTienConLai(rs.getDouble("TienConLai"));

                hd.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
                hd.setTrangThaiThanhToan(rs.getString("TrangThaiThanhToan"));
                hd.setGhiChu(rs.getString("GhiChu"));

                return hd;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }

    public int insertAndGetId(HoaDon hd) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "INSERT INTO HoaDon(MaPhieuThue,MaNhanVien,TongTien,TienKhachTra,TienConLai,HinhThucThanhToan,TrangThaiThanhToan,GhiChu)"
                            + " VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement pst =
                    con.prepareStatement(sql,
                            Statement.RETURN_GENERATED_KEYS);

            pst.setInt(1, hd.getMaPhieuThue());
            pst.setInt(2, hd.getMaNhanVien());

            pst.setDouble(3, hd.getTongTien());
            pst.setDouble(4, hd.getTienKhachTra());
            pst.setDouble(5, hd.getTienConLai());

            pst.setString(6, hd.getHinhThucThanhToan());
            pst.setString(7, hd.getTrangThaiThanhToan());
            pst.setString(8, hd.getGhiChu());

            pst.executeUpdate();

            ResultSet rs = pst.getGeneratedKeys();

            if (rs.next()) {

                return rs.getInt(1);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return -1;
    }

    public boolean update(HoaDon hd) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "UPDATE HoaDon SET TongTien=?,TienKhachTra=?,TienConLai=?,HinhThucThanhToan=?,TrangThaiThanhToan=?,GhiChu=? WHERE MaHoaDon=?";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setDouble(1, hd.getTongTien());
            pst.setDouble(2, hd.getTienKhachTra());
            pst.setDouble(3, hd.getTienConLai());

            pst.setString(4, hd.getHinhThucThanhToan());
            pst.setString(5, hd.getTrangThaiThanhToan());
            pst.setString(6, hd.getGhiChu());

            pst.setInt(7, hd.getMaHoaDon());

            return pst.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int maHoaDon) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "DELETE FROM HoaDon WHERE MaHoaDon=?";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setInt(1, maHoaDon);

            return pst.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }
    public HoaDon getByPhieuThue(int maPhieuThue) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM HoaDon WHERE MaPhieuThue = ?";

            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, maPhieuThue);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                HoaDon hd = new HoaDon();

                hd.setMaHoaDon(rs.getInt("MaHoaDon"));
                hd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                hd.setMaNhanVien(rs.getInt("MaNhanVien"));
                hd.setNgayLap(rs.getTimestamp("NgayLap"));

                hd.setTongTien(rs.getDouble("TongTien"));
                hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
                hd.setTienConLai(rs.getDouble("TienConLai"));

                hd.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
                hd.setTrangThaiThanhToan(rs.getString("TrangThaiThanhToan"));
                hd.setGhiChu(rs.getString("GhiChu"));

                return hd;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    public boolean xacNhanThanhToan(int maHoaDon,
            double tienKhachTra,
            double tienConLai) {

try {

Connection con = DBConnect.getConnection();

String sql =
"UPDATE HoaDon SET "
+ "TienKhachTra=?,"
+ "TienConLai=?,"
+ "TrangThaiThanhToan='DA_THANH_TOAN' "
+ "WHERE MaHoaDon=?";

PreparedStatement pst =
con.prepareStatement(sql);

pst.setDouble(1, tienKhachTra);
pst.setDouble(2, tienConLai);
pst.setInt(3, maHoaDon);

return pst.executeUpdate() > 0;

} catch (Exception e) {
e.printStackTrace();
}

return false;
}
	/*
	 * public boolean xacNhanThanhToan(int maHoaDon, double tienKhachTra, double
	 * tienConLai) {
	 * 
	 * try {
	 * 
	 * Connection con = DBConnect.getConnection();
	 * 
	 * String sql = "UPDATE HoaDon SET " + "TienKhachTra=?," + "TienConLai=?," +
	 * "TrangThaiThanhToan='Đã thanh toán' " + "WHERE MaHoaDon=?";
	 * 
	 * PreparedStatement pst = con.prepareStatement(sql);
	 * 
	 * pst.setDouble(1, tienKhachTra); pst.setDouble(2, tienConLai); pst.setInt(3,
	 * maHoaDon);
	 * 
	 * return pst.executeUpdate() > 0;
	 * 
	 * } catch (Exception e) {
	 * 
	 * e.printStackTrace(); }
	 * 
	 * return false; }
	 */
}