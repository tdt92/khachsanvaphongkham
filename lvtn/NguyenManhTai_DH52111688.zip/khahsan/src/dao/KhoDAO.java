package dao;

import connect.DBConnect;
import model.Kho;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KhoDAO {

   
    public List<Kho> getAll() {

        List<Kho> list = new ArrayList<>();

        String sql = "SELECT * FROM Kho";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Kho k = new Kho();

                k.setMaVatDung(rs.getInt("MaVatDung"));
                k.setTenVatDung(rs.getString("TenVatDung"));
                k.setDonViTinh(rs.getString("DonViTinh"));
                k.setSoLuongTon(rs.getInt("SoLuongTon"));
                k.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
                k.setDonGiaBan(rs.getDouble("DonGiaBan"));
                k.setNgayNhap(rs.getDate("NgayNhap"));
                k.setGhiChu(rs.getString("GhiChu"));

                list.add(k);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

     
    public boolean insert(Kho k) {

        String sql = """
                INSERT INTO Kho
                (
                    TenVatDung,
                    DonViTinh,
                    SoLuongTon,
                    DonGiaNhap,
                    DonGiaBan,
                    NgayNhap,
                    GhiChu
                )
                VALUES(?,?,?,?,?,?,?)
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, k.getTenVatDung());
            ps.setString(2, k.getDonViTinh());
            ps.setInt(3, k.getSoLuongTon());
            ps.setDouble(4, k.getDonGiaNhap());
            ps.setDouble(5, k.getDonGiaBan());
            ps.setDate(6, k.getNgayNhap());
            ps.setString(7, k.getGhiChu());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public boolean update(Kho k) {

        String sql = """
                UPDATE Kho
                SET TenVatDung=?,
                    DonViTinh=?,
                    SoLuongTon=?,
                    DonGiaNhap=?,
                    DonGiaBan=?,
                    NgayNhap=?,
                    GhiChu=?
                WHERE MaVatDung=?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, k.getTenVatDung());
            ps.setString(2, k.getDonViTinh());
            ps.setInt(3, k.getSoLuongTon());
            ps.setDouble(4, k.getDonGiaNhap());
            ps.setDouble(5, k.getDonGiaBan());
            ps.setDate(6, k.getNgayNhap());
            ps.setString(7, k.getGhiChu());
            ps.setInt(8, k.getMaVatDung());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public boolean delete(int maVatDung) {

        String sql = "DELETE FROM Kho WHERE MaVatDung=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maVatDung);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

     
    public List<Kho> search(String keyword) {

        List<Kho> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM Kho
                WHERE TenVatDung LIKE ?
                   OR DonViTinh LIKE ?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            String value = "%" + keyword + "%";

            ps.setString(1, value);
            ps.setString(2, value);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Kho k = new Kho();

                k.setMaVatDung(rs.getInt("MaVatDung"));
                k.setTenVatDung(rs.getString("TenVatDung"));
                k.setDonViTinh(rs.getString("DonViTinh"));
                k.setSoLuongTon(rs.getInt("SoLuongTon"));
                k.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
                k.setDonGiaBan(rs.getDouble("DonGiaBan"));
                k.setNgayNhap(rs.getDate("NgayNhap"));
                k.setGhiChu(rs.getString("GhiChu"));

                list.add(k);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean updateSoLuong(int maVatDung, int soLuongMoi) {
        try {
            Connection con = DBConnect.getConnection();

            String sql = "UPDATE Kho SET SoLuongTon=? WHERE MaVatDung=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, soLuongMoi);
            ps.setInt(2, maVatDung);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public Kho findById(int maVatDung) {

        String sql = "SELECT * FROM Kho WHERE MaVatDung=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maVatDung);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Kho k = new Kho();

                k.setMaVatDung(rs.getInt("MaVatDung"));
                k.setTenVatDung(rs.getString("TenVatDung"));
                k.setDonViTinh(rs.getString("DonViTinh"));
                k.setSoLuongTon(rs.getInt("SoLuongTon"));
                k.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
                k.setDonGiaBan(rs.getDouble("DonGiaBan"));
                k.setNgayNhap(rs.getDate("NgayNhap"));
                k.setGhiChu(rs.getString("GhiChu"));

                return k;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}