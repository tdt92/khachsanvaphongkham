package dao;

import connect.DBConnect;
import model.NhaCungCap;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NhaCungCapDAO {

    public List<NhaCungCap> getAll() {

        List<NhaCungCap> list = new ArrayList<>();

        String sql = "SELECT * FROM NhaCungCap";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                NhaCungCap ncc = new NhaCungCap();

                ncc.setMaNCC(rs.getInt("MaNCC"));
                ncc.setTenNCC(rs.getString("TenNCC"));
                ncc.setDiaChi(rs.getString("DiaChi"));
                ncc.setSoDienThoai(rs.getString("SoDienThoai"));
                ncc.setEmail(rs.getString("Email"));

                list.add(ncc);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(NhaCungCap ncc) {

        String sql = "INSERT INTO NhaCungCap(TenNCC,DiaChi,SoDienThoai,Email) VALUES(?,?,?,?)";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ncc.getTenNCC());
            ps.setString(2, ncc.getDiaChi());
            ps.setString(3, ncc.getSoDienThoai());
            ps.setString(4, ncc.getEmail());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(NhaCungCap ncc) {

        String sql = "UPDATE NhaCungCap SET TenNCC=?, DiaChi=?, SoDienThoai=?, Email=? WHERE MaNCC=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ncc.getTenNCC());
            ps.setString(2, ncc.getDiaChi());
            ps.setString(3, ncc.getSoDienThoai());
            ps.setString(4, ncc.getEmail());
            ps.setInt(5, ncc.getMaNCC());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int maNCC) {

        String sql = "DELETE FROM NhaCungCap WHERE MaNCC=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maNCC);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<NhaCungCap> search(String keyword) {

        List<NhaCungCap> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM NhaCungCap
                WHERE TenNCC LIKE ?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                NhaCungCap ncc = new NhaCungCap();

                ncc.setMaNCC(rs.getInt("MaNCC"));
                ncc.setTenNCC(rs.getString("TenNCC"));
                ncc.setDiaChi(rs.getString("DiaChi"));
                ncc.setSoDienThoai(rs.getString("SoDienThoai"));
                ncc.setEmail(rs.getString("Email"));

                list.add(ncc);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public List<Object[]> getHangHoaTheoNCC(int maNCC) {

        List<Object[]> list = new ArrayList<>();

        String sql = """
            SELECT
                k.MaVatDung,
                k.TenVatDung,
                k.DonViTinh,
                SUM(ct.SoLuong) AS TongSoLuong,
                ct.DonGiaNhap AS DonGiaNhap
            FROM NhaCungCap ncc
            INNER JOIN PhieuNhap pn
                ON ncc.MaNCC = pn.MaNCC
            INNER JOIN CT_PhieuNhap ct
                ON pn.MaPhieuNhap = ct.MaPhieuNhap
            INNER JOIN Kho k
                ON ct.MaVatDung = k.MaVatDung
            WHERE ncc.MaNCC = ?
            GROUP BY
                k.MaVatDung,
                k.TenVatDung,
                k.DonViTinh
            ORDER BY k.TenVatDung
            """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, maNCC);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Object[] row = {
                        rs.getInt("MaVatDung"),
                        rs.getString("TenVatDung"),
                        rs.getString("DonViTinh"),
                        rs.getInt("TongSoLuong"),
                        rs.getDouble("DonGiaNhap")
                };

                list.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}