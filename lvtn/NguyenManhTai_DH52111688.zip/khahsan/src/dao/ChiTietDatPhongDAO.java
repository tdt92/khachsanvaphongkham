package dao;

import connect.DBConnect;
import model.ChiTietDatPhong;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChiTietDatPhongDAO {

    public List<ChiTietDatPhong>
    getByPhieuDat(int maPhieuDat){

        List<ChiTietDatPhong> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * "
                  + "FROM ChiTietDatPhong "
                  + "WHERE MaPhieuDat=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuDat);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                ChiTietDatPhong ct =
                        new ChiTietDatPhong();

                ct.setMaPhieuDat(
                        rs.getInt("MaPhieuDat"));

                ct.setMaPhong(
                        rs.getInt("MaPhong"));

                Object mkh =
                        rs.getObject("MaKhachHang");

                if(mkh!=null){

                    ct.setMaKhachHang(
                            rs.getInt("MaKhachHang"));
                }

                list.add(ct);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(
            ChiTietDatPhong ct){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "INSERT INTO ChiTietDatPhong "
                  + "(MaPhieuDat,"
                  + "MaPhong,"
                  + "MaKhachHang)"
                  + " VALUES(?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,ct.getMaPhieuDat());
            ps.setInt(2,ct.getMaPhong());

            if(ct.getMaKhachHang()==null){

                ps.setNull(
                        3,
                        Types.INTEGER);

            }else{

                ps.setInt(
                        3,
                        ct.getMaKhachHang());
            }

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(
            int maPhieuDat,
            int maPhong){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "DELETE FROM ChiTietDatPhong "
                  + "WHERE MaPhieuDat=? "
                  + "AND MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuDat);
            ps.setInt(2,maPhong);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public List<ChiTietDatPhong> getAll() {

        List<ChiTietDatPhong> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM ChiTietDatPhong";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()) {

                ChiTietDatPhong ct =
                        new ChiTietDatPhong();

                ct.setMaPhieuDat(
                        rs.getInt("MaPhieuDat"));

                ct.setMaPhong(
                        rs.getInt("MaPhong"));

                ct.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                list.add(ct);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public boolean exists(
            int maPhieuDat,
            int maPhong){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT COUNT(*) "
                  + "FROM ChiTietDatPhong "
                  + "WHERE MaPhieuDat=? "
                  + "AND MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuDat);
            ps.setInt(2,maPhong);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                return rs.getInt(1) > 0;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
}