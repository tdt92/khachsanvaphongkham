package dao;

import connect.DBConnect;
import model.PhieuThuePhong;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PhieuThuePhongDAO {

    public List<PhieuThuePhong> getAll(){

        List<PhieuThuePhong> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhieuThuePhong";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                PhieuThuePhong pt =
                        new PhieuThuePhong();

                pt.setMaPhieuThue(
                        rs.getInt("MaPhieuThue"));

                pt.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                pt.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                pt.setNgayNhanPhong(
                        rs.getTimestamp("NgayNhanPhong"));

                pt.setNgayTraPhongDuKien(
                        rs.getDate("NgayTraPhongDuKien"));

                pt.setTrangThai(
                        rs.getString("TrangThai"));

                list.add(pt);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(
            PhieuThuePhong pt){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "INSERT INTO "
                  + "PhieuThuePhong("
                  + "MaKhachHang,"
                  + "MaNhanVien,"
                  + "NgayNhanPhong,"
                  + "NgayTraPhongDuKien,"
                  + "TrangThai)"
                  + " VALUES(?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,pt.getMaKhachHang());
            ps.setInt(2,pt.getMaNhanVien());
            ps.setTimestamp(3,pt.getNgayNhanPhong());
            ps.setDate(4,pt.getNgayTraPhongDuKien());
            ps.setString(5,pt.getTrangThai());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(
            PhieuThuePhong pt){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "UPDATE PhieuThuePhong SET "
                  + "TrangThai=? "
                  + "WHERE MaPhieuThue=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1,pt.getTrangThai());
            ps.setInt(2,pt.getMaPhieuThue());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int ma){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "DELETE FROM "
                  + "PhieuThuePhong "
                  + "WHERE MaPhieuThue=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,ma);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    
    public PhieuThuePhong getLastInserted() {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhieuThuePhong "
                  + "ORDER BY MaPhieuThue DESC "
                  + "LIMIT 1";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                PhieuThuePhong pt =
                        new PhieuThuePhong();

                pt.setMaPhieuThue(
                        rs.getInt("MaPhieuThue"));

                pt.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                pt.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                pt.setNgayNhanPhong(
                        rs.getTimestamp("NgayNhanPhong"));

                pt.setNgayTraPhongDuKien(
                        rs.getDate("NgayTraPhongDuKien"));

                pt.setTrangThai(
                        rs.getString("TrangThai"));

                return pt;
            }

        } catch(Exception e){

            e.printStackTrace();
        }

        return null;
    }
    public List<PhieuThuePhong> getDangThueSapHetHan() {

        List<PhieuThuePhong> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhieuThuePhong "
                  + "WHERE TrangThai='DANG_THUE' "
                  + "ORDER BY NgayTraPhongDuKien ASC";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                PhieuThuePhong pt =
                        new PhieuThuePhong();

                pt.setMaPhieuThue(
                        rs.getInt("MaPhieuThue"));

                pt.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                pt.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                pt.setNgayNhanPhong(
                        rs.getTimestamp("NgayNhanPhong"));

                pt.setNgayTraPhongDuKien(
                        rs.getDate("NgayTraPhongDuKien"));

                pt.setTrangThai(
                        rs.getString("TrangThai"));

                list.add(pt);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public List<PhieuThuePhong> getPhongDenHanTra() {

        List<PhieuThuePhong> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                "SELECT * FROM PhieuThuePhong " +
                "WHERE TrangThai='DangThue' " +
                "AND NgayTraPhongDuKien<=CURDATE()";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                PhieuThuePhong p =
                        new PhieuThuePhong();

                p.setMaPhieuThue(
                        rs.getInt("MaPhieuThue"));

                p.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                p.setMaNhanVien(
                        rs.getInt("MaNhanVien"));

                p.setNgayNhanPhong(
                        rs.getTimestamp("NgayNhanPhong"));

                p.setNgayTraPhongDuKien(
                        rs.getDate("NgayTraPhongDuKien"));

                p.setTrangThai(
                        rs.getString("TrangThai"));

                list.add(p);
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return list;
    }
    public double tinhTienPhong(int maPhieuThue){

        double tong=0;

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql=
            "SELECT ct.DonGia," +
            "pt.NgayNhanPhong " +
            "FROM ChiTietThuePhong ct " +
            "JOIN PhieuThuePhong pt " +
            "ON ct.MaPhieuThue=pt.MaPhieuThue " +
            "WHERE ct.MaPhieuThue=?";

            PreparedStatement ps=
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuThue);

            ResultSet rs=
                    ps.executeQuery();

            while(rs.next()){

                double donGia=
                        rs.getDouble("DonGia");

                Timestamp ngayNhan=
                        rs.getTimestamp("NgayNhanPhong");

                long millis=
                        System.currentTimeMillis()
                      - ngayNhan.getTime();

                long soNgay=
                        millis/(1000*60*60*24);

                if(soNgay<=0)
                    soNgay=1;

                tong+=soNgay*donGia;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return tong;
    }
    public int insertAndGetId(PhieuThuePhong pt){

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "INSERT INTO PhieuThuePhong("
                  + "MaKhachHang,"
                  + "MaNhanVien,"
                  + "NgayNhanPhong,"
                  + "NgayTraPhongDuKien,"
                  + "TrangThai)"
                  + " VALUES(?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS);

            ps.setInt(1, pt.getMaKhachHang());
            ps.setInt(2, pt.getMaNhanVien());
            ps.setTimestamp(3, pt.getNgayNhanPhong());
            ps.setDate(4, pt.getNgayTraPhongDuKien());
            ps.setString(5, pt.getTrangThai());

            int kq = ps.executeUpdate();

            if(kq > 0){

                ResultSet rs =
                        ps.getGeneratedKeys();

                if(rs.next()){

                    return rs.getInt(1);
                }
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return -1;
    }
    public boolean updateNgayTra(int maPhieuThue,
            Date ngayTra){

try{

Connection con =
DBConnect.getConnection();

String sql =
"UPDATE PhieuThuePhong "
+ "SET NgayTraPhongDuKien=? "
+ "WHERE MaPhieuThue=?";

PreparedStatement ps =
con.prepareStatement(sql);

ps.setDate(1, ngayTra);

ps.setInt(2, maPhieuThue);

return ps.executeUpdate()>0;

}catch(Exception e){

e.printStackTrace();
}

return false;
}
    public PhieuThuePhong getById(int maPhieuThue) {

        String sql =
                "SELECT * FROM PhieuThuePhong WHERE MaPhieuThue=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, maPhieuThue);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                PhieuThuePhong pt =
                        new PhieuThuePhong();

                pt.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                pt.setMaKhachHang(rs.getInt("MaKhachHang"));
                pt.setMaNhanVien(rs.getInt("MaNhanVien"));
                pt.setNgayNhanPhong(rs.getTimestamp("NgayNhanPhong"));
                pt.setNgayTraPhongDuKien(rs.getDate("NgayTraPhongDuKien"));
                pt.setTrangThai(rs.getString("TrangThai"));

                return pt;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    public boolean exists(
            int maPhieuThue,
            int maPhong) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT COUNT(*) "
                  + "FROM ChiTietThuePhong "
                  + "WHERE MaPhieuThue=? "
                  + "AND MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhieuThue);
            ps.setInt(2, maPhong);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}