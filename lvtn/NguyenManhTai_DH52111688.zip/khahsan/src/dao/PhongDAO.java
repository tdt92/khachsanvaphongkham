package dao;

import connect.DBConnect;
import model.Phong;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PhongDAO {

     
    public List<Phong> getAll() {

        List<Phong> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM Phong";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Phong p = new Phong();

                p.setMaPhong(rs.getInt("MaPhong"));
                p.setSoPhong(rs.getString("SoPhong"));
                p.setMaLoaiPhong(rs.getInt("MaLoaiPhong"));
                p.setTang(rs.getInt("Tang"));
                p.setTrangThai(rs.getString("TrangThai"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

  
    public boolean insert(Phong p) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "INSERT INTO Phong(SoPhong, MaLoaiPhong, Tang, TrangThai) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, p.getSoPhong());
            ps.setInt(2, p.getMaLoaiPhong());
            ps.setInt(3, p.getTang());
            ps.setString(4, p.getTrangThai());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

   
    public boolean update(Phong p) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "UPDATE Phong SET SoPhong=?, MaLoaiPhong=?, Tang=?, TrangThai=? WHERE MaPhong=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, p.getSoPhong());
            ps.setInt(2, p.getMaLoaiPhong());
            ps.setInt(3, p.getTang());
            ps.setString(4, p.getTrangThai());
            ps.setInt(5, p.getMaPhong());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean isExistSoPhong(String soPhong) {
        String sql = "SELECT COUNT(*) FROM Phong WHERE SoPhong = ?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, soPhong);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean isExistSoPhong(String soPhong, int maPhong) {
        String sql = "SELECT COUNT(*) FROM Phong WHERE SoPhong = ? AND MaPhong <> ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, soPhong);
            ps.setInt(2, maPhong);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean hasPhongByLoaiPhong(int maLoaiPhong) {
        String sql = "SELECT COUNT(*) FROM Phong WHERE MaLoaiPhong = ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maLoaiPhong);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean isPhongTrong(int maPhong) {
        String sql = "SELECT TrangThai FROM Phong WHERE MaPhong=?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maPhong);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("TrangThai").equalsIgnoreCase("Trong");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean updateTrangThai(
            int maPhong,
            String trangThai) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "UPDATE Phong "
                  + "SET TrangThai=? "
                  + "WHERE MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, trangThai);
            ps.setInt(2, maPhong);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }
    public boolean delete(int maPhong) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "DELETE FROM Phong WHERE MaPhong=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maPhong);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}