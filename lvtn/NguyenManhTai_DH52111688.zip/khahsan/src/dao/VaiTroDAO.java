package dao;

 import connect.DBConnect;
import model.VaiTro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class VaiTroDAO {

    
    public List<VaiTro> getAll() {

        List<VaiTro> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM VaiTro";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                VaiTro vt = new VaiTro();

                vt.setMaVaiTro(rs.getInt("MaVaiTro"));
                vt.setTenVaiTro(rs.getString("TenVaiTro"));

                list.add(vt);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    
    public boolean insert(VaiTro vt) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "INSERT INTO VaiTro(TenVaiTro) VALUES(?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, vt.getTenVaiTro());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

 
    public boolean update(VaiTro vt) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql =
                    "UPDATE VaiTro SET TenVaiTro=? WHERE MaVaiTro=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, vt.getTenVaiTro());
            ps.setInt(2, vt.getMaVaiTro());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public boolean delete(int maVaiTro) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "DELETE FROM VaiTro WHERE MaVaiTro=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maVaiTro);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public VaiTro findById(int maVaiTro) {

        VaiTro vt = null;

        try {

            Connection conn = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM VaiTro WHERE MaVaiTro=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maVaiTro);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                vt = new VaiTro();

                vt.setMaVaiTro(rs.getInt("MaVaiTro"));
                vt.setTenVaiTro(rs.getString("TenVaiTro"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return vt;
    }
}