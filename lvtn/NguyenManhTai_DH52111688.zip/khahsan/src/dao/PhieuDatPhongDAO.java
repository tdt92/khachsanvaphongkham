package dao;

import connect.DBConnect;
import model.DatPhongDTO;
import model.PhieuDatPhong;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PhieuDatPhongDAO {

    public List<PhieuDatPhong> getAll() {

        List<PhieuDatPhong> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM PhieuDatPhong";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                PhieuDatPhong pd =
                        new PhieuDatPhong();

                pd.setMaPhieuDat(
                        rs.getInt("MaPhieuDat"));

                pd.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                pd.setNgayDat(
                        rs.getTimestamp("NgayDat"));

                pd.setNgayNhanPhong(
                        rs.getDate("NgayNhanPhong"));

                pd.setNgayTraPhong(
                        rs.getDate("NgayTraPhong"));

                pd.setTienCoc(
                        rs.getDouble("TienCoc"));

                pd.setTrangThai(
                        rs.getString("TrangThai"));
                pd.setGhiChu(rs.getString("GhiChu"));
                Object obj = rs.getObject("MaPhieuThue");

                if(obj != null){
                    pd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                }
                Object nv = rs.getObject("MaNhanVien");

                if(nv != null){
                    pd.setMaNhanVien(rs.getInt("MaNhanVien"));
                }
                list.add(pd);
            }

        } catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(PhieuDatPhong pd){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
            		"INSERT INTO PhieuDatPhong("
            		+ "MaKhachHang,"
            		+ "NgayDat,"
            		+ "NgayNhanPhong,"
            		+ "NgayTraPhong,"
            		+ "TienCoc,"
            		+ "TrangThai,"
            		+ "GhiChu,"
            		+ "MaNhanVien)"
            		+ " VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);
            ps.setInt(1,pd.getMaKhachHang());
            ps.setTimestamp(2,pd.getNgayDat());
            ps.setDate(3,pd.getNgayNhanPhong());
            ps.setDate(4,pd.getNgayTraPhong());
            ps.setDouble(5,pd.getTienCoc());
            ps.setString(6,pd.getTrangThai());
            ps.setString(7,pd.getGhiChu());

            if(pd.getMaNhanVien()==null){
                ps.setNull(8, Types.INTEGER);
            }else{
                ps.setInt(8,pd.getMaNhanVien());
            }
            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(PhieuDatPhong pd){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "UPDATE PhieuDatPhong SET "
                  + "MaKhachHang=?,"
                  + "NgayDat=?,"
                  + "NgayNhanPhong=?,"
                  + "NgayTraPhong=?,"
                  + "TienCoc=?,"
                  + "TrangThai=?,"
                  + "GhiChu=?,"
                  + "MaPhieuThue=?,"
                  + "MaNhanVien=? "
                  + "WHERE MaPhieuDat=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,pd.getMaKhachHang());
            ps.setTimestamp(2,pd.getNgayDat());
            ps.setDate(3,pd.getNgayNhanPhong());
            ps.setDate(4,pd.getNgayTraPhong());
            ps.setDouble(5,pd.getTienCoc());
            ps.setString(6,pd.getTrangThai());

 
            ps.setString(7,pd.getGhiChu());

            if(pd.getMaPhieuThue()==null)
                ps.setNull(8, Types.INTEGER);
            else
                ps.setInt(8,pd.getMaPhieuThue());

            if(pd.getMaNhanVien()==null)
                ps.setNull(9, Types.INTEGER);
            else
                ps.setInt(9,pd.getMaNhanVien());

            ps.setInt(10,pd.getMaPhieuDat());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public boolean updateMaPhieuThue(int maPhieuDat, int maPhieuThue) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "UPDATE PhieuDatPhong " +
                    "SET MaPhieuThue=? " +
                    "WHERE MaPhieuDat=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhieuThue);
            ps.setInt(2, maPhieuDat);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }
    public boolean delete(int maPhieuDat){

        try{

            Connection con = DBConnect.getConnection();

            con.setAutoCommit(false);

            // Xóa chi tiết trước
            String sql1 =
                    "DELETE FROM ChiTietDatPhong WHERE MaPhieuDat=?";

            PreparedStatement ps1 =
                    con.prepareStatement(sql1);

            ps1.setInt(1, maPhieuDat);

            ps1.executeUpdate();

            // Xóa phiếu đặt
            String sql2 =
                    "DELETE FROM PhieuDatPhong WHERE MaPhieuDat=?";

            PreparedStatement ps2 =
                    con.prepareStatement(sql2);

            ps2.setInt(1, maPhieuDat);

            int kq = ps2.executeUpdate();

            con.commit();

            return kq > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
	/*
	 * public boolean delete(int ma){
	 * 
	 * try{
	 * 
	 * Connection con = DBConnect.getConnection();
	 * 
	 * String sql = "DELETE FROM PhieuDatPhong " + "WHERE MaPhieuDat=?";
	 * 
	 * PreparedStatement ps = con.prepareStatement(sql);
	 * 
	 * ps.setInt(1,ma);
	 * 
	 * return ps.executeUpdate()>0;
	 * 
	 * }catch(Exception e){ e.printStackTrace(); }
	 * 
	 * return false; }
	 */
    public PhieuDatPhong findById(
            int maPhieuDat) {

        try {

            Connection conn =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhieuDatPhong WHERE MaPhieuDat=?";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(1, maPhieuDat);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                PhieuDatPhong pd =
                        new PhieuDatPhong();

                pd.setMaPhieuDat(
                        rs.getInt("MaPhieuDat"));

                pd.setMaKhachHang(
                        rs.getInt("MaKhachHang"));

                pd.setNgayNhanPhong(
                        rs.getDate("NgayNhanPhong"));

                pd.setNgayTraPhong(
                        rs.getDate("NgayTraPhong"));

                pd.setTienCoc(
                        rs.getDouble("TienCoc"));

                pd.setTrangThai(
                        rs.getString("TrangThai"));
                pd.setGhiChu(rs.getString("GhiChu"));
                Object obj = rs.getObject("MaPhieuThue");

                if(obj != null){
                    pd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                }
                Object nv = rs.getObject("MaNhanVien");

                if(nv != null){
                    pd.setMaNhanVien(rs.getInt("MaNhanVien"));
                }
                return pd;
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return null;
    }
    public List<DatPhongDTO> getDanhSachDatPhong() {

        List<DatPhongDTO> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT pd.MaPhieuDat, " +
                    "kh.HoTen AS TenKhachHang, " +
                    "kh.CCCD, " +
                    "pd.NgayNhanPhong, " +
                    "pd.NgayTraPhong, " +
                    "COUNT(ct.MaPhong) AS SoPhong, " +
                    "pd.TienCoc, " +
                    "nv.HoTen AS TenNhanVien " +
                    "FROM PhieuDatPhong pd " +
                    "JOIN KhachHang kh " +
                    "ON pd.MaKhachHang = kh.MaKhachHang " +
                    "LEFT JOIN ChiTietDatPhong ct " +
                    "ON pd.MaPhieuDat = ct.MaPhieuDat " +
                    "LEFT JOIN NhanVien nv " +
                    "ON pd.MaNhanVien = nv.MaNhanVien " +
                    "WHERE pd.TrangThai = 'DA_DAT' " +
                    "GROUP BY " +
                    "pd.MaPhieuDat, " +
                    "kh.HoTen, " +
                    "kh.CCCD, " +
                    "pd.NgayNhanPhong, " +
                    "pd.NgayTraPhong, " +
                    "pd.TienCoc, " +
                    "nv.HoTen";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                DatPhongDTO dto = new DatPhongDTO();

                dto.setMaPhieuDat(rs.getInt("MaPhieuDat"));
                dto.setTenKhachHang(rs.getString("TenKhachHang"));
                dto.setCccd(rs.getString("CCCD"));
                dto.setNgayNhan(rs.getDate("NgayNhanPhong"));
                dto.setNgayTra(rs.getDate("NgayTraPhong"));
                dto.setSoPhong(rs.getInt("SoPhong"));
                dto.setTienCoc(rs.getDouble("TienCoc"));
                dto.setTenNhanVien(rs.getString("TenNhanVien"));

                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public int insertAndGetId(
            PhieuDatPhong pd) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
            	    "INSERT INTO PhieuDatPhong("
            	    + "MaKhachHang,"
            	    + "NgayDat,"
            	    + "NgayNhanPhong,"
            	    + "NgayTraPhong,"
            	    + "TienCoc,"
            	    + "TrangThai,"
            	    + "GhiChu,"
            	    + "MaNhanVien)"
            	    + "VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS);

            ps.setInt(1,pd.getMaKhachHang());
            ps.setTimestamp(2,pd.getNgayDat());
            ps.setDate(3,pd.getNgayNhanPhong());
            ps.setDate(4,pd.getNgayTraPhong());
            ps.setDouble(5,pd.getTienCoc());
            ps.setString(6,pd.getTrangThai());
            ps.setString(7, pd.getGhiChu());
            if(pd.getMaNhanVien()==null){
                ps.setNull(8, Types.INTEGER);
            }else{
                ps.setInt(8,pd.getMaNhanVien());
            }            int rows = ps.executeUpdate();

            if(rows > 0){

                ResultSet rs =
                        ps.getGeneratedKeys();

                if(rs.next()){

                    return rs.getInt(1);
                }
            }

        } catch(Exception e){

            e.printStackTrace();
        }

        return -1;
    }
}