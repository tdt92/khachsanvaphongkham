package dao;

import connect.DBConnect;
import model.DichVu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class DichVuDAO {

    
    public List<DichVu> getAll() {

        List<DichVu> list = new ArrayList<>();

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "SELECT * FROM DichVu";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                DichVu dv = new DichVu();

                dv.setMaDichVu(rs.getInt("MaDichVu"));
                dv.setTenDichVu(rs.getString("TenDichVu"));
                dv.setDonGia(rs.getDouble("DonGia"));
                 dv.setDonViTinh(rs.getString("DonViTinh"));
                dv.setGhiChu(rs.getString("GhiChu"));
                dv.setMaVatDung(rs.getObject("MaVatDung") == null
                        ? null
                        : rs.getInt("MaVatDung"));
                list.add(dv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public DichVu findById(int maDV) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM DichVu WHERE MaDichVu=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maDV);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                DichVu dv = new DichVu();

                dv.setMaDichVu(
                        rs.getInt("MaDichVu"));

                dv.setTenDichVu(
                        rs.getString("TenDichVu"));

                dv.setDonGia(
                        rs.getDouble("DonGia"));

                dv.setDonViTinh(
                        rs.getString("DonViTinh"));

                dv.setGhiChu(
                        rs.getString("GhiChu"));
                dv.setMaVatDung(
                        rs.getObject("MaVatDung")==null
                        ? null
                        : rs.getInt("MaVatDung"));
                return dv;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
     
    public boolean insert(DichVu dv) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql =
            		"INSERT INTO DichVu(TenDichVu, DonGia, DonViTinh, GhiChu, MaVatDung) VALUES(?,?,?,?,?)";

            		PreparedStatement ps = conn.prepareStatement(sql);

            		ps.setString(1, dv.getTenDichVu());
            		ps.setDouble(2, dv.getDonGia());
            		ps.setString(3, dv.getDonViTinh());
            		ps.setString(4, dv.getGhiChu());

            		if(dv.getMaVatDung()==null)
            		    ps.setNull(5, java.sql.Types.INTEGER);
            		else
            		    ps.setInt(5, dv.getMaVatDung());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

   
    public boolean update(DichVu dv) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "UPDATE DichVu SET TenDichVu=?, DonGia=?,   DonViTinh=?, GhiChu=?, MaVatDung=? WHERE MaDichVu=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1,dv.getTenDichVu());
            ps.setDouble(2,dv.getDonGia());
            ps.setString(3,dv.getDonViTinh());
            ps.setString(4,dv.getGhiChu());

            if(dv.getMaVatDung()==null)
                ps.setNull(5,Types.INTEGER);
            else
                ps.setInt(5,dv.getMaVatDung());

            ps.setInt(6,dv.getMaDichVu());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
 
    public boolean delete(int maDV) {

        try {

            Connection conn = DBConnect.getConnection();

            String sql = "DELETE FROM DichVu WHERE MaDichVu=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, maDV);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}