package dao;

import connect.DBConnect;
import model.ChiTietThuePhong;
import model.PhongDangThueDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChiTietThuePhongDAO {

    public List<ChiTietThuePhong>
    getByPhieuThue(int maPhieuThue){

        List<ChiTietThuePhong> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * "
                  + "FROM ChiTietThuePhong "
                  + "WHERE MaPhieuThue=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuThue);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                ChiTietThuePhong ct =
                        new ChiTietThuePhong();

                ct.setMaPhieuThue(
                        rs.getInt("MaPhieuThue"));

                ct.setMaPhong(
                        rs.getInt("MaPhong"));

                ct.setDonGia(
                        rs.getDouble("DonGia"));

                Object mkh =
                        rs.getObject("MaKhachHang");

                if(mkh!=null){

                    ct.setMaKhachHang(
                            rs.getInt("MaKhachHang"));
                }

                list.add(ct);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

	/*
	 * public boolean dangThuePhong(int maKhachHang) {
	 * 
	 * String sql = "SELECT COUNT(*) " + "FROM PhieuThuePhong pt " +
	 * "WHERE pt.MaKhachHang = ? " + "AND pt.TrangThai = 'DANG_THUE'";
	 * 
	 * try (Connection con = DBConnect.getConnection(); PreparedStatement ps =
	 * con.prepareStatement(sql)) {
	 * 
	 * ps.setInt(1, maKhachHang);
	 * 
	 * ResultSet rs = ps.executeQuery();
	 * 
	 * if (rs.next()) { return rs.getInt(1) > 0; }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return false; }
	 */
    public boolean dangThuePhong(int maKhachHang) {
        String sql =
            "SELECT 1 " +
            "FROM ChiTietThuePhong ct " +
            "JOIN PhieuThuePhong pt " +
            "ON ct.MaPhieuThue = pt.MaPhieuThue " +
            "WHERE ct.MaKhachHang = ? " +
            "AND pt.TrangThai = 'DANG_THUE' " +
            "LIMIT 1";

        try (
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, maKhachHang);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean insert(
            ChiTietThuePhong ct){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "INSERT INTO "
                  + "ChiTietThuePhong("
                  + "MaPhieuThue,"
                  + "MaPhong,"
                  + "MaKhachHang,"
                  + "DonGia)"
                  + " VALUES(?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,ct.getMaPhieuThue());
            ps.setInt(2,ct.getMaPhong());

            if(ct.getMaKhachHang()==null){

                ps.setNull(3,Types.INTEGER);

            }else{

                ps.setInt(
                        3,
                        ct.getMaKhachHang());
            }

            ps.setDouble(
                    4,
                    ct.getDonGia());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public List<PhongDangThueDTO> getPhongDangThue() {

        List<PhongDangThueDTO> list =
                new ArrayList<>();

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT pt.MaPhieuThue, " +
                    "p.MaPhong, p.SoPhong, " +
                    "kh.HoTen, pt.TrangThai " +
                    "FROM PhieuThuePhong pt " +
                    "JOIN ChiTietThuePhong ct " +
                    "ON pt.MaPhieuThue = ct.MaPhieuThue " +
                    "JOIN Phong p " +
                    "ON ct.MaPhong = p.MaPhong " +
                    "LEFT JOIN KhachHang kh " +
                    "ON pt.MaKhachHang = kh.MaKhachHang " +
                    "WHERE pt.TrangThai='DANG_THUE'";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()) {

                PhongDangThueDTO dto =
                        new PhongDangThueDTO();

                dto.setMaPhieuThue(
                        rs.getInt(1));

                dto.setMaPhong(
                        rs.getInt(2));

                dto.setSoPhong(
                        rs.getString(3));

                dto.setTenKhachHang(
                        rs.getString(4));

                dto.setTrangThai(
                        rs.getString(5));

                list.add(dto);
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return list;
    }
    public boolean update(ChiTietThuePhong ct) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "UPDATE ChiTietThuePhong "
                  + "SET MaPhong=?, "
                  + "MaKhachHang=?, "
                  + "DonGia=? "
                  + "WHERE MaPhieuThue=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, ct.getMaPhong());

            if (ct.getMaKhachHang() == null) {
                ps.setNull(2, Types.INTEGER);
            } else {
                ps.setInt(2, ct.getMaKhachHang());
            }

            ps.setDouble(3, ct.getDonGia());

            ps.setInt(4, ct.getMaPhieuThue());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean exists(
            int maPhieuThue,
            int maPhong) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                "SELECT COUNT(*) " +
                "FROM ChiTietThuePhong " +
                "WHERE MaPhieuThue=? " +
                "AND MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhieuThue);
            ps.setInt(2, maPhong);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                return rs.getInt(1) > 0;
            }

        } catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
    public boolean daNhanPhong(int maPhong) {

        try {

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT COUNT(*) " +
                    "FROM ChiTietThuePhong " +
                    "WHERE MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhong);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                return rs.getInt(1) > 0;
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public boolean delete(
            int maPhieuThue,
            int maPhong){

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "DELETE FROM "
                  + "ChiTietThuePhong "
                  + "WHERE MaPhieuThue=? "
                  + "AND MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maPhieuThue);
            ps.setInt(2,maPhong);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
}