package dao;

import connect.DBConnect;
import model.TaiKhoan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDAO {

     
    public TaiKhoan dangNhap(String tenDangNhap, String matKhau) {

        TaiKhoan tk = null;

        try {

            Connection con = DBConnect.getConnection();

			/*
			 * String sql = "SELECT * FROM TaiKhoan " + "WHERE TenDangNhap=? " +
			 * "AND MatKhau=? " + "AND TrangThai=1";
			 */
            String sql =
            		"SELECT tk.*, nv.MaNhanVien " +
            		"FROM TaiKhoan tk " +
            		"LEFT JOIN NhanVien nv ON tk.MaTaiKhoan = nv.MaTaiKhoan " +
            		"WHERE tk.TenDangNhap=? " +
            		"AND tk.MatKhau=? " +
            		"AND tk.TrangThai=1";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, tenDangNhap);
            ps.setString(2, matKhau);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                tk = new TaiKhoan();

                tk.setMaTaiKhoan(rs.getInt("MaTaiKhoan"));
                tk.setTenDangNhap(rs.getString("TenDangNhap"));
                tk.setMatKhau(rs.getString("MatKhau"));
                tk.setMaVaiTro(rs.getInt("MaVaiTro"));
                tk.setTrangThai(rs.getBoolean("TrangThai"));

                tk.setMaNhanVien(rs.getInt("MaNhanVien"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return tk;
    }

     
    public List<TaiKhoan> getAll() {

        List<TaiKhoan> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM TaiKhoan";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                TaiKhoan tk = new TaiKhoan();

                tk.setMaTaiKhoan(rs.getInt("MaTaiKhoan"));
                tk.setTenDangNhap(rs.getString("TenDangNhap"));
                tk.setMatKhau(rs.getString("MatKhau"));
                tk.setMaVaiTro(rs.getInt("MaVaiTro"));
                tk.setTrangThai(rs.getBoolean("TrangThai"));

                list.add(tk);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

   
    public boolean insert(TaiKhoan tk) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "INSERT INTO TaiKhoan("
                    + "TenDangNhap,"
                    + "MatKhau,"
                    + "MaVaiTro,"
                    + "TrangThai)"
                    + " VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, tk.getTenDangNhap());
            ps.setString(2, tk.getMatKhau());
            ps.setInt(3, tk.getMaVaiTro());
            ps.setBoolean(4, tk.isTrangThai());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

     
    public boolean update(TaiKhoan tk) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "UPDATE TaiKhoan SET "
                    + "TenDangNhap=?, "
                    + "MatKhau=?, "
                    + "MaVaiTro=?, "
                    + "TrangThai=? "
                    + "WHERE MaTaiKhoan=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, tk.getTenDangNhap());
            ps.setString(2, tk.getMatKhau());
            ps.setInt(3, tk.getMaVaiTro());
            ps.setBoolean(4, tk.isTrangThai());
            ps.setInt(5, tk.getMaTaiKhoan());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

   
    public boolean delete(int maTaiKhoan) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "DELETE FROM TaiKhoan "
                    + "WHERE MaTaiKhoan=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, maTaiKhoan);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public TaiKhoan getLast(){

        TaiKhoan tk = null;

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM TaiKhoan "
                  + "ORDER BY MaTaiKhoan DESC "
                  + "LIMIT 1";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                tk = new TaiKhoan();

                tk.setMaTaiKhoan(
                        rs.getInt("MaTaiKhoan"));

                tk.setTenDangNhap(
                        rs.getString("TenDangNhap"));

                tk.setMatKhau(
                        rs.getString("MatKhau"));

                tk.setMaVaiTro(
                        rs.getInt("MaVaiTro"));

                tk.setTrangThai(
                        rs.getBoolean("TrangThai"));
            }

        }catch (Exception e){

            e.printStackTrace();
        }

        return tk;
    }
    public TaiKhoan findById(int maTaiKhoan){

        TaiKhoan tk = null;

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM TaiKhoan "
                  + "WHERE MaTaiKhoan=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maTaiKhoan);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                tk = new TaiKhoan();

                tk.setMaTaiKhoan(
                        rs.getInt("MaTaiKhoan"));

                tk.setTenDangNhap(
                        rs.getString("TenDangNhap"));

                tk.setMatKhau(
                        rs.getString("MatKhau"));

                tk.setMaVaiTro(
                        rs.getInt("MaVaiTro"));

                tk.setTrangThai(
                        rs.getBoolean("TrangThai"));
            }

        }catch (Exception e){

            e.printStackTrace();
        }

        return tk;
    }
}