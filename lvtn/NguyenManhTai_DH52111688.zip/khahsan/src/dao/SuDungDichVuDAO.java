package dao;

import connect.DBConnect;
import model.SuDungDichVu;

import java.sql.*;
import java.util.ArrayList;

public class SuDungDichVuDAO {

    public ArrayList<SuDungDichVu> getAll() {

        ArrayList<SuDungDichVu> ds = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM SuDungDichVu";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                SuDungDichVu sd = new SuDungDichVu();

                sd.setMaSuDung(rs.getInt("MaSuDung"));
                sd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                sd.setMaPhong(rs.getInt("MaPhong"));
                sd.setMaDichVu(rs.getInt("MaDichVu"));
                sd.setSoLuong(rs.getInt("SoLuong"));
                sd.setThanhTien(rs.getDouble("ThanhTien"));
                sd.setNgaySuDung(rs.getTimestamp("NgaySuDung"));
                sd.setMaNhanVien(rs.getInt("MaNhanVien"));
                ds.add(sd);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return ds;
    }

    public boolean insert(SuDungDichVu sd){

        try{

            Connection con = DBConnect.getConnection();

            String sql =
            		"INSERT INTO SuDungDichVu(MaPhieuThue,MaPhong,MaDichVu,SoLuong,ThanhTien,NgaySuDung,MaNhanVien) "
            		+ "VALUES(?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1,sd.getMaPhieuThue());
            ps.setInt(2,sd.getMaPhong());
            ps.setInt(3,sd.getMaDichVu());
            ps.setInt(4,sd.getSoLuong());
            ps.setDouble(5,sd.getThanhTien());
            ps.setTimestamp(6,sd.getNgaySuDung());
            ps.setInt(7,sd.getMaNhanVien());

            return ps.executeUpdate()>0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    public boolean update(SuDungDichVu sd){

        try{

            Connection con = DBConnect.getConnection();

            String sql =
                    "UPDATE SuDungDichVu SET MaPhieuThue=?,MaPhong=?,MaDichVu=?,SoLuong=?,ThanhTien=?,NgaySuDung=?,MaNhanVien=? WHERE MaSuDung=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1,sd.getMaPhieuThue());
            ps.setInt(2,sd.getMaPhong());
            ps.setInt(3,sd.getMaDichVu());
            ps.setInt(4,sd.getSoLuong());
            ps.setDouble(5,sd.getThanhTien());
            ps.setTimestamp(6,sd.getNgaySuDung());
            ps.setInt(7,sd.getMaNhanVien());
            ps.setInt(8,sd.getMaSuDung());

            return ps.executeUpdate()>0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int maSuDung){

        try{

            Connection con = DBConnect.getConnection();

            String sql="DELETE FROM SuDungDichVu WHERE MaSuDung=?";

            PreparedStatement ps=con.prepareStatement(sql);

            ps.setInt(1,maSuDung);

            return ps.executeUpdate()>0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    public SuDungDichVu findById(int maSuDung){

        try{

            Connection con=DBConnect.getConnection();

            String sql="SELECT * FROM SuDungDichVu WHERE MaSuDung=?";

            PreparedStatement ps=con.prepareStatement(sql);

            ps.setInt(1,maSuDung);

            ResultSet rs=ps.executeQuery();

            if(rs.next()){

                SuDungDichVu sd=new SuDungDichVu();

                sd.setMaSuDung(rs.getInt("MaSuDung"));
                sd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                sd.setMaPhong(rs.getInt("MaPhong"));
                sd.setMaDichVu(rs.getInt("MaDichVu"));
                sd.setSoLuong(rs.getInt("SoLuong"));
                sd.setThanhTien(rs.getDouble("ThanhTien"));
                sd.setNgaySuDung(rs.getTimestamp("NgaySuDung"));
                sd.setMaNhanVien(rs.getInt("MaNhanVien"));
                return sd;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return null;
    }

    public ArrayList<SuDungDichVu> timTheoPhieuThue(int maPhieu){

        ArrayList<SuDungDichVu> ds=new ArrayList<>();

        try{

            Connection con=DBConnect.getConnection();

            String sql=
                    "SELECT * FROM SuDungDichVu WHERE MaPhieuThue=? ORDER BY NgaySuDung";

            PreparedStatement ps=con.prepareStatement(sql);

            ps.setInt(1,maPhieu);

            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                SuDungDichVu sd=new SuDungDichVu();

                sd.setMaSuDung(rs.getInt("MaSuDung"));
                sd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                sd.setMaPhong(rs.getInt("MaPhong"));
                sd.setMaDichVu(rs.getInt("MaDichVu"));
                sd.setSoLuong(rs.getInt("SoLuong"));
                sd.setThanhTien(rs.getDouble("ThanhTien"));
                sd.setNgaySuDung(rs.getTimestamp("NgaySuDung"));
                sd.setMaNhanVien(rs.getInt("MaNhanVien"));
                ds.add(sd);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return ds;
    }

    public ArrayList<SuDungDichVu> timTheoPhong(int maPhong){

        ArrayList<SuDungDichVu> ds=new ArrayList<>();

        try{

            Connection con=DBConnect.getConnection();

            String sql=
                    "SELECT * FROM SuDungDichVu WHERE MaPhong=?";

            PreparedStatement ps=con.prepareStatement(sql);

            ps.setInt(1,maPhong);

            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                SuDungDichVu sd=new SuDungDichVu();

                sd.setMaSuDung(rs.getInt("MaSuDung"));
                sd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                sd.setMaPhong(rs.getInt("MaPhong"));
                sd.setMaDichVu(rs.getInt("MaDichVu"));
                sd.setSoLuong(rs.getInt("SoLuong"));
                sd.setThanhTien(rs.getDouble("ThanhTien"));
                sd.setNgaySuDung(rs.getTimestamp("NgaySuDung"));
                sd.setMaNhanVien(rs.getInt("MaNhanVien"));
                ds.add(sd);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return ds;
    }
    public double tinhTienTheoPhong(int maPhong){

        try{

            Connection con = DBConnect.getConnection();

            String sql =
            "SELECT IFNULL(SUM(ThanhTien),0) Tong " +
            "FROM SuDungDichVu " +
            "WHERE MaPhong=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhong);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                return rs.getDouble("Tong");
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return 0;
    }
    public ArrayList<SuDungDichVu> getByPhieuThue(int maPhieuThue) {

        ArrayList<SuDungDichVu> ds = new ArrayList<>();

        try {
            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM SuDungDichVu WHERE MaPhieuThue=?";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setInt(1, maPhieuThue);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                SuDungDichVu sd = new SuDungDichVu();

                sd.setMaSuDung(rs.getInt("MaSuDung"));
                sd.setMaPhieuThue(rs.getInt("MaPhieuThue"));
                sd.setMaDichVu(rs.getInt("MaDichVu"));
                sd.setSoLuong(rs.getInt("SoLuong"));
                sd.setThanhTien(rs.getDouble("ThanhTien"));
                sd.setNgaySuDung(rs.getTimestamp("NgaySuDung"));
                sd.setMaNhanVien(rs.getInt("MaNhanVien"));
                ds.add(sd);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }
    public double tinhTienDichVu(int maPhieu){

        try{

            Connection con=DBConnect.getConnection();

            String sql=
                    "SELECT IFNULL(SUM(ThanhTien),0) Tong FROM SuDungDichVu WHERE MaPhieuThue=?";

            PreparedStatement ps=con.prepareStatement(sql);

            ps.setInt(1,maPhieu);

            ResultSet rs=ps.executeQuery();

            if(rs.next()){

                return rs.getDouble("Tong");
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return 0;
    }

}