package dao;

import connect.DBConnect;
import model.PhanCong;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class PhanCongDAO {

     
    public List<PhanCong> getAll() {

        List<PhanCong> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql = "SELECT * FROM PhanCong";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                PhanCong pc = new PhanCong();

                pc.setMaPhanCong(rs.getInt("MaPhanCong"));
                pc.setMaNhanVien(rs.getInt("MaNhanVien"));
                pc.setMaPhong(rs.getInt("MaPhong"));
                pc.setTenVaiTro(rs.getString("TenVaiTro"));
                pc.setNgayPhanCong(rs.getDate("NgayPhanCong"));
                pc.setGioBatDau(rs.getTime("GioBatDau"));
                pc.setGioKetThuc(rs.getTime("GioKetThuc"));
                pc.setGhiChu(rs.getString("GhiChu"));

                list.add(pc);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

     
    public boolean insert(PhanCong pc) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "INSERT INTO PhanCong "
                    + "(MaNhanVien, MaPhong, TenVaiTro, "
                    + "NgayPhanCong, GioBatDau, GioKetThuc, GhiChu) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, pc.getMaNhanVien());
            ps.setInt(2, pc.getMaPhong());
            ps.setString(3, pc.getTenVaiTro());
            ps.setDate(4, pc.getNgayPhanCong());
            ps.setTime(5, pc.getGioBatDau());
            ps.setTime(6, pc.getGioKetThuc());
            ps.setString(7, pc.getGhiChu());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

  
    public boolean update(PhanCong pc) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "UPDATE PhanCong SET "
                    + "MaNhanVien=?, "
                    + "MaPhong=?, "
                    + "TenVaiTro=?, "
                    + "NgayPhanCong=?, "
                    + "GioBatDau=?, "
                    + "GioKetThuc=?, "
                    + "GhiChu=? "
                    + "WHERE MaPhanCong=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, pc.getMaNhanVien());
            ps.setInt(2, pc.getMaPhong());
            ps.setString(3, pc.getTenVaiTro());
            ps.setDate(4, pc.getNgayPhanCong());
            ps.setTime(5, pc.getGioBatDau());
            ps.setTime(6, pc.getGioKetThuc());
            ps.setString(7, pc.getGhiChu());

            ps.setInt(8, pc.getMaPhanCong());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

     
    public boolean delete(int maPhanCong) {

        try {

            Connection con = DBConnect.getConnection();

            String sql = "DELETE FROM PhanCong "
                    + "WHERE MaPhanCong=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, maPhanCong);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean isTrungVaiTro(
            int maNhanVien,
            String vaiTro,
            Date ngay,
            Time bd,
            Time kt,
            int excludeMaPC) {

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhanCong " +
                    "WHERE TenVaiTro=? " +
                    "AND NgayPhanCong=? " +
                    "AND MaNhanVien<>? " +
                    "AND MaPhanCong<>?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, vaiTro);
            ps.setDate(2, ngay);
            ps.setInt(3, maNhanVien);
            ps.setInt(4, excludeMaPC);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                Time bdDB = rs.getTime("GioBatDau");
                Time ktDB = rs.getTime("GioKetThuc");

                if(bd.before(ktDB) && kt.after(bdDB)){
                    return true;
                }
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public List<PhanCong> search(String keyword) {

        List<PhanCong> list = new ArrayList<>();

        try {

            Connection con = DBConnect.getConnection();

            String sql =
                    "SELECT pc.* " +
                    "FROM PhanCong pc " +
                    "JOIN NhanVien nv ON pc.MaNhanVien = nv.MaNhanVien " +
                    "WHERE nv.HoTen LIKE ? " +
                    "OR pc.TenVaiTro LIKE ? " +
                    "OR DATE_FORMAT(pc.NgayPhanCong,'%d/%m/%Y') LIKE ? " +
                    "OR DATE_FORMAT(pc.NgayPhanCong,'%Y-%m-%d') LIKE ?";

            PreparedStatement ps = con.prepareStatement(sql);

            String key = "%" + keyword + "%";

            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);
            ps.setString(4, key);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                PhanCong pc = new PhanCong();

                pc.setMaPhanCong(rs.getInt("MaPhanCong"));
                pc.setMaNhanVien(rs.getInt("MaNhanVien"));
                pc.setMaPhong(rs.getInt("MaPhong"));
                pc.setTenVaiTro(rs.getString("TenVaiTro"));
                pc.setNgayPhanCong(rs.getDate("NgayPhanCong"));
                pc.setGioBatDau(rs.getTime("GioBatDau"));
                pc.setGioKetThuc(rs.getTime("GioKetThuc"));
                pc.setGhiChu(rs.getString("GhiChu"));

                list.add(pc);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public boolean isTrungLich(int maNV,
            java.sql.Date ngay,
            java.sql.Time bd,
            java.sql.Time kt,
            int excludeMaPC) {

try {

Connection con = DBConnect.getConnection();

String sql =
 "SELECT * FROM PhanCong " +
 "WHERE MaNhanVien=? " +
 "AND NgayPhanCong=? " +
 "AND MaPhanCong<>?";

PreparedStatement ps = con.prepareStatement(sql);

ps.setInt(1, maNV);
ps.setDate(2, ngay);
ps.setInt(3, excludeMaPC);

ResultSet rs = ps.executeQuery();

while (rs.next()) {

Time bdDB = rs.getTime("GioBatDau");
Time ktDB = rs.getTime("GioKetThuc");

if (bd.before(ktDB) && kt.after(bdDB)) {
 return true;
}
}

} catch (Exception e) {
e.printStackTrace();
}

return false;
}
    public List<PhanCong> getByNhanVien(int maNhanVien){

        List<PhanCong> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnect.getConnection();

            String sql =
                    "SELECT * FROM PhanCong "
                  + "WHERE MaNhanVien=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maNhanVien);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                PhanCong pc =
                        new PhanCong();

                pc.setMaPhanCong(
                        rs.getInt("MaPhanCong"));

                pc.setNgayPhanCong(
                        rs.getDate("NgayPhanCong"));

                pc.setGioBatDau(
                        rs.getTime("GioBatDau"));

                pc.setGioKetThuc(
                        rs.getTime("GioKetThuc"));

                pc.setTenVaiTro(
                        rs.getString("TenVaiTro"));

                list.add(pc);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
}