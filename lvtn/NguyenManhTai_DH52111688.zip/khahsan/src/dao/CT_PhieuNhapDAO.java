package dao;

import connect.DBConnect;
import model.CT_PhieuNhap;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CT_PhieuNhapDAO {

   
    public List<CT_PhieuNhap> getAll() {

        List<CT_PhieuNhap> list = new ArrayList<>();

        String sql = "SELECT * FROM CT_PhieuNhap";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                CT_PhieuNhap ct = new CT_PhieuNhap();

                ct.setMaCT(rs.getInt("MaCT"));
                ct.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
                ct.setMaVatDung(rs.getInt("MaVatDung"));
                ct.setSoLuong(rs.getInt("SoLuong"));
                ct.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
                ct.setThanhTien(rs.getDouble("ThanhTien"));

                list.add(ct);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

   
    public boolean insert(CT_PhieuNhap ct) {

        String sql = """
                INSERT INTO CT_PhieuNhap
                (MaPhieuNhap, MaVatDung, SoLuong, DonGiaNhap, ThanhTien)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            double thanhTien =
                    ct.getSoLuong() * ct.getDonGiaNhap();

            ps.setInt(1, ct.getMaPhieuNhap());
            ps.setInt(2, ct.getMaVatDung());
            ps.setInt(3, ct.getSoLuong());
            ps.setDouble(4, ct.getDonGiaNhap());
            ps.setDouble(5, thanhTien);

            boolean result = ps.executeUpdate() > 0;

            if (result) {

                congTonKho(
                        ct.getMaVatDung(),
                        ct.getSoLuong());

                updateTongTien(
                        ct.getMaPhieuNhap());
            }

            return result;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

   
    public boolean update(CT_PhieuNhap ct) {

        CT_PhieuNhap old =
                findById(ct.getMaCT());

        String sql = """
                UPDATE CT_PhieuNhap
                SET MaPhieuNhap=?,
                    MaVatDung=?,
                    SoLuong=?,
                    DonGiaNhap=?,
                    ThanhTien=?
                WHERE MaCT=?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps =
                        con.prepareStatement(sql)) {

            double thanhTien =
                    ct.getSoLuong()
                    * ct.getDonGiaNhap();

            ps.setInt(1, ct.getMaPhieuNhap());
            ps.setInt(2, ct.getMaVatDung());
            ps.setInt(3, ct.getSoLuong());
            ps.setDouble(4, ct.getDonGiaNhap());
            ps.setDouble(5, thanhTien);
            ps.setInt(6, ct.getMaCT());

            boolean result =
                    ps.executeUpdate() > 0;

            if (result && old != null) {

                truTonKho(
                        old.getMaVatDung(),
                        old.getSoLuong());

                congTonKho(
                        ct.getMaVatDung(),
                        ct.getSoLuong());

                updateTongTien(
                        ct.getMaPhieuNhap());
            }

            return result;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

     
    public boolean delete(int maCT) {

        CT_PhieuNhap old =
                findById(maCT);

        int maPhieuNhap =
                getMaPhieuNhapByMaCT(maCT);

        String sql =
                "DELETE FROM CT_PhieuNhap WHERE MaCT=?";

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps =
                        con.prepareStatement(sql)) {

            ps.setInt(1, maCT);

            boolean result =
                    ps.executeUpdate() > 0;

            if (result) {

                if (old != null) {

                    truTonKho(
                            old.getMaVatDung(),
                            old.getSoLuong());
                }

                updateTongTien(
                        maPhieuNhap);
            }

            return result;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

   
    public List<CT_PhieuNhap> search(String keyword) {

        List<CT_PhieuNhap> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM CT_PhieuNhap
                WHERE  
                    CAST(MaPhieuNhap AS CHAR) LIKE ?
                 """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            String value = "%" + keyword + "%";

            ps.setString(1, value);
  
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                CT_PhieuNhap ct = new CT_PhieuNhap();

                ct.setMaCT(rs.getInt("MaCT"));
                ct.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
                ct.setMaVatDung(rs.getInt("MaVatDung"));
                ct.setSoLuong(rs.getInt("SoLuong"));
                ct.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
                ct.setThanhTien(rs.getDouble("ThanhTien"));

                list.add(ct);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    
    private int getMaPhieuNhapByMaCT(int maCT) {

        String sql = """
                SELECT MaPhieuNhap
                FROM CT_PhieuNhap
                WHERE MaCT=?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maCT);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("MaPhieuNhap");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }

    
    private void updateTongTien(int maPhieuNhap) {

        String sql = """
                UPDATE PhieuNhap
                SET TongTien =
                (
                    SELECT IFNULL(SUM(ThanhTien),0)
                    FROM CT_PhieuNhap
                    WHERE MaPhieuNhap = ?
                )
                WHERE MaPhieuNhap = ?
                """;

        try (
                Connection con = DBConnect.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, maPhieuNhap);
            ps.setInt(2, maPhieuNhap);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
 private void congTonKho(int maVatDung, int soLuong) {

     String sql = """
             UPDATE Kho
             SET SoLuongTon = SoLuongTon + ?
             WHERE MaVatDung = ?
             """;

     try (
             Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

         ps.setInt(1, soLuong);
         ps.setInt(2, maVatDung);

         ps.executeUpdate();

     } catch (Exception e) {
         e.printStackTrace();
     }
 }

  
 private void truTonKho(int maVatDung, int soLuong) {

     String sql = """
             UPDATE Kho
             SET SoLuongTon = SoLuongTon - ?
             WHERE MaVatDung = ?
             """;

     try (
             Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

         ps.setInt(1, soLuong);
         ps.setInt(2, maVatDung);

         ps.executeUpdate();

     } catch (Exception e) {
         e.printStackTrace();
     }
 }

  
 public List<CT_PhieuNhap> getByPhieuNhap(int maPhieuNhap) {

	    List<CT_PhieuNhap> list =
	            new ArrayList<>();

	    String sql =
	            "SELECT * FROM CT_PhieuNhap WHERE MaPhieuNhap=?";

	    try (
	            Connection con =
	                    DBConnect.getConnection();

	            PreparedStatement ps =
	                    con.prepareStatement(sql)
	    ) {

	        ps.setInt(1, maPhieuNhap);

	        ResultSet rs =
	                ps.executeQuery();

	        while (rs.next()) {

	            CT_PhieuNhap ct =
	                    new CT_PhieuNhap();

	            ct.setMaCT(rs.getInt("MaCT"));
	            ct.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
	            ct.setMaVatDung(rs.getInt("MaVatDung"));
	            ct.setSoLuong(rs.getInt("SoLuong"));
	            ct.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
	            ct.setThanhTien(rs.getDouble("ThanhTien"));

	            list.add(ct);
	        }

	    } catch (Exception e) {

	        e.printStackTrace();
	    }

	    return list;
	}
 private CT_PhieuNhap findById(int maCT) {

     String sql =
             "SELECT * FROM CT_PhieuNhap WHERE MaCT=?";

     try (
             Connection con = DBConnect.getConnection();
             PreparedStatement ps =
                     con.prepareStatement(sql)) {

         ps.setInt(1, maCT);

         ResultSet rs = ps.executeQuery();

         if (rs.next()) {

             CT_PhieuNhap ct =
                     new CT_PhieuNhap();

             ct.setMaCT(rs.getInt("MaCT"));
             ct.setMaPhieuNhap(rs.getInt("MaPhieuNhap"));
             ct.setMaVatDung(rs.getInt("MaVatDung"));
             ct.setSoLuong(rs.getInt("SoLuong"));
             ct.setDonGiaNhap(rs.getDouble("DonGiaNhap"));
             ct.setThanhTien(rs.getDouble("ThanhTien"));

             return ct;
         }

     } catch (Exception e) {
         e.printStackTrace();
     }

     return null;
 }
}