package config;

import model.TaiKhoan;

public class Session {

    public static TaiKhoan currentUser;

}
