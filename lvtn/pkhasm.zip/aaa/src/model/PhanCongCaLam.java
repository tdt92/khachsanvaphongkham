package model;

import java.sql.Time;

public class PhanCongCaLam {

    private int id;
    private int maNhanVien;
    private String tenNhanVien; // join để hiển thị
    private String phong;
    private Time gioLam;
    private Time gioKetThuc;
    private String thu;

    public PhanCongCaLam() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMaNhanVien() { return maNhanVien; }
    public void setMaNhanVien(int maNhanVien) { this.maNhanVien = maNhanVien; }

    public String getTenNhanVien() { return tenNhanVien; }
    public void setTenNhanVien(String tenNhanVien) { this.tenNhanVien = tenNhanVien; }

    public String getPhong() { return phong; }
    public void setPhong(String phong) { this.phong = phong; }

    public Time getGioLam() { return gioLam; }
    public void setGioLam(Time gioLam) { this.gioLam = gioLam; }

    public Time getGioKetThuc() { return gioKetThuc; }
    public void setGioKetThuc(Time gioKetThuc) { this.gioKetThuc = gioKetThuc; }

    public String getThu() { return thu; }
    public void setThu(String thu) { this.thu = thu; }
}
