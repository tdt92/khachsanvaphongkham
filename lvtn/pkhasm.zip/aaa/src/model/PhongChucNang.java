package model;

public class PhongChucNang {

    private int maPhong;
    private String tenPhong;
    private String loaiPhong;
    public PhongChucNang() {}

    public PhongChucNang(int maPhong, String tenPhong, String loaiPhong) {
        this.maPhong = maPhong;
        this.tenPhong = tenPhong;
        this.loaiPhong = loaiPhong;
    }

    public int getMaPhong() { return maPhong; }
    public void setMaPhong(int maPhong) { this.maPhong = maPhong; }

    public String getTenPhong() { return tenPhong; }
    public void setTenPhong(String tenPhong) { this.tenPhong = tenPhong; }

    public String getLoaiPhong() { return loaiPhong; }
    public void setLoaiPhong(String loaiPhong) { this.loaiPhong = loaiPhong; }

    @Override
    public String toString() {
        return tenPhong;
    }
}
