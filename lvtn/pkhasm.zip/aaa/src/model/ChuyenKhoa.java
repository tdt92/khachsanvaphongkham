package model;

public class ChuyenKhoa {

    private int maChuyenKhoa;
    private String tenChuyenKhoa;
    private String moTa;

    public int getMaChuyenKhoa() { return maChuyenKhoa; }
    public void setMaChuyenKhoa(int maChuyenKhoa) { this.maChuyenKhoa = maChuyenKhoa; }

    public String getTenChuyenKhoa() { return tenChuyenKhoa; }
    public void setTenChuyenKhoa(String tenChuyenKhoa) { this.tenChuyenKhoa = tenChuyenKhoa; }

    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }

    @Override
    public String toString() {
        return tenChuyenKhoa;
    }
}
