package model;

import java.math.BigDecimal;

public class DichVu {

    private int maDichVu;
    private String tenDichVu;
    private BigDecimal donGia;
    private String loaiDichVu;
    private int phong;
    private Integer maChuyenKhoa;

    public DichVu() {}

    public int getMaDichVu() { return maDichVu; }
    public void setMaDichVu(int maDichVu) { this.maDichVu = maDichVu; }

    public String getTenDichVu() { return tenDichVu; }
    public void setTenDichVu(String tenDichVu) { this.tenDichVu = tenDichVu; }

    public BigDecimal getDonGia() { return donGia; }
    public void setDonGia(BigDecimal donGia) { this.donGia = donGia; }

    public String getLoaiDichVu() { return loaiDichVu; }
    public void setLoaiDichVu(String loaiDichVu) { this.loaiDichVu = loaiDichVu; }

    public int getPhong() { return phong; }
    public void setPhong(int phong) { this.phong = phong; }

    public Integer getMaChuyenKhoa() { return maChuyenKhoa; }
    public void setMaChuyenKhoa(Integer maChuyenKhoa) { this.maChuyenKhoa = maChuyenKhoa; }
}
