package model;

import java.util.Date;

public class LichSuKhamBenh {

    private int maPhieuKham;
    private String tenBenhNhan;
    private String cccd;
    private String tenBacSi;
    private String chuyenKhoa;
    private Date ngayKham;
    private String trangThai;
    private String ghiChu;
    private String lyDoKham;

    private String benhSu;

    private String tienSuBanThan;

    private String khamLamSang;

    private String ketQuaCanLamSang;

    private String chanDoanSoBo;

    private String loiDanBacSi;
    public int getMaPhieuKham() {
        return maPhieuKham;
    }

    public void setMaPhieuKham(int maPhieuKham) {
        this.maPhieuKham = maPhieuKham;
    }

    public String getTenBenhNhan() {
        return tenBenhNhan;
    }

    public void setTenBenhNhan(String tenBenhNhan) {
        this.tenBenhNhan = tenBenhNhan;
    }

    public String getCccd() {
        return cccd;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public String getTenBacSi() {
        return tenBacSi;
    }

    public void setTenBacSi(String tenBacSi) {
        this.tenBacSi = tenBacSi;
    }

    public String getChuyenKhoa() {
        return chuyenKhoa;
    }

    public void setChuyenKhoa(String chuyenKhoa) {
        this.chuyenKhoa = chuyenKhoa;
    }

    public Date getNgayKham() {
        return ngayKham;
    }

    public void setNgayKham(Date ngayKham) {
        this.ngayKham = ngayKham;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    public String getLyDoKham() {
        return lyDoKham;
    }

    public void setLyDoKham(String lyDoKham) {
        this.lyDoKham = lyDoKham;
    }

    public String getBenhSu() {
        return benhSu;
    }

    public void setBenhSu(String benhSu) {
        this.benhSu = benhSu;
    }

    public String getTienSuBanThan() {
        return tienSuBanThan;
    }

    public void setTienSuBanThan(String tienSuBanThan) {
        this.tienSuBanThan = tienSuBanThan;
    }

    public String getKhamLamSang() {
        return khamLamSang;
    }

    public void setKhamLamSang(String khamLamSang) {
        this.khamLamSang = khamLamSang;
    }

    public String getKetQuaCanLamSang() {
        return ketQuaCanLamSang;
    }

    public void setKetQuaCanLamSang(String ketQuaCanLamSang) {
        this.ketQuaCanLamSang = ketQuaCanLamSang;
    }

    public String getChanDoanSoBo() {
        return chanDoanSoBo;
    }

    public void setChanDoanSoBo(String chanDoanSoBo) {
        this.chanDoanSoBo = chanDoanSoBo;
    }

    public String getLoiDanBacSi() {
        return loiDanBacSi;
    }

    public void setLoiDanBacSi(String loiDanBacSi) {
        this.loiDanBacSi = loiDanBacSi;
    }
}