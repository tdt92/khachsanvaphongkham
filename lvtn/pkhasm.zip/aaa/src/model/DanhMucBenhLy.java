package model;

public class DanhMucBenhLy {

    private int id;
    private String maICD;
    private String tenBenh;
    private String trieuChungGoiY;
    private String chuyenKhoaLienQuan;

    public DanhMucBenhLy() {}

    public DanhMucBenhLy(int id, String maICD, String tenBenh,
                         String trieuChungGoiY, String chuyenKhoaLienQuan) {
        this.id = id;
        this.maICD = maICD;
        this.tenBenh = tenBenh;
        this.trieuChungGoiY = trieuChungGoiY;
        this.chuyenKhoaLienQuan = chuyenKhoaLienQuan;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getMaICD() { return maICD; }
    public void setMaICD(String maICD) { this.maICD = maICD; }

    public String getTenBenh() { return tenBenh; }
    public void setTenBenh(String tenBenh) { this.tenBenh = tenBenh; }

    public String getTrieuChungGoiY() { return trieuChungGoiY; }
    public void setTrieuChungGoiY(String trieuChungGoiY) { this.trieuChungGoiY = trieuChungGoiY; }

    public String getChuyenKhoaLienQuan() { return chuyenKhoaLienQuan; }
    public void setChuyenKhoaLienQuan(String chuyenKhoaLienQuan) {
        this.chuyenKhoaLienQuan = chuyenKhoaLienQuan;
    }
}
