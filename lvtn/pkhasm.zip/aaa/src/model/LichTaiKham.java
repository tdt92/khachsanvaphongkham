package model;

import java.sql.Date;

public class LichTaiKham {

    private int id;
    private int maBenhNhan;
    private int maChuyenKhoa;
    private Integer maPhieuKham;
    private int maNhanVien;
    private Date ngayTaiKham;
    private String ghiChu;
    private String trangThai;
    private boolean daGuiThongBao;

    // ====== DÙNG ĐỂ HIỂN THỊ JOIN ======
    private String tenBenhNhan;
    private String tenChuyenKhoa;
    private String tenNhanVien;

    // Getter Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMaBenhNhan() { return maBenhNhan; }
    public void setMaBenhNhan(int maBenhNhan) { this.maBenhNhan = maBenhNhan; }

    public int getMaChuyenKhoa() { return maChuyenKhoa; }
    public void setMaChuyenKhoa(int maChuyenKhoa) { this.maChuyenKhoa = maChuyenKhoa; }

    public Integer getMaPhieuKham() { return maPhieuKham; }
    public void setMaPhieuKham(Integer maPhieuKham) { this.maPhieuKham = maPhieuKham; }

    public int getMaNhanVien() { return maNhanVien; }
    public void setMaNhanVien(int maNhanVien) { this.maNhanVien = maNhanVien; }

    public Date getNgayTaiKham() { return ngayTaiKham; }
    public void setNgayTaiKham(Date ngayTaiKham) { this.ngayTaiKham = ngayTaiKham; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    public boolean isDaGuiThongBao() { return daGuiThongBao; }
    public void setDaGuiThongBao(boolean daGuiThongBao) { this.daGuiThongBao = daGuiThongBao; }

    public String getTenBenhNhan() { return tenBenhNhan; }
    public void setTenBenhNhan(String tenBenhNhan) { this.tenBenhNhan = tenBenhNhan; }

    public String getTenChuyenKhoa() { return tenChuyenKhoa; }
    public void setTenChuyenKhoa(String tenChuyenKhoa) { this.tenChuyenKhoa = tenChuyenKhoa; }

    public String getTenNhanVien() { return tenNhanVien; }
    public void setTenNhanVien(String tenNhanVien) { this.tenNhanVien = tenNhanVien; }
}