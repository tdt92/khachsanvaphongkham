package model;

import java.sql.Date;

public class BenhNhan {

    private int maBenhNhan;
    private String hoTen;
    private Date ngaySinh;
    private String diaChi;
    private String soDienThoai;
    private String email;
    private String ngheNghiep;
    private String nhomMau;
    private String diUngThuoc;
    private String nguoiGiamHo;
    private String soDienThoaiNguoiGiamHo;
    private String ghiChu;
    private String cccd;
    private int gioiTinh; // 0 = Nam, 1 = Nữ

    // Getter & Setter
    public int getMaBenhNhan() { return maBenhNhan; }
    public void setMaBenhNhan(int maBenhNhan) { this.maBenhNhan = maBenhNhan; }

    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }

    public Date getNgaySinh() { return ngaySinh; }
    public void setNgaySinh(Date ngaySinh) { this.ngaySinh = ngaySinh; }

    public String getDiaChi() { return diaChi; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }

    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getNgheNghiep() { return ngheNghiep; }
    public void setNgheNghiep(String ngheNghiep) { this.ngheNghiep = ngheNghiep; }

    public String getNhomMau() { return nhomMau; }
    public void setNhomMau(String nhomMau) { this.nhomMau = nhomMau; }

    public String getDiUngThuoc() { return diUngThuoc; }
    public void setDiUngThuoc(String diUngThuoc) { this.diUngThuoc = diUngThuoc; }

    public String getNguoiGiamHo() { return nguoiGiamHo; }
    public void setNguoiGiamHo(String nguoiGiamHo) { this.nguoiGiamHo = nguoiGiamHo; }

    public String getSoDienThoaiNguoiGiamHo() { return soDienThoaiNguoiGiamHo; }
    public void setSoDienThoaiNguoiGiamHo(String sdt) { this.soDienThoaiNguoiGiamHo = sdt; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }

    public String getCccd() { return cccd; }
    public void setCccd(String cccd) { this.cccd = cccd; }

    public int getGioiTinh() { return gioiTinh; }
    public void setGioiTinh(int gioiTinh) { this.gioiTinh = gioiTinh; }
}
