package model;

public class ChiSoKhamTongHop {

    private int maPhieuKham;
    private int maNhanVienNhap;

    private Float nhietDo;
    private Integer nhipTim;
    private Integer huyetApTamThu;
    private Integer nhipTho;
    private Float canNang;
    private Float chieuCao;
    private String ghiChu;
    private String tinhTrangRang;
    private String sauRang;
    private String caoRang;
    private String viemNuou;
    private String khopCan;
    private String niemMacMieng;
    private String doLungLay;
    private String phuHinhCu;
    private String benhLyKhacRHM;

 
    // ==========================
    // GETTER & SETTER
    // ==========================

     

    public void setMaNhanVienNhap(Integer maNhanVienNhap) {
        this.maNhanVienNhap = maNhanVienNhap;
    }

    public String getTinhTrangRang() {
        return tinhTrangRang;
    }

    public void setTinhTrangRang(String tinhTrangRang) {
        this.tinhTrangRang = tinhTrangRang;
    }

    public String getSauRang() {
        return sauRang;
    }

    public void setSauRang(String sauRang) {
        this.sauRang = sauRang;
    }

    public String getCaoRang() {
        return caoRang;
    }

    public void setCaoRang(String caoRang) {
        this.caoRang = caoRang;
    }

    public String getViemNuou() {
        return viemNuou;
    }

    public void setViemNuou(String viemNuou) {
        this.viemNuou = viemNuou;
    }

    public String getKhopCan() {
        return khopCan;
    }

    public void setKhopCan(String khopCan) {
        this.khopCan = khopCan;
    }

    public String getNiemMacMieng() {
        return niemMacMieng;
    }

    public void setNiemMacMieng(String niemMacMieng) {
        this.niemMacMieng = niemMacMieng;
    }

    public String getDoLungLay() {
        return doLungLay;
    }

    public void setDoLungLay(String doLungLay) {
        this.doLungLay = doLungLay;
    }

    public String getPhuHinhCu() {
        return phuHinhCu;
    }

    public void setPhuHinhCu(String phuHinhCu) {
        this.phuHinhCu = phuHinhCu;
    }

    public String getBenhLyKhacRHM() {
        return benhLyKhacRHM;
    }

    public void setBenhLyKhacRHM(String benhLyKhacRHM) {
        this.benhLyKhacRHM = benhLyKhacRHM;
    }

    
    public int getMaPhieuKham() { return maPhieuKham; }
    public void setMaPhieuKham(int maPhieuKham) { this.maPhieuKham = maPhieuKham; }

    public int getMaNhanVienNhap() { return maNhanVienNhap; }
    public void setMaNhanVienNhap(int maNhanVienNhap) { this.maNhanVienNhap = maNhanVienNhap; }

    public Float getNhietDo() { return nhietDo; }
    public void setNhietDo(Float nhietDo) { this.nhietDo = nhietDo; }

    public Integer getNhipTim() { return nhipTim; }
    public void setNhipTim(Integer nhipTim) { this.nhipTim = nhipTim; }

    public Integer getHuyetApTamThu() { return huyetApTamThu; }
    public void setHuyetApTamThu(Integer huyetApTamThu) { this.huyetApTamThu = huyetApTamThu; }

    public Integer getNhipTho() { return nhipTho; }
    public void setNhipTho(Integer nhipTho) { this.nhipTho = nhipTho; }

    public Float getCanNang() { return canNang; }
    public void setCanNang(Float canNang) { this.canNang = canNang; }

    public Float getChieuCao() { return chieuCao; }
    public void setChieuCao(Float chieuCao) { this.chieuCao = chieuCao; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}