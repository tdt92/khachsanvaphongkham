package model;

public class KhamLamSang {

    private int maPhieuKham;
    private String lyDoKham;
    private String tienSuBanThan;
    private String benhSu;
    private String chanDoanSoBo;
    private String loiDanBacSi;
    private String ketQuaCLS;
    private String khamLamSang;

    public int getMaPhieuKham() { return maPhieuKham; }
    public void setMaPhieuKham(int maPhieuKham) { this.maPhieuKham = maPhieuKham; }

    public String getLyDoKham() { return lyDoKham; }
    public void setLyDoKham(String lyDoKham) { this.lyDoKham = lyDoKham; }

    public String getTienSuBanThan() { return tienSuBanThan; }
    public void setTienSuBanThan(String tienSuBanThan) { this.tienSuBanThan = tienSuBanThan; }

    public String getBenhSu() { return benhSu; }
    public void setBenhSu(String benhSu) { this.benhSu = benhSu; }

    public String getChanDoanSoBo() { return chanDoanSoBo; }
    public void setChanDoanSoBo(String chanDoanSoBo) { this.chanDoanSoBo = chanDoanSoBo; }

    public String getLoiDanBacSi() { return loiDanBacSi; }
    public void setLoiDanBacSi(String loiDanBacSi) { this.loiDanBacSi = loiDanBacSi; }

    public String getKetQuaCLS() { return ketQuaCLS; }
    public void setKetQuaCLS(String ketQuaCLS) { this.ketQuaCLS = ketQuaCLS; }

    public String getKhamLamSang() { return khamLamSang; }
    public void setKhamLamSang(String khamLamSang) { this.khamLamSang = khamLamSang; }
}