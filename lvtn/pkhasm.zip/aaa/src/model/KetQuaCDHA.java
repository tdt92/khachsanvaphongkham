package model;

import java.util.Date;

public class KetQuaCDHA {

    private int id;
    private int idChiTietChiDinh;

    private String moTaHinhAnh;
    private String ketLuan;
    private String deNghi;

    private String duongDanAnh1;
    private String duongDanAnh2;

    private Date ngayThucHien;

    private Integer maBacSiThucHien;
    private Integer maNhanVienThucHien;

    public KetQuaCDHA() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdChiTietChiDinh() {
        return idChiTietChiDinh;
    }

    public void setIdChiTietChiDinh(int idChiTietChiDinh) {
        this.idChiTietChiDinh = idChiTietChiDinh;
    }

    public String getMoTaHinhAnh() {
        return moTaHinhAnh;
    }

    public void setMoTaHinhAnh(String moTaHinhAnh) {
        this.moTaHinhAnh = moTaHinhAnh;
    }

    public String getKetLuan() {
        return ketLuan;
    }

    public void setKetLuan(String ketLuan) {
        this.ketLuan = ketLuan;
    }

    public String getDeNghi() {
        return deNghi;
    }

    public void setDeNghi(String deNghi) {
        this.deNghi = deNghi;
    }

    public String getDuongDanAnh1() {
        return duongDanAnh1;
    }

    public void setDuongDanAnh1(String duongDanAnh1) {
        this.duongDanAnh1 = duongDanAnh1;
    }

    public String getDuongDanAnh2() {
        return duongDanAnh2;
    }

    public void setDuongDanAnh2(String duongDanAnh2) {
        this.duongDanAnh2 = duongDanAnh2;
    }

    public Date getNgayThucHien() {
        return ngayThucHien;
    }

    public void setNgayThucHien(Date ngayThucHien) {
        this.ngayThucHien = ngayThucHien;
    }

    public Integer getMaBacSiThucHien() {
        return maBacSiThucHien;
    }

    public void setMaBacSiThucHien(Integer maBacSiThucHien) {
        this.maBacSiThucHien = maBacSiThucHien;
    }

    public Integer getMaNhanVienThucHien() {
        return maNhanVienThucHien;
    }

    public void setMaNhanVienThucHien(Integer maNhanVienThucHien) {
        this.maNhanVienThucHien = maNhanVienThucHien;
    }
}