package model;

public class CLSChanDoanHinhAnh {

    private int maPhieuKham;
    private int idChiTietChiDinh;

    private String tenBenhNhan;
    private String lyDoKham;

    private Double nhietDo;
    private Double chieuCao;
    private Double canNang;

    private String huyetAp;

    public int getMaPhieuKham() {
        return maPhieuKham;
    }

    public void setMaPhieuKham(int maPhieuKham) {
        this.maPhieuKham = maPhieuKham;
    }

    public int getIdChiTietChiDinh() {
        return idChiTietChiDinh;
    }

    public void setIdChiTietChiDinh(int idChiTietChiDinh) {
        this.idChiTietChiDinh = idChiTietChiDinh;
    }

    public String getTenBenhNhan() {
        return tenBenhNhan;
    }

    public void setTenBenhNhan(String tenBenhNhan) {
        this.tenBenhNhan = tenBenhNhan;
    }

    public String getLyDoKham() {
        return lyDoKham;
    }

    public void setLyDoKham(String lyDoKham) {
        this.lyDoKham = lyDoKham;
    }

    public Double getNhietDo() {
        return nhietDo;
    }

    public void setNhietDo(Double nhietDo) {
        this.nhietDo = nhietDo;
    }

    public Double getChieuCao() {
        return chieuCao;
    }

    public void setChieuCao(Double chieuCao) {
        this.chieuCao = chieuCao;
    }

    public Double getCanNang() {
        return canNang;
    }

    public void setCanNang(Double canNang) {
        this.canNang = canNang;
    }

    public String getHuyetAp() {
        return huyetAp;
    }

    public void setHuyetAp(String huyetAp) {
        this.huyetAp = huyetAp;
    }
}