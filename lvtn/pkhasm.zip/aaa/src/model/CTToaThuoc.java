package model;

public class CTToaThuoc {

    private int id;
    private int maToaThuoc;
    private int maThuoc;

    private String lieuDung;

    private String sang;
    private String trua;
    private String chieu;
    private String toi;

    private int soNgay;

    private String cachDung;
    private String thoiDiemDung;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMaToaThuoc() {
        return maToaThuoc;
    }

    public void setMaToaThuoc(int maToaThuoc) {
        this.maToaThuoc = maToaThuoc;
    }

    public int getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(int maThuoc) {
        this.maThuoc = maThuoc;
    }

    public String getLieuDung() {
        return lieuDung;
    }

    public void setLieuDung(String lieuDung) {
        this.lieuDung = lieuDung;
    }

    public String getSang() {
        return sang;
    }

    public void setSang(String sang) {
        this.sang = sang;
    }

    public String getTrua() {
        return trua;
    }

    public void setTrua(String trua) {
        this.trua = trua;
    }

    public String getChieu() {
        return chieu;
    }

    public void setChieu(String chieu) {
        this.chieu = chieu;
    }

    public String getToi() {
        return toi;
    }

    public void setToi(String toi) {
        this.toi = toi;
    }

    public int getSoNgay() {
        return soNgay;
    }

    public void setSoNgay(int soNgay) {
        this.soNgay = soNgay;
    }

    public String getCachDung() {
        return cachDung;
    }

    public void setCachDung(String cachDung) {
        this.cachDung = cachDung;
    }

    public String getThoiDiemDung() {
        return thoiDiemDung;
    }

    public void setThoiDiemDung(String thoiDiemDung) {
        this.thoiDiemDung = thoiDiemDung;
    }
}