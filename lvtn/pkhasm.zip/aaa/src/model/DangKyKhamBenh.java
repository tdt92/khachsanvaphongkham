package model;

import java.sql.Timestamp;

public class DangKyKhamBenh {

    private int id;
    private int maBenhNhan;
    private Integer maNhanVien;
    private int maChuyenKhoa;
    private int soThuTu;
    private Timestamp thoiGianDangKy;
    private String trangThai;
    private String ghiChu;

    private String hoTen;
    private Integer maPhieuKham;

    public Integer getMaPhieuKham() {
        return maPhieuKham;
    }

    public void setMaPhieuKham(Integer maPhieuKham) {
        this.maPhieuKham = maPhieuKham;
    }
    
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public DangKyKhamBenh(){}

    public DangKyKhamBenh(int maBenhNhan, Integer maNhanVien,
                          int maChuyenKhoa, int soThuTu,
                          String trangThai, String ghiChu){
        this.maBenhNhan = maBenhNhan;
        this.maNhanVien = maNhanVien;
        this.maChuyenKhoa = maChuyenKhoa;
        this.soThuTu = soThuTu;
        this.trangThai = trangThai;
        this.ghiChu = ghiChu;
    }

    // Getter Setter đầy đủ
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMaBenhNhan() { return maBenhNhan; }
    public void setMaBenhNhan(int maBenhNhan) { this.maBenhNhan = maBenhNhan; }

    public Integer getMaNhanVien() { return maNhanVien; }
    public void setMaNhanVien(Integer maNhanVien) { this.maNhanVien = maNhanVien; }

    public int getMaChuyenKhoa() { return maChuyenKhoa; }
    public void setMaChuyenKhoa(int maChuyenKhoa) { this.maChuyenKhoa = maChuyenKhoa; }

    public int getSoThuTu() { return soThuTu; }
    public void setSoThuTu(int soThuTu) { this.soThuTu = soThuTu; }

    public Timestamp getThoiGianDangKy() { return thoiGianDangKy; }
    public void setThoiGianDangKy(Timestamp thoiGianDangKy) { this.thoiGianDangKy = thoiGianDangKy; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}