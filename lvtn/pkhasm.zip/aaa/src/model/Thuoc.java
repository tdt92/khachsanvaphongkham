package model;

import java.math.BigDecimal;
import java.sql.Date;

public class Thuoc {

    private int maThuoc;
    private String tenThuoc;
    private String hoatChat;
    private String hamLuong;
    private String dangThuoc;
    private String loaiThuoc;
    private String donViTinh;
    private BigDecimal donGiaNhap;
    private BigDecimal donGiaBan;
    private Date ngaySanXuat;
    private Date hanSuDung;
    private String nhaSanXuat;
    private String nuocSanXuat;
    private String ghiChu;

    public int getMaThuoc() { return maThuoc; }
    public void setMaThuoc(int maThuoc) { this.maThuoc = maThuoc; }

    public String getTenThuoc() { return tenThuoc; }
    public void setTenThuoc(String tenThuoc) { this.tenThuoc = tenThuoc; }

    public String getHoatChat() { return hoatChat; }
    public void setHoatChat(String hoatChat) { this.hoatChat = hoatChat; }

    public String getHamLuong() { return hamLuong; }
    public void setHamLuong(String hamLuong) { this.hamLuong = hamLuong; }

    public String getDangThuoc() { return dangThuoc; }
    public void setDangThuoc(String dangThuoc) { this.dangThuoc = dangThuoc; }

    public String getLoaiThuoc() { return loaiThuoc; }
    public void setLoaiThuoc(String loaiThuoc) { this.loaiThuoc = loaiThuoc; }

    public String getDonViTinh() { return donViTinh; }
    public void setDonViTinh(String donViTinh) { this.donViTinh = donViTinh; }

    public BigDecimal getDonGiaNhap() { return donGiaNhap; }
    public void setDonGiaNhap(BigDecimal donGiaNhap) { this.donGiaNhap = donGiaNhap; }

    public BigDecimal getDonGiaBan() { return donGiaBan; }
    public void setDonGiaBan(BigDecimal donGiaBan) { this.donGiaBan = donGiaBan; }

    public Date getNgaySanXuat() { return ngaySanXuat; }
    public void setNgaySanXuat(Date ngaySanXuat) { this.ngaySanXuat = ngaySanXuat; }

    public Date getHanSuDung() { return hanSuDung; }
    public void setHanSuDung(Date hanSuDung) { this.hanSuDung = hanSuDung; }

    public String getNhaSanXuat() { return nhaSanXuat; }
    public void setNhaSanXuat(String nhaSanXuat) { this.nhaSanXuat = nhaSanXuat; }

    public String getNuocSanXuat() { return nuocSanXuat; }
    public void setNuocSanXuat(String nuocSanXuat) { this.nuocSanXuat = nuocSanXuat; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}
