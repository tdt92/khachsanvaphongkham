package model;

public class TaiKhoan {

    private int maTaiKhoan;
    private String username;
    private String email;
    private String matKhau;
    private int maNhanVien;
    private String vaiTro;
    private boolean lanDauDangNhap;

    public int getMaTaiKhoan() {
        return maTaiKhoan;
    }

    public void setMaTaiKhoan(int maTaiKhoan) {
        this.maTaiKhoan = maTaiKhoan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(String vaiTro) {
        this.vaiTro = vaiTro;
    }

    public boolean isLanDauDangNhap() {
        return lanDauDangNhap;
    }

    public void setLanDauDangNhap(boolean lanDauDangNhap) {
        this.lanDauDangNhap = lanDauDangNhap;
    }
}
