/**
 * 
 */
/**
 * 
 */
module aaa {
	requires java.desktop;
	requires java.sql;
	requires jcalendar;
}