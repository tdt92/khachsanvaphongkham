package dao;

import model.ChiSoKhamTongHop;
import java.sql.*;

import config.DBConnection;

public class ChiSoKhamTongHopDAO {

    public boolean insert(ChiSoKhamTongHop c){

        String sql = "INSERT INTO chi_so_kham_tong_hop " +
                "(ma_phieu_kham,ma_nhan_vien_nhap,nhiet_do,nhip_tim,nhip_tho,huyet_ap_tam_thu,can_nang,chieu_cao,ghi_chu) " +
                "VALUES(?,?,?,?,?,?,?,?,?)";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,c.getMaPhieuKham());
            ps.setInt(2,c.getMaNhanVienNhap());
            ps.setObject(3,c.getNhietDo());
            ps.setObject(4,c.getNhipTim());
            ps.setObject(5,c.getNhipTho());
            ps.setObject(6,c.getHuyetApTamThu());
            ps.setObject(7,c.getCanNang());
            ps.setObject(8,c.getChieuCao());
            ps.setString(9,c.getGhiChu());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public ChiSoKhamTongHop findByMaPhieu(int maPhieu){

        String sql = "SELECT * FROM chi_so_kham_tong_hop WHERE ma_phieu_kham=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                ChiSoKhamTongHop c = new ChiSoKhamTongHop();

                c.setMaPhieuKham(maPhieu);
                c.setTinhTrangRang(rs.getString("tinh_trang_rang"));
                c.setViemNuou(rs.getString("viem_nuou"));
                c.setSauRang(rs.getString("sau_rang"));
                c.setNiemMacMieng(rs.getString("niem_mac_mieng"));
                c.setCaoRang(rs.getString("cao_rang"));
                c.setDoLungLay(rs.getString("do_lung_lay"));
                c.setKhopCan(rs.getString("khop_can"));
                c.setBenhLyKhacRHM(rs.getString("benh_ly_khac_rhm"));
                c.setPhuHinhCu(rs.getString("phu_hinh_cu"));
                c.setGhiChu(rs.getString("ghi_chu"));

                return c;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }
    public ChiSoKhamTongHop findByMaPhieu11(int maPhieu){

        String sql =
                "SELECT * FROM chi_so_kham_tong_hop " +
                "WHERE ma_phieu_kham=?";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setInt(1, maPhieu);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                ChiSoKhamTongHop c =
                        new ChiSoKhamTongHop();

                // =================================================
                // THÔNG TIN CƠ BẢN
                // =================================================

                c.setMaPhieuKham(
                        rs.getInt("ma_phieu_kham")
                );

                c.setMaNhanVienNhap(
                        rs.getInt("ma_nhan_vien_nhap")
                );

                // =================================================
                // CHỈ SỐ TỔNG HỢP
                // =================================================

                c.setNhietDo(
                        rs.getObject(
                                "nhiet_do",
                                Float.class
                        )
                );

                c.setNhipTim(
                        rs.getObject(
                                "nhip_tim",
                                Integer.class
                        )
                );

                c.setNhipTho(
                        rs.getObject(
                                "nhip_tho",
                                Integer.class
                        )
                );

                c.setHuyetApTamThu(
                        rs.getObject(
                                "huyet_ap_tam_thu",
                                Integer.class
                        )
                );

                c.setCanNang(
                        rs.getObject(
                                "can_nang",
                                Float.class
                        )
                );

                c.setChieuCao(
                        rs.getObject(
                                "chieu_cao",
                                Float.class
                        )
                );

                // =================================================
                // KHÁM RĂNG
                // =================================================

                c.setTinhTrangRang(
                        rs.getString("tinh_trang_rang")
                );

                c.setViemNuou(
                        rs.getString("viem_nuou")
                );

                c.setSauRang(
                        rs.getString("sau_rang")
                );

                c.setNiemMacMieng(
                        rs.getString("niem_mac_mieng")
                );

                c.setCaoRang(
                        rs.getString("cao_rang")
                );

                c.setDoLungLay(
                        rs.getString("do_lung_lay")
                );

                c.setKhopCan(
                        rs.getString("khop_can")
                );

                c.setBenhLyKhacRHM(
                        rs.getString("benh_ly_khac_rhm")
                );

                c.setPhuHinhCu(
                        rs.getString("phu_hinh_cu")
                );

                c.setGhiChu(
                        rs.getString("ghi_chu")
                );

                return c;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return null;
    }

    public boolean saveOrUpdate(ChiSoKhamTongHop c) {

        String checkSql = "SELECT id FROM chi_so_kham_tong_hop WHERE ma_phieu_kham = ?";

        String insertSql = """
            INSERT INTO chi_so_kham_tong_hop
            (ma_phieu_kham,
             tinh_trang_rang,
             viem_nuou,
             sau_rang,
             niem_mac_mieng,
             cao_rang,
             do_lung_lay,
             khop_can,
             benh_ly_khac_rhm,
             phu_hinh_cu,
             ghi_chu)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """;

        String updateSql = """
            UPDATE chi_so_kham_tong_hop
            SET tinh_trang_rang=?,
                viem_nuou=?,
                sau_rang=?,
                niem_mac_mieng=?,
                cao_rang=?,
                do_lung_lay=?,
                khop_can=?,
                benh_ly_khac_rhm=?,
                phu_hinh_cu=?,
                ghi_chu=?
            WHERE ma_phieu_kham=?
        """;

        try(Connection con = DBConnection.getConnection()) {

            PreparedStatement check = con.prepareStatement(checkSql);
            check.setInt(1, c.getMaPhieuKham());
            ResultSet rs = check.executeQuery();

            if(rs.next()) {

                // UPDATE
                PreparedStatement ps = con.prepareStatement(updateSql);

                ps.setString(1, c.getTinhTrangRang());
                ps.setString(2, c.getViemNuou());
                ps.setString(3, c.getSauRang());
                ps.setString(4, c.getNiemMacMieng());
                ps.setString(5, c.getCaoRang());
                ps.setString(6, c.getDoLungLay());
                ps.setString(7, c.getKhopCan());
                ps.setString(8, c.getBenhLyKhacRHM());
                ps.setString(9, c.getPhuHinhCu());
                ps.setString(10, c.getGhiChu());
                ps.setInt(11, c.getMaPhieuKham());

                return ps.executeUpdate() > 0;

            } else {

                // INSERT
                PreparedStatement ps = con.prepareStatement(insertSql);

                ps.setInt(1, c.getMaPhieuKham());
                ps.setString(2, c.getTinhTrangRang());
                ps.setString(3, c.getViemNuou());
                ps.setString(4, c.getSauRang());
                ps.setString(5, c.getNiemMacMieng());
                ps.setString(6, c.getCaoRang());
                ps.setString(7, c.getDoLungLay());
                ps.setString(8, c.getKhopCan());
                ps.setString(9, c.getBenhLyKhacRHM());
                ps.setString(10, c.getPhuHinhCu());
                ps.setString(11, c.getGhiChu());

                return ps.executeUpdate() > 0;
            }

        } catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    
    public ChiSoKhamTongHop findByMaPhieu1(int maPhieu){

        String sql = "SELECT * FROM chi_so_kham_tong_hop WHERE ma_phieu_kham=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                ChiSoKhamTongHop c = new ChiSoKhamTongHop();

                c.setMaPhieuKham(maPhieu);
                c.setTinhTrangRang(rs.getString("tinh_trang_rang"));
                c.setSauRang(rs.getString("sau_rang"));
                c.setCaoRang(rs.getString("cao_rang"));
                c.setDoLungLay(rs.getString("do_lung_lay"));
                c.setKhopCan(rs.getString("khop_can"));
                c.setBenhLyKhacRHM(rs.getString("benh_ly_khac_rhm"));
                c.setPhuHinhCu(rs.getString("phu_hinh_cu"));
                c.setGhiChu(rs.getString("ghi_chu"));

                return c;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }
    public boolean saveOrUpdate1(ChiSoKhamTongHop c) {

        String checkSql = """
            SELECT id FROM chi_so_kham_tong_hop
            WHERE ma_phieu_kham = ?
        """;

        String insertSql = """
            INSERT INTO chi_so_kham_tong_hop
            (ma_phieu_kham,
             tinh_trang_rang,
              viem_nuou,
             sau_rang,
               niem_mac_mieng,
             cao_rang,
             do_lung_lay,
             khop_can,
             benh_ly_khac_rhm,
             phu_hinh_cu,
             ghi_chu
           
       )
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """;

        String updateSql = """
            UPDATE chi_so_kham_tong_hop
            SET tinh_trang_rang=?,
               viem_nuou=?,
                sau_rang=?,
                       niem_mac_mieng=?,
                cao_rang=?,
                do_lung_lay=?,
                khop_can=?,
                benh_ly_khac_rhm=?,
                phu_hinh_cu=?,
                ghi_chu=?
          
             WHERE ma_phieu_kham=?
        """;

        try(Connection con = DBConnection.getConnection()) {

            PreparedStatement check = con.prepareStatement(checkSql);
            check.setInt(1, c.getMaPhieuKham());
            ResultSet rs = check.executeQuery();

            if(rs.next()) {

                // ===== UPDATE =====
                PreparedStatement ps = con.prepareStatement(updateSql);

                ps.setString(1, c.getTinhTrangRang());
                ps.setString(2, c.getViemNuou());
                ps.setString(3, c.getSauRang());
                ps.setString(4, c.getNiemMacMieng());
                ps.setString(5, c.getCaoRang());
                ps.setString(6, c.getDoLungLay());
                ps.setString(7, c.getKhopCan());
                ps.setString(8, c.getBenhLyKhacRHM());
                ps.setString(9, c.getPhuHinhCu());
                ps.setString(10, c.getGhiChu());
                ps.setInt(11, c.getMaPhieuKham());

                return ps.executeUpdate() > 0;

            } else {

                // ===== INSERT =====
                PreparedStatement ps = con.prepareStatement(insertSql);

                ps.setInt(1, c.getMaPhieuKham());
                 ps.setString(2, c.getTinhTrangRang());
                ps.setString(3, c.getViemNuou());
                ps.setString(4, c.getSauRang());
                ps.setString(5, c.getNiemMacMieng());
                ps.setString(6, c.getCaoRang());
                ps.setString(7, c.getDoLungLay());
                ps.setString(8, c.getKhopCan());
                ps.setString(9, c.getBenhLyKhacRHM());
                ps.setString(10, c.getPhuHinhCu());
                ps.setString(11, c.getGhiChu());
  
                return ps.executeUpdate() > 0;
            }

        } catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean insert1(ChiSoKhamTongHop c){

        String sql = """
            INSERT INTO chi_so_kham_tong_hop
            (ma_phieu_kham, tinh_trang_rang, sau_rang, cao_rang,
             do_lung_lay, khop_can, benh_ly_khac_rhm,
             phu_hinh_cu, ghi_chu)
            VALUES (?,?,?,?,?,?,?,?,?)
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, c.getMaPhieuKham());
            ps.setString(2, c.getTinhTrangRang());
            ps.setString(3, c.getSauRang());
            ps.setString(4, c.getCaoRang());
            ps.setString(5, c.getDoLungLay());
            ps.setString(6, c.getKhopCan());
            ps.setString(7, c.getBenhLyKhacRHM());
            ps.setString(8, c.getPhuHinhCu());
            ps.setString(9, c.getGhiChu());

            return ps.executeUpdate() > 0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean update1(ChiSoKhamTongHop c){

        String sql = """
            UPDATE chi_so_kham_tong_hop
            SET tinh_trang_rang=?,
                sau_rang=?,
                cao_rang=?,
                do_lung_lay=?,
                khop_can=?,
                benh_ly_khac_rhm=?,
                phu_hinh_cu=?,
                ghi_chu=?
            WHERE ma_phieu_kham=?
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1, c.getTinhTrangRang());
            ps.setString(2, c.getSauRang());
            ps.setString(3, c.getCaoRang());
            ps.setString(4, c.getDoLungLay());
            ps.setString(5, c.getKhopCan());
            ps.setString(6, c.getBenhLyKhacRHM());
            ps.setString(7, c.getPhuHinhCu());
            ps.setString(8, c.getGhiChu());
            ps.setInt(9, c.getMaPhieuKham());

            return ps.executeUpdate() > 0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(ChiSoKhamTongHop c){

        String sql = "UPDATE chi_so_kham_tong_hop SET " +
                "nhiet_do=?,nhip_tim=?,nhip_tho=?,huyet_ap_tam_thu=?,can_nang=?,chieu_cao=?,ghi_chu=? " +
                "WHERE ma_phieu_kham=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setObject(1,c.getNhietDo());
            ps.setObject(2,c.getNhipTim());
            ps.setObject(3,c.getNhipTho());
            ps.setObject(4,c.getHuyetApTamThu());
            ps.setObject(5,c.getCanNang());
            ps.setObject(6,c.getChieuCao());
            ps.setString(7,c.getGhiChu());
            ps.setInt(8,c.getMaPhieuKham());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}