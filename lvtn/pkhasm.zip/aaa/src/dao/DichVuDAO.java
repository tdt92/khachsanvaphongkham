package dao;

import config.DBConnection;
import model.DichVu;

import java.sql.*;
import java.util.*;

public class DichVuDAO {

    public List<DichVu> getAll(){
        List<DichVu> list=new ArrayList<>();
        String sql="SELECT * FROM dich_vu";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery()){

            while(rs.next()){
                DichVu dv=new DichVu();
                dv.setMaDichVu(rs.getInt("ma_dich_vu"));
                dv.setTenDichVu(rs.getString("ten_dich_vu"));
                dv.setDonGia(rs.getBigDecimal("don_gia"));
                dv.setLoaiDichVu(rs.getString("loai_dich_vu"));
                dv.setPhong(rs.getInt("phong"));
                dv.setMaChuyenKhoa((Integer)rs.getObject("ma_chuyen_khoa"));
                list.add(dv);
            }

        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }

    public void insert(DichVu dv){
        String sql="INSERT INTO dich_vu(ten_dich_vu,don_gia,loai_dich_vu,phong,ma_chuyen_khoa) VALUES(?,?,?,?,?)";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){

            ps.setString(1,dv.getTenDichVu());
            ps.setBigDecimal(2,dv.getDonGia());
            ps.setString(3,dv.getLoaiDichVu());
            ps.setInt(4,dv.getPhong());

            if(dv.getMaChuyenKhoa()==null)
                ps.setNull(5,Types.INTEGER);
            else
                ps.setInt(5,dv.getMaChuyenKhoa());

            ps.executeUpdate();

        }catch(Exception e){ e.printStackTrace(); }
    }

    public void update(DichVu dv){
        String sql="UPDATE dich_vu SET ten_dich_vu=?,don_gia=?,loai_dich_vu=?,phong=?,ma_chuyen_khoa=? WHERE ma_dich_vu=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){

            ps.setString(1,dv.getTenDichVu());
            ps.setBigDecimal(2,dv.getDonGia());
            ps.setString(3,dv.getLoaiDichVu());
            ps.setInt(4,dv.getPhong());

            if(dv.getMaChuyenKhoa()==null)
                ps.setNull(5,Types.INTEGER);
            else
                ps.setInt(5,dv.getMaChuyenKhoa());

            ps.setInt(6,dv.getMaDichVu());

            ps.executeUpdate();

        }catch(Exception e){ e.printStackTrace(); }
    }

    public void delete(int id){
        String sql="DELETE FROM dich_vu WHERE ma_dich_vu=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,id);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public List<DichVu> search(String key){
        List<DichVu> list=new ArrayList<>();
        String sql="SELECT * FROM dich_vu WHERE ten_dich_vu LIKE ? OR ma_dich_vu LIKE ?";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){

            ps.setString(1,"%"+key+"%");
            ps.setString(2,"%"+key+"%");
            ResultSet rs=ps.executeQuery();

            while(rs.next()){
                DichVu dv=new DichVu();
                dv.setMaDichVu(rs.getInt("ma_dich_vu"));
                dv.setTenDichVu(rs.getString("ten_dich_vu"));
                dv.setDonGia(rs.getBigDecimal("don_gia"));
                dv.setLoaiDichVu(rs.getString("loai_dich_vu"));
                dv.setPhong(rs.getInt("phong"));
                dv.setMaChuyenKhoa((Integer)rs.getObject("ma_chuyen_khoa"));
                list.add(dv);
            }

        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }
    public DichVu getDichVuKhamByChuyenKhoa(int maChuyenKhoa){

        String sql = """
            SELECT *
            FROM dich_vu
            WHERE loai_dich_vu='KHAM_BENH'
            AND ma_chuyen_khoa=?
            LIMIT 1
        """;

        try(
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ){

            ps.setInt(1, maChuyenKhoa);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                DichVu dv = new DichVu();

                dv.setMaDichVu(rs.getInt("ma_dich_vu"));
                dv.setTenDichVu(rs.getString("ten_dich_vu"));
                dv.setDonGia(rs.getBigDecimal("don_gia"));
                dv.setLoaiDichVu(rs.getString("loai_dich_vu"));
                dv.setPhong(rs.getInt("phong"));
                dv.setMaChuyenKhoa(
                        rs.getInt("ma_chuyen_khoa")
                );

                return dv;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }
}
