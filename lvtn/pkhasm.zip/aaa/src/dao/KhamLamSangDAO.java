package dao;

import model.KhamLamSang;
import java.sql.*;

import config.DBConnection;

public class KhamLamSangDAO {

    public boolean insert(KhamLamSang k){

        String sql = "INSERT INTO kham_lam_sang " +
                "(ma_phieu_kham,ly_do_kham,tien_su_ban_than,benh_su,ket_qua_kham_can_lam_sang,kham_lam_sang) " +
                "VALUES(?,?,?,?,?,?)";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,k.getMaPhieuKham());
            ps.setString(2,k.getLyDoKham());
            ps.setString(3,k.getTienSuBanThan());
            ps.setString(4,k.getBenhSu());
            ps.setString(5,"");
            ps.setString(6,"");

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public KhamLamSang findByMaPhieu1(int maPhieu){

        String sql =
                "SELECT * FROM kham_lam_sang " +
                "WHERE ma_phieu_kham=?";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setInt(1, maPhieu);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                KhamLamSang k =
                        new KhamLamSang();

                // =========================================
                // THÔNG TIN CHUNG
                // =========================================

                k.setMaPhieuKham(
                        rs.getInt("ma_phieu_kham")
                );

                // =========================================
                // THÔNG TIN LÂM SÀNG
                // =========================================

                k.setLyDoKham(
                        rs.getString("ly_do_kham")
                );

                k.setBenhSu(
                        rs.getString("benh_su")
                );

                k.setTienSuBanThan(
                        rs.getString("tien_su_ban_than")
                );

                k.setKhamLamSang(
                        rs.getString("kham_lam_sang")
                );

               

                k.setChanDoanSoBo(
                        rs.getString("chan_doan_so_bo")
                );

                k.setLoiDanBacSi(
                        rs.getString("loi_dan_bac_si")
                );

                return k;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return null;
    }
    public KhamLamSang findByMaPhieu(int maPhieu){

        String sql = "SELECT * FROM kham_lam_sang WHERE ma_phieu_kham=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                KhamLamSang k = new KhamLamSang();

                k.setMaPhieuKham(maPhieu);
                k.setChanDoanSoBo(rs.getString("chan_doan_so_bo"));
                k.setLoiDanBacSi(rs.getString("loi_dan_bac_si"));

                return k;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }

    public boolean saveOrUpdate(KhamLamSang k){

        if(findByMaPhieu(k.getMaPhieuKham()) == null){

            String sql = """
                INSERT INTO kham_lam_sang
                (ma_phieu_kham, chan_doan_so_bo, loi_dan_bac_si,
                 ket_qua_kham_can_lam_sang, kham_lam_sang)
                VALUES (?,?,?,?,?)
            """;

            try(Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)){

                ps.setInt(1, k.getMaPhieuKham());
                ps.setString(2, k.getChanDoanSoBo());
                ps.setString(3, k.getLoiDanBacSi());
                ps.setString(4, "");
                ps.setString(5, "");

                return ps.executeUpdate() > 0;

            }catch(Exception e){
                e.printStackTrace();
            }

        } else {

            String sql = """
                UPDATE kham_lam_sang
                SET chan_doan_so_bo=?,
                    loi_dan_bac_si=?
                WHERE ma_phieu_kham=?
            """;

            try(Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)){

                ps.setString(1, k.getChanDoanSoBo());
                ps.setString(2, k.getLoiDanBacSi());
                ps.setInt(3, k.getMaPhieuKham());

                return ps.executeUpdate() > 0;

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public boolean update(KhamLamSang k){

        String sql = "UPDATE kham_lam_sang SET " +
                "ly_do_kham=?,tien_su_ban_than=?,benh_su=? " +
                "WHERE ma_phieu_kham=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1,k.getLyDoKham());
            ps.setString(2,k.getTienSuBanThan());
            ps.setString(3,k.getBenhSu());
            ps.setInt(4,k.getMaPhieuKham());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}