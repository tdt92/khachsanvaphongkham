package dao;

import config.DBConnection;
import model.LichTaiKham;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LichTaiKhamDAO {

    private LichTaiKham map(ResultSet rs) throws SQLException {
        LichTaiKham l = new LichTaiKham();

        l.setId(rs.getInt("id"));
        l.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
        l.setMaChuyenKhoa(rs.getInt("ma_chuyen_khoa"));
        l.setMaPhieuKham(rs.getObject("ma_phieu_kham") != null ?
                rs.getInt("ma_phieu_kham") : null);
        l.setMaNhanVien(rs.getInt("ma_nhan_vien"));
        l.setNgayTaiKham(rs.getDate("ngay_tai_kham"));
        l.setGhiChu(rs.getString("ghi_chu"));
        l.setTrangThai(rs.getString("trang_thai"));
        l.setDaGuiThongBao(rs.getBoolean("da_gui_thong_bao"));

        l.setTenBenhNhan(rs.getString("ho_ten_bn"));
        l.setTenChuyenKhoa(rs.getString("ten_chuyen_khoa"));
        l.setTenNhanVien(rs.getString("ho_ten_nv"));

        return l;
    }

    public List<LichTaiKham> getAll() {

        List<LichTaiKham> list = new ArrayList<>();

        String sql = """
            SELECT l.*, 
                   bn.ho_ten AS ho_ten_bn,
                   ck.ten_chuyen_khoa,
                   nv.ho_ten AS ho_ten_nv
            FROM lich_tai_kham l
            JOIN benh_nhan bn ON l.ma_benh_nhan = bn.ma_benh_nhan
            JOIN chuyen_khoa ck ON l.ma_chuyen_khoa = ck.ma_chuyen_khoa
            JOIN nhan_vien nv ON l.ma_nhan_vien = nv.ma_nhan_vien
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(map(rs));

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public List<LichTaiKham> search(String keyword) {

        List<LichTaiKham> list = new ArrayList<>();

        String sql = """
            SELECT l.*, 
                   bn.ho_ten AS ho_ten_bn,
                   ck.ten_chuyen_khoa,
                   nv.ho_ten AS ho_ten_nv
            FROM lich_tai_kham l
            JOIN benh_nhan bn ON l.ma_benh_nhan = bn.ma_benh_nhan
            JOIN chuyen_khoa ck ON l.ma_chuyen_khoa = ck.ma_chuyen_khoa
            JOIN nhan_vien nv ON l.ma_nhan_vien = nv.ma_nhan_vien
            WHERE bn.ho_ten LIKE ? OR l.ma_benh_nhan LIKE ?
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public void insert(LichTaiKham l) {
        String sql = """
            INSERT INTO lich_tai_kham
            (ma_benh_nhan,ma_chuyen_khoa,ma_phieu_kham,
             ma_nhan_vien,ngay_tai_kham,ghi_chu,trang_thai,da_gui_thong_bao)
            VALUES(?,?,?,?,?,?,?,?)
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, l.getMaBenhNhan());
            ps.setInt(2, l.getMaChuyenKhoa());
            ps.setObject(3, l.getMaPhieuKham());
            ps.setInt(4, l.getMaNhanVien());
            ps.setDate(5, l.getNgayTaiKham());
            ps.setString(6, l.getGhiChu());
            ps.setString(7, l.getTrangThai());
            ps.setBoolean(8, l.isDaGuiThongBao());

            ps.executeUpdate();

        } catch (Exception e) { e.printStackTrace(); }
    }

    public void update(LichTaiKham l) {
        String sql = """
            UPDATE lich_tai_kham
            SET ma_benh_nhan=?,ma_chuyen_khoa=?,ma_phieu_kham=?,
                ma_nhan_vien=?,ngay_tai_kham=?,ghi_chu=?,
                trang_thai=?,da_gui_thong_bao=?
            WHERE id=?
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, l.getMaBenhNhan());
            ps.setInt(2, l.getMaChuyenKhoa());
            ps.setObject(3, l.getMaPhieuKham());
            ps.setInt(4, l.getMaNhanVien());
            ps.setDate(5, l.getNgayTaiKham());
            ps.setString(6, l.getGhiChu());
            ps.setString(7, l.getTrangThai());
            ps.setBoolean(8, l.isDaGuiThongBao());
            ps.setInt(9, l.getId());

            ps.executeUpdate();

        } catch (Exception e) { e.printStackTrace(); }
    }

    public void delete(int id) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "DELETE FROM lich_tai_kham WHERE id=?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) { e.printStackTrace(); }
    }
}