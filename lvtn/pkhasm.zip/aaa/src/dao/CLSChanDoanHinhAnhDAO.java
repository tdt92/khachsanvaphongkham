package dao;

import config.DBConnection;
import model.CLSChanDoanHinhAnh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CLSChanDoanHinhAnhDAO {

    public List<CLSChanDoanHinhAnh> getAll(){

        List<CLSChanDoanHinhAnh> list =
                new ArrayList<>();

        String sql =
                "SELECT " +
                "pk.ma_phieu_kham, " +
                "ct.id AS id_chi_tiet_chi_dinh, " +
                "bn.ho_ten AS ten_benh_nhan, " +
                "ls.ly_do_kham, " +
                "cs.nhiet_do, " +
                "cs.chieu_cao, " +
                "cs.can_nang, " +
                "CONCAT(cs.huyet_ap_tam_thu,'/',cs.huyet_ap_tam_truong) AS huyet_ap " +
                "FROM phieu_kham pk " +

                "JOIN benh_nhan bn " +
                "ON pk.ma_benh_nhan = bn.ma_benh_nhan " +

                "LEFT JOIN kham_lam_sang ls " +
                "ON pk.ma_phieu_kham = ls.ma_phieu_kham " +

                "LEFT JOIN chi_so_kham_tong_hop cs " +
                "ON pk.ma_phieu_kham = cs.ma_phieu_kham " +

                "JOIN chi_tiet_chi_dinh ct " +
                "ON pk.ma_phieu_kham = ct.ma_phieu_kham " +

                "WHERE pk.trang_thai = 'CLS_CHAN_DOAN_HINH_ANH'";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ResultSet rs =
                        ps.executeQuery()
        ){

            while(rs.next()){

                CLSChanDoanHinhAnh c =
                        new CLSChanDoanHinhAnh();

                c.setMaPhieuKham(
                        rs.getInt("ma_phieu_kham")
                );

                c.setIdChiTietChiDinh(
                        rs.getInt("id_chi_tiet_chi_dinh")
                );

                c.setTenBenhNhan(
                        rs.getString("ten_benh_nhan")
                );

                c.setLyDoKham(
                        rs.getString("ly_do_kham")
                );

                c.setNhietDo(
                        rs.getDouble("nhiet_do")
                );

                c.setChieuCao(
                        rs.getDouble("chieu_cao")
                );

                c.setCanNang(
                        rs.getDouble("can_nang")
                );

                c.setHuyetAp(
                        rs.getString("huyet_ap")
                );

                list.add(c);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return list;
    }
}