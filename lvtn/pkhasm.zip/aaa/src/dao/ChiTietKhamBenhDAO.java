package dao;

import config.DBConnection;
import model.ChiTietKhamBenh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ChiTietKhamBenhDAO {

    public ChiTietKhamBenh getByMaPhieuKham(int maPhieuKham){

        ChiTietKhamBenh ct = null;

        String sql = """
            SELECT
                pk.ma_phieu_kham,
                bn.ho_ten,
                bn.cccd,
                nv.ho_ten AS ten_bac_si,
                ck.ten_chuyen_khoa,
                pk.ngay_kham,
                pk.trang_thai,

                kls.ly_do_kham,
                kls.tien_su_ban_than,
                kls.benh_su,
                kls.chan_doan_so_bo,
                kls.loi_dan_bac_si,
                kls.ket_qua_kham_can_lam_sang,
                kls.kham_lam_sang

            FROM phieu_kham pk

            JOIN benh_nhan bn
                ON pk.ma_benh_nhan = bn.ma_benh_nhan

            JOIN nhan_vien nv
                ON pk.ma_nhan_vien = nv.ma_nhan_vien

            LEFT JOIN chuyen_khoa ck
                ON pk.ma_chuyen_khoa = ck.ma_chuyen_khoa

            LEFT JOIN kham_lam_sang kls
                ON pk.ma_phieu_kham = kls.ma_phieu_kham

            WHERE pk.ma_phieu_kham = ?
        """;

        try(
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ){

            ps.setInt(1, maPhieuKham);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                ct = new ChiTietKhamBenh();

                ct.setMaPhieuKham(rs.getInt("ma_phieu_kham"));
                ct.setTenBenhNhan(rs.getString("ho_ten"));
                ct.setCccd(rs.getString("cccd"));
                ct.setTenBacSi(rs.getString("ten_bac_si"));
                ct.setChuyenKhoa(rs.getString("ten_chuyen_khoa"));
                ct.setNgayKham(rs.getTimestamp("ngay_kham"));
                ct.setTrangThai(rs.getString("trang_thai"));

                ct.setLyDoKham(rs.getString("ly_do_kham"));
                ct.setTienSuBanThan(rs.getString("tien_su_ban_than"));
                ct.setBenhSu(rs.getString("benh_su"));
                ct.setChanDoanSoBo(rs.getString("chan_doan_so_bo"));
                ct.setLoiDanBacSi(rs.getString("loi_dan_bac_si"));
                ct.setKetQuaCanLamSang(
                        rs.getString("ket_qua_kham_can_lam_sang"));
                ct.setKhamLamSang(rs.getString("kham_lam_sang"));
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return ct;
    }
}