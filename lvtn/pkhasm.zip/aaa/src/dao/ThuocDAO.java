package dao;

import config.DBConnection;
import model.Thuoc;

import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class ThuocDAO {

    private Thuoc map(ResultSet rs) throws Exception {
        Thuoc t = new Thuoc();
        t.setMaThuoc(rs.getInt("ma_thuoc"));
        t.setTenThuoc(rs.getString("ten_thuoc"));
        t.setHoatChat(rs.getString("hoat_chat"));
        t.setHamLuong(rs.getString("ham_luong"));
        t.setDangThuoc(rs.getString("dang_thuoc"));
        t.setLoaiThuoc(rs.getString("loai_thuoc"));
        t.setDonViTinh(rs.getString("don_vi_tinh"));
        t.setDonGiaNhap(rs.getBigDecimal("don_gia_nhap"));
        t.setDonGiaBan(rs.getBigDecimal("don_gia_ban"));
        t.setNgaySanXuat(rs.getDate("ngay_san_xuat"));
        t.setHanSuDung(rs.getDate("han_su_dung"));
        t.setNhaSanXuat(rs.getString("nha_san_xuat"));
        t.setNuocSanXuat(rs.getString("nuoc_san_xuat"));
        t.setGhiChu(rs.getString("ghi_chu"));
        return t;
    }

    public List<Thuoc> getAll() {
        List<Thuoc> list = new ArrayList<>();
        String sql = "SELECT * FROM thuoc";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public void insert(Thuoc t) {
        String sql = "INSERT INTO thuoc(ten_thuoc,hoat_chat,ham_luong,dang_thuoc,loai_thuoc,don_vi_tinh,don_gia_nhap,don_gia_ban,ngay_san_xuat,han_su_dung,nha_san_xuat,nuoc_san_xuat,ghi_chu) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setData(ps, t);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void update(Thuoc t) {
        String sql = "UPDATE thuoc SET ten_thuoc=?,hoat_chat=?,ham_luong=?,dang_thuoc=?,loai_thuoc=?,don_vi_tinh=?,don_gia_nhap=?,don_gia_ban=?,ngay_san_xuat=?,han_su_dung=?,nha_san_xuat=?,nuoc_san_xuat=?,ghi_chu=? WHERE ma_thuoc=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setData(ps, t);
            ps.setInt(14, t.getMaThuoc());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void delete(int id) {
        String sql = "DELETE FROM thuoc WHERE ma_thuoc=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<Thuoc> search(String keyword) {
        List<Thuoc> list = new ArrayList<>();
        String sql = "SELECT * FROM thuoc WHERE ten_thuoc LIKE ? OR ma_thuoc LIKE ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));

        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    private void setData(PreparedStatement ps, Thuoc t) throws Exception {
        ps.setString(1, t.getTenThuoc());
        ps.setString(2, t.getHoatChat());
        ps.setString(3, t.getHamLuong());
        ps.setString(4, t.getDangThuoc());
        ps.setString(5, t.getLoaiThuoc());
        ps.setString(6, t.getDonViTinh());
        ps.setBigDecimal(7, t.getDonGiaNhap());
        ps.setBigDecimal(8, t.getDonGiaBan());
        ps.setDate(9, t.getNgaySanXuat());
        ps.setDate(10, t.getHanSuDung());
        ps.setString(11, t.getNhaSanXuat());
        ps.setString(12, t.getNuocSanXuat());
        ps.setString(13, t.getGhiChu());
    }
}
