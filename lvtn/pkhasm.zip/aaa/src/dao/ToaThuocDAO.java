package dao;

import config.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

public class ToaThuocDAO {

    public int createToaThuoc(int maPhieuKham){

        int generatedId = -1;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO toa_thuoc(ma_phieu_kham) VALUES(?)";

            PreparedStatement ps =
                    con.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS
                    );

            ps.setInt(1, maPhieuKham);

            ps.executeUpdate();

            ResultSet rs =
                    ps.getGeneratedKeys();

            if(rs.next()){

                generatedId = rs.getInt(1);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return generatedId;
    }
    public int findByMaPhieuKham(int maPhieu){

        int maToa = -1;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT ma_toa_thuoc " +
                    "FROM toa_thuoc " +
                    "WHERE ma_phieu_kham=? " +
                    "LIMIT 1";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhieu);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                maToa = rs.getInt("ma_toa_thuoc");
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return maToa;
    }
}