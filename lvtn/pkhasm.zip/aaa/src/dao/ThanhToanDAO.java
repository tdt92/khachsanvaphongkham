package dao;

import config.DBConnection;

import java.sql.*;
import java.util.*;

public class ThanhToanDAO {

    public List<Object[]> getDanhSachChoThanhToan(){

        List<Object[]> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT pk.ma_phieu_kham," +
                            "bn.ho_ten," +
                            "pk.ngay_kham " +
                    "FROM phieu_kham pk " +
                    "JOIN benh_nhan bn " +
                    "ON pk.ma_benh_nhan=bn.ma_benh_nhan " +
                    "WHERE pk.trang_thai='KHAM_XONG'";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(new Object[]{

                        rs.getInt(1),
                        rs.getString(2),
                        rs.getTimestamp(3)
                });
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
}