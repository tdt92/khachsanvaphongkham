package dao;

import config.DBConnection;
import config.Session;
import java.sql.*;

public class PhieuKhamDAO {

    public int createPhieuKham(int maDangKy){

        try(Connection con = DBConnection.getConnection()){

            // 1. Lấy mã bệnh nhân từ đăng ký
            String sqlGet = """
                SELECT ma_benh_nhan, ma_chuyen_khoa
                FROM dang_ky_kham_benh
                WHERE id = ?
            """;

            PreparedStatement psGet = con.prepareStatement(sqlGet);
            psGet.setInt(1, maDangKy);
            ResultSet rsGet = psGet.executeQuery();

            if(!rsGet.next())
                return -1;

            int maBenhNhan = rsGet.getInt("ma_benh_nhan");
            int maChuyenKhoa = rsGet.getInt("ma_chuyen_khoa");

            int maNhanVien = Session.currentUser.getMaNhanVien();

            // 2. Insert phiếu khám đầy đủ
            String sqlInsert = """
                INSERT INTO phieu_kham
                (ma_benh_nhan, ma_nhan_vien, ma_chuyen_khoa, ngay_kham)
                VALUES (?, ?, ?, NOW())
            """;

            PreparedStatement psInsert = con.prepareStatement(
                    sqlInsert, Statement.RETURN_GENERATED_KEYS);

            psInsert.setInt(1, maBenhNhan);
            psInsert.setInt(2, maNhanVien);
            psInsert.setInt(3, maChuyenKhoa);

            psInsert.executeUpdate();

            ResultSet rs = psInsert.getGeneratedKeys();
            if(rs.next())
                return rs.getInt(1);

        }catch(Exception e){
            e.printStackTrace();
        }

        return -1;
    }

    public boolean updateTrangThai(
            int maPhieu,
            String trangThai
    ){

        String sql =
                "UPDATE phieu_kham " +
                "SET trang_thai = ? " +
                "WHERE ma_phieu_kham = ?";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setString(1,trangThai);

            ps.setInt(2,maPhieu);

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
    
    public int createPhieuChiDinh(
            int maPhieuKham
    ){

        String sql =
                "INSERT INTO phieu_chi_dinh(" +
                "ma_phieu_kham," +
                "ngay_chi_dinh," +
                "ma_nhan_vien_chi_dinh" +
                ") VALUES(?,?,?)";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(
                                sql,
                                Statement.RETURN_GENERATED_KEYS
                        )
        ){

            ps.setInt(1,maPhieuKham);

            ps.setTimestamp(
                    2,
                    new Timestamp(
                            System.currentTimeMillis()
                    )
            );

            // nhân viên/bác sĩ đang chỉ định
            ps.setInt(
                    3,
                    Session.currentUser.getMaNhanVien()
            );

            ps.executeUpdate();

            ResultSet rs =
                    ps.getGeneratedKeys();

            if(rs.next()){

                return rs.getInt(1);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return -1;
    }
    public boolean checkDaChiDinhDichVu(
            int maPhieuKham,
            int maDichVu
    ){

        String sql =
                """
                SELECT ctd.id
                FROM chi_tiet_chi_dinh ctd
                JOIN phieu_chi_dinh pcd
                    ON ctd.ma_phieu_chi_dinh = pcd.ma_phieu_chi_dinh
                WHERE pcd.ma_phieu_kham = ?
                AND ctd.ma_dich_vu = ?
                LIMIT 1
                """;

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setInt(1,maPhieuKham);

            ps.setInt(2,maDichVu);

            ResultSet rs =
                    ps.executeQuery();

            return rs.next();

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
    
    public boolean insertChiTietChiDinh(
            int maPhieuChiDinh,
            int maDichVu
    ){

        String sql =
                "INSERT INTO chi_tiet_chi_dinh(" +
                "ma_phieu_chi_dinh," +
                "ma_dich_vu," +
                "so_luong," +
                "don_gia," +
                "trang_thai_dv" +
                ") VALUES(?,?,?,?,?)";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setInt(1,maPhieuChiDinh);

            ps.setInt(2,maDichVu);

            ps.setInt(3,1);

            ps.setDouble(4,200000);

            ps.setString(
                    5,
                    "CHUA_THUC_HIEN"
            );

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
    
    
    public boolean updateDangKyWithPhieu(int maDangKy, int maPhieuKham){

        String sql = """
            UPDATE dang_ky_kham_benh
            SET ma_phieu_kham = ?, trang_thai = 'DANG_KHAM'
            WHERE id = ?
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, maPhieuKham);
            ps.setInt(2, maDangKy);

            return ps.executeUpdate() > 0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public int createPhieuKham1(int maDangKy) {

        String sql = """
            INSERT INTO phieu_kham (ngay_kham)
            VALUES (NOW())
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();

            if (rs.next()) {
                int maPhieu = rs.getInt(1);

                // Cập nhật lại bảng đăng ký
                String update = """
                    UPDATE dang_ky_kham_benh
                    SET ma_phieu_kham = ?
                    WHERE id = ?
                """;

                PreparedStatement ps2 = con.prepareStatement(update);
                ps2.setInt(1, maPhieu);
                ps2.setInt(2, maDangKy);
                ps2.executeUpdate();

                return maPhieu;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }
 // =====================================================
 // CẬP NHẬT BÁC SĨ KHÁM
 // =====================================================

 public boolean updateBacSiKham(
         int maPhieuKham,
         int maNhanVien
 ){

     String sql =
             "UPDATE phieu_kham " +
             "SET ma_nhan_vien = ? " +
             "WHERE ma_phieu_kham = ?";

     try(
             Connection con = DBConnection.getConnection();

             PreparedStatement ps =
                     con.prepareStatement(sql)
     ){

         ps.setInt(1, maNhanVien);

         ps.setInt(2, maPhieuKham);

         return ps.executeUpdate() > 0;

     }catch(Exception ex){

         ex.printStackTrace();
     }

     return false;
 }
 public boolean chuyenChuyenKhoa(
	        int maPhieu,
	        int maChuyenKhoa,
	        String ghiChu
	){

	    Connection con = null;

	    try{

	        con = DBConnection.getConnection();

	        con.setAutoCommit(false);

	        // =====================================
	        // UPDATE PHIEU_KHAM
	        // =====================================

	        String sqlPK =
	                "UPDATE phieu_kham " +
	                "SET ma_chuyen_khoa = ?, " +
	                "ghi_chu = ?, " +
	                "trang_thai = ? " +
	                "WHERE ma_phieu_kham = ?";

	        PreparedStatement ps1 =
	                con.prepareStatement(sqlPK);

	        ps1.setInt(1, maChuyenKhoa);

	        ps1.setString(2, ghiChu);

	        ps1.setString(3, "DANG_KHAM");

	        ps1.setInt(4, maPhieu);

	        int r1 = ps1.executeUpdate();

	        // =====================================
	        // UPDATE DANG_KY_KHAM_BENH
	        // =====================================

	        String sqlDK =
	                "UPDATE dang_ky_kham_benh " +
	                "SET ma_chuyen_khoa = ? " +
	                "WHERE ma_phieu_kham = ?";

	        PreparedStatement ps2 =
	                con.prepareStatement(sqlDK);

	        ps2.setInt(1, maChuyenKhoa);

	        ps2.setInt(2, maPhieu);

	        int r2 = ps2.executeUpdate();

	        // =====================================
	        // COMMIT
	        // =====================================

	        if(r1 > 0){

	            con.commit();

	            return true;

	        }else{

	            con.rollback();
	        }

	    }catch(Exception e){

	        e.printStackTrace();

	        try{

	            if(con != null){
	                con.rollback();
	            }

	        }catch(Exception ex){
	            ex.printStackTrace();
	        }

	    }finally{

	        try{

	            if(con != null){

	                con.setAutoCommit(true);

	                con.close();
	            }

	        }catch(Exception e){
	            e.printStackTrace();
	        }
	    }

	    return false;
	}
}