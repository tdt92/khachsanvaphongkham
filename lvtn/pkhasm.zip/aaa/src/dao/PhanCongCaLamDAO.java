package dao;

import config.DBConnection;
import model.PhanCongCaLam;

import java.sql.*;
import java.util.*;

public class PhanCongCaLamDAO {

    public List<PhanCongCaLam> getAll(){
        List<PhanCongCaLam> list=new ArrayList<>();
        String sql="""
            SELECT pc.*, nv.ho_ten
            FROM bang_phan_cong_ca_lam pc
            JOIN nhan_vien nv ON pc.ma_nhan_vien = nv.ma_nhan_vien
        """;

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery()){

            while(rs.next()){
                PhanCongCaLam p=new PhanCongCaLam();
                p.setId(rs.getInt("id"));
                p.setMaNhanVien(rs.getInt("ma_nhan_vien"));
                p.setTenNhanVien(rs.getString("ho_ten"));
                p.setPhong(rs.getString("phong"));
                p.setGioLam(rs.getTime("gio_lam"));
                p.setGioKetThuc(rs.getTime("gio_ket_thuc"));
                p.setThu(rs.getString("thu"));
                list.add(p);
            }

        }catch(Exception e){ e.printStackTrace(); }
        return list;
    }

    public void insert(PhanCongCaLam p){
        String sql="INSERT INTO bang_phan_cong_ca_lam(ma_nhan_vien,phong,gio_lam,gio_ket_thuc,thu) VALUES(?,?,?,?,?)";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,p.getMaNhanVien());
            ps.setString(2,p.getPhong());
            ps.setTime(3,p.getGioLam());
            ps.setTime(4,p.getGioKetThuc());
            ps.setString(5,p.getThu());
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void update(PhanCongCaLam p){
        String sql="UPDATE bang_phan_cong_ca_lam SET ma_nhan_vien=?, phong=?, gio_lam=?, gio_ket_thuc=?, thu=? WHERE id=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,p.getMaNhanVien());
            ps.setString(2,p.getPhong());
            ps.setTime(3,p.getGioLam());
            ps.setTime(4,p.getGioKetThuc());
            ps.setString(5,p.getThu());
            ps.setInt(6,p.getId());
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void delete(int id){
        String sql="DELETE FROM bang_phan_cong_ca_lam WHERE id=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,id);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public List<PhanCongCaLam> search(String key){
        List<PhanCongCaLam> list=new ArrayList<>();
        String sql="""
            SELECT pc.*, nv.ho_ten
            FROM bang_phan_cong_ca_lam pc
            JOIN nhan_vien nv ON pc.ma_nhan_vien = nv.ma_nhan_vien
            WHERE nv.ho_ten LIKE ? OR pc.ma_nhan_vien LIKE ?
        """;

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setString(1,"%"+key+"%");
            ps.setString(2,"%"+key+"%");
            ResultSet rs=ps.executeQuery();

            while(rs.next()){
                PhanCongCaLam p=new PhanCongCaLam();
                p.setId(rs.getInt("id"));
                p.setMaNhanVien(rs.getInt("ma_nhan_vien"));
                p.setTenNhanVien(rs.getString("ho_ten"));
                p.setPhong(rs.getString("phong"));
                p.setGioLam(rs.getTime("gio_lam"));
                p.setGioKetThuc(rs.getTime("gio_ket_thuc"));
                p.setThu(rs.getString("thu"));
                list.add(p);
            }
        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }
}
