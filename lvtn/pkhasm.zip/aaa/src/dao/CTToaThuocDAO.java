package dao;

import config.DBConnection;
import model.CTToaThuoc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CTToaThuocDAO {

    public boolean insert(CTToaThuoc ct){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO ct_toa_thuoc(" +
                            "ma_toa_thuoc," +
                            "ma_thuoc," +
                            "lieu_dung," +
                            "sang," +
                            "trua," +
                            "chieu," +
                            "toi," +
                            "so_ngay," +
                            "cach_dung," +
                            "thoi_diem_dung" +
                            ") VALUES(?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, ct.getMaToaThuoc());
            ps.setInt(2, ct.getMaThuoc());
            ps.setString(3, ct.getLieuDung());
            ps.setString(4, ct.getSang());
            ps.setString(5, ct.getTrua());
            ps.setString(6, ct.getChieu());
            ps.setString(7, ct.getToi());
            ps.setInt(8, ct.getSoNgay());
            ps.setString(9, ct.getCachDung());
            ps.setString(10, ct.getThoiDiemDung());

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }
    public List<Object[]> getByMaToaThuoc(int maToaThuoc){

        List<Object[]> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT t.ten_thuoc," +
                            "ct.sang," +
                            "ct.trua," +
                            "ct.chieu," +
                            "ct.toi," +
                            "ct.so_ngay," +
                            "ct.cach_dung," +
                            "ct.thoi_diem_dung " +
                    "FROM ct_toa_thuoc ct " +
                    "JOIN thuoc t " +
                    "ON ct.ma_thuoc=t.ma_thuoc " +
                    "WHERE ct.ma_toa_thuoc=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maToaThuoc);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(new Object[]{

                        rs.getString("ten_thuoc"),

                        rs.getString("sang"),

                        rs.getString("trua"),

                        rs.getString("chieu"),

                        rs.getString("toi"),

                        rs.getInt("so_ngay"),

                        rs.getString("cach_dung"),

                        rs.getString("thoi_diem_dung")
                });
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
    public void deleteByMaToaThuoc(int maToaThuoc){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "DELETE FROM ct_toa_thuoc " +
                    "WHERE ma_toa_thuoc=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maToaThuoc);

            ps.executeUpdate();

        }catch(Exception e){

            e.printStackTrace();
        }
    }
}