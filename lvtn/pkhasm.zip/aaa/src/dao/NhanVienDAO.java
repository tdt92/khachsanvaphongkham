package dao;

import config.DBConnection;
import model.NhanVien;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    // ===================== GET ALL =====================
    public List<NhanVien> getAll() {

        List<NhanVien> list = new ArrayList<>();
        String sql = "SELECT * FROM nhan_vien";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public boolean updateSDT(int maNV, String sdt){

        String sql = "UPDATE nhan_vien SET so_dien_thoai=? WHERE ma_nhan_vien=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1,sdt);
            ps.setInt(2,maNV);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public int getMaChuyenKhoaByNhanVien(int maNhanVien){

        String sql = "SELECT ma_chuyen_khoa FROM nhan_vien WHERE ma_nhan_vien=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,maNhanVien);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                return rs.getInt("ma_chuyen_khoa");
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return -1;
    }
    public String getChuyenKhoaByMaNV(int maNhanVien){

        String sql = "SELECT chuyen_khoa FROM nhan_vien WHERE ma_nhan_vien=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,maNhanVien);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                return rs.getString("chuyen_khoa");
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }
    // ===================== GET BY CHUYEN KHOA =====================
    public List<NhanVien> getByChuyenKhoa(String tenCK) {

        List<NhanVien> list = new ArrayList<>();
        String sql = "SELECT * FROM nhan_vien WHERE chuyen_khoa = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, tenCK);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ===================== INSERT =====================
    public void insert(NhanVien nv) {

        String sql = "INSERT INTO nhan_vien(ho_ten,gioi_tinh,ngay_sinh,dia_chi,so_dien_thoai,email,chuyen_khoa,bang_cap,chuc_vu,ngay_vao_lam,cccd) "
                + "VALUES(?,?,?,?,?,?,?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nv.getHoTen());
            ps.setInt(2, nv.getGioiTinh());
            ps.setDate(3, nv.getNgaySinh());
            ps.setString(4, nv.getDiaChi());
            ps.setString(5, nv.getSoDienThoai());
            ps.setString(6, nv.getEmail());
            ps.setString(7, nv.getChuyenKhoa());
            ps.setString(8, nv.getBangCap());
            ps.setString(9, nv.getChucVu());
            ps.setDate(10, nv.getNgayVaoLam());
            ps.setString(11, nv.getCccd());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===================== UPDATE =====================
    public void update(NhanVien nv) {

        String sql = "UPDATE nhan_vien SET ho_ten=?,gioi_tinh=?,ngay_sinh=?,dia_chi=?,"
                + "so_dien_thoai=?,email=?,chuyen_khoa=?,bang_cap=?,chuc_vu=?,"
                + "ngay_vao_lam=?,cccd=? WHERE ma_nhan_vien=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nv.getHoTen());
            ps.setInt(2, nv.getGioiTinh());
            ps.setDate(3, nv.getNgaySinh());
            ps.setString(4, nv.getDiaChi());
            ps.setString(5, nv.getSoDienThoai());
            ps.setString(6, nv.getEmail());
            ps.setString(7, nv.getChuyenKhoa());
            ps.setString(8, nv.getBangCap());
            ps.setString(9, nv.getChucVu());
            ps.setDate(10, nv.getNgayVaoLam());
            ps.setString(11, nv.getCccd());
            ps.setInt(12, nv.getMaNhanVien());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===================== DELETE =====================
    public void delete(int id) {

        String sql = "DELETE FROM nhan_vien WHERE ma_nhan_vien = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===================== MAP RESULTSET =====================
    private NhanVien map(ResultSet rs) throws SQLException {

        NhanVien nv = new NhanVien();

        nv.setMaNhanVien(rs.getInt("ma_nhan_vien"));
        nv.setHoTen(rs.getString("ho_ten"));
        nv.setGioiTinh(rs.getInt("gioi_tinh"));
        nv.setNgaySinh(rs.getDate("ngay_sinh"));
        nv.setDiaChi(rs.getString("dia_chi"));
        nv.setSoDienThoai(rs.getString("so_dien_thoai"));
        nv.setEmail(rs.getString("email"));
        nv.setChuyenKhoa(rs.getString("chuyen_khoa"));
        nv.setBangCap(rs.getString("bang_cap"));
        nv.setChucVu(rs.getString("chuc_vu"));
        nv.setNgayVaoLam(rs.getDate("ngay_vao_lam"));
        nv.setCccd(rs.getString("cccd"));

        return nv;
    }
}