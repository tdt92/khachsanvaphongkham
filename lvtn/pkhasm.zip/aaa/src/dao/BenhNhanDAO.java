package dao;

import model.BenhNhan;
import config.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BenhNhanDAO {

    public List<BenhNhan> getAll(){
        List<BenhNhan> list=new ArrayList<>();
        String sql="SELECT * FROM benh_nhan";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery()){

            while(rs.next()){
                BenhNhan bn=map(rs);
                list.add(bn);
            }
        }catch(Exception e){ e.printStackTrace(); }
        return list;
    }

	/*
	 * public List<BenhNhan> searchByName(String name){ List<BenhNhan> list=new
	 * ArrayList<>(); String sql="SELECT * FROM benh_nhan WHERE ho_ten LIKE OR?";
	 * 
	 * try(Connection con=DBConnection.getConnection(); PreparedStatement
	 * ps=con.prepareStatement(sql)){
	 * 
	 * ps.setString(1,"%"+name+"%"); ResultSet rs=ps.executeQuery();
	 * 
	 * while(rs.next()){ list.add(map(rs)); } }catch(Exception e){
	 * e.printStackTrace(); } return list; }
	 */
    public boolean existsCCCD(String cccd){
        String sql="SELECT COUNT(*) FROM benh_nhan WHERE cccd=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){

            ps.setString(1,cccd);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1)>0;
            }
        }catch(Exception e){ e.printStackTrace(); }
        return false;
    }

    public void insert(BenhNhan bn){
        String sql="INSERT INTO benh_nhan(ho_ten,ngay_sinh,dia_chi,so_dien_thoai,email,nghe_nghiep,nhom_mau,di_ung_thuoc,nguoi_giam_ho,so_dien_thoai_nguoi_giam_ho,ghi_chu,cccd,gioi_tinh) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            setData(ps,bn);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void update(BenhNhan bn){
        String sql="UPDATE benh_nhan SET ho_ten=?,ngay_sinh=?,dia_chi=?,so_dien_thoai=?,email=?,nghe_nghiep=?,nhom_mau=?,di_ung_thuoc=?,nguoi_giam_ho=?,so_dien_thoai_nguoi_giam_ho=?,ghi_chu=?,cccd=?,gioi_tinh=? WHERE ma_benh_nhan=?";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            setData(ps,bn);
            ps.setInt(14,bn.getMaBenhNhan());
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void delete(int id){
        String sql="DELETE FROM benh_nhan WHERE ma_benh_nhan=?";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,id);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    private BenhNhan map(ResultSet rs)throws Exception{
        BenhNhan bn=new BenhNhan();
        bn.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
        bn.setHoTen(rs.getString("ho_ten"));
        bn.setNgaySinh(rs.getDate("ngay_sinh"));
        bn.setDiaChi(rs.getString("dia_chi"));
        bn.setSoDienThoai(rs.getString("so_dien_thoai"));
        bn.setEmail(rs.getString("email"));
        bn.setNgheNghiep(rs.getString("nghe_nghiep"));
        bn.setNhomMau(rs.getString("nhom_mau"));
        bn.setDiUngThuoc(rs.getString("di_ung_thuoc"));
        bn.setNguoiGiamHo(rs.getString("nguoi_giam_ho"));
        bn.setSoDienThoaiNguoiGiamHo(rs.getString("so_dien_thoai_nguoi_giam_ho"));
        bn.setGhiChu(rs.getString("ghi_chu"));
        bn.setCccd(rs.getString("cccd"));
        bn.setGioiTinh(rs.getInt("gioi_tinh"));
        return bn;
    }
    public List<BenhNhan> searchByName(String keyword){
        List<BenhNhan> list = new ArrayList<>();
        String sql = "SELECT * FROM benh_nhan WHERE ho_ten LIKE ? ";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1,  keyword );

            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                list.add(map(rs));
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
    public BenhNhan getById(int maBenhNhan){

        String sql = "SELECT * FROM benh_nhan WHERE ma_benh_nhan=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,maBenhNhan);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                BenhNhan bn = new BenhNhan();

                bn.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
                bn.setHoTen(rs.getString("ho_ten"));
                bn.setGioiTinh(rs.getInt("gioi_tinh"));
                bn.setSoDienThoai(rs.getString("so_dien_thoai"));
                bn.setCccd(rs.getString("cccd"));
                bn.setNgaySinh(rs.getDate("ngay_sinh"));

                return bn;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }
    public BenhNhan findByCCCD(String cccd){

        String sql =
                "SELECT * FROM benh_nhan WHERE cccd=?";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setString(1, cccd);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                BenhNhan b =
                        new BenhNhan();

                b.setMaBenhNhan(
                        rs.getInt("ma_benh_nhan")
                );

                b.setHoTen(
                        rs.getString("ho_ten")
                );

                b.setCccd(
                        rs.getString("cccd")
                );

                return b;
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return null;
    }
    private void setData(PreparedStatement ps,BenhNhan bn)throws Exception{
        ps.setString(1,bn.getHoTen());
        ps.setDate(2,bn.getNgaySinh());
        ps.setString(3,bn.getDiaChi());
        ps.setString(4,bn.getSoDienThoai());
        ps.setString(5,bn.getEmail());
        ps.setString(6,bn.getNgheNghiep());
        ps.setString(7,bn.getNhomMau());
        ps.setString(8,bn.getDiUngThuoc());
        ps.setString(9,bn.getNguoiGiamHo());
        ps.setString(10,bn.getSoDienThoaiNguoiGiamHo());
        ps.setString(11,bn.getGhiChu());
        ps.setString(12,bn.getCccd());
        ps.setInt(13,bn.getGioiTinh());
    }
}
