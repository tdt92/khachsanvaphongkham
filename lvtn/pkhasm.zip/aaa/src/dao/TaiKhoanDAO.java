package dao;

import model.TaiKhoan;
import model.NhanVien;
import config.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDAO {

    public List<TaiKhoan> getAll(){
        List<TaiKhoan> list=new ArrayList<>();
        try(Connection con=DBConnection.getConnection()){
            String sql="select * from tai_khoan";
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();

            while(rs.next()){
                TaiKhoan tk=new TaiKhoan();
                tk.setMaTaiKhoan(rs.getInt("ma_tai_khoan"));
                tk.setUsername(rs.getString("username"));
                tk.setEmail(rs.getString("email"));
                tk.setMatKhau(rs.getString("mat_khau"));
                tk.setMaNhanVien(rs.getInt("ma_nhan_vien"));
                tk.setVaiTro(rs.getString("vai_tro"));
                tk.setLanDauDangNhap(rs.getBoolean("lan_dau_dang_nhap"));
                list.add(tk);
            }
        }catch(Exception e){e.printStackTrace();}
        return list;
    }

    public List<String> getVaiTro(){
        List<String> list=new ArrayList<>();
        try(Connection con=DBConnection.getConnection()){
            String sql="select ma_vai_tro from vai_tro";
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                list.add(rs.getString(1));
            }
        }catch(Exception e){e.printStackTrace();}
        return list;
    }
    public boolean updateThongTinCaNhan(int maTK, String email, String matKhau){

        String sql = "UPDATE tai_khoan SET email=?, mat_khau=? WHERE ma_tai_khoan=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1,email);
            ps.setString(2,matKhau);
            ps.setInt(3,maTK);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public TaiKhoan dangNhap(String user, String pass) {

        try (Connection con = DBConnection.getConnection()) {

            String sql =
            "SELECT * FROM tai_khoan WHERE username=? AND mat_khau=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, user);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                TaiKhoan tk = new TaiKhoan();

                tk.setMaTaiKhoan(rs.getInt("ma_tai_khoan"));
                tk.setUsername(rs.getString("username"));
                tk.setEmail(rs.getString("email"));
                tk.setMatKhau(rs.getString("mat_khau"));
                tk.setMaNhanVien(rs.getInt("ma_nhan_vien"));
                tk.setVaiTro(rs.getString("vai_tro"));
                tk.setLanDauDangNhap(rs.getBoolean("lan_dau_dang_nhap"));

                return tk;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public void insert(TaiKhoan tk){
        try(Connection con=DBConnection.getConnection()){
            String sql="insert into tai_khoan(username,email,mat_khau,ma_nhan_vien,vai_tro,lan_dau_dang_nhap) values(?,?,?,?,?,?)";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,tk.getUsername());
            ps.setString(2,tk.getEmail());
            ps.setString(3,tk.getMatKhau());
            ps.setInt(4,tk.getMaNhanVien());
            ps.setString(5,tk.getVaiTro());
            ps.setBoolean(6,tk.isLanDauDangNhap());
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }

    public void update(TaiKhoan tk){
        try(Connection con=DBConnection.getConnection()){
            String sql="update tai_khoan set username=?,email=?,mat_khau=?,ma_nhan_vien=?,vai_tro=?,lan_dau_dang_nhap=? where ma_tai_khoan=?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,tk.getUsername());
            ps.setString(2,tk.getEmail());
            ps.setString(3,tk.getMatKhau());
            ps.setInt(4,tk.getMaNhanVien());
            ps.setString(5,tk.getVaiTro());
            ps.setBoolean(6,tk.isLanDauDangNhap());
            ps.setInt(7,tk.getMaTaiKhoan());
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }

    public void delete(int id){
        try(Connection con=DBConnection.getConnection()){
            String sql="delete from tai_khoan where ma_tai_khoan=?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setInt(1,id);
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }

    // ================= THÊM MỚI =================
    public List<NhanVien> getNhanVienChuaCoTaiKhoan(){

        List<NhanVien> list = new ArrayList<>();

        String sql =
                "SELECT nv.* " +
                "FROM nhan_vien nv " +
                "LEFT JOIN tai_khoan tk " +
                "ON nv.ma_nhan_vien = tk.ma_nhan_vien " +
                "WHERE tk.ma_nhan_vien IS NULL";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            while(rs.next()){

                NhanVien nv = new NhanVien();
                nv.setMaNhanVien(rs.getInt("ma_nhan_vien"));
                nv.setHoTen(rs.getString("ho_ten"));
                nv.setEmail(rs.getString("email"));

                list.add(nv);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
}