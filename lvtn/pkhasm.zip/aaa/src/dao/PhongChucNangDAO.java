package dao;

import model.PhongChucNang;
import config.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PhongChucNangDAO {

    public List<PhongChucNang> getAll(){
        List<PhongChucNang> list = new ArrayList<>();
        try(Connection con = DBConnection.getConnection()){
            String sql = "SELECT * FROM phong_chuc_nang";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                list.add(new PhongChucNang(
                        rs.getInt("ma_phong"),
                        rs.getString("ten_phong"),
                        rs.getString("loai_phong")
                ));
            }
        }catch(Exception e){ e.printStackTrace(); }
        return list;
    }

    public boolean isTenPhongExist(String ten){
        try(Connection con = DBConnection.getConnection()){
            String sql = "SELECT COUNT(*) FROM phong_chuc_nang WHERE LOWER(ten_phong)=LOWER(?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,ten);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1) > 0;
            }
        }catch(Exception e){ e.printStackTrace(); }
        return false;
    }

    public void insert(PhongChucNang p){
        try(Connection con = DBConnection.getConnection()){
            String sql = "INSERT INTO phong_chuc_nang(ten_phong,loai_phong) VALUES(?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,p.getTenPhong());
            ps.setString(2,p.getLoaiPhong());
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void update(PhongChucNang p){
        try(Connection con = DBConnection.getConnection()){
            String sql = "UPDATE phong_chuc_nang SET ten_phong=?, loai_phong=? WHERE ma_phong=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,p.getTenPhong());
            ps.setString(2,p.getLoaiPhong());
            ps.setInt(3,p.getMaPhong());
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public void delete(int id){
        try(Connection con = DBConnection.getConnection()){
            String sql = "DELETE FROM phong_chuc_nang WHERE ma_phong=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1,id);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace(); }
    }

    public List<PhongChucNang> search(String keyword){
        List<PhongChucNang> list = new ArrayList<>();
        try(Connection con = DBConnection.getConnection()){
            String sql = "SELECT * FROM phong_chuc_nang WHERE ma_phong LIKE ? OR ten_phong LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,"%"+keyword+"%");
            ps.setString(2,"%"+keyword+"%");
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                list.add(new PhongChucNang(
                        rs.getInt("ma_phong"),
                        rs.getString("ten_phong"),
                        rs.getString("loai_phong")
                ));
            }
        }catch(Exception e){ e.printStackTrace(); }
        return list;
    }
}