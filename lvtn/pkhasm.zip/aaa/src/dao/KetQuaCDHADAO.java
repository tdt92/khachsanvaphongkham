package dao;

import config.DBConnection;
import model.KetQuaCDHA;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class KetQuaCDHADAO {

    public boolean insert(KetQuaCDHA kq){

        String sql =
                "INSERT INTO ket_qua_cdha(" +
                        "id_chi_tiet_chi_dinh," +
                        "mo_ta_hinh_anh," +
                        "ket_luan," +
                        "de_nghi," +
                        "duong_dan_anh_1," +
                        "duong_dan_anh_2," +
                        "ma_nhan_vien_thuc_hien" +
                        ") VALUES(?,?,?,?,?,?,?)";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setInt(
                    1,
                    kq.getIdChiTietChiDinh()
            );

            ps.setString(
                    2,
                    kq.getMoTaHinhAnh()
            );

            ps.setString(
                    3,
                    kq.getKetLuan()
            );

            ps.setString(
                    4,
                    kq.getDeNghi()
            );

            ps.setString(
                    5,
                    kq.getDuongDanAnh1()
            );

            ps.setString(
                    6,
                    kq.getDuongDanAnh2()
            );

            ps.setInt(
                    7,
                    kq.getMaNhanVienThucHien()
            );

            return ps.executeUpdate() > 0;

        }catch (Exception e){
            e.printStackTrace();
        }

        return false;
    }
}