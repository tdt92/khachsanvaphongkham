package dao;

import config.DBConnection;
import model.LichSuKhamBenh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LichSuKhamBenhDAO {

    public List<LichSuKhamBenh> search(String keyword){

        List<LichSuKhamBenh> list = new ArrayList<>();

        String sql = """
            SELECT
                pk.ma_phieu_kham,
                bn.ho_ten,
                bn.cccd,
                nv.ho_ten AS ten_bac_si,
                ck.ten_chuyen_khoa,
                pk.ngay_kham,
                pk.trang_thai,
                pk.ghi_chu
            FROM phieu_kham pk
            JOIN benh_nhan bn
                ON pk.ma_benh_nhan = bn.ma_benh_nhan
            JOIN nhan_vien nv
                ON pk.ma_nhan_vien = nv.ma_nhan_vien
            LEFT JOIN chuyen_khoa ck
                ON pk.ma_chuyen_khoa = ck.ma_chuyen_khoa
            WHERE bn.ho_ten LIKE ?
               OR bn.cccd LIKE ?
            ORDER BY pk.ngay_kham DESC
        """;

        try(
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ){

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                LichSuKhamBenh ls = new LichSuKhamBenh();

                ls.setMaPhieuKham(rs.getInt("ma_phieu_kham"));
                ls.setTenBenhNhan(rs.getString("ho_ten"));
                ls.setCccd(rs.getString("cccd"));
                ls.setTenBacSi(rs.getString("ten_bac_si"));
                ls.setChuyenKhoa(rs.getString("ten_chuyen_khoa"));
                ls.setNgayKham(rs.getTimestamp("ngay_kham"));
                ls.setTrangThai(rs.getString("trang_thai"));
                ls.setGhiChu(rs.getString("ghi_chu"));

                list.add(ls);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
    public List<LichSuKhamBenh> getByCCCD(String cccd){

        List<LichSuKhamBenh> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT " +
                    "pk.ma_phieu_kham, " +
                    "pk.ngay_kham, " +
                    "pk.trang_thai, " +
                    "bn.ho_ten AS ten_benh_nhan, " +
                    "bn.cccd, " +
                    "nv.ho_ten AS ten_bac_si, " +
                    "ck.ten_chuyen_khoa, " +
                    "kls.ly_do_kham, " +
                    "kls.benh_su, " +
                    "kls.tien_su_ban_than, " +
                    "kls.kham_lam_sang, " +
                     
                    "kls.chan_doan_so_bo, " +
                    "kls.loi_dan_bac_si " +
                    "FROM phieu_kham pk " +

                    "JOIN benh_nhan bn " +
                    "ON pk.ma_benh_nhan = bn.ma_benh_nhan " +

                    "LEFT JOIN nhan_vien nv " +
                    "ON pk.ma_nhan_vien = nv.ma_nhan_vien " +

                    "LEFT JOIN chuyen_khoa ck " +
                    "ON pk.ma_chuyen_khoa = ck.ma_chuyen_khoa " +

                    "LEFT JOIN kham_lam_sang kls " +
                    "ON pk.ma_phieu_kham = kls.ma_phieu_kham " +

                    "WHERE bn.cccd = ? " +
                    "ORDER BY pk.ngay_kham DESC";

            PreparedStatement ps =
                    con.prepareStatement(sql);
            String getByCCCD = cccd ;
            ps.setString(1, cccd);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                LichSuKhamBenh ls =
                        new LichSuKhamBenh();

                ls.setMaPhieuKham(
                        rs.getInt("ma_phieu_kham"));

                ls.setNgayKham(
                        rs.getTimestamp("ngay_kham"));

                ls.setTrangThai(
                        rs.getString("trang_thai"));

                ls.setTenBenhNhan(
                        rs.getString("ten_benh_nhan"));

                ls.setCccd(
                        rs.getString("cccd"));

                ls.setTenBacSi(
                        rs.getString("ten_bac_si"));

                ls.setChuyenKhoa(
                        rs.getString("ten_chuyen_khoa"));

                ls.setLyDoKham(
                        rs.getString("ly_do_kham"));

                ls.setBenhSu(
                        rs.getString("benh_su"));

                ls.setTienSuBanThan(
                        rs.getString("tien_su_ban_than"));

                ls.setKhamLamSang(
                        rs.getString("kham_lam_sang"));

         

                ls.setChanDoanSoBo(
                        rs.getString("chan_doan_so_bo"));

                ls.setLoiDanBacSi(
                        rs.getString("loi_dan_bac_si"));

                list.add(ls);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
}