package dao;

import config.DBConnection;
import model.HoaDon;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HoaDonDAO {

    // =========================================
    // TẠO HÓA ĐƠN CHỜ THANH TOÁN
    // =========================================

    public int taoHoaDon(int maPhieuKham,
                         int maNhanVien,
                         BigDecimal tongTien){

        int id = -1;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO hoa_don(" +
                            "ma_phieu_kham," +
                            "ma_nhan_vien," +
                            "tong_tien," +
                            "trang_thai" +
                            ") VALUES(?,?,?,'CHO_THANH_TOAN')";

            PreparedStatement ps =
                    con.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS
                    );

            ps.setInt(1, maPhieuKham);
            ps.setInt(2, maNhanVien);
            ps.setBigDecimal(3, tongTien);

            ps.executeUpdate();

            ResultSet rs =
                    ps.getGeneratedKeys();

            if(rs.next()){

                id = rs.getInt(1);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return id;
    }

    // =========================================
    // LẤY TẤT CẢ HÓA ĐƠN
    // =========================================

    public List<HoaDon> getAll(){
    	

        List<HoaDon> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM hoa_don " +
                    "ORDER BY ma_hoa_don DESC";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                HoaDon hd =
                        mapHoaDon(rs);

                list.add(hd);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }
 // =========================================
 // LẤY HÓA ĐƠN + THÔNG TIN BỆNH NHÂN
 // =========================================

 public List<Object[]> getAllHoaDonFull(){

     List<Object[]> list =
             new ArrayList<>();

     try{

         Connection con =
                 DBConnection.getConnection();

         String sql =
        	        "SELECT hd.ma_hoa_don, " +
        	                "hd.ma_phieu_kham, " +
        	                "hd.ma_nhan_vien, " +
        	                "bn.ho_ten, " +
        	                "bn.cccd, " +
        	                "hd.tong_tien, " +
        	                "hd.ngay_thanh_toan, " +
        	                "hd.trang_thai, " +
        	                "hd.ghi_chu " +
        	        "FROM hoa_don hd " +
        	        "JOIN phieu_kham pk " +
        	        "ON hd.ma_phieu_kham = pk.ma_phieu_kham " +
        	        "JOIN benh_nhan bn " +
        	        "ON pk.ma_benh_nhan = bn.ma_benh_nhan " +
        	        "WHERE hd.trang_thai='CHUA_THANH_TOAN' " +
        	        "ORDER BY hd.ma_hoa_don DESC";

         PreparedStatement ps =
                 con.prepareStatement(sql);

         ResultSet rs =
                 ps.executeQuery();

         while(rs.next()){

             list.add(new Object[]{

                     rs.getInt("ma_hoa_don"),

                     rs.getInt("ma_phieu_kham"),

                     rs.getInt("ma_nhan_vien"),

                     rs.getString("ho_ten"),

                     rs.getString("cccd"),

                     rs.getBigDecimal("tong_tien"),

                     rs.getTimestamp("ngay_thanh_toan"),

                     rs.getString("trang_thai"),

                     rs.getString("ghi_chu")
             });
         }

     }catch(Exception e){

         e.printStackTrace();
     }

     return list;
 }

    // =========================================
    // HÓA ĐƠN ĐÃ THANH TOÁN
    // =========================================

    public List<HoaDon> getDaThanhToan(){

        List<HoaDon> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM hoa_don " +
                    "WHERE trang_thai='DA_THANH_TOAN' " +
                    "ORDER BY ngay_thanh_toan DESC";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(mapHoaDon(rs));
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }

    // =========================================
    // HÓA ĐƠN CHỜ THANH TOÁN
    // =========================================

    public List<HoaDon> getChoThanhToan(){

        List<HoaDon> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM hoa_don " +
                    "WHERE trang_thai='CHO_THANH_TOAN' " +
                    "ORDER BY ma_hoa_don DESC";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(mapHoaDon(rs));
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }

    // =========================================
    // TÌM THEO MÃ PHIẾU KHÁM
    // =========================================

    public HoaDon findByMaPhieuKham(int maPhieuKham){

        HoaDon hd = null;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM hoa_don " +
                    "WHERE ma_phieu_kham=? " +
                    "LIMIT 1";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maPhieuKham);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                hd = mapHoaDon(rs);
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return hd;
    }

    // =========================================
    // INSERT
    // =========================================

    public boolean insert(HoaDon hd){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO hoa_don(" +
                            "ma_phieu_kham," +
                            "ma_nhan_vien," +
                            "tong_tien," +
                            "ghi_chu," +
                            "trang_thai" +
                            ") VALUES(?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, hd.getMaPhieuKham());

            ps.setInt(2, hd.getMaNhanVien());

            ps.setBigDecimal(3, hd.getTongTien());

            ps.setString(4, hd.getGhiChu());

            ps.setString(5, hd.getTrangThai());

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    // =========================================
    // UPDATE
    // =========================================

    public boolean update(HoaDon hd){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "UPDATE hoa_don SET " +
                            "tong_tien=?," +
                            "ghi_chu=?," +
                            "trang_thai=? " +
                            "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setBigDecimal(1, hd.getTongTien());

            ps.setString(2, hd.getGhiChu());

            ps.setString(3, hd.getTrangThai());

            ps.setInt(4, hd.getMaHoaDon());

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    // =========================================
    // XÓA
    // =========================================

    public boolean delete(int maHoaDon){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "DELETE FROM hoa_don " +
                    "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maHoaDon);

            return ps.executeUpdate() > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    // =========================================
    // THANH TOÁN
    // =========================================

    public boolean thanhToan(int maHoaDon,
                             int maNhanVienThuNgan){

        try{

            Connection con =
                    DBConnection.getConnection();

            // cập nhật hóa đơn

            String sql =
                    "UPDATE hoa_don SET " +
                            "trang_thai='DA_THANH_TOAN'," +
                            "ma_nhan_vien=?," +
                            "ngay_thanh_toan=NOW() " +
                            "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maNhanVienThuNgan);

            ps.setInt(2, maHoaDon);

            int kq = ps.executeUpdate();

            // cập nhật phiếu khám

            String sql2 =
                    "UPDATE phieu_kham pk " +
                    "JOIN hoa_don hd " +
                    "ON pk.ma_phieu_kham=hd.ma_phieu_kham " +
                    "SET pk.trang_thai='KHAM_XONG' " +
                    "WHERE hd.ma_hoa_don=?";

            PreparedStatement ps2 =
                    con.prepareStatement(sql2);

            ps2.setInt(1, maHoaDon);

            ps2.executeUpdate();

            return kq > 0;

        }catch(Exception e){

            e.printStackTrace();
        }

        return false;
    }

    // =========================================
    // TÍNH TỔNG TIỀN
    // =========================================

    public double tinhTongTien(int maHoaDon){

        double tong = 0;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT SUM(thanh_tien) tong " +
                    "FROM ct_hoa_don " +
                    "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maHoaDon);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                tong = rs.getDouble("tong");
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return tong;
    }

    // =========================================
    // SEARCH
    // =========================================

    public List<HoaDon> search(String keyword){

        List<HoaDon> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM hoa_don " +
                    "WHERE ma_hoa_don LIKE ? " +
                    "OR ma_phieu_kham LIKE ?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1,
                    "%" + keyword + "%");

            ps.setString(2,
                    "%" + keyword + "%");

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(mapHoaDon(rs));
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }

    // =========================================
    // MAP OBJECT
    // =========================================

    private HoaDon mapHoaDon(ResultSet rs)
            throws SQLException {

        HoaDon hd =
                new HoaDon();

        hd.setMaHoaDon(
                rs.getInt("ma_hoa_don"));

        hd.setMaPhieuKham(
                rs.getInt("ma_phieu_kham"));

        hd.setMaNhanVien(
                rs.getInt("ma_nhan_vien"));

        hd.setTongTien(
                rs.getBigDecimal("tong_tien"));

        hd.setNgayThanhToan(
                rs.getTimestamp(
                        "ngay_thanh_toan"));

        hd.setTrangThai(
                rs.getString("trang_thai"));

        hd.setGhiChu(
                rs.getString("ghi_chu"));

        return hd;
    }
    private Object[] getDichVuKhamByChuyenKhoa(
            Connection con,
            int maChuyenKhoa) throws Exception {

        String sql =
                "SELECT ma_dich_vu, ten_dich_vu, don_gia " +
                "FROM dich_vu " +
                "WHERE ma_chuyen_khoa=? " +
                "AND loai_dich_vu='KHAM_BENH' " +
                "LIMIT 1";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ps.setInt(1, maChuyenKhoa);

        ResultSet rs = ps.executeQuery();

        if(rs.next()){

            return new Object[]{
                    rs.getInt("ma_dich_vu"),
                    rs.getString("ten_dich_vu"),
                    rs.getBigDecimal("don_gia")
            };
        }

        return null;
    }

    // =====================================================
    // TẠO HÓA ĐƠN TỪ PHIẾU KHÁM
    // =====================================================

    public int taoHoaDonTuPhieuKham(
            int maPhieuKham,
            int maNhanVien){

        Connection con = null;

        try{

            con = DBConnection.getConnection();

            con.setAutoCommit(false);

            // =========================================
            // LẤY THÔNG TIN PHIẾU KHÁM
            // =========================================

            String sqlPK =
                    "SELECT ma_chuyen_khoa " +
                    "FROM phieu_kham " +
                    "WHERE ma_phieu_kham=?";

            PreparedStatement psPK =
                    con.prepareStatement(sqlPK);

            psPK.setInt(1, maPhieuKham);

            ResultSet rsPK =
                    psPK.executeQuery();

            if(!rsPK.next()){

                return -1;
            }

            int maChuyenKhoa =
                    rsPK.getInt("ma_chuyen_khoa");

            // =========================================
            // TẠO HÓA ĐƠN
            // =========================================

            String sqlHD =
                    "INSERT INTO hoa_don(" +
                            "ma_phieu_kham," +
                            "ma_nhan_vien," +
                            "tong_tien," +
                            "trang_thai" +
                            ") VALUES(?,?,?,?)";

            PreparedStatement psHD =
                    con.prepareStatement(
                            sqlHD,
                            Statement.RETURN_GENERATED_KEYS);

            psHD.setInt(1, maPhieuKham);

            psHD.setInt(2, maNhanVien);

            psHD.setBigDecimal(
                    3,
                    BigDecimal.ZERO);

            psHD.setString(
                    4,
                    "CHUA_THANH_TOAN");

            psHD.executeUpdate();

            ResultSet rsHD =
                    psHD.getGeneratedKeys();

            if(!rsHD.next()){

                con.rollback();

                return -1;
            }

            int maHoaDon =
                    rsHD.getInt(1);

            BigDecimal tongTien =
                    BigDecimal.ZERO;

            // =========================================
            // THÊM PHÍ KHÁM BỆNH
            // =========================================

            Object[] dvKham =
                    getDichVuKhamByChuyenKhoa(
                            con,
                            maChuyenKhoa);

            if(dvKham != null){

                String tenDV =
                        dvKham[1].toString();

                BigDecimal donGia =
                        (BigDecimal) dvKham[2];

                String sqlCT =
                        "INSERT INTO ct_hoa_don(" +
                                "ma_hoa_don," +
                                "noi_dung," +
                                "loai_muc," +
                                "so_luong," +
                                "don_gia," +
                                "thanh_tien" +
                                ") VALUES(?,?,?,?,?,?)";

                PreparedStatement psCT =
                        con.prepareStatement(sqlCT);

                psCT.setInt(1, maHoaDon);

                psCT.setString(2, tenDV);

                // KHÔNG GHI QUÁ DÀI
                psCT.setString(3, "KHAM");

                psCT.setInt(4, 1);

                psCT.setBigDecimal(5, donGia);

                psCT.setBigDecimal(6, donGia);

                psCT.executeUpdate();

                tongTien =
                        tongTien.add(donGia);
            }

            // =========================================
            // LẤY DỊCH VỤ CHỈ ĐỊNH
            // =========================================

            String sqlDV =
                    "SELECT dv.ten_dich_vu, " +
                            "ct.so_luong, " +
                            "ct.don_gia " +
                    "FROM chi_tiet_chi_dinh ct " +
                    "JOIN phieu_chi_dinh pc " +
                    "ON ct.ma_phieu_chi_dinh = pc.ma_phieu_chi_dinh " +
                    "JOIN dich_vu dv " +
                    "ON ct.ma_dich_vu = dv.ma_dich_vu " +
                    "WHERE pc.ma_phieu_kham=?";

            PreparedStatement psDV =
                    con.prepareStatement(sqlDV);

            psDV.setInt(1, maPhieuKham);

            ResultSet rsDV =
                    psDV.executeQuery();

            String sqlInsertCT =
                    "INSERT INTO ct_hoa_don(" +
                            "ma_hoa_don," +
                            "noi_dung," +
                            "loai_muc," +
                            "so_luong," +
                            "don_gia," +
                            "thanh_tien" +
                            ") VALUES(?,?,?,?,?,?)";

            PreparedStatement psInsertCT =
                    con.prepareStatement(sqlInsertCT);

            while(rsDV.next()){

                String tenDV =
                        rsDV.getString("ten_dich_vu");

                int soLuong =
                        rsDV.getInt("so_luong");

                BigDecimal donGia =
                        rsDV.getBigDecimal("don_gia");

                BigDecimal thanhTien =
                        donGia.multiply(
                                new BigDecimal(soLuong));

                psInsertCT.setInt(1, maHoaDon);

                psInsertCT.setString(2, tenDV);

                // KHÔNG ĐỂ QUÁ DÀI
                psInsertCT.setString(3, "DICH_VU");

                psInsertCT.setInt(4, soLuong);

                psInsertCT.setBigDecimal(5, donGia);

                psInsertCT.setBigDecimal(6, thanhTien);

                psInsertCT.addBatch();

                tongTien =
                        tongTien.add(thanhTien);
            }

            psInsertCT.executeBatch();

            // =========================================
            // UPDATE TỔNG TIỀN
            // =========================================

            String sqlUpdateHD =
                    "UPDATE hoa_don " +
                    "SET tong_tien=? " +
                    "WHERE ma_hoa_don=?";

            PreparedStatement psUpdateHD =
                    con.prepareStatement(sqlUpdateHD);

            psUpdateHD.setBigDecimal(1, tongTien);

            psUpdateHD.setInt(2, maHoaDon);

            psUpdateHD.executeUpdate();

            // =========================================
            // UPDATE PHIẾU KHÁM
            // =========================================

            String sqlUpdatePK =
                    "UPDATE phieu_kham " +
                    "SET trang_thai='CHO_THANH_TOAN' " +
                    "WHERE ma_phieu_kham=?";

            PreparedStatement psUpdatePK =
                    con.prepareStatement(sqlUpdatePK);

            psUpdatePK.setInt(1, maPhieuKham);

            psUpdatePK.executeUpdate();
            String sqlUpdateDK =
                    "UPDATE dang_ky_kham_benh " +
                    "SET trang_thai='DA_KHAM' " +
                    "WHERE ma_phieu_kham=?";

            PreparedStatement psUpdateDK =
                    con.prepareStatement(sqlUpdateDK);

            psUpdateDK.setInt(1, maPhieuKham);

            psUpdateDK.executeUpdate();

            con.commit();

            return maHoaDon;

        }catch(Exception e){

            e.printStackTrace();

            try{

                if(con != null){

                    con.rollback();
                }

            }catch(Exception ex){

                ex.printStackTrace();
            }

        }finally{

            try{

                if(con != null){

                    con.setAutoCommit(true);
                }

            }catch(Exception e){

                e.printStackTrace();
            }
        }

        return -1;
    }
    public Object[] getThongTinHoaDon(int maHoaDon){

        Object[] obj = null;

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT " +
                    "bn.ho_ten, " +
                    "nv.ho_ten, " +
                    "pk.ngay_kham, " +
                    "ls.chan_doan_so_bo, " +
                    "ls.loi_dan_bac_si, " +
                    "ltk.ngay_tai_kham " +
                    "FROM hoa_don hd " +

                    "JOIN phieu_kham pk " +
                    "ON hd.ma_phieu_kham = pk.ma_phieu_kham " +

                    "JOIN benh_nhan bn " +
                    "ON pk.ma_benh_nhan = bn.ma_benh_nhan " +

                    "JOIN nhan_vien nv " +
                    "ON pk.ma_nhan_vien = nv.ma_nhan_vien " +

                    "LEFT JOIN kham_lam_sang ls " +
                    "ON pk.ma_phieu_kham = ls.ma_phieu_kham " +

                    "LEFT JOIN lich_tai_kham ltk " +
                    "ON pk.ma_phieu_kham = ltk.ma_phieu_kham " +

                    "WHERE hd.ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1,maHoaDon);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()){

                obj = new Object[]{

                        rs.getString(1),

                        rs.getString(2),

                        rs.getTimestamp(3),

                        rs.getString(4),

                        rs.getString(5),

                        rs.getDate(6)
                };
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return obj;
    }
    public List<Object[]> thongKeDoanhThu(
            String loai,
            String value
    ){

        List<Object[]> list =
                new ArrayList<>();

        String condition = "";

        if(loai.equals("Ngày")){

            condition =
                    "DATE(h.ngay_thanh_toan) = ?";

        }else if(loai.equals("Tháng")){

            condition =
                    "DATE_FORMAT(h.ngay_thanh_toan,'%m/%Y') = ?";

        }else{

            condition =
                    "YEAR(h.ngay_thanh_toan) = ?";
        }

        String sql =
                "SELECT " +
                "h.ma_hoa_don, " +
                "h.ngay_thanh_toan, " +
                "tk.username, " +
                "h.tong_tien " +
                "FROM hoa_don h " +

                "LEFT JOIN tai_khoan tk " +
                "ON h.ma_nhan_vien = tk.ma_nhan_vien " +

                "WHERE " + condition +

                " AND h.trang_thai = 'DA_THANH_TOAN' " +

                "ORDER BY h.ngay_thanh_toan DESC";

        try(
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ){

            ps.setString(1,value);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(new Object[]{

                        rs.getInt("ma_hoa_don"),

                        rs.getTimestamp(
                                "ngay_thanh_toan"
                        ),

                        rs.getString("username"),

                        rs.getBigDecimal(
                                "tong_tien"
                        )
                });
            }

        }catch(Exception ex){

            ex.printStackTrace();
        }

        return list;
    }
    
}