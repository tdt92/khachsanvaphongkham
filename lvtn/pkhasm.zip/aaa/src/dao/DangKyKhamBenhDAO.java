package dao;

import config.DBConnection;
import model.DangKyKhamBenh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DangKyKhamBenhDAO {

    public boolean insert(DangKyKhamBenh dk){

        String sql = "INSERT INTO dang_ky_kham_benh " +
                "(ma_benh_nhan, ma_nhan_vien, ma_chuyen_khoa, so_thu_tu, trang_thai, ghi_chu) " +
                "VALUES (?,?,?,?,?,?)";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, dk.getMaBenhNhan());

            if(dk.getMaNhanVien()!=null)
                ps.setInt(2, dk.getMaNhanVien());
            else
                ps.setNull(2, java.sql.Types.INTEGER);

            ps.setInt(3, dk.getMaChuyenKhoa());
            ps.setInt(4, dk.getSoThuTu());
            ps.setString(5, dk.getTrangThai());
            ps.setString(6, dk.getGhiChu());

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
 // ================= LOAD CHO KHÁM =================
    public ResultSet getChoKham(Connection con, int maChuyenKhoa) throws Exception {

        String sql =
            "SELECT d.id, d.so_thu_tu, bn.ma_benh_nhan, bn.ho_ten, " +
            "d.thoi_gian_dang_ky, d.trang_thai " +
            "FROM dang_ky_kham_benh d " +
            "JOIN benh_nhan bn ON d.ma_benh_nhan = bn.ma_benh_nhan " +
            "WHERE DATE(d.thoi_gian_dang_ky)=CURDATE() " +
            "AND d.ma_chuyen_khoa=? " +
            "AND d.trang_thai='CHO_KHAM_BS' " +
            "ORDER BY d.so_thu_tu";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1,maChuyenKhoa);
        return ps.executeQuery();
    }
    public List<Object[]> getChoKham(){

        List<Object[]> list = new ArrayList<>();

        String sql =
                "SELECT d.id, d.so_thu_tu, bn.ma_benh_nhan, bn.ho_ten, " +
                "d.thoi_gian_dang_ky, d.trang_thai " +
                "FROM dang_ky_kham_benh d " +
                "JOIN benh_nhan bn ON d.ma_benh_nhan = bn.ma_benh_nhan " +
                "WHERE DATE(d.thoi_gian_dang_ky)=CURDATE() " +
                "AND d.trang_thai='CHO_KHAM_BS' " +
                "ORDER BY d.so_thu_tu";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            while(rs.next()){
                list.add(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("so_thu_tu"),
                        rs.getInt("ma_benh_nhan"),
                        rs.getString("ho_ten"),
                        rs.getTimestamp("thoi_gian_dang_ky"),
                        rs.getString("trang_thai")
                });
            }

        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }

    // ================= LOAD VẮNG MẶT =================
    public List<Object[]> getVangMat(){

        List<Object[]> list = new ArrayList<>();

        String sql =
                "SELECT d.id, d.so_thu_tu, bn.ma_benh_nhan, bn.ho_ten, " +
                "d.thoi_gian_dang_ky, d.trang_thai " +
                "FROM dang_ky_kham_benh d " +
                "JOIN benh_nhan bn ON d.ma_benh_nhan = bn.ma_benh_nhan " +
                "WHERE DATE(d.thoi_gian_dang_ky)=CURDATE() " +
                "AND d.trang_thai='VANG_MAT' " +
                "ORDER BY d.so_thu_tu";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            while(rs.next()){
                list.add(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("so_thu_tu"),
                        rs.getInt("ma_benh_nhan"),
                        rs.getString("ho_ten"),
                        rs.getTimestamp("thoi_gian_dang_ky"),
                        rs.getString("trang_thai")
                });
            }

        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }

    // ================= LOAD VANG MAT =================
    public ResultSet getVangMat(Connection con, int maChuyenKhoa) throws Exception {

        String sql =
            "SELECT d.id, d.so_thu_tu, bn.ma_benh_nhan, bn.ho_ten, " +
            "d.thoi_gian_dang_ky, d.trang_thai " +
            "FROM dang_ky_kham_benh d " +
            "JOIN benh_nhan bn ON d.ma_benh_nhan = bn.ma_benh_nhan " +
            "WHERE DATE(d.thoi_gian_dang_ky)=CURDATE() " +
            "AND d.ma_chuyen_khoa=? " +
            "AND d.trang_thai='VANG_MAT' " +
            "ORDER BY d.so_thu_tu";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1,maChuyenKhoa);
        return ps.executeQuery();
    }

    // ================= UPDATE TRANG THAI =================
    public boolean updateTrangThai(int id, String trangThai){

        String sql="UPDATE dang_ky_kham_benh SET trang_thai=? WHERE id=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setString(1,trangThai);
            ps.setInt(2,id);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
 // ================= HỦY THEO ID =================
    public boolean deleteById(int id){

        String sql = "DELETE FROM dang_ky_kham_benh WHERE id=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,id);
            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
 // ================= XOÁ ĐĂNG KÝ CŨ =================
    public void deleteDangKyCu(){

        String sql = "DELETE FROM dang_ky_kham_benh " +
                "WHERE DATE(thoi_gian_dang_ky) < CURDATE()";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.executeUpdate();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
 // ================= LOAD HÔM NAY =================
    public ResultSet getDanhSachChoHomNay(Connection con) throws Exception {

        String sql = "SELECT d.id, d.so_thu_tu, bn.ma_benh_nhan, bn.ho_ten, " +
                "ck.ten_chuyen_khoa, nv.ho_ten AS ten_bs, d.ghi_chu " +
                "FROM dang_ky_kham_benh d " +
                "JOIN benh_nhan bn ON d.ma_benh_nhan = bn.ma_benh_nhan " +
                "JOIN chuyen_khoa ck ON d.ma_chuyen_khoa = ck.ma_chuyen_khoa " +
                "LEFT JOIN nhan_vien nv ON d.ma_nhan_vien = nv.ma_nhan_vien " +
                "WHERE DATE(d.thoi_gian_dang_ky)=CURDATE() " +
                "AND d.trang_thai='CHO_KHAM_BS' " +
                "ORDER BY d.so_thu_tu";

        return con.prepareStatement(sql).executeQuery();
    }
    public int getMaxSTT(){

        String sql =
                "SELECT MAX(so_thu_tu) FROM dang_ky_kham_benh " +
                "WHERE DATE(thoi_gian_dang_ky)=CURDATE()";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            if(rs.next()){
                return rs.getInt(1);
            }

        }catch(Exception e){ e.printStackTrace(); }

        return 0;
    }
 // ================= CẬP NHẬT STT + TRẠNG THÁI =================
    public boolean updateSTTAndTrangThai(int id, int newSTT){

        String sql =
                "UPDATE dang_ky_kham_benh " +
                "SET so_thu_tu=?, trang_thai='CHO_KHAM_BS' " +
                "WHERE id=?";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,newSTT);
            ps.setInt(2,id);

            return ps.executeUpdate()>0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    public int insertAndGetId(int maDangKy){

        String sql = "INSERT INTO phieu_kham(ma_dang_ky) VALUES(?)";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql,
                    Statement.RETURN_GENERATED_KEYS)){

            ps.setInt(1, maDangKy);
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
                return rs.getInt(1);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return -1;
    }
    public List<DangKyKhamBenh> getChoKhamByChuyenKhoa(int maChuyenKhoa){

        List<DangKyKhamBenh> list = new ArrayList<>();

        String sql = """
            SELECT *
            FROM dang_ky_kham_benh
            WHERE ma_chuyen_khoa = ?
            AND trang_thai IN ('CHO_KHAM_BS','CHO_KHAM')
            ORDER BY so_thu_tu
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1, maChuyenKhoa);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                DangKyKhamBenh dk = new DangKyKhamBenh();

                dk.setId(rs.getInt("id"));
                dk.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
                dk.setSoThuTu(rs.getInt("so_thu_tu"));

                list.add(dk);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
    
    public List<DangKyKhamBenh> getChoKhamKhoaRang(){

        List<DangKyKhamBenh> list = new ArrayList<>();

        String sql = """
            SELECT dk.id,
                   dk.ma_benh_nhan,
                   bn.ho_ten,
                   dk.so_thu_tu,
                   dk.ma_phieu_kham
            FROM dang_ky_kham_benh dk
            JOIN benh_nhan bn 
                 ON dk.ma_benh_nhan = bn.ma_benh_nhan
            WHERE dk.ma_chuyen_khoa = 5
            AND dk.trang_thai = 'DANG_KHAM'
            ORDER BY dk.so_thu_tu
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            while(rs.next()){

                DangKyKhamBenh dk = new DangKyKhamBenh();

                dk.setId(rs.getInt("id"));
                dk.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
                dk.setHoTen(rs.getString("ho_ten"));
                dk.setSoThuTu(rs.getInt("so_thu_tu"));

                int maPhieu = rs.getInt("ma_phieu_kham");
                if(!rs.wasNull()){
                    dk.setMaPhieuKham(maPhieu);
                }

                list.add(dk);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
    public List<DangKyKhamBenh> getChoKhamKhoaNoi(){

        List<DangKyKhamBenh> list = new ArrayList<>();

        String sql = """
            SELECT dk.id,
                   dk.ma_benh_nhan,
                   bn.ho_ten,
                   dk.so_thu_tu,
                   dk.ma_phieu_kham
            FROM dang_ky_kham_benh dk
            JOIN benh_nhan bn 
                 ON dk.ma_benh_nhan = bn.ma_benh_nhan
            WHERE dk.ma_chuyen_khoa = 1
            AND dk.trang_thai = 'DANG_KHAM'
            ORDER BY dk.so_thu_tu
        """;

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){

            while(rs.next()){

                DangKyKhamBenh dk = new DangKyKhamBenh();

                dk.setId(rs.getInt("id"));
                dk.setMaBenhNhan(rs.getInt("ma_benh_nhan"));
                dk.setHoTen(rs.getString("ho_ten"));
                dk.setSoThuTu(rs.getInt("so_thu_tu"));

                int maPhieu = rs.getInt("ma_phieu_kham");
                if(!rs.wasNull()){
                    dk.setMaPhieuKham(maPhieu);
                }

                list.add(dk);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
    public List<DangKyKhamBenh> getByMaNhanVien(int maNV){

        List<DangKyKhamBenh> list = new ArrayList<>();

        String sql =
          "SELECT dk.id, dk.ma_benh_nhan, bn.ho_ten, dk.so_thu_tu " +
          "FROM dang_ky_kham_benh dk " +
          "JOIN benh_nhan bn ON dk.ma_benh_nhan=bn.ma_benh_nhan " +
          "WHERE dk.ma_nhan_vien=? AND dk.trang_thai='CHO_KHAM'";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,maNV);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                DangKyKhamBenh dk = new DangKyKhamBenh();
                dk.setId(rs.getInt(1));
                dk.setMaBenhNhan(rs.getInt(2));
                 dk.setSoThuTu(rs.getInt(4));
                list.add(dk);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

    // Lấy STT lớn nhất theo chuyên khoa trong ngày
    public int getMaxSTT(int maChuyenKhoa){

        String sql = "SELECT MAX(so_thu_tu) FROM dang_ky_kham_benh " +
                "WHERE ma_chuyen_khoa=? AND DATE(thoi_gian_dang_ky)=CURDATE()";

        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){

            ps.setInt(1,maChuyenKhoa);
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                return rs.getInt(1);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return 0;
    }
}