package dao;

import model.DanhMucBenhLy;
import config.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DanhMucBenhLyDAO {

    public List<DanhMucBenhLy> getAll() {
        List<DanhMucBenhLy> list = new ArrayList<>();
        String sql = "SELECT * FROM danh_muc_benh_ly";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new DanhMucBenhLy(
                        rs.getInt("id"),
                        rs.getString("ma_icd"),
                        rs.getString("ten_benh"),
                        rs.getString("trieu_chung_goi_y"),
                        rs.getString("chuyen_khoa_lien_quan")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public boolean insert(DanhMucBenhLy dm) {
        String sql = "INSERT INTO danh_muc_benh_ly(ma_icd,ten_benh,trieu_chung_goi_y,chuyen_khoa_lien_quan) VALUES(?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dm.getMaICD());
            ps.setString(2, dm.getTenBenh());
            ps.setString(3, dm.getTrieuChungGoiY());
            ps.setString(4, dm.getChuyenKhoaLienQuan());

            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }

        return false;
    }

    public boolean update(DanhMucBenhLy dm) {
        String sql = "UPDATE danh_muc_benh_ly SET ma_icd=?,ten_benh=?,trieu_chung_goi_y=?,chuyen_khoa_lien_quan=? WHERE id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dm.getMaICD());
            ps.setString(2, dm.getTenBenh());
            ps.setString(3, dm.getTrieuChungGoiY());
            ps.setString(4, dm.getChuyenKhoaLienQuan());
            ps.setInt(5, dm.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }

        return false;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM danh_muc_benh_ly WHERE id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }

        return false;
    }
    public boolean existsMaICD(String maICD) {

        String sql = "SELECT COUNT(*) FROM danh_muc_benh_ly WHERE ma_icd=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, maICD);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) { e.printStackTrace(); }

        return false;
    }


    public List<DanhMucBenhLy> search(String keyword) {

        List<DanhMucBenhLy> list = new ArrayList<>();
        String sql = "SELECT * FROM danh_muc_benh_ly WHERE ma_icd LIKE ? OR ten_benh LIKE ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new DanhMucBenhLy(
                        rs.getInt("id"),
                        rs.getString("ma_icd"),
                        rs.getString("ten_benh"),
                        rs.getString("trieu_chung_goi_y"),
                        rs.getString("chuyen_khoa_lien_quan")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }
}
