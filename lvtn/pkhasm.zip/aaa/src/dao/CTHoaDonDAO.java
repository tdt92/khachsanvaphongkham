package dao;

import config.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CTHoaDonDAO {

    // =========================================
    // THÊM CHI TIẾT HÓA ĐƠN
    // =========================================

    public void insert(int maHoaDon,
                       String noiDung,
                       String loaiMuc,
                       int soLuong,
                       BigDecimal donGia){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO ct_hoa_don(" +
                            "ma_hoa_don," +
                            "noi_dung," +
                            "loai_muc," +
                            "so_luong," +
                            "don_gia," +
                            "thanh_tien" +
                            ") VALUES(?,?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            BigDecimal thanhTien =
                    donGia.multiply(
                            new BigDecimal(soLuong));

            ps.setInt(1, maHoaDon);

            ps.setString(2, noiDung);

            ps.setString(3, loaiMuc);

            ps.setInt(4, soLuong);

            ps.setBigDecimal(5, donGia);

            ps.setBigDecimal(6, thanhTien);

            ps.executeUpdate();

        }catch(Exception e){

            e.printStackTrace();
        }
    }

    // =========================================
    // LẤY CHI TIẾT HÓA ĐƠN
    // =========================================

    public List<Object[]> getByHoaDon(int maHoaDon){

        List<Object[]> list =
                new ArrayList<>();

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM ct_hoa_don " +
                    "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maHoaDon);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                list.add(new Object[]{

                        rs.getInt("id"),

                        rs.getString("noi_dung"),

                        rs.getString("loai_muc"),

                        rs.getInt("so_luong"),

                        rs.getBigDecimal("don_gia"),

                        rs.getBigDecimal("thanh_tien")
                });
            }

        }catch(Exception e){

            e.printStackTrace();
        }

        return list;
    }

    // =========================================
    // XÓA THEO HÓA ĐƠN
    // =========================================

    public void deleteByHoaDon(int maHoaDon){

        try{

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "DELETE FROM ct_hoa_don " +
                    "WHERE ma_hoa_don=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, maHoaDon);

            ps.executeUpdate();

        }catch(Exception e){

            e.printStackTrace();
        }
    }
}