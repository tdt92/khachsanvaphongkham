package dao;

import config.DBConnection;
import model.ChuyenKhoa;

import java.sql.*;
import java.util.*;

public class ChuyenKhoaDAO {

    public List<ChuyenKhoa> getAll(){
        List<ChuyenKhoa> list=new ArrayList<>();
        String sql="SELECT * FROM chuyen_khoa";

        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery()){

            while(rs.next()){
                ChuyenKhoa ck=new ChuyenKhoa();
                ck.setMaChuyenKhoa(rs.getInt("ma_chuyen_khoa"));
                ck.setTenChuyenKhoa(rs.getString("ten_chuyen_khoa"));
                ck.setMoTa(rs.getString("mo_ta"));
                list.add(ck);
            }

        }catch(Exception e){ e.printStackTrace(); }

        return list;
    }
}
