package gui;

import bus.HoaDonBUS;
import model.HoaDon;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class QuanLyHoaDonForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private HoaDonBUS bus = new HoaDonBUS();

    // ===== BỘ MÀU FLAT UI ĐỒNG BỘ HỆ THỐNG =====
    private final Color PRIMARY = new Color(52, 152, 219);     // Xanh Sky Blue chủ đạo
    private final Color SUCCESS = new Color(46, 204, 113);     // Xanh lá cho nút Chi tiết
    private final Color DANGER = new Color(231, 76, 60);       // Đỏ nhẹ cho nút Đóng
    private final Color REFRESH = new Color(149, 165, 166);    // Xám tinh tế cho nút Làm mới
    private final Color BG_WINDOW = new Color(245, 247, 250);  // Nền cửa sổ sáng dịu
    private final Color TEXT_MAIN = new Color(44, 62, 80);     // Chữ chính đậm rõ ràng
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public QuanLyHoaDonForm(){
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("QUẢN LÝ HÓA ĐƠN");
        setSize(1150, 680); // Tăng nhẹ kích thước để bảng hiển thị rộng rãi hơn
        setLocationRelativeTo(null);
 
        // Root Panel với khoảng đệm xung quanh chỉn chu
        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG_WINDOW);
        root.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(root);

        // =====================================
        // TIÊU ĐỀ TRÊN CÙNG (HEADER)
        // =====================================
        JLabel title = new JLabel("QUẢN LÝ HÓA ĐƠN", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(TEXT_MAIN);
        title.setBorder(new EmptyBorder(5, 0, 10, 0));
        root.add(title, BorderLayout.NORTH);

        // =====================================
        // BẢNG DỮ LIỆU HIỆN ĐẠI (TABLE)
        // =====================================
        model = new DefaultTableModel(
                new String[]{
                        "Mã HD", "Mã Phiếu", "Mã NV", "Tên Bệnh Nhân", 
                        "CCCD", "Tổng Tiền", "Ngày Thanh Toán", "Trạng Thái", "Ghi Chú"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Khóa không cho sửa trực tiếp trên lưới dữ liệu
            }
        };

        table = new JTable(model);
        table.setRowHeight(36); // Dòng cao vừa vặn, chuẩn UI hiện đại
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setGridColor(new Color(240, 243, 248));
        table.setSelectionBackground(new Color(230, 242, 255)); // Màu nền khi click chọn dòng
        table.setSelectionForeground(TEXT_MAIN);
        table.setShowVerticalLines(false); // Ẩn đường kẻ dọc để giảm rối mắt

        // Tùy biến thanh đầu bảng (Header)
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(Color.WHITE);
        header.setForeground(TEXT_MAIN);
        header.setPreferredSize(new Dimension(0, 42));
        ((DefaultTableCellRenderer)header.getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);

        // Đổ màu xen kẽ giữa các dòng (Zebra Striping) giúp dễ quan sát số liệu tiền tệ
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                if (!isSel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 253));
                }
                setBorder(noFocusBorder); // Xóa viền nét đứt khi focus
                return comp;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1, true));
        scroll.getViewport().setBackground(Color.WHITE);
        root.add(scroll, BorderLayout.CENTER);

        // =====================================
        // KHU VỰC NÚT BẤM DƯỚI CÙNG (BUTTON BAR)
        // =====================================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        bottom.setOpaque(false);

        JButton btnRefresh = createFlatButton("LÀM MỚI", REFRESH);
        JButton btnChiTiet = createFlatButton("🔎 XEM CHI TIẾT", SUCCESS);
        JButton btnDong = createFlatButton("ĐÓNG", DANGER);

        bottom.add(btnRefresh);
        bottom.add(btnChiTiet);
        bottom.add(btnDong);
        root.add(bottom, BorderLayout.SOUTH);

        // =====================================
        // SỰ KIỆN VÀ ĐỔ DỮ LIỆU ( giữ nguyên logic )
        // =====================================
        btnRefresh.addActionListener(e -> loadData());
        btnDong.addActionListener(e -> dispose());
        btnChiTiet.addActionListener(e -> xemChiTiet());

        loadData();
    }

    // Hàm tạo nút phẳng cao cấp kèm hiệu ứng Hover đổi màu mượt mà
    private JButton createFlatButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(baseColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        // Đảm bảo kích thước nút đồng đều, vuông vắn
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width + 20, 40));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(baseColor.darker()); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(baseColor); }
        });
        return btn;
    }

    private void loadData(){
        model.setRowCount(0);

        DecimalFormat df = new DecimalFormat("#,###");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        List<Object[]> list = bus.getAllHoaDonFull();

        for(Object[] row : list){
            model.addRow(new Object[]{
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                    row[4],
                    row[5] != null ? df.format(row[5]) + " VNĐ" : "0 VNĐ",
                    row[6] == null ? "" : sdf.format(row[6]),
                    row[7],
                    row[8]
            });
        }
    }

    private void xemChiTiet(){
        int row = table.getSelectedRow();
        if(row == -1){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một hóa đơn từ danh sách!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maHD = Integer.parseInt(model.getValueAt(row, 0).toString());
        new ChiTietHoaDonForm(maHD).setVisible(true);
    }
}