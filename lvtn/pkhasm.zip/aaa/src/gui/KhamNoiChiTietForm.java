package gui;
import bus.ChuyenKhoaBUS;
import dao.PhieuKhamDAO;
import bus.ChiTietKhamBenhBUS;
import bus.HoaDonBUS;
import bus.LichSuKhamBenhBUS;
import config.Session;
import dao.BenhNhanDAO;
import dao.ChiSoKhamTongHopDAO;
import dao.KhamLamSangDAO;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import bus.LichTaiKhamBUS;

public class KhamNoiChiTietForm extends JFrame {

    private final int maPhieu;

     private final JTextArea txtTinhTrangChung = new JTextArea(4, 20);
    private final JTextArea txtBenhLyKhac = new JTextArea(4, 20);
    private final JTextArea txtGhiChu = new JTextArea(4, 20);
    private final JTextField txtChanDoan = new JTextField();
    private final JTextArea txtLoiDan = new JTextArea(4, 20);

     private final JTextArea txtThongTinCu = new JTextArea();
    private JTable tableHistory;
    private DefaultTableModel historyModel;

    private final ChuyenKhoaBUS chuyenKhoaBUS =    new ChuyenKhoaBUS();
     private final ChiSoKhamTongHopDAO csDao = new ChiSoKhamTongHopDAO();
    private final KhamLamSangDAO lsDao = new KhamLamSangDAO();
    private final LichSuKhamBenhBUS lichSuBUS = new LichSuKhamBenhBUS();
    private final ChiTietKhamBenhBUS chiTietBUS = new ChiTietKhamBenhBUS();
    private final LichTaiKhamBUS lichTaiKhamBUS = new LichTaiKhamBUS();
    private final BenhNhanDAO benhNhanDAO = new BenhNhanDAO();

     private final Color PRIMARY_COLOR = new Color(2, 136, 209);  
    private final Color SUCCESS_COLOR = new Color(46, 125, 50);  
    private final Color TEXT_COLOR = new Color(33, 33, 33);
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public KhamNoiChiTietForm(int maPhieu) {
        this.maPhieu = maPhieu;

        setTitle("HỆ THỐNG QUẢN LÝ PHÒNG KHÁM - KHÁM NỘI CHI TIẾT");
        setSize(1450, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
         JPanel mainContainer = new JPanel(new BorderLayout(15, 15));
        mainContainer.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(mainContainer);

        initUI();
        loadOldData();
        loadHistory();
    }

    private void initUI() {
       
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setPreferredSize(new Dimension(450, 0));

         txtThongTinCu.setEditable(false);
        txtThongTinCu.setLineWrap(true);
        txtThongTinCu.setWrapStyleWord(true);
        txtThongTinCu.setFont(MAIN_FONT);
        txtThongTinCu.setBackground(new Color(250, 250, 250));
        txtThongTinCu.setMargin(new Insets(8, 8, 8, 8));

        JScrollPane spInfo = new JScrollPane(txtThongTinCu);
        spInfo.setBorder(createTitledBorder("Thông tin lâm sàng trước đó"));

         historyModel = new DefaultTableModel(
                new String[]{"Mã PK", "Ngày khám", "Bác sĩ", "Trạng thái"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableHistory = new JTable(historyModel);
        tableHistory.setFont(MAIN_FONT);
        tableHistory.setRowHeight(32);
        tableHistory.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableHistory.setGridColor(new Color(230, 230, 230));

         JTableHeader header = tableHistory.getTableHeader();
        header.setFont(BOLD_FONT);
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 35));

         DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tableHistory.getColumnModel().getColumn(0).setPreferredWidth(60);
        tableHistory.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tableHistory.getColumnModel().getColumn(1).setPreferredWidth(130);
        tableHistory.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        JScrollPane spHistory = new JScrollPane(tableHistory);
        spHistory.setBorder(createTitledBorder("Lịch sử khám bệnh (Đúp chuột để xem)"));

         tableHistory.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableHistory.getSelectedRow();
                    if (row >= 0) {
                        int maPK = Integer.parseInt(historyModel.getValueAt(row, 0).toString());
                        showChiTietKham(maPK);
                    }
                }
            }
        });

         JSplitPane leftSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, spInfo, spHistory);
        leftSplit.setDividerLocation(350);
        leftSplit.setBorder(null);
        leftPanel.add(leftSplit, BorderLayout.CENTER);

 
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

         setupInputComponent(txtTinhTrangChung);
        setupInputComponent(txtBenhLyKhac);
        setupInputComponent(txtGhiChu);
        setupInputComponent(txtLoiDan);
        txtChanDoan.setFont(MAIN_FONT);
        txtChanDoan.setPreferredSize(new Dimension(0, 35));

         int row = 0;
        addFormRow(formPanel, gbc, "Tình trạng chung RHM:", new JScrollPane(txtTinhTrangChung), row++);
        addFormRow(formPanel, gbc, "Bệnh lý khác:", new JScrollPane(txtBenhLyKhac), row++);
        addFormRow(formPanel, gbc, "Ghi chú chỉ số tổng hợp:", new JScrollPane(txtGhiChu), row++);
        addFormRow(formPanel, gbc, "Chẩn đoán sơ bộ:", txtChanDoan, row++);
        addFormRow(formPanel, gbc, "Lời dặn bác sĩ:", new JScrollPane(txtLoiDan), row);

        JScrollPane spForm = new JScrollPane(formPanel);
        spForm.setBorder(createTitledBorder("Nhập liệu thông tin khám và điều trị"));
        spForm.getVerticalScrollBar().setUnitIncrement(16);

         JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, spForm);
        mainSplit.setDividerLocation(460);
        mainSplit.setBorder(null);
        getContentPane().add(mainSplit, BorderLayout.CENTER);

       
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

         JPanel subActionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JButton btnViewCDHA = createStyledButton("Xem kết quả CDHA", PRIMARY_COLOR, false);
        JButton btnChuyenCK =
                createStyledButton(
                        "Chuyển chuyên khoa",
                        new Color(255,140,0),
                        false
                );
        subActionPanel.add(btnChuyenCK);
        JButton btnXQuang = createStyledButton("Chụp X-Quang", PRIMARY_COLOR, false);
        JButton btnDonThuoc = createStyledButton("Đơn thuốc", PRIMARY_COLOR, false);
        JButton btnTaiKham = createStyledButton("Hẹn tái khám", PRIMARY_COLOR, false);
        subActionPanel.add(btnViewCDHA);
        subActionPanel.add(btnXQuang);
        subActionPanel.add(btnDonThuoc);
        subActionPanel.add(btnTaiKham);

        // Nhóm các nút lưu trữ hệ thống bên phải
        JPanel mainActionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton btnSave = createStyledButton("Lưu tạm", new Color(117, 117, 117), true);
        JButton btnUpdate = createStyledButton("Cập nhật", PRIMARY_COLOR, true);
        JButton btnKetThuc = createStyledButton("Kết thúc khám", SUCCESS_COLOR, true);
        mainActionPanel.add(btnSave);
        mainActionPanel.add(btnUpdate);
        mainActionPanel.add(btnKetThuc);

        bottomPanel.add(subActionPanel, BorderLayout.WEST);
        bottomPanel.add(mainActionPanel, BorderLayout.EAST);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // =====================================================================
        // THIẾT LẬP CÁC SỰ KIỆN (LISTENERS)
        // =====================================================================
        btnDonThuoc.addActionListener(e -> moDonThuoc());
        btnTaiKham.addActionListener(e -> henTaiKham());
        btnSave.addActionListener(e -> save());
        btnUpdate.addActionListener(e -> update());
        btnViewCDHA.addActionListener(e -> {
            TienHanhCDHAForm f = new TienHanhCDHAForm(maPhieu);
            f.setVisible(true);
        });
        btnXQuang.addActionListener(e -> chuyenXQuang());
        btnChuyenCK.addActionListener(
                e -> chuyenChuyenKhoa()
        );
        
        btnKetThuc.addActionListener(e -> {

    	    try{

    	        int confirm = JOptionPane.showConfirmDialog(
    	                null,
    	                "Kết thúc khám và tạo hóa đơn?",
    	                "Xác nhận",
    	                JOptionPane.YES_NO_OPTION
    	        );

    	        if(confirm != JOptionPane.YES_OPTION){
    	            return;
    	        }

    	        // =========================================
    	        // LƯU DỮ LIỆU KHÁM
    	        // =========================================

    	        save();

    	        PhieuKhamDAO pkDao =
    	                new PhieuKhamDAO();

    	        // =========================================
    	        // CẬP NHẬT BÁC SĨ ĐANG KHÁM
    	        // =========================================

    	        boolean okBS =
    	                pkDao.updateBacSiKham(
    	                        maPhieu,
    	                        Session.currentUser.getMaNhanVien()
    	                );

    	        if(!okBS){

    	            JOptionPane.showMessageDialog(
    	                    this,
    	                    "Không cập nhật được bác sĩ khám!"
    	            );

    	            return;
    	        }

    	        // =========================================
    	        // CẬP NHẬT TRẠNG THÁI
    	        // =========================================

    	        pkDao.updateTrangThai(
    	                maPhieu,
    	                "CHO_THANH_TOAN"
    	        );
    	        System.out.println(
    	                "Ma phieu = " + maPhieu
    	        );

    	        System.out.println(
    	                "Ma nhan vien current = "
    	                        + Session.currentUser.getMaNhanVien()
    	        );

    	        // =========================================
    	        // TẠO HÓA ĐƠN
    	        // =========================================

    	        HoaDonBUS hoaDonBUS =
    	                new HoaDonBUS();

    	        int maHoaDon =
    	                hoaDonBUS.taoHoaDonTuPhieuKham(
    	                        maPhieu,
    	                        Session.currentUser.getMaNhanVien()
    	                );

    	        if(maHoaDon > 0){

    	            JOptionPane.showMessageDialog(
    	                    null,
    	                    "Đã kết thúc khám!\n" +
    	                    "Mã hóa đơn: " + maHoaDon
    	            );

    	            dispose();

    	        }else{

    	            JOptionPane.showMessageDialog(
    	                    null,
    	                    "Tạo hóa đơn thất bại!"
    	            );
    	        }

    	    }catch(Exception ex){

    	        ex.printStackTrace();

    	        JOptionPane.showMessageDialog(
    	                this,
    	                "Lỗi kết thúc khám!"
    	        );
    	    }
    	});
    }

    // =====================================================================
    // CÁC HÀM TRỢ GIÚP THIẾT KẾ UI (HELPER METHODS)
    // =====================================================================
    private TitledBorder createTitledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true), title
        );
        border.setTitleFont(BOLD_FONT);
        border.setTitleColor(PRIMARY_COLOR);
        return border;
    }

    private void setupInputComponent(JTextArea textArea) {
        textArea.setFont(MAIN_FONT);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setMargin(new Insets(5, 5, 5, 5));
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String labelText, Component comp, int row) {
        JLabel label = new JLabel(labelText);
        label.setFont(BOLD_FONT);
        label.setForeground(TEXT_COLOR);

        // Thêm nhãn (Cột trái)
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(label, gbc);

        // Thêm ô nhập liệu (Cột phải)
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(comp, gbc);
    }

    private JButton createStyledButton(String text, Color baseColor, boolean isMainAction) {
        JButton button = new JButton(text);
        button.setFont(BOLD_FONT);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        if (isMainAction) {
            button.setBackground(baseColor);
            button.setForeground(Color.WHITE);
            button.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        } else {
            button.setBackground(Color.WHITE);
            button.setForeground(baseColor);
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(baseColor, 1, true),
                    BorderFactory.createEmptyBorder(7, 14, 7, 14)
            ));
        }

        // Hiệu ứng Hover đổi màu mượt mà
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isMainAction) {
                    button.setBackground(baseColor.brighter());
                } else {
                    button.setBackground(new Color(240, 244, 248));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (isMainAction) {
                    button.setBackground(baseColor);
                } else {
                    button.setBackground(Color.WHITE);
                }
            }
        });

        return button;
    }

    // =====================================================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN HOẶC TINH CHỈNH THÔNG BÁO)
    // =====================================================================
    private void loadOldData() {
        StringBuilder sb = new StringBuilder();

        KhamLamSang ls = lsDao.findByMaPhieu1(maPhieu);
        if (ls != null) {
            sb.append("⚡ KHÁM LÂM SÀNG CŨ\n-----------------------------------------\n");
            sb.append("• Lý do khám: ").append(nullToEmpty(ls.getLyDoKham())).append("\n\n");
            sb.append("• Bệnh sử: ").append(nullToEmpty(ls.getBenhSu())).append("\n\n");
            sb.append("• Tiền sử: ").append(nullToEmpty(ls.getTienSuBanThan())).append("\n\n");
            txtChanDoan.setText(ls.getChanDoanSoBo());
            txtLoiDan.setText(ls.getLoiDanBacSi());
        }

        ChiSoKhamTongHop cs = csDao.findByMaPhieu11(maPhieu);
        if (cs != null) {
            sb.append("\n📊 CHỈ SỐ SINH HIỆU\n-----------------------------------------\n");
            sb.append("• Nhiệt độ: ").append(cs.getNhietDo()).append(" °C\n");
            sb.append("• Nhịp tim: ").append(cs.getNhipTim()).append(" lần/phút\n");
            sb.append("• Nhịp thở: ").append(cs.getNhipTho()).append(" lần/phút\n");
            sb.append("• Huyết áp: ").append(cs.getHuyetApTamThu()).append(" mmHg\n");
            sb.append("• Cân nặng: ").append(cs.getCanNang()).append(" kg | Chiều cao: ").append(cs.getChieuCao()).append(" cm\n");
            sb.append("• Điều dưỡng ghi chú: ").append(nullToEmpty(cs.getGhiChu())).append("\n");

            txtTinhTrangChung.setText(cs.getTinhTrangRang());
            txtBenhLyKhac.setText(cs.getBenhLyKhacRHM());
            txtGhiChu.setText(cs.getGhiChu());
        }

        txtThongTinCu.setText(sb.toString());
    }

    private void loadHistory() {
        historyModel.setRowCount(0);
        ChiTietKhamBenh current = chiTietBUS.getByMaPhieuKham(maPhieu);
        if (current == null) return;

        List<LichSuKhamBenh> list = lichSuBUS.getByCCCD(current.getCccd());
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        for (LichSuKhamBenh ls : list) {
            historyModel.addRow(new Object[]{
                    ls.getMaPhieuKham(),
                    ls.getNgayKham() != null ? sdf.format(ls.getNgayKham()) : "",
                    ls.getTenBacSi(),
                    ls.getTrangThai()
            });
        }
    }

    private void showChiTietKham(int maPK) {
        ChiTietKhamBenh ct = chiTietBUS.getByMaPhieuKham(maPK);
        if (ct == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy dữ liệu chi tiết!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(MAIN_FONT);
        area.setMargin(new Insets(10, 10, 10, 10));

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        area.setText(
                "==================================================\n" +
                "               CHI TIẾT LỊCH SỬ CA KHÁM\n" +
                "==================================================\n\n" +
                "• Mã phiếu khám: " + ct.getMaPhieuKham() + "\n" +
                "• Bệnh nhân: " + ct.getTenBenhNhan() + " | CCCD: " + ct.getCccd() + "\n" +
                "• Bác sĩ phụ trách: " + ct.getTenBacSi() + " (" + ct.getChuyenKhoa() + ")\n" +
                "• Ngày giờ khám: " + (ct.getNgayKham() != null ? sdf.format(ct.getNgayKham()) : "") + "\n\n" +
                "--------------------------------------------------\n" +
                " TRẠNG THÁI LÂM SÀNG BỆNH NHÂN\n" +
                "--------------------------------------------------\n" +
                "• Lý do khám: " + nullToEmpty(ct.getLyDoKham()) + "\n" +
                "• Bệnh sử: " + nullToEmpty(ct.getBenhSu()) + "\n" +
                "• Tiền sử bệnh: " + nullToEmpty(ct.getTienSuBanThan()) + "\n" +
                "• Khám lâm sàng: " + nullToEmpty(ct.getKhamLamSang()) + "\n" +
                "• Kết quả cận lâm sàng: " + nullToEmpty(ct.getKetQuaCanLamSang()) + "\n\n" +
                "--------------------------------------------------\n" +
                " CHẨN ĐOÁN & ĐIỀU TRỊ CỦA BÁC SĨ\n" +
                "--------------------------------------------------\n" +
                "• Chẩn đoán sơ bộ: " + nullToEmpty(ct.getChanDoanSoBo()) + "\n" +
                "• Lời dặn bác sĩ: " + nullToEmpty(ct.getLoiDanBacSi()) + "\n"
        );

        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(650, 500));
        JOptionPane.showMessageDialog(this, sp, "Hồ sơ bệnh án cũ: " + maPK, JOptionPane.INFORMATION_MESSAGE);
    }

    private void save() {
        ChiSoKhamTongHop c = new ChiSoKhamTongHop();
        c.setMaPhieuKham(maPhieu);
        c.setMaNhanVienNhap(Session.currentUser.getMaNhanVien());
        c.setTinhTrangRang(txtTinhTrangChung.getText());
        c.setBenhLyKhacRHM(txtBenhLyKhac.getText());
        c.setGhiChu(txtGhiChu.getText());

        boolean ok = csDao.saveOrUpdate(c);

        KhamLamSang ls = new KhamLamSang();
        ls.setMaPhieuKham(maPhieu);
        ls.setChanDoanSoBo(txtChanDoan.getText());
        ls.setLoiDanBacSi(txtLoiDan.getText());
        lsDao.saveOrUpdate(ls);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Hệ thống đã lưu lại dữ liệu hiện tại!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
            loadOldData();
            loadHistory();
        } else {
            JOptionPane.showMessageDialog(this, "Lưu dữ liệu thất bại!", "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void update() {
        save();
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private void chuyenXQuang() {
        try {
            save();
            PhieuKhamDAO dao = new PhieuKhamDAO();
            boolean daCo = dao.checkDaChiDinhDichVu(maPhieu, 31);

            if (daCo) {
                JOptionPane.showMessageDialog(this, "Bệnh nhân này đã được chỉ định dịch vụ X-Quang trước đó!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean okTrangThai = dao.updateTrangThai(maPhieu, "CLS_CHAN_DOAN_HINH_ANH");
            int maPhieuChiDinh = dao.createPhieuChiDinh(maPhieu);

            if (maPhieuChiDinh == -1) {
                JOptionPane.showMessageDialog(this, "Lỗi không thể tạo phiếu chỉ định dịch vụ!", "Thất bại", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean okChiTiet = dao.insertChiTietChiDinh(maPhieuChiDinh, 31);

            if (okTrangThai && okChiTiet) {
                JOptionPane.showMessageDialog(this, "Đã gửi yêu cầu và chuyển bệnh nhân sang phòng chụp X-Quang thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Quá trình chuyển tiếp phòng ban thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi hệ thống trong quá trình điều phối!", "Lỗi nghiêm trọng", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void moDonThuoc() {
        try {
            save();
            ToaThuocForm f = new ToaThuocForm(maPhieu);
            f.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Không thể khởi tạo màn hình đơn thuốc!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void henTaiKham() {
        try {
            save();
            ChiTietKhamBenh ct = chiTietBUS.getByMaPhieuKham(maPhieu);
            if (ct == null) {
                JOptionPane.showMessageDialog(this, "Không thể truy xuất thông tin ca khám để hẹn tái khám!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            BenhNhan bn = benhNhanDAO.findByCCCD(ct.getCccd());
            if (bn == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy hồ sơ gốc của bệnh nhân!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.DATE, 3);

            JSpinner dateSpinner = new JSpinner(new SpinnerDateModel(cal.getTime(), null, null, java.util.Calendar.DAY_OF_MONTH));
            JSpinner.DateEditor editor = new JSpinner.DateEditor(dateSpinner, "dd/MM/yyyy");
            dateSpinner.setEditor(editor);
            dateSpinner.setFont(MAIN_FONT);

            JTextArea txtGhiChuTaiKham = new JTextArea(4, 20);
            txtGhiChuTaiKham.setFont(MAIN_FONT);

            JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
            panel.add(new JLabel("Ngày hẹn tái khám:"));
            panel.add(dateSpinner);
            panel.add(new JLabel("Nội dung dặn dò:"));
            panel.add(new JScrollPane(txtGhiChuTaiKham));

            int result = JOptionPane.showConfirmDialog(this, panel, "Lập lịch hẹn tái khám cho bệnh nhân", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result != JOptionPane.OK_OPTION) return;

            java.util.Date utilDate = (java.util.Date) dateSpinner.getValue();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            LichTaiKham l = new LichTaiKham();
            l.setMaBenhNhan(bn.getMaBenhNhan());
            l.setMaChuyenKhoa(5); // Mã chuyên khoa mặc định hệ thống
            l.setMaPhieuKham(maPhieu);
            l.setMaNhanVien(Session.currentUser.getMaNhanVien());
            l.setNgayTaiKham(sqlDate);
            l.setGhiChu(txtGhiChuTaiKham.getText());
            l.setTrangThai("CHUA_DEN");
            l.setDaGuiThongBao(false);

            lichTaiKhamBUS.insert(l);
            JOptionPane.showMessageDialog(this, "Đã ghi nhận lịch tái khám thành công vào hệ thống!", "Thành công", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Đã xảy ra lỗi khi tạo lịch hẹn tái khám!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void chuyenChuyenKhoa(){

        try{

            save();

            JComboBox<ChuyenKhoa> cbCK =
                    new JComboBox<>();

            // load chuyên khoa
            for(ChuyenKhoa ck :
                    chuyenKhoaBUS.getAll()){

                cbCK.addItem(ck);
            }

            JTextArea txtLyDo =
                    new JTextArea(4,20);

            JPanel panel =
                    new JPanel(
                            new GridLayout(2,2,10,10)
                    );

            panel.add(
                    new JLabel("Chuyên khoa chuyển đến")
            );

            panel.add(cbCK);

            panel.add(
                    new JLabel("Lý do chuyển")
            );

            panel.add(
                    new JScrollPane(txtLyDo)
            );

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Chuyển chuyên khoa",
                            JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE
                    );

            if(result != JOptionPane.OK_OPTION){
                return;
            }

            ChuyenKhoa ck =
                    (ChuyenKhoa)
                            cbCK.getSelectedItem();

            if(ck == null){
                return;
            }

            // =====================================
            // UPDATE PHIẾU KHÁM
            // =====================================

            PhieuKhamDAO dao =
                    new PhieuKhamDAO();

            boolean ok =
                    dao.chuyenChuyenKhoa(
                            maPhieu,
                            ck.getMaChuyenKhoa(),
                            txtLyDo.getText()
                    );

            if(ok){

                JOptionPane.showMessageDialog(
                        this,
                        "Đã chuyển bệnh nhân sang chuyên khoa: "
                                + ck.getTenChuyenKhoa()
                );

                dispose();

            }else{

                JOptionPane.showMessageDialog(
                        this,
                        "Chuyển chuyên khoa thất bại!"
                );
            }

        }catch(Exception ex){

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi chuyển chuyên khoa!"
            );
        }
    }

    private void ketThucKham() {
        try {
            PhieuKhamDAO dao = new PhieuKhamDAO();
            boolean ok = dao.updateTrangThai(maPhieu, "CHO_THANH_TOAN");
            if (ok) {
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Không thể chuyển trạng thái phiếu khám sang chờ thanh toán!", "Lỗi cập nhật", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi kết thúc ca khám!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}