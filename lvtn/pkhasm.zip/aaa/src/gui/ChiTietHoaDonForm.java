package gui;

import bus.HoaDonBUS;
import config.Session;
import dao.CTHoaDonDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;

public class ChiTietHoaDonForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JLabel lbTongTien;
    private HoaDonBUS hoaDonBUS = new HoaDonBUS();
    private CTHoaDonDAO dao = new CTHoaDonDAO();

    // Định nghĩa bảng màu hiện đại (Modern Material Colors)
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);   // Xanh dương thanh lịch
    private final Color SUCCESS_COLOR = new Color(39, 174, 96);    // Xanh lá thanh toán
    private final Color DANGER_COLOR = new Color(192, 41, 43);     // Đỏ chỉn chu
    private final Color TEXT_COLOR = new Color(44, 62, 80);        // Chữ xám đậm dễ đọc
    private final Color BG_LIGHT = new Color(245, 247, 250);       // Nền xám nhạt nhẹ mắt

    public ChiTietHoaDonForm(int maHoaDon) {
        // Khuyến khích cài FlatLaf ở hàm main: UIManager.setLookAndFeel(new FlatLightLaf());
        
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Chi Tiết Hóa Đơn #" + maHoaDon);
        setSize(900, 650); // Tăng nhẹ kích thước cho không gian thở
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);
        setContentPane(root);

        // ================= TITLE SECTION =================
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Color.WHITE);
        titlePanel.setBorder(new EmptyBorder(20, 25, 15, 25));

        JLabel title = new JLabel("CHI TIẾT HÓA ĐƠN", SwingConstants.LEFT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);

        JLabel subtitle = new JLabel("Mã số: #" + maHoaDon, SwingConstants.LEFT);
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        subtitle.setForeground(Color.GRAY);

        titlePanel.add(title, BorderLayout.NORTH);
        titlePanel.add(subtitle, BorderLayout.SOUTH);
        root.add(titlePanel, BorderLayout.NORTH);

        // ================= TABLE SECTION =================
        model = new DefaultTableModel(
                new String[]{
                        "ID", "Nội Dung", "Loại", "Số Lượng", "Đơn Giá (VNĐ)", "Thành Tiền (VNĐ)"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho sửa trực tiếp trên bảng dữ liệu
            }
        };

        table = new JTable(model);
        table.setRowHeight(35); // Dòng cao nhìn thông thoáng hơn
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setSelectionBackground(new Color(232, 244, 248));
        table.setSelectionForeground(TEXT_COLOR);
        table.setGridColor(new Color(230, 230, 230));
        table.setShowVerticalLines(false); // Tắt đường kẻ dọc theo style hiện đại

        // Custom Header cho Table
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(100, 40));

        // Căn giữa/phải nội dung các cột dữ liệu
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);

        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // ID
        table.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); // Loại
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // Số lượng
        table.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);  // Đơn giá
        table.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);  // Thành tiền

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(new EmptyBorder(0, 25, 0, 25)); // Đẩy bảng cách lề đều 2 bên
        scroll.getViewport().setBackground(Color.WHITE);
        root.add(scroll, BorderLayout.CENTER);

        // ================= FOOTER SECTION =================
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BG_LIGHT);
        footer.setBorder(new EmptyBorder(15, 25, 15, 25));

        lbTongTien = new JLabel("Tổng tiền: 0 VNĐ");
        lbTongTien.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbTongTien.setForeground(DANGER_COLOR);

        // Panel chứa các nút bấm (Sử dụng FlowLayout có Gap tăng khoảng cách)
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setBackground(BG_LIGHT);

        JButton btnXemHoaDon = createModernButton("XEM HÓA ĐƠN", Color.WHITE, TEXT_COLOR);
        JButton btnInHoaDon = createModernButton("IN HÓA ĐƠN", Color.WHITE, TEXT_COLOR);
        JButton btnThanhToan = createModernButton("THANH TOÁN", SUCCESS_COLOR, Color.WHITE);
        JButton btnDong = createModernButton("ĐÓNG", new Color(149, 165, 166), Color.WHITE);

        rightPanel.add(btnXemHoaDon);
        rightPanel.add(btnInHoaDon);
        rightPanel.add(btnThanhToan);
        rightPanel.add(btnDong);

        footer.add(lbTongTien, BorderLayout.WEST);
        footer.add(rightPanel, BorderLayout.EAST);
        root.add(footer, BorderLayout.SOUTH);

        // ================= ACTIONS =================
        btnDong.addActionListener(e -> dispose());

        btnThanhToan.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this, "Xác nhận thanh toán hóa đơn này?", "Thanh toán",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE
            );
            if (confirm != JOptionPane.YES_OPTION) return;

            int maNhanVien = Session.currentUser.getMaNhanVien();
            boolean kq = hoaDonBUS.thanhToan(maHoaDon, maNhanVien);

            if (kq) {
                JOptionPane.showMessageDialog(this, "Thanh toán thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Thanh toán thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnXemHoaDon.addActionListener(e -> {
            try {
                Object[] info = hoaDonBUS.getThongTinHoaDon(maHoaDon);
                StringBuilder hd = new StringBuilder();
                hd.append("=========== HÓA ĐƠN KHÁM BỆNH ===========\n\n");
                hd.append(String.format("Mã hóa đơn:    %s\n", maHoaDon));
                hd.append(String.format("Bệnh nhân:     %s\n", info[0]));
                hd.append(String.format("Bác sĩ khám:   %s\n", info[1]));
                hd.append(String.format("Ngày khám:     %s\n", info[2]));
                hd.append(String.format("Chuẩn đoán:    %s\n", info[3] == null ? "" : info[3]));
                hd.append(String.format("Lời dặn:       %s\n", info[4] == null ? "" : info[4]));
                hd.append(String.format("Tái khám:      %s\n\n", info[5] == null ? "Không có" : info[5]));
                hd.append("=========== CHI TIẾT DỊCH VỤ ===========\n\n");

                for (int i = 0; i < model.getRowCount(); i++) {
                    hd.append(String.format("- %s (%s)\n", model.getValueAt(i, 1), model.getValueAt(i, 2)));
                    hd.append(String.format("  SL: %s  x  Đơn giá: %s VNĐ  ->  Thành tiền: %s VNĐ\n", 
                            model.getValueAt(i, 3), model.getValueAt(i, 4), model.getValueAt(i, 5)));
                    hd.append("--------------------------------------------------\n");
                }
                hd.append("\n").append(lbTongTien.getText());

                JTextArea area = new JTextArea(hd.toString());
                area.setFont(new Font("Monospaced", Font.PLAIN, 14));
                area.setEditable(false);
                area.setBorder(new EmptyBorder(10, 10, 10, 10));

                JOptionPane.showMessageDialog(this, new JScrollPane(area), "Xem chi tiết", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi xem hóa đơn!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnInHoaDon.addActionListener(e -> {
            try {
                Object[] info = hoaDonBUS.getThongTinHoaDon(maHoaDon);
                JTextArea area = new JTextArea();
                StringBuilder sb = new StringBuilder();
                sb.append("=============== HÓA ĐƠN ===============\n\n");
                sb.append("Mã hóa đơn: ").append(maHoaDon).append("\n");
                sb.append("Bệnh nhân: ").append(info[0]).append("\n");
                sb.append("Bác sĩ: ").append(info[1]).append("\n");
                sb.append("Ngày khám: ").append(info[2]).append("\n");
                sb.append("Chuẩn đoán: ").append(info[3]).append("\n");
                sb.append("Lời dặn: ").append(info[4]).append("\n");
                sb.append("Ngày tái khám: ").append(info[5]).append("\n\n");
                sb.append("=========== CHI TIẾT ===========\n\n");

                for (int i = 0; i < model.getRowCount(); i++) {
                    sb.append(model.getValueAt(i, 1))
                            .append(" | SL: ").append(model.getValueAt(i, 3))
                            .append(" | ").append(model.getValueAt(i, 5)).append(" VNĐ\n");
                }
                sb.append("\n").append(lbTongTien.getText());
                area.setText(sb.toString());
                area.setFont(new Font("Monospaced", Font.PLAIN, 12));

                if (area.print()) {
                    JOptionPane.showMessageDialog(this, "In hóa đơn thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Đã hủy in!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi in hóa đơn!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        // ================= LOAD DATA =================
        loadData(maHoaDon);
    }

    // Hàm phụ trợ khởi tạo Button chuẩn chỉnh, đỡ rối code mắt
    private JButton createModernButton(String text, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setBackground(background);
        button.setForeground(foreground);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(130, 38)); // Kích thước nút cân đối
        
        // Nếu dùng giao diện mặc định, đường line border này giúp nút phẳng (Flat) hơn
        if(background != Color.WHITE) {
            button.setBorder(BorderFactory.createLineBorder(background));
        } else {
            button.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        }
        return button;
    }

    private void loadData(int maHoaDon) {
        model.setRowCount(0);
        DecimalFormat df = new DecimalFormat("#,###");
        BigDecimal tong = BigDecimal.ZERO;

        List<Object[]> list = dao.getByHoaDon(maHoaDon);
        for (Object[] row : list) {
            BigDecimal thanhTien = (BigDecimal) row[5];
            tong = tong.add(thanhTien);

            model.addRow(new Object[]{
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                    df.format(row[4]),
                    df.format(row[5])
            });
        }
        lbTongTien.setText("Tổng tiền: " + df.format(tong) + " VNĐ");
    }
}