package gui;

import config.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DanhSachChoCDHAForm extends JFrame {

    JTable table;
    DefaultTableModel model;

    public DanhSachChoCDHAForm() {
        setTitle("Danh sách chờ chẩn đoán hình ảnh");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 247, 250)); // Nền sáng hiện đại

        // ====================================
        // HEADER PANEL
        // ====================================
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 224, 230)));
        headerPanel.setPreferredSize(new Dimension(1200, 70));

        JLabel lblTitle = new JLabel(" DANH SÁCH CHỜ CHẨN ĐOÁN HÌNH ẢNH");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(new Color(28, 43, 65));
        lblTitle.setBorder(new EmptyBorder(0, 20, 0, 0));
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // ====================================
        // TABLE SETUP (UI/UX Optimized)
        // ====================================
        model = new DefaultTableModel(
                new String[]{
                        "Mã PK",
                        "Tên bệnh nhân",
                        "Lý do khám",
                        "Trạng thái"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho sửa trực tiếp trên bảng
            }
        };

        table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(new Color(28, 43, 65));
        table.setGridColor(new Color(240, 242, 245));
        table.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo style hiện đại

        // Tùy biến Header của Table
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableHeader.setBackground(new Color(240, 242, 245));
        tableHeader.setForeground(new Color(74, 85, 104));
        tableHeader.setPreferredSize(new Dimension(100, 40));
        tableHeader.setReorderingAllowed(false);

        // Cấu hình độ rộng các cột hợp lý
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(250);
        table.getColumnModel().getColumn(2).setPreferredWidth(550);
        table.getColumnModel().getColumn(3).setPreferredWidth(300);

        // Custom Renderer vẽ màu nền xen kẽ (Zebra) và trạng thái Badge mẫu
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, isSel, hasFocus, row, col);
                
                // Đổ màu dòng xen kẽ
                if (!isSel) {
                    if (row % 2 == 0) {
                        c.setBackground(Color.WHITE);
                    } else {
                        c.setBackground(new Color(250, 251, 253));
                    }
                }
                
                setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10)); // Thêm padding cho chữ

                // Thiết kế cột trạng thái thành dạng Badge trực quan
                if (col == 3 && val != null) {
                    JPanel badgePanel = new JPanel(new GridBagLayout());
                    badgePanel.setBackground(c.getBackground());
                    
                    JLabel lblBadge = new JLabel(val.toString());
                    lblBadge.setFont(new Font("Segoe UI", Font.BOLD, 12));
                    lblBadge.setOpaque(true);
                    lblBadge.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
                    
                    // Style cho chuỗi CLS_CHAN_DOAN_HINH_ANH hoặc chữ rút gọn
                    lblBadge.setBackground(new Color(224, 242, 241));
                    lblBadge.setForeground(new Color(0, 121, 107));
                    
                    badgePanel.add(lblBadge);
                    return badgePanel;
                }

                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        // ====================================
        // BUTTONS PANEL
        // ====================================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220, 224, 230)));

        JButton btnKham = new JButton("Tiến hành khám");
        btnKham.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKham.setBackground(new Color(13, 110, 253)); // Xanh dương Primary
        btnKham.setForeground(Color.WHITE);
        btnKham.setFocusPainted(false);
        btnKham.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnKham.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JButton btnHuy = new JButton("Hủy đăng ký");
        btnHuy.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnHuy.setBackground(new Color(248, 215, 218)); // Đỏ nhạt dịu mắt cho thao tác Danger
        btnHuy.setForeground(new Color(132, 32, 41));
        btnHuy.setFocusPainted(false);
        btnHuy.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnHuy.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Hiệu ứng Hover thủ công tăng trải nghiệm tương tác mượt mà
        btnKham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btnKham.setBackground(new Color(11, 94, 215)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btnKham.setBackground(new Color(13, 110, 253)); }
        });
        btnHuy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btnHuy.setBackground(new Color(245, 194, 199)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btnHuy.setBackground(new Color(248, 215, 218)); }
        });

        btnKham.addActionListener(e -> open());
        btnHuy.addActionListener(e -> huyDangKy());

        bottom.add(btnHuy);
        bottom.add(btnKham);
        add(bottom, BorderLayout.SOUTH);

        // Khởi động load dữ liệu
        loadData();
    }

    private void loadData() {
        model.setRowCount(0);
        
        // Sử dụng SwingWorker giúp tải DB bất đồng bộ không gây treo đơ khung hình UI
        SwingWorker<List<Object[]>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Object[]> doInBackground() throws Exception {
                List<Object[]> list = new ArrayList<>();
                String sql = """
                        SELECT pk.ma_phieu_kham,
                               bn.ho_ten,
                               ls.ly_do_kham,
                               pk.trang_thai
                        FROM phieu_kham pk
                        JOIN benh_nhan bn
                            ON pk.ma_benh_nhan = bn.ma_benh_nhan
                        LEFT JOIN kham_lam_sang ls
                            ON pk.ma_phieu_kham = ls.ma_phieu_kham
                        WHERE pk.trang_thai = 'CLS_CHAN_DOAN_HINH_ANH'
                        """;

                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql);
                     ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {
                        list.add(new Object[]{
                                rs.getInt(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4)
                        });
                    }
                }
                return list;
            }

            @Override
            protected void done() {
                try {
                    List<Object[]> result = get();
                    for (Object[] row : result) {
                        model.addRow(row);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(DanhSachChoCDHAForm.this, 
                            "Lỗi tải dữ liệu danh sách chờ!", "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void open() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một bệnh nhân từ danh sách!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(model.getValueAt(row, 0).toString());
        new TienHanhCDHAForm(maPhieu).setVisible(true);
    }

    private void huyDangKy() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn bệnh nhân cần hủy chỉ định!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn hủy chỉ định CDHA của bệnh nhân này?",
                "Xác nhận hành động",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        int maPhieu = Integer.parseInt(model.getValueAt(row, 0).toString());

        // Đưa tác vụ cập nhật DB nặng vào luồng chạy nền riêng biệt
        SwingWorker<Boolean, Void> updateWorker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                try (Connection con = DBConnection.getConnection()) {
                    con.setAutoCommit(false); // Sử dụng Transaction đảm bảo an toàn dữ liệu

                    String updatePK = """
                            UPDATE phieu_kham
                            SET trang_thai='DANG_KHAM'
                            WHERE ma_phieu_kham=?
                            """;
                    try (PreparedStatement ps1 = con.prepareStatement(updatePK)) {
                        ps1.setInt(1, maPhieu);
                        ps1.executeUpdate();
                    }

                    String updateCT = """
                            UPDATE chi_tiet_chi_dinh ctd
                            JOIN phieu_chi_dinh pcd
                                ON ctd.ma_phieu_chi_dinh = pcd.ma_phieu_chi_dinh
                            SET ctd.trang_thai_dv='HUY'
                            WHERE pcd.ma_phieu_kham=?
                            AND ctd.ma_dich_vu=31
                            """;
                    try (PreparedStatement ps2 = con.prepareStatement(updateCT)) {
                        ps2.setInt(1, maPhieu);
                        ps2.executeUpdate();
                    }

                    con.commit();
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }

            @Override
            protected void done() {
                try {
                    if (get()) {
                        JOptionPane.showMessageDialog(DanhSachChoCDHAForm.this, "Hủy đăng ký CDHA thành công!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(DanhSachChoCDHAForm.this, "Lỗi khi xử lý dữ liệu hủy đăng ký!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        updateWorker.execute();
    }
}