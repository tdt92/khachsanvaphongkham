package gui;

import dao.DangKyKhamBenhDAO;
import model.DangKyKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class KhamRangForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JLabel lblCount; // Nhãn hiển thị số lượng bệnh nhân đang chờ

    private final Color BG = new Color(244, 246, 249);       // Nền xám xanh nhẹ thanh lịch
    private final Color PRIMARY = new Color(41, 128, 185);   // Xanh chủ đạo
    private final Color SUCCESS = new Color(39, 174, 96);    // Xanh lá hành động thành công
    private final Color TEXT_DARK = new Color(44, 62, 80);

    private DangKyKhamBenhDAO dao = new DangKyKhamBenhDAO();

    public KhamRangForm() {
        setTitle("DANH SÁCH BỆNH NHÂN CHỜ KHÁM RĂNG");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(root);

        // =========================================================================
        // THANH TRÊN (TOP): THỐNG KÊ & LÀM MỚI
        // =========================================================================
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(BG);

        // Bên trái: Tiêu đề và bộ đếm số lượng ca chờ
        JPanel leftTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        leftTop.setBackground(BG);
        
        JLabel lblTitle = new JLabel("DANH SÁCH CHỜ KHÁM  ");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_DARK);
        
        lblCount = new JLabel("(Đang chờ: 0)");
        lblCount.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 14));
        lblCount.setForeground(new Color(230, 126, 34)); // Màu cam nổi bật cảnh báo số lượng

        leftTop.add(lblTitle);
        leftTop.add(lblCount);

        // Bên phải: Nút làm mới dữ liệu
        JButton btnRefresh = new JButton("🔄 Làm mới danh sách");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBackground(Color.WHITE);
        btnRefresh.setForeground(PRIMARY);
        btnRefresh.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 220), 1),
                BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRefresh.addActionListener(e -> loadData());

        topPanel.add(leftTop, BorderLayout.WEST);
        topPanel.add(btnRefresh, BorderLayout.EAST);
        root.add(topPanel, BorderLayout.NORTH);

        // =========================================================================
        // KHU VỰC GIỮA (CENTER): BẢNG DỮ LIỆU ĐƯỢC TỐI ƯU
        // =========================================================================
        model = new DefaultTableModel(
                new String[]{"ID ĐK", "Mã BN", "Họ tên bệnh nhân", "Số thứ tự", "Mã phiếu"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(38); // Hàng cao rộng rãi, dễ click chọn trên màn hình cảm ứng cảm quan tốt
        table.setSelectionBackground(new Color(232, 244, 248)); // Màu nền khi chọn hàng
        table.setSelectionForeground(TEXT_DARK);
        table.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo xu hướng UI hiện đại
        table.setGridColor(new Color(230, 235, 240));

        // Định dạng Header của Table
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(PRIMARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
        table.getTableHeader().setReorderingAllowed(false);

        // Căn giữa dữ liệu cho các cột số (ID, Mã, STT)
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        // Điều chỉnh tỷ lệ độ rộng các cột
        table.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID ĐK
        table.getColumnModel().getColumn(1).setPreferredWidth(100); // Mã BN
        table.getColumnModel().getColumn(2).setPreferredWidth(400); // Họ tên
        table.getColumnModel().getColumn(3).setPreferredWidth(100); // STT

        // Ẩn cột Mã phiếu (Giữ nguyên logic của bạn)
        table.getColumnModel().getColumn(4).setMinWidth(0);
        table.getColumnModel().getColumn(4).setMaxWidth(0);
        table.getColumnModel().getColumn(4).setWidth(0);

        // Bọc bảng vào ScrollPane phẳng không viền thô
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 225), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
        root.add(scrollPane, BorderLayout.CENTER);

        // =========================================================================
        // THANH DƯỚI (SOUTH): ĐIỀU HƯỚNG & HÀNH ĐỘNG
        // =========================================================================
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(BG);

        // Bên trái: Quay lại Dashboard chính
        JButton btnBack = new JButton("⬅ Quay lại");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setFocusPainted(false);
        btnBack.setContentAreaFilled(false); // Dạng nút text phẳng tinh tế
        btnBack.setForeground(new Color(127, 140, 141));
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> {
            new KhoaRangForm().setVisible(true);
            dispose();
        });

        // Bên phải: Nút Tiến hành khám bệnh lớn nổi bật
        JButton btnKham = new JButton("TIẾN HÀNH KHÁM ➜");
        btnKham.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKham.setFocusPainted(false);
        btnKham.setBackground(SUCCESS);
        btnKham.setForeground(Color.WHITE);
        btnKham.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        btnKham.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnKham.addActionListener(e -> openKham());

        bottomPanel.add(btnBack, BorderLayout.WEST);
        bottomPanel.add(btnKham, BorderLayout.EAST);
        root.add(bottomPanel, BorderLayout.SOUTH);

        loadData();
    }

    private void loadData() {
        model.setRowCount(0);
        List<DangKyKhamBenh> list = dao.getChoKhamKhoaRang();

        if (list != null) {
            // Cập nhật số ca chờ trực quan lên nhãn tiêu đề
            lblCount.setText("(Đang chờ: " + list.size() + " ca)");
            
            for (DangKyKhamBenh dk : list) {
                model.addRow(new Object[]{
                        dk.getId(),
                        dk.getMaBenhNhan(),
                        dk.getHoTen(),
                        dk.getSoThuTu(),
                        dk.getMaPhieuKham()
                });
            }
        } else {
            lblCount.setText("(Đang chờ: 0 ca)");
        }
    }

    private void openKham() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một bệnh nhân từ danh sách để tiến hành khám!", 
                    "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object value = model.getValueAt(row, 4);

        if (value == null) {
            JOptionPane.showMessageDialog(this, "Bệnh nhân này chưa được tạo mã phiếu khám trên hệ thống!", 
                    "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(value.toString());

        if (maPhieu <= 0) {
            JOptionPane.showMessageDialog(this, "Mã phiếu khám không hợp lệ!", 
                    "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
            return;
        }

        System.out.println("Mở phiếu khám: " + maPhieu);
        
        // Mở màn hình khám chi tiết
        KhamRangChiTietForm f =
                new KhamRangChiTietForm(maPhieu);

        f.setVisible(true);
    }
}