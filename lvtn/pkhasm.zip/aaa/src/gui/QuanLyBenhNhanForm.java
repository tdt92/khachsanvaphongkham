package gui;

import bus.BenhNhanBUS;
import model.BenhNhan;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.Date;
import java.util.List;

public class QuanLyBenhNhanForm extends JFrame {

    private JTextField txtHoTen, txtDiaChi, txtSDT,
            txtEmail, txtNgheNghiep, txtNhomMau,
            txtDiUng, txtNguoiGH, txtSDTGH,
            txtGhiChu, txtCCCD, txtSearch;

    private JComboBox<String> cbGioiTinh;
    private JDateChooser dateChooser;

    private JTable table;
    private DefaultTableModel model;

    private BenhNhanBUS bus = new BenhNhanBUS();
    private int selectedId = -1;

    // ===== BẢNG MÀU GIAO DIỆN HIỆN ĐẠI (FLAT UI) =====
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color CARD_BG = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 122, 255);
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);
    
    private final Color COLOR_ADD = new Color(40, 167, 69);
    private final Color COLOR_EDIT = new Color(255, 193, 7);
    private final Color COLOR_DELETE = new Color(239, 68, 68);
    private final Color COLOR_CLEAR = new Color(23, 162, 184);

    public QuanLyBenhNhanForm() {
        setTitle("QUẢN LÝ BỆNH NHÂN");
        setSize(1450, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Khởi tạo Panel nền tổng thể có padding trống xung quanh thanh thoát hơn
        JPanel rootPanel = new JPanel(new BorderLayout(0, 15));
        rootPanel.setBackground(BG_WINDOW);
        rootPanel.setBorder(new EmptyBorder(15, 20, 15, 20));
        setContentPane(rootPanel);

        // Tiêu đề form trên cùng
        rootPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Container chia đôi Form nhập liệu (NORTH) và Bảng dữ liệu (CENTER)
        JPanel mainContent = new JPanel(new BorderLayout(0, 15));
        mainContent.setOpaque(false);
        mainContent.add(createInputPanel(), BorderLayout.NORTH);
        mainContent.add(createTablePanel(), BorderLayout.CENTER);

        rootPanel.add(mainContent, BorderLayout.CENTER);

        loadData();
    }

    private void onlyNumber(JTextField txt) {
        ((AbstractDocument) txt.getDocument()).setDocumentFilter(new DocumentFilter() {
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                if (string.matches("\\d+"))
                    super.insertString(fb, offset, string, attr);
            }

            public void replace(FilterBypass fb, int offset, int length,
                                String text, AttributeSet attrs)
                    throws BadLocationException {
                if (text.matches("\\d+"))
                    super.replace(fb, offset, length, text, attrs);
            }
        });
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel lblTitle = new JLabel("👥 HỒ SƠ QUẢN LÝ BỆNH NHÂN THÔNG MINH");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_MAIN);
        header.add(lblTitle, BorderLayout.WEST);

        return header;
    }

    private JPanel createInputPanel() {
        // Tạo panel bo góc đổ bóng giả lập Card UI phẳng
        JPanel panel = new JPanel(new BorderLayout(10, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(15, 20, 15, 20),
                BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), "THÔNG TIN CHI TIẾT BỆNH NHÂN",
                        TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 14), PRIMARY_COLOR)
        ));

        // Khởi tạo các Textfield được style bo góc nhẹ viền mỏng
        txtHoTen = createStyledTextField();
        txtDiaChi = createStyledTextField();
        txtSDT = createStyledTextField();
        txtEmail = createStyledTextField();
        txtNgheNghiep = createStyledTextField();
        txtNhomMau = createStyledTextField();
        txtDiUng = createStyledTextField();
        txtNguoiGH = createStyledTextField();
        txtSDTGH = createStyledTextField();
        txtGhiChu = createStyledTextField();
        txtCCCD = createStyledTextField();
        txtSearch = createStyledTextField();

        onlyNumber(txtSDT);
        onlyNumber(txtCCCD);
        onlyNumber(txtSDTGH);

        cbGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ"});
        cbGioiTinh.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");
        dateChooser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateChooser.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));

        // Thiết kế lưới Grid Layout 4 cột thông thoáng, không dùng lưới 6 cột gây co cụm ô nhập liệu
        JPanel gridForm = new JPanel(new GridLayout(4, 4, 25, 12));
        gridForm.setOpaque(false);

        // Hàng 1
        gridForm.add(createFieldComponent("Họ và tên *", txtHoTen));
        gridForm.add(createFieldComponent("Ngày sinh *", dateChooser));
        gridForm.add(createFieldComponent("Giới tính *", cbGioiTinh));
        gridForm.add(createFieldComponent("Mã định danh CCCD *", txtCCCD));

        // Hàng 2
        gridForm.add(createFieldComponent("Số điện thoại *", txtSDT));
        gridForm.add(createFieldComponent("Địa chỉ thường trú", txtDiaChi));
        gridForm.add(createFieldComponent("Hòm thư Email", txtEmail));
        gridForm.add(createFieldComponent("Nghề nghiệp", txtNgheNghiep));

        // Hàng 3
        gridForm.add(createFieldComponent("Nhóm máu", txtNhomMau));
        gridForm.add(createFieldComponent("Tiền sử dị ứng thuốc", txtDiUng));
        gridForm.add(createFieldComponent("Người giám hộ", txtNguoiGH));
        gridForm.add(createFieldComponent("SĐT người giám hộ", txtSDTGH));

        // Hàng 4
        gridForm.add(createFieldComponent("Ghi chú bệnh án", txtGhiChu));
        gridForm.add(createFieldComponent("🔍 Tìm nhanh (Nhập tên bệnh nhân)", txtSearch));

        panel.add(gridForm, BorderLayout.CENTER);

        // ===== KHU VỰC THÀNH CÔNG CỤ NÚT BẤM CHỨC NĂNG =====
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        actionsPanel.setOpaque(false);

        JButton btnThem = styleButton("＋ Thêm mới", COLOR_ADD, Color.WHITE);
        JButton btnSua = styleButton("🔧 Chỉnh sửa", COLOR_EDIT, TEXT_MAIN);
        JButton btnXoa = styleButton("❌ Xóa hồ sơ", COLOR_DELETE, Color.WHITE);
        JButton btnMoi = styleButton("🔄 Làm mới", COLOR_CLEAR, Color.WHITE);

        btnThem.addActionListener(e -> add());
        btnSua.addActionListener(e -> update());
        btnXoa.addActionListener(e -> delete());
        btnMoi.addActionListener(e -> clearForm());

        actionsPanel.add(btnThem);
        actionsPanel.add(btnSua);
        actionsPanel.add(btnXoa);
        actionsPanel.add(btnMoi);

        panel.add(actionsPanel, BorderLayout.SOUTH);

        // Giữ nguyên logic tìm kiếm thời gian thực của bạn
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e){ search(); }
            public void removeUpdate(DocumentEvent e){ search(); }
            public void changedUpdate(DocumentEvent e){ search(); }
        });

        return panel;
    }

    // Các hàm Helper hỗ trợ vẽ giao diện Flat hiện đại nhanh chóng
    private JTextField createStyledTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return field;
    }

    private JPanel createFieldComponent(String labelText, Component comp) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 4));
        wrapper.setOpaque(false);
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(TEXT_MAIN);
        wrapper.add(label, BorderLayout.NORTH);
        wrapper.add(comp, BorderLayout.CENTER);
        return wrapper;
    }

    private JButton styleButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(fg);
        btn.setBackground(bg);
        btn.setPreferredSize(new Dimension(130, 38));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(bg); }
        });
        return btn;
    }

    // Thay đổi hàm tạo bảng sang dạng Card phẳng đồng bộ đồ họa
    private JComponent createTablePanel() {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(15, 20, 15, 20));

        model = new DefaultTableModel();
        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; } // Không cho edit đè trực tiếp trên cell
        };

        model.setColumnIdentifiers(new String[]{
                "ID","Họ tên","Ngày sinh","Giới tính",
                "Địa chỉ","SĐT","Email","Nghề nghiệp",
                "Nhóm máu","Dị ứng","Người GH",
                "SĐT GH","CCCD","Ghi chú"
        });

        // Thiết kế Table phẳng
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setSelectionBackground(new Color(232, 244, 255));
        table.setSelectionForeground(Color.BLACK);
        table.setShowGrid(true);
        table.setGridColor(new Color(240, 242, 245));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(240, 244, 248));
        header.setForeground(TEXT_MAIN);
        header.setReorderingAllowed(false);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.getSelectionModel().addListSelectionListener(e -> fillForm());

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(BORDER_COLOR), 
                " DANH SÁCH BỆNH NHÂN TRÊN HỆ THỐNG ", TitledBorder.LEFT, TitledBorder.TOP, 
                new Font("Segoe UI", Font.BOLD, 13), TEXT_MAIN));
        scrollPane.getViewport().setBackground(Color.WHITE);

        card.add(scrollPane, BorderLayout.CENTER);
        return card;
    }


    // =========================================================================
    // KHU VỰC GIỮ NGUYÊN HOÀN TOÀN LOGIC CŨ CỦA BẠN (KHÔNG CHỈNH SỬA LOGIC GỌI BUS)
    // =========================================================================
    
    private boolean validateForm(){
        if(txtHoTen.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(this,"Họ tên bắt buộc nhập!");
            return false;
        }
        if(txtCCCD.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(this,"CCCD bắt buộc nhập!");
            return false;
        }
        if(txtSDT.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(this,"SĐT bắt buộc nhập!");
            return false;
        }
        if(dateChooser.getDate()==null){
            JOptionPane.showMessageDialog(this,"Ngày sinh bắt buộc chọn!");
            return false;
        }
         if(txtDiaChi.getText().trim().isEmpty()
                || txtEmail.getText().trim().isEmpty()
                || txtNgheNghiep.getText().trim().isEmpty()){

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Một số thông tin phụ đang để trống. Bạn vẫn muốn tiếp tục?",
                    "Cảnh báo",
                    JOptionPane.YES_NO_OPTION);

            if(confirm != JOptionPane.YES_OPTION)
                return false;
        }
        return true;
    }

    private void add(){
        if(!validateForm()) return;
        if(bus.existsCCCD(txtCCCD.getText())){
            JOptionPane.showMessageDialog(this,"CCCD đã tồn tại!");
            return;
        }
        bus.insert(getForm());
        loadData();
        clearForm();
    }

    private void update(){
        if(selectedId==-1) return;
        if(!validateForm()) return;
        BenhNhan bn = getForm();
        bn.setMaBenhNhan(selectedId);
        bus.update(bn);
        loadData();
        clearForm();
    }

    private void delete(){
        if(selectedId==-1) return;
        bus.delete(selectedId);
        loadData();
        clearForm();
    }

    private void search(){
        model.setRowCount(0);
        for(BenhNhan bn : bus.searchByName(txtSearch.getText())){
            addRow(bn);
        }
    }

    private BenhNhan getForm(){
        BenhNhan bn = new BenhNhan();
        bn.setHoTen(txtHoTen.getText());
        bn.setNgaySinh(new Date(dateChooser.getDate().getTime()));
        bn.setDiaChi(txtDiaChi.getText());
        bn.setSoDienThoai(txtSDT.getText());
        bn.setEmail(txtEmail.getText());
        bn.setNgheNghiep(txtNgheNghiep.getText());
        bn.setNhomMau(txtNhomMau.getText());
        bn.setDiUngThuoc(txtDiUng.getText());
        bn.setNguoiGiamHo(txtNguoiGH.getText());
        bn.setSoDienThoaiNguoiGiamHo(txtSDTGH.getText());
        bn.setGhiChu(txtGhiChu.getText());
        bn.setCccd(txtCCCD.getText());
        bn.setGioiTinh(cbGioiTinh.getSelectedIndex());
        return bn;
    }

    private void loadData(){
        model.setRowCount(0);
        List<BenhNhan> list = bus.getAll();
        for(BenhNhan bn : list){
            addRow(bn);
        }
    }

    private void addRow(BenhNhan bn){
        model.addRow(new Object[]{
                bn.getMaBenhNhan(),
                bn.getHoTen(),
                bn.getNgaySinh(),
                bn.getGioiTinh()==0?"Nam":"Nữ",
                bn.getDiaChi(),
                bn.getSoDienThoai(),
                bn.getEmail(),
                bn.getNgheNghiep(),
                bn.getNhomMau(),
                bn.getDiUngThuoc(),
                bn.getNguoiGiamHo(),
                bn.getSoDienThoaiNguoiGiamHo(),
                bn.getCccd(),
                bn.getGhiChu()
        });
    }

    private void fillForm(){
        int row = table.getSelectedRow();
        if(row==-1) return;

        selectedId = (int) model.getValueAt(row,0);

        // Chỉ bổ sung toán tử điều kiện check null để tránh vỡ chương trình khi dữ liệu SQL trống rỗng
        txtHoTen.setText(getSafeValue(model.getValueAt(row,1)));
        
        Object dateObj = model.getValueAt(row,2);
        if (dateObj instanceof java.util.Date) {
            dateChooser.setDate((java.util.Date) dateObj);
        } else {
            dateChooser.setDate(null);
        }
        
        cbGioiTinh.setSelectedItem(getSafeValue(model.getValueAt(row,3)));
        txtDiaChi.setText(getSafeValue(model.getValueAt(row,4)));
        txtSDT.setText(getSafeValue(model.getValueAt(row,5)));
        txtEmail.setText(getSafeValue(model.getValueAt(row,6)));
        txtNgheNghiep.setText(getSafeValue(model.getValueAt(row,7)));
        txtNhomMau.setText(getSafeValue(model.getValueAt(row,8)));
        txtDiUng.setText(getSafeValue(model.getValueAt(row,9)));
        txtNguoiGH.setText(getSafeValue(model.getValueAt(row,10)));
        txtSDTGH.setText(getSafeValue(model.getValueAt(row,11)));
        txtCCCD.setText(getSafeValue(model.getValueAt(row,12)));
        txtGhiChu.setText(getSafeValue(model.getValueAt(row,13)));
    }

    private String getSafeValue(Object val) {
        return val == null ? "" : val.toString();
    }

    private void clearForm(){
        selectedId = -1;
        txtHoTen.setText("");
        dateChooser.setDate(null);
        txtDiaChi.setText("");
        txtSDT.setText("");
        txtEmail.setText("");
        txtNgheNghiep.setText("");
        txtNhomMau.setText("");
        txtDiUng.setText("");
        txtNguoiGH.setText("");
        txtSDTGH.setText("");
        txtGhiChu.setText("");
        txtCCCD.setText("");
        cbGioiTinh.setSelectedIndex(0);
        table.clearSelection();
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() ->
                new QuanLyBenhNhanForm().setVisible(true));
    }
}