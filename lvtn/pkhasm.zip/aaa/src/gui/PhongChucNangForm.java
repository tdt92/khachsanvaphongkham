package gui;

import bus.PhongChucNangBUS;
import model.PhongChucNang;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PhongChucNangForm extends JFrame {

    private JTextField txtMa = new JTextField();
    private JTextField txtTen = new JTextField();
    private JTextField txtLoai = new JTextField();    
    private JTextField txtSearch = new JTextField();

    private JTable table = new JTable();
    private DefaultTableModel model;

    private PhongChucNangBUS bus = new PhongChucNangBUS();
    private int selectedId = -1;

    public PhongChucNangForm(){

        setTitle("DASHBOARD QUẢN LÝ PHÒNG");
        setSize(1000,600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(15,15));
        getContentPane().setBackground(new Color(240,245,250));

        add(createCardPanel(),BorderLayout.NORTH);
        add(createTablePanel(),BorderLayout.CENTER);

        loadData();
    }

    private JPanel createCardPanel(){

        JPanel card = new JPanel(new GridLayout(3,4,15,15));
        card.setBorder(new EmptyBorder(20,20,20,20));
        card.setBackground(Color.WHITE);

        txtMa.setEditable(false);

        card.add(new JLabel("Mã phòng"));
        card.add(txtMa);

        card.add(new JLabel("Tên phòng"));
        card.add(txtTen);

        card.add(new JLabel("Loại phòng"));
        card.add(txtLoai);    

        card.add(new JLabel("Tìm kiếm"));
        card.add(txtSearch);

        JButton btnAdd = createButton("Thêm");
        JButton btnUpdate = createButton("Sửa");
        JButton btnDelete = createButton("Xóa");

        card.add(btnAdd);
        card.add(btnUpdate);
        card.add(btnDelete);

        btnAdd.addActionListener(e->add());
        btnUpdate.addActionListener(e->update());
        btnDelete.addActionListener(e->delete());
        txtSearch.addCaretListener(e->search());

        return card;
    }

    private JButton createButton(String text){
        JButton btn = new JButton(text);
        btn.setBackground(new Color(52,152,219));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    private JScrollPane createTablePanel(){

        model = new DefaultTableModel(
                new String[]{"Mã","Tên phòng","Loại phòng"},0);

        table.setModel(model);
        table.setRowHeight(25);

        table.getSelectionModel()
                .addListSelectionListener(e->fillForm());

        return new JScrollPane(table);
    }

    private void loadData(){
        model.setRowCount(0);
        for(PhongChucNang p:bus.getAll()){
            model.addRow(new Object[]{
                    p.getMaPhong(),
                    p.getTenPhong(),
                    p.getLoaiPhong()
            });
        }
    }

    private void search(){
        model.setRowCount(0);
        for(PhongChucNang p:bus.search(txtSearch.getText())){
            model.addRow(new Object[]{
                    p.getMaPhong(),
                    p.getTenPhong(),
                    p.getLoaiPhong()
            });
        }
    }

    private void fillForm(){
        int row = table.getSelectedRow();
        if(row<0) return;

        selectedId = (int)model.getValueAt(row,0);
        txtMa.setText(model.getValueAt(row,0)+"");
        txtTen.setText(model.getValueAt(row,1)+"");
        txtLoai.setText(model.getValueAt(row,2)+"");   // ← sửa chỗ này
    }

    private void add(){
        try{
            PhongChucNang p = new PhongChucNang();
            p.setTenPhong(txtTen.getText().trim());
            p.setLoaiPhong(txtLoai.getText().trim());

            bus.insert(p);
            loadData();
            clear();

            JOptionPane.showMessageDialog(this,"Thêm thành công");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this,ex.getMessage());
        }
    }

    private void update(){
        if(selectedId==-1) return;

        try{
            PhongChucNang p = new PhongChucNang();
            p.setMaPhong(selectedId);
            p.setTenPhong(txtTen.getText().trim());
            p.setLoaiPhong(txtLoai.getText().trim());

            bus.update(p);
            loadData();
            clear();

            JOptionPane.showMessageDialog(this,"Cập nhật thành công");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this,ex.getMessage());
        }
    }

    private void delete(){
        if(selectedId==-1) return;

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        );

        if(confirm == JOptionPane.YES_OPTION){
            bus.delete(selectedId);
            loadData();
            clear();
        }
    }

    private void clear(){
        selectedId=-1;
        txtMa.setText("");
        txtTen.setText("");
        txtLoai.setText("");
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(()->
                new PhongChucNangForm().setVisible(true));
    }
}