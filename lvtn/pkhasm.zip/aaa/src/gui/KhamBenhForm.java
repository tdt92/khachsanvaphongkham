package gui;

import bus.KhamBenhBUS;
import config.Session;
import dao.PhieuKhamDAO;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KhamBenhForm extends JFrame {

    private int maDangKy;
    private int maPhieuKham = -1;

    // Thay thế JTextField thông thường bằng các ô nhập định dạng số
    JTextField txtNhietDo = new JTextField();
    JTextField txtNhipTim = new JTextField();
    JTextField txtHuyetAp = new JTextField();
    JTextField txtNhipTho = new JTextField();
    JTextField txtCanNang = new JTextField();
    JTextField txtChieuCao = new JTextField();

    JTextArea txtLyDo = new JTextArea(3, 20);
    JTextArea txtBenhSu = new JTextArea(3, 20);
    JTextArea txtTienSu = new JTextArea(3, 20);
    JTextArea txtGhiChu = new JTextArea(3, 20);

    KhamBenhBUS bus = new KhamBenhBUS();

    // Bảng màu giao diện y tế phẳng hiện đại
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color COLOR_PRIMARY = new Color(0, 122, 255);
    private final Color COLOR_SUCCESS = new Color(46, 204, 113);
    private final Color COLOR_MUTED = new Color(149, 165, 166);

    public KhamBenhForm(int maDangKy) {
        this.maDangKy = maDangKy;

        setTitle("Hồ Sơ Khám Bệnh - Đăng Ký Số: " + maDangKy);
        setSize(1000, 680); // Tăng chiều ngang để chia 2 cột đẹp mắt
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG_WINDOW);
        root.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(root);

        // ================= TOP: TIÊU ĐỀ =================
        JLabel title = new JLabel("PHIẾU TIẾP NHẬN & CHẨN ĐOÁN LÂM SÀNG");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(TEXT_MAIN);
        root.add(title, BorderLayout.NORTH);

        // ================= CENTER: BIỂU MẪU CHIA 2 CỘT =================
        JPanel mainForm = new JPanel(new GridLayout(1, 2, 25, 0));
        mainForm.setOpaque(false);

        // Ràng buộc chỉ cho phép nhập số vào các ô sinh hiệu
        onlyAllowNumberInput(txtNhietDo, true);  // Số thực (Nhiệt độ)
        onlyAllowNumberInput(txtNhipTim, false); // Số nguyên (Nhịp tim)
        onlyAllowNumberInput(txtHuyetAp, false); // Số nguyên (Huyết áp)
        onlyAllowNumberInput(txtNhipTho, false); // Số nguyên (Nhịp thở)
        onlyAllowNumberInput(txtCanNang, true);  // Số thực (Cân nặng)
        onlyAllowNumberInput(txtChieuCao, true); // Số thực (Chiều cao)

        // --- CỘT TRÁI: THÔNG TIN LÂM SÀNG (TEXT AREA) ---
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setOpaque(false);
        GridBagConstraints gbcL = new GridBagConstraints();
        gbcL.gridx = 0; gbcL.weightx = 1.0; gbcL.fill = GridBagConstraints.HORIZONTAL;
        gbcL.insets = new Insets(0, 0, 10, 0);

        addTextAreaField(leftPanel, "Lý do khám bệnh:", txtLyDo, gbcL, 0);
        addTextAreaField(leftPanel, "Bệnh sử hiện tại:", txtBenhSu, gbcL, 2);
        addTextAreaField(leftPanel, "Tiền sử bệnh lý:", txtTienSu, gbcL, 4);
        addTextAreaField(leftPanel, "Ghi chú thêm:", txtGhiChu, gbcL, 6);

        // --- CỘT PHẢI: CHỈ SỐ SINH HIỆU (TEXT FIELD + ĐƠN VỊ) ---
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 230, 238), 1),
                new EmptyBorder(15, 20, 15, 20)
        ));
        
        GridBagConstraints gbcR = new GridBagConstraints();
        gbcR.fill = GridBagConstraints.HORIZONTAL;
        gbcR.insets = new Insets(8, 0, 8, 0);

        addInputField(rightPanel, "Nhiệt độ cơ thể:", txtNhietDo, "°C", gbcR, 0);
        addInputField(rightPanel, "Nhịp tim:", txtNhipTim, "lần/phút", gbcR, 1);
        addInputField(rightPanel, "Huyết áp tâm thu:", txtHuyetAp, "mmHg", gbcR, 2);
        addInputField(rightPanel, "Nhịp thở:", txtNhipTho, "lần/phút", gbcR, 3);
        addInputField(rightPanel, "Cân nặng bệnh nhân:", txtCanNang, "kg", gbcR, 4);
        addInputField(rightPanel, "Chiều cao hiện tại:", txtChieuCao, "cm", gbcR, 5);

        mainForm.add(leftPanel);
        mainForm.add(rightPanel);
        root.add(mainForm, BorderLayout.CENTER);

        // ================= SOUTH: HỆ THỐNG NÚT BẤM CÂN ĐỐI =================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        bottom.setOpaque(false);

        JButton btnXQuang = createModernButton("⚙ Chỉ định X-Quang", COLOR_PRIMARY);
        JButton btnUpdate = createModernButton("Cập nhật số liệu", COLOR_MUTED);
        JButton btnSave = createModernButton("Lưu bệnh án 💾", COLOR_SUCCESS);

        bottom.add(btnXQuang);
        bottom.add(btnUpdate);
        bottom.add(btnSave);
        root.add(bottom, BorderLayout.SOUTH);

        // ================= KẾT NỐI SỰ KIỆN GỐC =================
        btnSave.addActionListener(e -> save());
        btnUpdate.addActionListener(e -> update());
        btnXQuang.addActionListener(e -> chuyenXQuang());
    }

    // ================= THIẾT KẾ GIAO DIỆN TRƯỜNG PHỤ TRỢ =================
    private void addTextAreaField(JPanel parent, String labelText, JTextArea textArea, GridBagConstraints gbc, int row) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(TEXT_MAIN);
        gbc.gridy = row;
        parent.add(label, gbc);

        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(210, 215, 225), 1));
        gbc.gridy = row + 1;
        parent.add(scroll, gbc);
    }

    private void addInputField(JPanel parent, String labelText, JTextField field, String unit, GridBagConstraints gbc, int row) {
        gbc.gridy = row;
        
        // Nhãn mô tả trường nhập
        gbc.gridx = 0; gbc.weightx = 0.4;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        parent.add(label, gbc);

        // Panel bọc ô nhập dữ liệu và đơn vị y tế đi kèm
        gbc.gridx = 1; gbc.weightx = 0.6;
        JPanel fieldPane = new JPanel(new BorderLayout(5, 0));
        fieldPane.setOpaque(false);
        
        field.setFont(new Font("Segoe UI", Font.BOLD, 14));
        field.setPreferredSize(new Dimension(100, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 225), 1),
                new EmptyBorder(0, 8, 0, 8)
        ));
        
        JLabel lblUnit = new JLabel(unit);
        lblUnit.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblUnit.setForeground(new Color(120, 130, 140));
        lblUnit.setPreferredSize(new Dimension(80, 32));

        fieldPane.add(field, BorderLayout.CENTER);
        fieldPane.add(lblUnit, BorderLayout.EAST);
        parent.add(fieldPane, gbc);
    }

    private JButton createModernButton(String text, Color baseColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(baseColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(180, 42));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { button.setBackground(baseColor.brighter()); }
            @Override public void mouseExited(MouseEvent e) { button.setBackground(baseColor); }
        });
        return button;
    }

    // ================= BỘ LỌC CHỈ CHO PHÉP NHẬP SỐ CHUẨN Y KHOA =================
    private void onlyAllowNumberInput(JTextField field, boolean isFloat) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) return;
                if (isValid(fb.getDocument().getText(0, fb.getDocument().getLength()), string, offset, isFloat)) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text == null) return;
                // Tạo chuỗi giả định sau khi thay thế để kiểm tra tính hợp lệ
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                String before = currentText.substring(0, offset);
                String after = currentText.substring(offset + length);
                if (isValid(before + after, text, offset, isFloat)) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }

            private boolean isValid(String currentText, String incomingText, int offset, boolean isFloat) {
                // Chỉ cho phép ký tự số, nếu là số thực thì cho phép thêm đúng một dấu chấm phân tách thập phân
                if (isFloat) {
                    if (incomingText.equals(".")) {
                        return !currentText.contains(".");
                    }
                    return incomingText.matches("[0-9]+");
                } else {
                    return incomingText.matches("[0-9]+");
                }
            }
        });
    }

    // =====================================================
    // CÁC HÀM XỬ LÝ LOGIC GỐC (GIỮ NGUYÊN HOÀN TOÀN)
    // =====================================================
    private void save() {
        try {
            if (maPhieuKham == -1) {
                PhieuKhamDAO pkDao = new PhieuKhamDAO();
                maPhieuKham = pkDao.createPhieuKham(maDangKy);

                if (maPhieuKham == -1) {
                    JOptionPane.showMessageDialog(this, "Không tạo được phiếu khám!");
                    return;
                }
                if (!pkDao.updateDangKyWithPhieu(maDangKy, maPhieuKham)) {
                    JOptionPane.showMessageDialog(this, "Không cập nhật được đăng ký!");
                    return;
                }
            }

            ChiSoKhamTongHop cs = getChiSo();
            KhamLamSang ls = getLamSang();

            if (bus.insert(cs, ls)) {
                JOptionPane.showMessageDialog(this, "Lưu thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi lưu dữ liệu!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi hệ thống!");
        }
    }

    private void update() {
        if (maPhieuKham == -1) {
            JOptionPane.showMessageDialog(this, "Chưa có phiếu khám để cập nhật!");
            return;
        }

        ChiSoKhamTongHop cs = getChiSo();
        KhamLamSang ls = getLamSang();

        if (bus.update(cs, ls)) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật!");
        }
    }

    private void chuyenXQuang() {
        try {
            if (maPhieuKham == -1) {
                save();
                if (maPhieuKham == -1) return;
            }

            PhieuKhamDAO dao = new PhieuKhamDAO();
            boolean okTrangThai = dao.updateTrangThai(maPhieuKham, "CLS_CHAN_DOAN_HINH_ANH");
            int maPhieuChiDinh = dao.createPhieuChiDinh(maPhieuKham);

            if (maPhieuChiDinh == -1) {
                JOptionPane.showMessageDialog(this, "Không tạo được phiếu chỉ định!");
                return;
            }

            boolean okChiTiet = dao.insertChiTietChiDinh(maPhieuChiDinh, 31);

            if (okTrangThai && okChiTiet) {
                JOptionPane.showMessageDialog(this, "Đã chuyển bệnh nhân sang chụp X-Quang!");
            } else {
                JOptionPane.showMessageDialog(this, "Chuyển thất bại!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi hệ thống!");
        }
    }

    private ChiSoKhamTongHop getChiSo() {
        ChiSoKhamTongHop c = new ChiSoKhamTongHop();
        c.setMaPhieuKham(maPhieuKham);
        c.setMaNhanVienNhap(Session.currentUser.getMaNhanVien());
        c.setNhietDo(parseFloat(txtNhietDo.getText()));
        c.setNhipTim(parseInt(txtNhipTim.getText()));
        c.setHuyetApTamThu(parseInt(txtHuyetAp.getText()));
        c.setNhipTho(parseInt(txtNhipTho.getText()));
        c.setCanNang(parseFloat(txtCanNang.getText()));
        c.setChieuCao(parseFloat(txtChieuCao.getText()));
        c.setGhiChu(txtGhiChu.getText());
        return c;
    }

    private KhamLamSang getLamSang() {
        KhamLamSang k = new KhamLamSang();
        k.setMaPhieuKham(maPhieuKham);
        k.setLyDoKham(txtLyDo.getText());
        k.setTienSuBanThan(txtTienSu.getText());
        k.setBenhSu(txtBenhSu.getText());
        return k;
    }

    private Float parseFloat(String s) {
        try { return Float.parseFloat(s); } catch (Exception e) { return null; }
    }

    private Integer parseInt(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return null; }
    }
}