package gui;

import bus.ThuocBUS;
import dao.CTToaThuocDAO;
import dao.ToaThuocDAO;
import model.CTToaThuoc;
import model.Thuoc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.awt.print.PrinterException;

public class ToaThuocForm extends JFrame {

    private int maPhieu;
    private int maToaThuoc;

    JTable table;

    DefaultTableModel model;

    ThuocBUS thuocBUS =
            new ThuocBUS();

    List<Thuoc> dsThuoc;

    JComboBox<String> cboThuoc;

    public ToaThuocForm(int maPhieu){

        this.maPhieu = maPhieu;

        setTitle("Đơn thuốc");

        setSize(1100,600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();

        // ==========================================
        // KIỂM TRA TOA ĐÃ TỒN TẠI CHƯA
        // ==========================================

        kiemTraHoacTaoToa();

        // ==========================================
        // LOAD TOA CŨ
        // ==========================================

        loadData();
    }

    // =================================================
    // UI
    // =================================================

    private void initUI(){

        setLayout(new BorderLayout());

        // ==========================================
        // LOAD DANH SÁCH THUỐC
        // ==========================================

        dsThuoc =
                thuocBUS.getAll();

        cboThuoc =
                new JComboBox<>();

        for(Thuoc t : dsThuoc){

            cboThuoc.addItem(
                    t.getTenThuoc()
            );
        }

        // ==========================================
        // TABLE
        // ==========================================

        model =
                new DefaultTableModel(

                        new String[]{
                                "Thuốc",
                                "Sáng",
                                "Trưa",
                                "Chiều",
                                "Tối",
                                "Số ngày",
                                "Cách dùng",
                                "Thời điểm dùng"
                        },0
                ){

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {
                        return true;
                    }
                };

        table =
                new JTable(model);

        table.setRowHeight(30);

        table.getTableHeader().setFont(
                new Font("Segoe UI",Font.BOLD,13)
        );

        JScrollPane sp =
                new JScrollPane(table);

        add(sp,BorderLayout.CENTER);

        // ==========================================
        // TOP PANEL
        // ==========================================

        JPanel top =
                new JPanel(
                        new FlowLayout(FlowLayout.LEFT)
                );

        JButton btnThem =
                new JButton("Thêm thuốc");

        JButton btnXoa =
                new JButton("Xóa dòng");

        top.add(new JLabel("Thuốc"));

        top.add(cboThuoc);

        top.add(btnThem);

        top.add(btnXoa);

        add(top,BorderLayout.NORTH);

        // ==========================================
        // BOTTOM PANEL
        // ==========================================

        JPanel bottom =
                new JPanel();

        JButton btnSave =
                new JButton("Lưu toa thuốc");

        JButton btnPrint =
                new JButton("In toa thuốc");
        JButton btnPreview =
                new JButton("Xem trước");

        bottom.add(btnSave);
        bottom.add(btnPreview);

         bottom.add(btnPrint);

        add(bottom,BorderLayout.SOUTH);

        // ==========================================
        // EVENT THÊM THUỐC
        // ==========================================

        btnThem.addActionListener(e -> {

            String tenThuoc =
                    cboThuoc.getSelectedItem().toString();

            model.addRow(new Object[]{

                    tenThuoc,
                    "",
                    "",
                    "",
                    "",
                    1,
                    "",
                    ""
            });
        });

        // ==========================================
        // EVENT XÓA
        // ==========================================

        btnXoa.addActionListener(e -> {

            int row =
                    table.getSelectedRow();

            if(row >= 0){

                model.removeRow(row);

            }else{

                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng chọn dòng cần xóa!"
                );
            }
        });

        // ==========================================
        // EVENT SAVE
        // ==========================================

        btnSave.addActionListener(
                e -> saveAll()
        );
        btnPrint.addActionListener(
                e -> printToaThuoc()
        );
        btnPreview.addActionListener(
                e -> previewToaThuoc()
        );
    }

    // =================================================
    // KIỂM TRA TOA ĐÃ CÓ CHƯA
    // =================================================

    private void kiemTraHoacTaoToa(){

        ToaThuocDAO dao =
                new ToaThuocDAO();

        int existing =
                dao.findByMaPhieuKham(maPhieu);

        if(existing != -1){

            maToaThuoc = existing;

        }else{

            maToaThuoc =
                    dao.createToaThuoc(maPhieu);
        }
    }

    // =================================================
    // LOAD DỮ LIỆU CŨ
    // =================================================

    private void loadData(){

        model.setRowCount(0);

        CTToaThuocDAO dao =
                new CTToaThuocDAO();

        List<Object[]> list =
                dao.getByMaToaThuoc(maToaThuoc);

        for(Object[] row : list){

            model.addRow(row);
        }
    }

    // =================================================
    // SAVE TOÀN BỘ TOA
    // =================================================

    private void saveAll(){

        try{

            CTToaThuocDAO dao =
                    new CTToaThuocDAO();

            // ======================================
            // XÓA TOÀN BỘ CHI TIẾT CŨ
            // ======================================

            dao.deleteByMaToaThuoc(
                    maToaThuoc
            );

            // ======================================
            // INSERT LẠI
            // ======================================

            for(int i=0;i<model.getRowCount();i++){

                String tenThuoc =
                        model.getValueAt(i,0).toString();

                Thuoc thuoc =
                        timThuocTheoTen(tenThuoc);

                if(thuoc == null){
                    continue;
                }

                CTToaThuoc ct =
                        new CTToaThuoc();

                ct.setMaToaThuoc(
                        maToaThuoc
                );

                ct.setMaThuoc(
                        thuoc.getMaThuoc()
                );

                ct.setSang(
                        model.getValueAt(i,1).toString()
                );

                ct.setTrua(
                        model.getValueAt(i,2).toString()
                );

                ct.setChieu(
                        model.getValueAt(i,3).toString()
                );

                ct.setToi(
                        model.getValueAt(i,4).toString()
                );

                ct.setSoNgay(
                        Integer.parseInt(
                                model.getValueAt(i,5).toString()
                        )
                );

                ct.setCachDung(
                        model.getValueAt(i,6).toString()
                );

                ct.setThoiDiemDung(
                        model.getValueAt(i,7).toString()
                );

                dao.insert(ct);
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Đã lưu toa thuốc!"
            );

        }catch(Exception ex){

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi lưu toa thuốc!"
            );
        }
    }

    // =================================================
    // TÌM THUỐC THEO TÊN
    // =================================================

    private Thuoc timThuocTheoTen(String ten){

        for(Thuoc t : dsThuoc){

            if(t.getTenThuoc()
                    .equalsIgnoreCase(ten)){

                return t;
            }
        }

        return null;
    }
 // =================================================
 // IN TOA THUỐC
 // =================================================

 private void printToaThuoc(){

     try{

         StringBuilder sb =
                 new StringBuilder();

         sb.append("\n");

         sb.append("        PHÒNG KHÁM NHA KHOA\n");

         sb.append("========================================\n\n");

         sb.append("Mã phiếu khám: ")
                 .append(maPhieu)
                 .append("\n");

         sb.append("Mã toa thuốc: ")
                 .append(maToaThuoc)
                 .append("\n\n");

         sb.append("========================================\n");

         for(int i=0;i<model.getRowCount();i++){

             String tenThuoc =
                     getValue(i,0);

             if(tenThuoc.isEmpty()){
                 continue;
             }

             sb.append("Thuốc: ")
                     .append(tenThuoc)
                     .append("\n");

             sb.append("Sáng: ")
                     .append(getValue(i,1))
                     .append("   ");

             sb.append("Trưa: ")
                     .append(getValue(i,2))
                     .append("   ");

             sb.append("Chiều: ")
                     .append(getValue(i,3))
                     .append("   ");

             sb.append("Tối: ")
                     .append(getValue(i,4))
                     .append("\n");

             sb.append("Số ngày: ")
                     .append(getValue(i,5))
                     .append("\n");

             sb.append("Cách dùng: ")
                     .append(getValue(i,6))
                     .append("\n");

             sb.append("Thời điểm dùng: ")
                     .append(getValue(i,7))
                     .append("\n");

             sb.append("----------------------------------------\n");
         }

         sb.append("\n");

         sb.append("       Bác sĩ kê toa\n\n\n");

         JTextArea area =
                 new JTextArea(
                         sb.toString()
                 );

         area.setFont(
                 new Font(
                         "Monospaced",
                         Font.PLAIN,
                         14
                 )
         );

         boolean done =
                 area.print();

         if(done){

             JOptionPane.showMessageDialog(
                     this,
                     "Đã in toa thuốc!"
             );

         }else{

             JOptionPane.showMessageDialog(
                     this,
                     "Đã hủy in!"
             );
         }

     }catch(PrinterException ex){

         ex.printStackTrace();

         JOptionPane.showMessageDialog(
                 this,
                 "Lỗi máy in!"
         );
     }
 }
 private String getValue(int row, int col){

	    Object value =
	            model.getValueAt(row,col);

	    return value == null
	            ? ""
	            : value.toString().trim();
	}
 private String taoHTMLToaThuoc(){

	    StringBuilder html =
	            new StringBuilder();

	    html.append("""
	        <html>
	        <head>
	        <style>

	        body{
	            font-family: Arial;
	            padding:20px;
	        }

	        h1{
	            text-align:center;
	        }

	        table{
	            width:100%;
	            border-collapse:collapse;
	            margin-top:20px;
	        }

	        th,td{
	            border:1px solid black;
	            padding:8px;
	            text-align:center;
	        }

	        th{
	            background:#f0f0f0;
	        }

	        .info{
	            margin-top:20px;
	            margin-bottom:20px;
	        }

	        </style>
	        </head>
	        <body>
	        """);

	    html.append("<h1>TOA THUỐC</h1>");

	    html.append("<div class='info'>");

	    html.append("<b>Mã phiếu khám:</b> ")
	            .append(maPhieu)
	            .append("<br>");

	    html.append("<b>Mã toa thuốc:</b> ")
	            .append(maToaThuoc)
	            .append("<br>");

	    html.append("</div>");

	    html.append("""
	        <table>
	        <tr>
	            <th>Thuốc</th>
	            <th>Sáng</th>
	            <th>Trưa</th>
	            <th>Chiều</th>
	            <th>Tối</th>
	            <th>Số ngày</th>
	            <th>Cách dùng</th>
	            <th>Thời điểm dùng</th>
	        </tr>
	        """);

	    for(int i=0;i<model.getRowCount();i++){

	        String tenThuoc =
	                getValue(i,0);

	        if(tenThuoc.isEmpty()){
	            continue;
	        }

	        html.append("<tr>");

	        for(int j=0;j<8;j++){

	            html.append("<td>")
	                    .append(getValue(i,j))
	                    .append("</td>");
	        }

	        html.append("</tr>");
	    }

	    html.append("""
	        </table>

	        <br><br><br>

	        <div style='text-align:right'>
	            Bác sĩ kê toa
	        </div>

	        </body>
	        </html>
	        """);

	    return html.toString();
	}
 private void previewToaThuoc(){

	    JDialog dialog =
	            new JDialog(
	                    this,
	                    "Xem trước toa thuốc",
	                    true
	            );

	    dialog.setSize(900,700);

	    dialog.setLocationRelativeTo(this);

	    JEditorPane editor =
	            new JEditorPane();

	    editor.setContentType("text/html");

	    editor.setEditable(false);

	    editor.setText(
	            taoHTMLToaThuoc()
	    );

	    JScrollPane sp =
	            new JScrollPane(editor);

	    dialog.add(sp);

	    dialog.setVisible(true);
	}
}