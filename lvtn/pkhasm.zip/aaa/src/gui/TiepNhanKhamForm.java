package gui;

import bus.DangKyKhamBenhBUS;
import config.Session;
import model.DangKyKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TiepNhanKhamForm extends JFrame {

    private JTable tableCho;
    private JTable tableVang;
    private DefaultTableModel modelCho;
    private DefaultTableModel modelVang;

    private DangKyKhamBenhBUS bus = new DangKyKhamBenhBUS();

    // ===== BẢNG MÀU PHÒNG KHÁM HIỆN ĐẠI =====
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color COLOR_PRIMARY = new Color(0, 122, 255);  // Xanh dương chủ đạo
    private final Color COLOR_SUCCESS = new Color(46, 204, 113); // Xanh lá (Khám bệnh)
    private final Color COLOR_WARNING = new Color(230, 126, 34); // Cam (Vắng mặt)
    private final Color COLOR_MUTED = new Color(149, 165, 166);   // Xám (Quay lại)

    public TiepNhanKhamForm(){

        setTitle("TIẾP NHẬN KHÁM");
        setSize(1150, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG_WINDOW);
        root.setBorder(new EmptyBorder(25, 25, 25, 25));
        setContentPane(root);

        // ================= TOP: TIÊU ĐỀ CHÍNH =================
        JLabel title = new JLabel("DANH SÁCH TIẾP NHẬN HÔM NAY");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(TEXT_MAIN);
        root.add(title, BorderLayout.NORTH);

        // ================= CENTER: KHỐI HAI BẢNG DỮ LIỆU =================
        JPanel center = new JPanel(new GridLayout(2, 1, 0, 20));
        center.setOpaque(false);

        // 1. Khởi tạo Bảng Chờ Khám
        modelCho = new DefaultTableModel(
                new String[]{"ID", "STT", "Mã BN", "Họ tên", "Thời gian", "Trạng thái"}, 0);
        tableCho = new JTable(modelCho);
        styleTable(tableCho, COLOR_PRIMARY);
        
        JPanel panelCho = createTablePanel("DANH SÁCH BỆNH NHÂN ĐANG CHỜ KHÁM", tableCho, new Color(235, 243, 250));
        center.add(panelCho);

        // 2. Khởi tạo Bảng Vắng Mặt
        modelVang = new DefaultTableModel(
                new String[]{"ID", "STT", "Mã BN", "Họ tên", "Thời gian", "Trạng thái"}, 0);
        tableVang = new JTable(modelVang);
        styleTable(tableVang, new Color(108, 117, 125));
        
        JPanel panelVang = createTablePanel("DANH SÁCH BỆNH NHÂN VẮNG MẶT / HOÃN LỊCH", tableVang, new Color(242, 244, 244));
        center.add(panelVang);

        root.add(center, BorderLayout.CENTER);

        // ================= SOUTH: KHU VỰC ĐIỀU KHIỂN / NÚT BẤM =================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        bottom.setOpaque(false);

        JButton btnBack = createModernButton("Quay lại", COLOR_MUTED);
        JButton btnRefresh = createModernButton("Làm mới ↻", COLOR_PRIMARY);
        JButton btnVangMat = createModernButton("Đánh dấu VẮNG MẶT", COLOR_WARNING);
        JButton btnSTT = createModernButton("Đăng ký STT mới", COLOR_PRIMARY);
        JButton btnKham = createModernButton("Tiến hành khám ➜", COLOR_SUCCESS);

        // Đổ dữ liệu vào thanh điều hướng theo thứ tự cân đối
        bottom.add(btnBack);
        JPanel spacer = new JPanel(); spacer.setOpaque(false); bottom.add(spacer); // Khoảng cách nhỏ
        bottom.add(btnRefresh);
        bottom.add(btnVangMat);
        bottom.add(btnSTT);
        bottom.add(btnKham);

        root.add(bottom, BorderLayout.SOUTH);

        // ================= KẾT NỐI LOGIC SỰ KIỆN GỐC =================
        btnBack.addActionListener(e -> {
            new TroLyBacSiDashboard().setVisible(true);
            dispose();
        });

        btnRefresh.addActionListener(e -> loadData());

        btnVangMat.addActionListener(e -> {
            int row = tableCho.getSelectedRow();
            if(row == -1){
                JOptionPane.showMessageDialog(this, "Vui lòng chọn bệnh nhân ở bảng chờ!");
                return;
            }

            int id = (int) modelCho.getValueAt(row, 0);
            bus.updateTrangThai(id, "VANG_MAT");
            loadData();
        });

        btnKham.addActionListener(e -> {
            int row = tableCho.getSelectedRow();
            if(row == -1){
                JOptionPane.showMessageDialog(this, "Chọn bệnh nhân cần khám!");
                return;
            }

            int id = (int) modelCho.getValueAt(row, 0);
            new KhamBenhForm(id).setVisible(true);
        });

        btnSTT.addActionListener(e -> {
            int row = tableVang.getSelectedRow();
            if(row == -1){
                JOptionPane.showMessageDialog(this, "Chọn bệnh nhân ở bảng VẮNG MẶT!");
                return;
            }

            int id = (int) modelVang.getValueAt(row, 0);

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Đăng ký lại STT mới cho bệnh nhân này?",
                    "Xác nhận hành động",
                    JOptionPane.YES_NO_OPTION
            );

            if(confirm != JOptionPane.YES_OPTION) return;

            int newSTT = bus.getNextSTT();
            boolean success = bus.updateSTTAndTrangThai(id, newSTT);

            if(success){
                JOptionPane.showMessageDialog(this, "Đã cấp số thứ tự mới: " + newSTT);
            } else {
                JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
            }

            loadData();
        });

        bus.deleteDangKyCu();
        loadData();
    }

    // ================= HÀM ĐỊNH DẠNG BẢNG CHUYÊN NGHIỆP =================
    private void styleTable(JTable table, Color headerColor) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(32); // Tăng chiều cao dòng cho thoáng mắt
        table.setSelectionBackground(new Color(232, 244, 253));
        table.setSelectionForeground(Color.BLACK);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));

        // Định dạng thanh tiêu đề cột (Header)
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(headerColor);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(100, 38));

        // Căn giữa nội dung toàn bộ các cột
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.setDefaultRenderer(Object.class, centerRenderer);

        // Ẩn cột ID (Index 0) để sạch giao diện nhưng vẫn lấy được giá trị lập trình
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);
    }

    // ================= BỌC BẢNG VÀO PANEL CÓ TIÊU ĐỀ KHU VỰC =================
    private JPanel createTablePanel(String title, JTable table, Color titleContainerBg) {
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(Color.WHITE);
        container.setBorder(BorderFactory.createLineBorder(new Color(230, 235, 240), 1));

        // Thanh tiêu đề phụ của bảng
        JLabel lblSubTitle = new JLabel("  " + title);
        lblSubTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSubTitle.setForeground(TEXT_MAIN);
        lblSubTitle.setOpaque(true);
        lblSubTitle.setBackground(titleContainerBg);
        lblSubTitle.setPreferredSize(new Dimension(100, 35));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);

        container.add(lblSubTitle, BorderLayout.NORTH);
        container.add(scrollPane, BorderLayout.CENTER);
        return container;
    }

    // ================= TẠO NÚT BẤM FLAT UI PHẲNG HIỆN ĐẠI =================
    private JButton createModernButton(String text, Color baseColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(baseColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(180, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(baseColor.brighter());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(baseColor);
            }
        });

        return button;
    }

    private void loadData(){
        modelCho.setRowCount(0);
        modelVang.setRowCount(0);

        for(Object[] row : bus.getChoKham()){
            modelCho.addRow(row);
        }

        for(Object[] row : bus.getVangMat()){
            modelVang.addRow(row);
        }
    }
}