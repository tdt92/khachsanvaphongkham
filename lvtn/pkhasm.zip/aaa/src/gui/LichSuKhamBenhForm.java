package gui;

import bus.LichSuKhamBenhBUS;
import model.LichSuKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class LichSuKhamBenhForm extends JFrame {

    private JTextField txtSearch;
    private JTable table;
    private DefaultTableModel model;
    private JButton btnChiTiet;

    private LichSuKhamBenhBUS bus = new LichSuKhamBenhBUS();

    // ===== BẢNG MÀU GIAO DIỆN HIỆN ĐẠI (FLAT UI) =====
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color CARD_BG = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 122, 255); // Xanh dương Modern
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public LichSuKhamBenhForm(){
        setTitle("LỊCH SỬ KHÁM BỆNH");
        setSize(1250, 680); // Tinh chỉnh lại tỷ lệ khung hình cân đối hơn
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();
        loadData();
    }

    private void initUI(){
        // Panel gốc có khoảng đệm bao quanh giúp form không bị ngợp
        JPanel rootPanel = new JPanel(new BorderLayout(0, 15));
        rootPanel.setBackground(BG_WINDOW);
        rootPanel.setBorder(new EmptyBorder(20, 22, 20, 22));
        setContentPane(rootPanel);

        // ================= TOP: THANH TÌM KIẾM FLAT CARD =================
        JPanel topCard = new JPanel(new BorderLayout(15, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
            }
        };
        topCard.setOpaque(false);
        topCard.setBorder(new EmptyBorder(12, 18, 12, 18));

        JLabel lbl = new JLabel("🔍 Tìm kiếm thông minh:");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(TEXT_MAIN);

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setToolTipText("Nhập tên bệnh nhân hoặc mã định danh CCCD để tra cứu nhanh...");
        // Tạo viền bo góc ôm chữ mềm mại cho ô tìm kiếm
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        topCard.add(lbl, BorderLayout.WEST);
        topCard.add(txtSearch, BorderLayout.CENTER);
        rootPanel.add(topCard, BorderLayout.NORTH);

        // ================= CENTER: BẢNG DỮ LIỆU FLAT CARD =================
        JPanel centerCard = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        centerCard.setOpaque(false);
        centerCard.setBorder(new EmptyBorder(15, 18, 15, 18));

        model = new DefaultTableModel(
                new String[]{
                        "Mã PK", "Tên bệnh nhân", "CCCD", "Bác sĩ phụ trách",
                        "Chuyên khoa", "Ngày khám", "Trạng thái", "Ghi chú bệnh án"
                }, 0
        ){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32); // Tăng độ cao dòng để chữ không bị kích
        table.setSelectionBackground(new Color(232, 244, 255)); // Màu nền khi click chọn nhẹ nhàng
        table.setSelectionForeground(Color.BLACK);
        table.setShowGrid(true);
        table.setGridColor(new Color(242, 244, 247));

        // Định dạng thanh tiêu đề bảng (Table Header)
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(242, 245, 249));
        header.setForeground(TEXT_MAIN);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), 
                " NHẬT KÝ LỊCH SỬ KHÁM BỆNH TOÀN VIỆN ", TitledBorder.LEFT, TitledBorder.TOP, 
                new Font("Segoe UI", Font.BOLD, 14), PRIMARY_COLOR));
        sp.getViewport().setBackground(Color.WHITE);
        
        centerCard.add(sp, BorderLayout.CENTER);
        rootPanel.add(centerCard, BorderLayout.CENTER);

        // ================= BOTTOM: THANH ĐIỀU KHIỂN CHỨC NĂNG =================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottom.setOpaque(false);

        btnChiTiet = new JButton("📄 Xem hồ sơ chi tiết");
        btnChiTiet.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnChiTiet.setBackground(PRIMARY_COLOR);
        btnChiTiet.setForeground(Color.WHITE);
        btnChiTiet.setPreferredSize(new Dimension(180, 40));
        btnChiTiet.setFocusPainted(false);
        btnChiTiet.setBorderPainted(false);
        btnChiTiet.setOpaque(true);
        btnChiTiet.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Thêm hiệu ứng rê chuột chuyển màu mượt mà cho nút bấm
        btnChiTiet.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnChiTiet.setBackground(PRIMARY_COLOR.darker()); }
            @Override public void mouseExited(MouseEvent e) { btnChiTiet.setBackground(PRIMARY_COLOR); }
        });

        bottom.add(btnChiTiet);
        rootPanel.add(bottom, BorderLayout.SOUTH);

        // ================= KEEP ORIGINAL EVENTS =================
        txtSearch.addCaretListener(new CaretListener() {
            @Override
            public void caretUpdate(CaretEvent e) {
                loadData();
            }
        });

        btnChiTiet.addActionListener(e -> {
            int row = table.getSelectedRow();
            if(row < 0){
                JOptionPane.showMessageDialog(
                        this,
                        "Vui lòng chọn một bệnh nhân từ danh sách!",
                        "Thông báo",
                        JOptionPane.WARNING_MESSAGE
                ); // <--- Đã sửa dấu ngoặc tròn tại đây
                return;
            }

            int maPhieuKham = (int) model.getValueAt(row, 0);
            new ChiTietKhamBenhForm(maPhieuKham).setVisible(true);
        });
    }

    private void loadData(){
        model.setRowCount(0);
        String keyword = txtSearch.getText().trim();
        List<LichSuKhamBenh> list = bus.search(keyword);

        for(LichSuKhamBenh ls : list){
            model.addRow(new Object[]{
                    ls.getMaPhieuKham(),
                    ls.getTenBenhNhan(),
                    ls.getCccd(),
                    ls.getTenBacSi(),
                    ls.getChuyenKhoa(),
                    ls.getNgayKham(),
                    ls.getTrangThai(),
                    ls.getGhiChu()
            });
        }
    }
}