package gui;

import bus.PhanCongCaLamBUS;
import model.PhanCongCaLam;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

public class LichLamViecHomNayForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    private PhanCongCaLamBUS bus = new PhanCongCaLamBUS();

    public LichLamViecHomNayForm(){

        setTitle("LỊCH LÀM VIỆC HÔM NAY");
        setSize(900,500);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(
                new String[]{
                        "ID",
                        "Mã NV",
                        "Tên nhân viên",
                        "Phòng",
                        "Giờ làm",
                        "Giờ kết thúc",
                        "Thứ"
                },0);

        table = new JTable(model);

        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData();
    }

    private void loadData(){

        model.setRowCount(0);

        String thuHomNay = getThuHomNay();

        List<PhanCongCaLam> list = bus.getAll();

        for(PhanCongCaLam p : list){

            if(p.getThu() != null &&
                    p.getThu().equalsIgnoreCase(thuHomNay)){

                model.addRow(new Object[]{
                        p.getId(),
                        p.getMaNhanVien(),
                        p.getTenNhanVien(),
                        p.getPhong(),
                        p.getGioLam(),
                        p.getGioKetThuc(),
                        p.getThu()
                });
            }
        }
    }

    private String getThuHomNay(){

        DayOfWeek day = LocalDate.now().getDayOfWeek();

        switch(day){

            case MONDAY:
                return "Thứ 2";

            case TUESDAY:
                return "Thứ 3";

            case WEDNESDAY:
                return "Thứ 4";

            case THURSDAY:
                return "Thứ 5";

            case FRIDAY:
                return "Thứ 6";

            case SATURDAY:
                return "Thứ 7";

            default:
                return "Chủ nhật";
        }
    }
}