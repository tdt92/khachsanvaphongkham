package gui;

import bus.TaiKhoanBUS;
import bus.NhanVienBUS;
import config.Session;
import model.TaiKhoan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class LoginForm extends JFrame {

    private JTextField txtUser;
    private JPasswordField txtPass;
    private TaiKhoanBUS bus = new TaiKhoanBUS();
    private NhanVienBUS nvBus = new NhanVienBUS();

    private final Color BG = new Color(236,240,245);
    private final Color CARD = Color.WHITE;
    private final Color PRIMARY = new Color(41,128,185);
    private final Color BORDER = new Color(210,210,210);

    public LoginForm(){

        setTitle("Đăng nhập hệ thống");
        setSize(420,520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root=new JPanel(new BorderLayout());
        root.setBackground(BG);
        setContentPane(root);

         JPanel header=new JPanel();
        header.setBackground(BG);
        header.setBorder(new EmptyBorder(25,0,10,0));
        header.setLayout(new BoxLayout(header,BoxLayout.Y_AXIS));

        JLabel icon=new JLabel("🏨");
        icon.setFont(new Font("Segoe UI Emoji",Font.PLAIN,48));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title=new JLabel("HỆ THỐNG PHÒNG KHÁM");
        title.setFont(new Font("Segoe UI",Font.BOLD,18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(icon);
        header.add(Box.createVerticalStrut(5));
        header.add(title);

        root.add(header,BorderLayout.NORTH);

        // ================= LOGIN CARD =================
        JPanel wrapper=new JPanel(new GridBagLayout());
        wrapper.setBackground(BG);
        root.add(wrapper,BorderLayout.CENTER);

        JPanel card=new JPanel();
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setBackground(CARD);
        card.setBorder(new EmptyBorder(25,30,25,30));
        card.setPreferredSize(new Dimension(320,260));

        JLabel lbLogin=new JLabel("Đăng nhập");
        lbLogin.setFont(new Font("Segoe UI",Font.BOLD,20));
        lbLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(lbLogin);
        card.add(Box.createVerticalStrut(20));

        txtUser=new JTextField();
        styleField(txtUser,"Tài khoản");
        card.add(txtUser);

        card.add(Box.createVerticalStrut(12));

        txtPass=new JPasswordField();
        styleField(txtPass,"Mật khẩu");
        card.add(txtPass);

        JCheckBox show=new JCheckBox("Hiện mật khẩu");
        show.setBackground(CARD);
        show.addActionListener(e->
                txtPass.setEchoChar(show.isSelected()?0:'*'));
        card.add(show);

        card.add(Box.createVerticalStrut(15));

        JButton btnLogin=new JButton("ĐĂNG NHẬP");
        btnLogin.setBackground(PRIMARY);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setFont(new Font("Segoe UI",Font.BOLD,14));
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE,40));

        btnLogin.addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){
                btnLogin.setBackground(PRIMARY.darker());
            }
            public void mouseExited(MouseEvent e){
                btnLogin.setBackground(PRIMARY);
            }
        });

        card.add(btnLogin);

        wrapper.add(card);

         ActionListener action=e->login();

        btnLogin.addActionListener(action);
        txtPass.addActionListener(action);
    }

    private void styleField(JTextField txt,String title){
        txt.setBorder(BorderFactory.createTitledBorder(title));
        txt.setFont(new Font("Segoe UI",Font.PLAIN,14));
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE,40));
    }

    private void login(){

        TaiKhoan tk =
            bus.dangNhap(txtUser.getText(),
            new String(txtPass.getPassword()));

        if(tk != null){

            Session.currentUser = tk;

            String role = tk.getVaiTro();

            switch(role){

                case "QUAN_TRI_VIEN":
                    new MainForm().setVisible(true);
                    break;

                case "LE_TAN":
                    new LeTanDashboard().setVisible(true);
                    break;

                case "TRO_LY_BAC_SI_CHUYEN_KHOA":
                    new TroLyBacSiDashboard().setVisible(true);
                    break;

                case "BAC_SI":
                    openDoctorBySpecialty(tk.getMaNhanVien());
                    break;
                case "KY_THUAT_VIEN_CHAN_DOAN_HINH_ANH":
                    new KyThuatVienCDHADashboard().setVisible(true);
                    break;
                case "THU_NGAN":
                    new ThuNganDashboard().setVisible(true);
                    break;
                case "DUOC_SI":
                    new DuocSiDashboard().setVisible(true);
                    break;

                default:
                    JOptionPane.showMessageDialog(this,
                            "Vai trò không hợp lệ: " + role);
                    return;
            }

            dispose();

        }else{
            JOptionPane.showMessageDialog(this,
                    "Sai tài khoản hoặc mật khẩu");
        }
    }

     private void openDoctorBySpecialty(int maNhanVien){

        String chuyenKhoa = nvBus.getChuyenKhoa(maNhanVien);

        if(chuyenKhoa == null){
            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy chuyên khoa của bác sĩ!");
            return;
        }

        chuyenKhoa = chuyenKhoa.trim();

        if(chuyenKhoa.equalsIgnoreCase("Răng - Hàm - Mặt")){
            new KhoaRangForm().setVisible(true);
        }
        else if(chuyenKhoa.equalsIgnoreCase("Nội tổng quát")){
            new KhoanoiForm().setVisible(true);

         }
        else if(chuyenKhoa.equalsIgnoreCase("Nhi")){
         }
        else{
            JOptionPane.showMessageDialog(this,
                    "Chưa có form cho chuyên khoa: " + chuyenKhoa);
        }
    }

    public static void main(String[] args){
        new LoginForm().setVisible(true);
    }
}