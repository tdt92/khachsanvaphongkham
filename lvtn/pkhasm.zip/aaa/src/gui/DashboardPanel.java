package gui;

import javax.swing.*;
import java.awt.*;
import javax.swing.JPanel;   // ✅ bắt buộc


public class DashboardPanel extends JPanel {

    public DashboardPanel(){

        setLayout(new BorderLayout());

        JLabel lb=new JLabel(
        "DASHBOARD HỆ THỐNG",
        SwingConstants.CENTER);

        lb.setFont(new Font("Arial",Font.BOLD,24));

        add(lb,BorderLayout.CENTER);
    }
}
