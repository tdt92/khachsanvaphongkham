package gui;

import dao.PhieuKhamDAO;
import bus.ChiTietKhamBenhBUS;
import bus.HoaDonBUS;
import bus.LichSuKhamBenhBUS;
import config.Session;
import dao.BenhNhanDAO;
import dao.ChiSoKhamTongHopDAO;
import dao.KhamLamSangDAO;
import model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import bus.LichTaiKhamBUS;
import java.sql.Date;
import bus.ChuyenKhoaBUS;

public class KhamRangChiTietForm extends JFrame {

    private int maPhieu;

    // Các thành phần giao diện giữ nguyên tên biến của bạn
    JTextArea txtTinhTrangChung = new JTextArea(3,20);
    JTextArea txtTinhTrangNuou = new JTextArea(3,20);
    JTextArea txtSauRang = new JTextArea(3,20);
    JTextArea txtNiemMac = new JTextArea(3,20);
    JTextArea txtCaoRang = new JTextArea(3,20);
    JTextArea txtDoLungLay = new JTextArea(3,20);
    JTextArea txtKhopCan = new JTextArea(3,20);
    JTextArea txtBenhLyKhac = new JTextArea(3,20);
    JTextArea txtPhucHinhCu = new JTextArea(3,20);
    JTextArea txtGhiChu = new JTextArea(3,20);

    JTextField txtChanDoan = new JTextField();
    JTextArea txtLoiDan = new JTextArea(3,20);

    JTextArea txtThongTinCu = new JTextArea();

    JTable tableHistory;
    DefaultTableModel historyModel;

    private final ChuyenKhoaBUS chuyenKhoaBUS = new ChuyenKhoaBUS();
    ChiSoKhamTongHopDAO csDao = new ChiSoKhamTongHopDAO();
    KhamLamSangDAO lsDao = new KhamLamSangDAO();
    LichSuKhamBenhBUS lichSuBUS = new LichSuKhamBenhBUS();
    ChiTietKhamBenhBUS chiTietBUS = new ChiTietKhamBenhBUS();
    LichTaiKhamBUS lichTaiKhamBUS = new LichTaiKhamBUS();
    BenhNhanDAO benhNhanDAO = new BenhNhanDAO();

    // Định nghĩa bảng màu Hiện đại / Y tế chuyên nghiệp
    private final Color PRIMARY_COLOR = new Color(0, 122, 255); // Xanh dương Modern iOS
    private final Color BACKGROUND_COLOR = new Color(245, 247, 250); // Xám trắng nhạt dịu mắt
    private final Color CARD_BACKGROUND = Color.WHITE;
    private final Color TEXT_DARK = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(218, 224, 233);
    private final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public KhamRangChiTietForm(int maPhieu){
        this.maPhieu = maPhieu;

        setTitle("HỆ THỐNG PHÒNG KHÁM - KHÁM RĂNG CHI TIẾT");
        setSize(1550, 900);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Cài đặt màu nền cho khung cửa sổ chính
        getContentPane().setBackground(BACKGROUND_COLOR);
        setLayout(new BorderLayout(15, 15));

        initUI();
        loadOldData();
        loadHistory();
    }

    private void initUI(){
        // Thêm khoảng cách đệm an toàn xung quanh Form chính
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));

        // =================================================
        // LEFT PANEL (Thông tin cũ & Lịch sử)
        // =================================================
        JPanel leftPanel = new JPanel(new BorderLayout(0, 15));
        leftPanel.setPreferredSize(new Dimension(480, 0));
        leftPanel.setOpaque(false);

        // Định dạng vùng hiển thị thông tin lâm sàng cũ
        txtThongTinCu.setEditable(false);
        txtThongTinCu.setLineWrap(true);
        txtThongTinCu.setWrapStyleWord(true);
        txtThongTinCu.setFont(MAIN_FONT);
        txtThongTinCu.setBackground(CARD_BACKGROUND);
        txtThongTinCu.setForeground(TEXT_DARK);
        txtThongTinCu.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane spInfo = new JScrollPane(txtThongTinCu);
        styleScrollPane(spInfo, "Thông tin lâm sàng trước đó");

        // Cấu hình bảng lịch sử khám bệnh mềm mại hơn
        historyModel = new DefaultTableModel(
                new String[]{"Mã PK", "Ngày khám", "Bác sĩ", "Trạng thái"}, 0
        ){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableHistory = new JTable(historyModel);
        tableHistory.setRowHeight(35); // Tăng chiều cao hàng để dễ nhìn
        tableHistory.setFont(MAIN_FONT);
        tableHistory.setForeground(TEXT_DARK);
        tableHistory.setSelectionBackground(new Color(230, 242, 255));
        tableHistory.setSelectionForeground(TEXT_DARK);
        tableHistory.setGridColor(BACKGROUND_COLOR);
        tableHistory.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo style hiện đại

        JTableHeader header = tableHistory.getTableHeader();
        header.setFont(BOLD_FONT);
        header.setBackground(Color.WHITE);
        header.setForeground(TEXT_DARK);
        header.setPreferredSize(new Dimension(0, 40));
        ((JLabel)header.getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);

        JScrollPane spHistory = new JScrollPane(tableHistory);
        spHistory.getViewport().setBackground(Color.WHITE);
        styleScrollPane(spHistory, "Lịch sử khám bệnh (Double-click xem chi tiết)");

        // Sự kiện double click giữ nguyên của bạn
        tableHistory.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if(e.getClickCount() == 2){
                    int row = tableHistory.getSelectedRow();
                    if(row >= 0){
                        int maPK = Integer.parseInt(historyModel.getValueAt(row, 0).toString());
                        showChiTietKham(maPK);
                    }
                }
            }
        });

        // Chia đôi vùng bên trái bằng SplitPane cao cấp
        JSplitPane leftSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, spInfo, spHistory);
        leftSplit.setDividerLocation(380);
        leftSplit.setBorder(null);
        leftSplit.setOpaque(false);
        leftPanel.add(leftSplit, BorderLayout.CENTER);

        // =================================================
        // RIGHT PANEL (Nhập liệu khám răng khoa học hơn)
        // =================================================
        // Thay vì GridLayout ép tất cả các ô bằng nhau, dùng GridBagLayout để căn chỉnh chuẩn xác nhất
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(CARD_BACKGROUND);
        formPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.WEST;

        // Mảng chứa các cặp Nhãn và Ô văn bản tương ứng để đưa vào Grid tự động
        String[] labels = {
            "Tình trạng chung", "Viêm nướu", "Sâu răng", "Niêm mạc miệng", 
            "Cao răng", "Độ lung lay", "Khớp cắn", "Bệnh lý khác", 
            "Phục hình cũ", "Ghi chú"
        };
        JTextArea[] textAreas = {
            txtTinhTrangChung, txtTinhTrangNuou, txtSauRang, txtNiemMac, 
            txtCaoRang, txtDoLungLay, txtKhopCan, txtBenhLyKhac, 
            txtPhucHinhCu, txtGhiChu
        };

        // Vòng lặp sắp xếp 10 trường nhập liệu Răng Hàm Mặt thành bố cục 2 cột song song tiết kiệm diện tích
        for (int i = 0; i < labels.length; i++) {
            int row = i / 2;
            int colIdx = (i % 2) * 2;

            // Cột nhãn thuộc tính
            gbc.gridx = colIdx;
            gbc.gridy = row;
            gbc.weightx = 0.0;
            gbc.weighty = 0.0;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(BOLD_FONT);
            lbl.setForeground(TEXT_DARK);
            formPanel.add(lbl, gbc);

            // Cột ô nhập liệu bao quanh bởi ScrollPane chỉ định chiều cao cố định văn bản
            gbc.gridx = colIdx + 1;
            gbc.weightx = 0.5;
            styleTextArea(textAreas[i]);
            JScrollPane spArea = new JScrollPane(textAreas[i]);
            spArea.setPreferredSize(new Dimension(220, 65));
            spArea.setBorder(new LineBorder(BORDER_COLOR, 1));
            formPanel.add(spArea, gbc);
        }

        // Dòng chuẩn đoán sơ bộ (Chiếm trọn bề ngang)
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        JLabel lblCD = new JLabel("Chẩn đoán sơ bộ");
        lblCD.setFont(BOLD_FONT);
        lblCD.setForeground(TEXT_DARK);
        formPanel.add(lblCD, gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        txtChanDoan.setFont(MAIN_FONT);
        txtChanDoan.setPreferredSize(new Dimension(0, 35));
        txtChanDoan.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        formPanel.add(txtChanDoan, gbc);

        // Dòng lời dặn bác sĩ (Chiếm trọn bề ngang)
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        JLabel lblLD = new JLabel("Lời dặn bác sĩ");
        lblLD.setFont(BOLD_FONT);
        lblLD.setForeground(TEXT_DARK);
        formPanel.add(lblLD, gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        gbc.weighty = 0.2; // Dành khoảng trống co giãn cho lời dặn
        styleTextArea(txtLoiDan);
        JScrollPane spLoiDan = new JScrollPane(txtLoiDan);
        spLoiDan.setPreferredSize(new Dimension(0, 80));
        spLoiDan.setBorder(new LineBorder(BORDER_COLOR, 1));
        formPanel.add(spLoiDan, gbc);

        JScrollPane spForm = new JScrollPane(formPanel);
        styleScrollPane(spForm, "Nhập liệu thông tin khám răng chi tiết");

        // SplitPane chính nối bảng bên Trái và bên Phải
        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, spForm);
        mainSplit.setDividerLocation(480);
        mainSplit.setBorder(null);
        mainSplit.setOpaque(false);
        add(mainSplit, BorderLayout.CENTER);

        // =================================================
        // BOTTOM BUTTON BAR (Thanh công cụ nút bấm phẳng hiện đại)
        // =================================================
        JButton btnSave = new JButton("Lưu phiếu");
        JButton btnUpdate = new JButton("Cập nhật");
        JButton btnChuyenCK = new JButton("Chuyển chuyên khoa");
        JButton btnViewCDHA = new JButton("Xem kết quả CĐHA");
        JButton btnXQuang = new JButton("Chỉ định X-Quang");
        JButton btnDonThuoc = new JButton("Kê đơn thuốc");
        JButton btnTaiKham = new JButton("Hẹn tái khám");
        JButton btnKetThuc = new JButton("Kết thúc khám");

        // Áp dụng phong cách nút bấm phẳng (Flat Style)
        styleButton(
                btnChuyenCK,
                new Color(168, 85, 247),
                Color.WHITE
        );
        
        styleButton(btnSave, PRIMARY_COLOR, Color.WHITE);
        styleButton(btnUpdate, new Color(74, 85, 104), Color.WHITE);
        styleButton(btnViewCDHA, new Color(59, 130, 246), Color.WHITE);
        styleButton(btnXQuang, new Color(245, 158, 11), Color.WHITE);
        styleButton(btnDonThuoc, new Color(16, 185, 129), Color.WHITE);
        styleButton(btnTaiKham, new Color(139, 92, 246), Color.WHITE);
        styleButton(btnKetThuc, new Color(239, 68, 68), Color.WHITE); // Màu đỏ đặc trưng cho hành động kết thúc

        JPanel bottom = new JPanel(
                new GridLayout(1, 8, 10, 0)
        );

        bottom.setBackground(CARD_BACKGROUND);

        bottom.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(BORDER_COLOR, 1),
                        new EmptyBorder(10, 10, 10, 10)
                )
        );

        // chỉnh width nhỏ lại cho vừa
        Dimension btnSize = new Dimension(140, 40);

        btnSave.setPreferredSize(btnSize);
        btnUpdate.setPreferredSize(btnSize);
        btnChuyenCK.setPreferredSize(btnSize);
        btnViewCDHA.setPreferredSize(btnSize);
        btnXQuang.setPreferredSize(btnSize);
        btnDonThuoc.setPreferredSize(btnSize);
        btnTaiKham.setPreferredSize(btnSize);
        btnKetThuc.setPreferredSize(btnSize);

        bottom.add(btnSave);
        bottom.add(btnUpdate);
        bottom.add(btnChuyenCK);
        bottom.add(btnViewCDHA);
        bottom.add(btnXQuang);
        bottom.add(btnDonThuoc);
        bottom.add(btnTaiKham);
        bottom.add(btnKetThuc);

        add(bottom, BorderLayout.SOUTH);

        // Đăng ký toàn bộ các ActionListeners logic gốc của bạn
        btnDonThuoc.addActionListener(e -> moDonThuoc());
        btnTaiKham.addActionListener(e -> henTaiKham());
        btnSave.addActionListener(e -> save());
        btnUpdate.addActionListener(e -> update());
        btnViewCDHA.addActionListener(e -> {
             TienHanhCDHAForm f = new TienHanhCDHAForm(maPhieu);
             f.setVisible(true);
        });
        btnXQuang.addActionListener(e -> chuyenXQuang());
        btnChuyenCK.addActionListener(e ->
        chuyenChuyenKhoa()
);
        
        // Giữ nguyên logic xử lý nghiệp vụ phức tạp của nút Kết thúc khám
        btnKetThuc.addActionListener(e -> {
            try{
                int confirm = JOptionPane.showConfirmDialog(
                        null,
                        "Kết thúc khám và tạo hóa đơn?",
                        "Xác nhận hành động",
                        JOptionPane.YES_NO_OPTION
                );

                if(confirm != JOptionPane.YES_OPTION){
                    return;
                }

                save();
                PhieuKhamDAO pkDao = new PhieuKhamDAO();
                boolean okBS = pkDao.updateBacSiKham(maPhieu, Session.currentUser.getMaNhanVien());

                if(!okBS){
                    JOptionPane.showMessageDialog(this, "Không cập nhật được bác sĩ khám!");
                    return;
                }

                pkDao.updateTrangThai(maPhieu, "CHO_THANH_TOAN");
                System.out.println("Ma phieu = " + maPhieu);
                System.out.println("Ma nhan vien current = " + Session.currentUser.getMaNhanVien());

                HoaDonBUS hoaDonBUS = new HoaDonBUS();
                int maHoaDon = hoaDonBUS.taoHoaDonTuPhieuKham(maPhieu, Session.currentUser.getMaNhanVien());

                if(maHoaDon > 0){
                    JOptionPane.showMessageDialog(null, "Đã kết thúc khám!\nMã hóa đơn: " + maHoaDon);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Tạo hóa đơn thất bại!");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi kết thúc khám!");
            }
        });
    }

    // =====================================================
    // CÁC HÀM TRỢ GIÚP GIAO DIỆN (Helper Methods)
    // =====================================================
    private void styleTextArea(JTextArea area) {
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(MAIN_FONT);
        area.setForeground(TEXT_DARK);
        area.setBorder(new EmptyBorder(5, 8, 5, 8));
    }

    private void styleScrollPane(JScrollPane sp, String title) {
        sp.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                title,
                TitledBorder.LEFT,
                TitledBorder.TOP,
                BOLD_FONT,
                PRIMARY_COLOR
        ));
        sp.setBackground(CARD_BACKGROUND);
    }

    private void styleButton(JButton btn, Color background, Color foreground) {
        btn.setFont(BOLD_FONT);
        btn.setBackground(background);
        btn.setForeground(foreground);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(160, 40));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hiệu ứng rê chuột phản hồi trực quan nhẹ nhàng
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(background.darker());
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(background);
            }
        });
    }

    // =====================================================
    // HỆ THỐNG LOGIC NGHIỆP VỤ (Giữ nguyên gốc 100%)
    // =====================================================
    private void loadOldData(){
        StringBuilder sb = new StringBuilder();
        KhamLamSang ls = lsDao.findByMaPhieu1(maPhieu);
        if(ls != null){
            sb.append("===== THÔNG TIN LÂM SÀNG =====\n\n");
            sb.append("Lý do khám: ").append(nullToEmpty(ls.getLyDoKham())).append("\n\n");
            sb.append("Bệnh sử: ").append(nullToEmpty(ls.getBenhSu())).append("\n\n");
            sb.append("Tiền sử bản thân: ").append(nullToEmpty(ls.getTienSuBanThan())).append("\n\n");
            txtChanDoan.setText(ls.getChanDoanSoBo());
            txtLoiDan.setText(ls.getLoiDanBacSi());
        }

        ChiSoKhamTongHop cs = csDao.findByMaPhieu11(maPhieu);
        if(cs != null){
            sb.append("===== CHỈ SỐ TỔNG HỢP =====\n\n");
            sb.append("Nhiệt độ: ").append(cs.getNhietDo()).append("\n\n");
            sb.append("Nhịp tim: ").append(cs.getNhipTim()).append("\n\n");
            sb.append("Nhịp thở: ").append(cs.getNhipTho()).append("\n\n");
            sb.append("Huyết áp tâm thu: ").append(cs.getHuyetApTamThu()).append("\n\n");
            sb.append("Cân nặng: ").append(cs.getCanNang()).append("\n\n");
            sb.append("Chiều cao: ").append(cs.getChieuCao()).append("\n\n");
            sb.append("Ghi chú trợ lý: ").append(nullToEmpty(cs.getGhiChu())).append("\n\n");

            txtTinhTrangChung.setText(cs.getTinhTrangRang());
            txtTinhTrangNuou.setText(cs.getViemNuou());
            txtSauRang.setText(cs.getSauRang());
            txtNiemMac.setText(cs.getNiemMacMieng());
            txtCaoRang.setText(cs.getCaoRang());
            txtDoLungLay.setText(cs.getDoLungLay());
            txtKhopCan.setText(cs.getKhopCan());
            txtBenhLyKhac.setText(cs.getBenhLyKhacRHM());
            txtPhucHinhCu.setText(cs.getPhuHinhCu());
            txtGhiChu.setText(cs.getGhiChu());
        }
        txtThongTinCu.setText(sb.toString());
    }

    private void loadHistory(){
        historyModel.setRowCount(0);
        ChiTietKhamBenh current = chiTietBUS.getByMaPhieuKham(maPhieu);
        if(current == null) return;

        String keyword = current.getCccd();
        List<LichSuKhamBenh> list = lichSuBUS.getByCCCD(keyword);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        for(LichSuKhamBenh dataLs : list){
            historyModel.addRow(new Object[]{
                    dataLs.getMaPhieuKham(),
                    dataLs.getNgayKham() != null ? sdf.format(dataLs.getNgayKham()) : "",
                    dataLs.getTenBacSi(),
                    dataLs.getTrangThai()
            });
        }
    }

    private void showChiTietKham(int maPK){
        ChiTietKhamBenh ct = chiTietBUS.getByMaPhieuKham(maPK);
        if(ct == null){
            JOptionPane.showMessageDialog(this, "Không tìm thấy dữ liệu");
            return;
        }

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(MAIN_FONT);
        area.setBorder(new EmptyBorder(10, 10, 10, 10));

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        area.setText(
                "===== THÔNG TIN KHÁM =====\n\n" +
                "Mã phiếu: " + ct.getMaPhieuKham() + "\n\n" +
                "Tên bệnh nhân: " + ct.getTenBenhNhan() + "\n\n" +
                "CCCD: " + ct.getCccd() + "\n\n" +
                "Bác sĩ: " + ct.getTenBacSi() + "\n\n" +
                "Chuyên khoa: " + ct.getChuyenKhoa() + "\n\n" +
                "Ngày khám: " + (ct.getNgayKham() != null ? sdf.format(ct.getNgayKham()) : "") + "\n\n" +
                "Lý do khám: " + nullToEmpty(ct.getLyDoKham()) + "\n\n" +
                "Bệnh sử: " + nullToEmpty(ct.getBenhSu()) + "\n\n" +
                "Tiền sử: " + nullToEmpty(ct.getTienSuBanThan()) + "\n\n" +
                "Khám lâm sàng: " + nullToEmpty(ct.getKhamLamSang()) + "\n\n" +
                "Kết quả CLS: " + nullToEmpty(ct.getKetQuaCanLamSang()) + "\n\n" +
                "Chuẩn đoán sơ bộ: " + nullToEmpty(ct.getChanDoanSoBo()) + "\n\n" +
                "Lời dặn bác sĩ: " + nullToEmpty(ct.getLoiDanBacSi())
        );

        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(750, 550));
        JOptionPane.showMessageDialog(this, sp, "Chi tiết khám bệnh", JOptionPane.INFORMATION_MESSAGE);
    }

    private void save(){
        ChiSoKhamTongHop c = new ChiSoKhamTongHop();
        c.setMaPhieuKham(maPhieu);
        c.setMaNhanVienNhap(Session.currentUser.getMaNhanVien());
        c.setTinhTrangRang(txtTinhTrangChung.getText());
        c.setViemNuou(txtTinhTrangNuou.getText());
        c.setSauRang(txtSauRang.getText());
        c.setNiemMacMieng(txtNiemMac.getText());
        c.setCaoRang(txtCaoRang.getText());
        c.setDoLungLay(txtDoLungLay.getText());
        c.setKhopCan(txtKhopCan.getText());
        c.setBenhLyKhacRHM(txtBenhLyKhac.getText());
        c.setPhuHinhCu(txtPhucHinhCu.getText());
        c.setGhiChu(txtGhiChu.getText());

        boolean ok = csDao.saveOrUpdate(c);

        KhamLamSang ls = new KhamLamSang();
        ls.setMaPhieuKham(maPhieu);
        ls.setChanDoanSoBo(txtChanDoan.getText());
        ls.setLoiDanBacSi(txtLoiDan.getText());
        lsDao.saveOrUpdate(ls);

        if(ok){
            JOptionPane.showMessageDialog(this, "Đã lưu thành công");
            loadOldData();
            loadHistory();
        }else{
            JOptionPane.showMessageDialog(this, "Lưu thất bại");
        }
    }

    private void update(){
        save();
    }

    private String nullToEmpty(String s){
        return s == null ? "" : s;
    }

    private void chuyenXQuang(){
        try{
            save();
            PhieuKhamDAO dao = new PhieuKhamDAO();
            boolean daCo = dao.checkDaChiDinhDichVu(maPhieu, 31);

            if(daCo){
                JOptionPane.showMessageDialog(this, "Bệnh nhân đã được chỉ định X-Quang!");
                return;
            }

            boolean okTrangThai = dao.updateTrangThai(maPhieu, "CLS_CHAN_DOAN_HINH_ANH");
            int maPhieuChiDinh = dao.createPhieuChiDinh(maPhieu);

            if(maPhieuChiDinh == -1){
                JOptionPane.showMessageDialog(this, "Không tạo được phiếu chỉ định!");
                return;
            }

            boolean okChiTiet = dao.insertChiTietChiDinh(maPhieuChiDinh, 31);

            if(okTrangThai && okChiTiet){
                JOptionPane.showMessageDialog(this, "Đã chuyển bệnh nhân sang chụp X-Quang!");
            }else{
                JOptionPane.showMessageDialog(this, "Chuyển thất bại!");
            }
        }catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi hệ thống!");
        }
    }

    private void moDonThuoc(){
        try{
            save();
            ToaThuocForm f = new ToaThuocForm(maPhieu);
            f.setVisible(true);
        }catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Không mở được form đơn thuốc!");
        }
    }

    private void henTaiKham(){
        try{
            save();
            ChiTietKhamBenh ct = chiTietBUS.getByMaPhieuKham(maPhieu);
            if(ct == null){
                JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin khám!");
                return;
            }

            BenhNhan bn = benhNhanDAO.findByCCCD(ct.getCccd());
            if(bn == null){
                JOptionPane.showMessageDialog(this, "Không tìm thấy bệnh nhân!");
                return;
            }

            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.DATE, 3);
            java.util.Date defaultDate = cal.getTime();

            JSpinner dateSpinner = new JSpinner(new SpinnerDateModel(defaultDate, null, null, java.util.Calendar.DAY_OF_MONTH));
            JSpinner.DateEditor editor = new JSpinner.DateEditor(dateSpinner, "dd/MM/yyyy");
            dateSpinner.setEditor(editor);

            JTextArea txtGhiChuPopup = new JTextArea(5, 20);
            styleTextArea(txtGhiChuPopup);

            JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
            panel.add(new JLabel("Ngày tái khám"));
            panel.add(dateSpinner);
            panel.add(new JLabel("Ghi chú"));
            panel.add(new JScrollPane(txtGhiChuPopup));

            int result = JOptionPane.showConfirmDialog(this, panel, "Hẹn tái khám", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if(result != JOptionPane.OK_OPTION){
                return;
            }

            java.util.Date utilDate = (java.util.Date) dateSpinner.getValue();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            LichTaiKham l = new LichTaiKham();
            l.setMaBenhNhan(bn.getMaBenhNhan());
            l.setMaChuyenKhoa(5);
            l.setMaPhieuKham(maPhieu);
            l.setMaNhanVien(Session.currentUser.getMaNhanVien());
            l.setNgayTaiKham(sqlDate);
            l.setGhiChu(txtGhiChuPopup.getText());
            l.setTrangThai("CHUA_DEN");
            l.setDaGuiThongBao(false);

            lichTaiKhamBUS.insert(l);
            JOptionPane.showMessageDialog(this, "Đặt lịch tái khám thành công!");
        }catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi đặt lịch tái khám!");
        }
    }

    private void ketThucKham(){
        try{
            save();
            PhieuKhamDAO dao = new PhieuKhamDAO();
            boolean ok = dao.updateTrangThai(maPhieu, "CHO_THANH_TOAN");

            if(ok){
                JOptionPane.showMessageDialog(this, "Đã kết thúc khám!");
                dispose();
            }else{
                JOptionPane.showMessageDialog(this, "Không thể cập nhật trạng thái!");
            }
        }catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi kết thúc khám!");
        }
    }
    private void chuyenChuyenKhoa(){

        try{

            save();

            JComboBox<ChuyenKhoa> cbCK =
                    new JComboBox<>();

            // load chuyên khoa
            for(ChuyenKhoa ck :
                    chuyenKhoaBUS.getAll()){

                cbCK.addItem(ck);
            }

            JTextArea txtLyDo =
                    new JTextArea(4,20);

            JPanel panel =
                    new JPanel(
                            new GridLayout(2,2,10,10)
                    );

            panel.add(
                    new JLabel("Chuyên khoa chuyển đến")
            );

            panel.add(cbCK);

            panel.add(
                    new JLabel("Lý do chuyển")
            );

            panel.add(
                    new JScrollPane(txtLyDo)
            );

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Chuyển chuyên khoa",
                            JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE
                    );

            if(result != JOptionPane.OK_OPTION){
                return;
            }

            ChuyenKhoa ck =
                    (ChuyenKhoa)
                            cbCK.getSelectedItem();

            if(ck == null){
                return;
            }

            // =====================================
            // UPDATE PHIẾU KHÁM
            // =====================================

            PhieuKhamDAO dao =
                    new PhieuKhamDAO();

            boolean ok =
                    dao.chuyenChuyenKhoa(
                            maPhieu,
                            ck.getMaChuyenKhoa(),
                            txtLyDo.getText()
                    );

            if(ok){

                JOptionPane.showMessageDialog(
                        this,
                        "Đã chuyển bệnh nhân sang chuyên khoa: "
                                + ck.getTenChuyenKhoa()
                );

                dispose();

            }else{

                JOptionPane.showMessageDialog(
                        this,
                        "Chuyển chuyên khoa thất bại!"
                );
            }

        }catch(Exception ex){

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi chuyển chuyên khoa!"
            );
        }
    }
}