package gui;

import dao.DangKyKhamBenhDAO;
import model.DangKyKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class KhamnoiForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JLabel lblCount; // Nhãn hiển thị số lượng bệnh nhân đang chờ

    // Biến lưu trữ tham chiếu đến Form mẹ (Dashboard) để quay lại
    private JFrame parentForm;

    // Hệ màu Flat UI chuyên dụng cho phân hệ Nội khoa
    private final Color BG = new Color(244, 246, 249);       // Nền xám xanh nhẹ thanh lịch
    private final Color PRIMARY = new Color(26, 140, 140);   // Màu xanh Teal đặc trưng khoa nội
    private final Color SUCCESS = new Color(39, 174, 96);    // Xanh lá cho nút hành động chính
    private final Color TEXT_DARK = new Color(44, 62, 80);

    private DangKyKhamBenhDAO dao = new DangKyKhamBenhDAO();

    // =========================================================================
    // NẠP CHỒNG CONSTRUCTOR (OVERLOADING) ĐỂ QUAY LẠI DASHBOARD AN TOÀN
    // =========================================================================
    
    /**
     * Constructor 1: Không tham số (Hỗ trợ gọi trực tiếp hoặc từ các luồng cũ)
     */
    public KhamnoiForm() {
        this(null);
    }

    /**
     * Constructor 2: Có tham số (Nhận Dashboard truyền vào để quay lại khi bấm nút)
     */
    public KhamnoiForm(JFrame parentForm) {
        this.parentForm = parentForm;

        setTitle("DANH SÁCH BỆNH NHÂN CHỜ KHÁM NỘI TỔNG QUÁT");
        setSize(1000, 650); // Tăng nhẹ không gian hiển thị bảng
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(root);

        // =========================================================================
        // THANH TRÊN (TOP): TIÊU ĐỀ, BỘ ĐẾM & LÀM MỚI
        // =========================================================================
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(BG);

        // Khối tiêu đề bên trái
        JPanel leftTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        leftTop.setBackground(BG);
        
        JLabel lblTitle = new JLabel("DANH SÁCH CHỜ KHÁM NỘI  ");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_DARK);
        
        lblCount = new JLabel("(Đang chờ: 0)");
        lblCount.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 14));
        lblCount.setForeground(new Color(230, 126, 34)); // Màu cam nổi bật cảnh báo số lượng ca

        leftTop.add(lblTitle);
        leftTop.add(lblCount);

        // Nút làm mới danh sách bên phải
        JButton btnRefresh = new JButton("🔄 Làm mới danh sách");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBackground(Color.WHITE);
        btnRefresh.setForeground(PRIMARY);
        btnRefresh.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 220), 1),
                BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRefresh.addActionListener(e -> loadData());

        topPanel.add(leftTop, BorderLayout.WEST);
        topPanel.add(btnRefresh, BorderLayout.EAST);
        root.add(topPanel, BorderLayout.NORTH);

        // =========================================================================
        // KHU VỰC GIỮA (CENTER): BẢNG DỮ LIỆU ĐƯỢC TỐI ƯU
        // =========================================================================
        model = new DefaultTableModel(
                new String[]{"ID ĐK", "Mã BN", "Họ tên bệnh nhân", "Số thứ tự", "Mã phiếu"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Khóa không cho sửa trực tiếp trên ô dữ liệu
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(38); // Tăng chiều cao hàng giúp bác sĩ dễ quan sát và click chọn
        table.setSelectionBackground(new Color(228, 242, 242)); // Màu nền pastel khi chọn dòng
        table.setSelectionForeground(TEXT_DARK);
        table.setShowVerticalLines(false); // Ẩn đường kẻ dọc giúp giao diện thoáng đãng hơn
        table.setGridColor(new Color(230, 235, 240));

        // Định dạng thanh Header của Table
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(PRIMARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
        table.getTableHeader().setReorderingAllowed(false);

        // Căn giữa dữ liệu các cột có định dạng số (ID, Mã, STT)
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        // Cấu hình tỷ lệ phân bổ chiều rộng các cột hợp lý
        table.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID ĐK
        table.getColumnModel().getColumn(1).setPreferredWidth(100); // Mã BN
        table.getColumnModel().getColumn(2).setPreferredWidth(400); // Họ tên bệnh nhân chiếm không gian lớn nhất
        table.getColumnModel().getColumn(3).setPreferredWidth(100); // Số thứ tự

        // Ẩn cột ẩn chứa dữ liệu Mã phiếu
        table.getColumnModel().getColumn(4).setMinWidth(0);
        table.getColumnModel().getColumn(4).setMaxWidth(0);
        table.getColumnModel().getColumn(4).setWidth(0);

        // Bọc Table vào thanh cuộn phẳng không viền thô
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 225), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
        root.add(scrollPane, BorderLayout.CENTER);

        // =========================================================================
        // THANH DƯỚI (SOUTH): ĐIỀU HƯỚNG & HÀNH ĐỘNG
        // =========================================================================
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(BG);

        // Bên trái: Nút QUAY LẠI Dashboard chính của bác sĩ thay vì chỉ đóng thuần túy
        JButton btnBack = new JButton("⬅ Quay lại");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setFocusPainted(false);
        btnBack.setContentAreaFilled(false);
        btnBack.setForeground(new Color(127, 140, 141));
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> {
            if (parentForm != null) {
                parentForm.setVisible(true); // Hiển thị lại Dashboard mẹ nếu có
            }
            dispose(); // Giải phóng form hiện tại
        });

        // Bên phải: Nút tiến hành gọi vào khám bệnh lớn, nổi bật
        JButton btnKham = new JButton("TIẾN HÀNH KHÁM ➜");
        btnKham.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKham.setFocusPainted(false);
        btnKham.setBackground(SUCCESS);
        btnKham.setForeground(Color.WHITE);
        btnKham.setBorder(BorderFactory.createEmptyBorder(12, 35, 12, 35));
        btnKham.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnKham.addActionListener(e -> openKham());

        bottomPanel.add(btnBack, BorderLayout.WEST);
        bottomPanel.add(btnKham, BorderLayout.EAST);
        root.add(bottomPanel, BorderLayout.SOUTH);

        loadData();
    }

    private void loadData() {
        model.setRowCount(0);
        
        List<DangKyKhamBenh> list = dao.getChoKhamKhoaNoi();

        if (list != null) {
            lblCount.setText("(Đang chờ: " + list.size() + " ca)");
            
            for (DangKyKhamBenh dk : list) {
                model.addRow(new Object[]{
                        dk.getId(),
                        dk.getMaBenhNhan(),
                        dk.getHoTen(),
                        dk.getSoThuTu(),
                        dk.getMaPhieuKham()
                });
            }
        } else {
            lblCount.setText("(Đang chờ: 0 ca)");
        }
    }

    private void openKham() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một bệnh nhân từ danh sách để tiến hành khám bệnh!", 
                    "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object value = model.getValueAt(row, 4);

        if (value == null) {
            JOptionPane.showMessageDialog(this, "Bệnh nhân này chưa được tạo mã phiếu khám trên hệ thống!", 
                    "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(value.toString());

        if (maPhieu <= 0) {
            JOptionPane.showMessageDialog(this, "Mã phiếu khám không hợp lệ!", 
                    "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
            return;
        }

        System.out.println("Mở phiếu khám nội khoa: " + maPhieu);

        // Mở form nhập liệu chi tiết khoa nội
        new KhamNoiChiTietForm(maPhieu).setVisible(true);
        this.dispose(); // Giải phóng màn hình danh sách để bác sĩ tập trung khám bệnh
    }
}