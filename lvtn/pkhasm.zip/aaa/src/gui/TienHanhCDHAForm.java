package gui;

import config.DBConnection;
import config.Session;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TienHanhCDHAForm extends JFrame {

    private int maPhieu;
    private int idChiTietChiDinh = -1;

    // Các thành phần UI giao diện
    private JTextArea txtThongTin = new JTextArea();
    private JTextArea txtMoTa = new JTextArea();
    private JTextArea txtKetLuan = new JTextArea();
    private JTextArea txtDeNghi = new JTextArea();

    private JTextField txtAnh1 = new JTextField();
    private JTextField txtAnh2 = new JTextField();

    private JLabel lblPreview1 = new JLabel();
    private JLabel lblPreview2 = new JLabel();

    public TienHanhCDHAForm(int maPhieu) {
        this.maPhieu = maPhieu;
        setTitle("TIẾN HÀNH CHẨN ĐOÁN HÌNH ẢNH - PHIẾU KHÁM: " + maPhieu);
        setSize(1300, 800); // Tăng nhẹ kích thước để không gian thở thoải mái hơn
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        init();
        loadInfo();
    }

    private void init() {
        // Sử dụng khoảng cách 15px giữa các vùng lớn vùng Border chính
        setLayout(new BorderLayout(15, 15));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // =========================================================================
        // KHU VỰC TRÁI: THÔNG TIN BỆNH NHÂN
        // =========================================================================
        txtThongTin.setEditable(false);
        txtThongTin.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtThongTin.setLineWrap(true);
        txtThongTin.setWrapStyleWord(true);
        txtThongTin.setBackground(new Color(245, 247, 250)); // Đổi màu nền xám nhẹ dễ đọc
        txtThongTin.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane leftScrollPane = new JScrollPane(txtThongTin);
        leftScrollPane.setPreferredSize(new Dimension(320, 0));
        leftScrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(180, 190, 200)),
                "HÀNH CHÍNH & LÂM SÀNG", TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12), new Color(70, 80, 95)
        ));

        // =========================================================================
        // KHU VỰC GIỮA: NHẬP KẾT QUẢ & HÌNH ẢNH (Bọc trong Scroll chính để chống tràn)
        // =========================================================================
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // 1. Nhóm nhập text (Mô tả, Kết luận, Đề nghị)
        JPanel textFieldsPanel = new JPanel(new GridLayout(3, 1, 0, 10));
        textFieldsPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 220)),
                "NỘI DUNG CHẨN ĐOÁN", TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12), new Color(0, 102, 204)
        ));

        textFieldsPanel.add(createInputGroup("Mô tả hình ảnh tổn thương:", txtMoTa));
        textFieldsPanel.add(createInputGroup("Kết luận chẩn đoán:", txtKetLuan));
        textFieldsPanel.add(createInputGroup("Đề nghị / Hẹn tái khám:", txtDeNghi));

        // 2. Nhóm quản lý và xem trước hình ảnh (Thiết kế lưới ngang song song)
        JPanel imagesPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        imagesPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 220)),
                "HÌNH ẢNH MINH HỌA (Double-click để phóng to)", TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12), new Color(0, 102, 204)
        ));

        imagesPanel.add(createImageSection("Chọn ảnh 1", txtAnh1, lblPreview1, () -> choose1()));
        imagesPanel.add(createImageSection("Chọn ảnh 2", txtAnh2, lblPreview2, () -> choose2()));

        centerPanel.add(textFieldsPanel);
        centerPanel.add(Box.createVerticalStrut(15));
        centerPanel.add(imagesPanel);

        JScrollPane centerScrollPane = new JScrollPane(centerPanel);
        centerScrollPane.setBorder(null); // Ẩn viền ngoài cùng của scroll chính
        centerScrollPane.getVerticalScrollBar().setUnitIncrement(16); // Cuộn mượt hơn

        // =========================================================================
        // KHU VỰC DƯỚI: NÚT THAO TÁC
        // =========================================================================
        JButton btnSave = new JButton("LƯU KẾT QUẢ (F5)");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setBackground(new Color(0, 153, 76)); // Màu xanh lá cây chuẩn khám chữa bệnh
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setPreferredSize(new Dimension(220, 45));
        btnSave.addActionListener(e -> save());

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(btnSave);

        // Thêm vào JFrame chính
        add(leftScrollPane, BorderLayout.WEST);
        add(centerScrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Hàm tiện ích tạo cụm nhãn nhập liệu Text Area trực quan
     */
    private JPanel createInputGroup(String labelText, JTextArea textArea) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setPreferredSize(new Dimension(0, 85)); // Khóa cứng chiều cao cho gọn gàng

        panel.add(label, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    /**
     * Hàm tiện ích tạo khối tải ảnh gồm: Nút bấm, Đường dẫn Textfield và Khung hiển thị lớn bên dưới
     */
    private JPanel createImageSection(String buttonText, JTextField textField, JLabel previewLabel, Runnable chooseAction) {
        JPanel mainSection = new JPanel(new BorderLayout(8, 8));

        // Thanh chọn file ở trên
        JPanel topBar = new JPanel(new BorderLayout(5, 5));
        JButton btnChoose = new JButton(buttonText);
        btnChoose.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnChoose.addActionListener(e -> chooseAction.run());
        
        textField.setEditable(false);
        textField.setBackground(Color.WHITE);

        topBar.add(btnChoose, BorderLayout.WEST);
        topBar.add(textField, BorderLayout.CENTER);

        // Vùng xem ảnh ở dưới
        previewLabel.setPreferredSize(new Dimension(0, 240)); // Kích thước khung ảnh lý tưởng
        previewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        previewLabel.setBorder(BorderFactory.createLineBorder(new Color(210, 215, 225)));
        previewLabel.setBackground(new Color(250, 250, 252));
        previewLabel.setOpaque(true);
        previewLabel.setText("Chưa có hình ảnh chẩn đoán");
        previewLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        previewLabel.setForeground(Color.GRAY);

        previewLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    openImage(textField.getText());
                }
            }
        });

        mainSection.add(topBar, BorderLayout.NORTH);
        mainSection.add(previewLabel, BorderLayout.CENTER);
        return mainSection;
    }

    // =========================================================================
    // GIỮ NGUYÊN CÁC LOGIC XỬ LÝ DỮ LIỆU/DATABASE PHÍA DƯỚI CỦA BẠN
    // =========================================================================
    private void loadInfo() {
        String sqlFind = """
                SELECT ctd.id
                FROM chi_tiet_chi_dinh ctd
                JOIN phieu_chi_dinh pcd ON ctd.ma_phieu_chi_dinh = pcd.ma_phieu_chi_dinh
                WHERE pcd.ma_phieu_kham = ? AND ctd.ma_dich_vu = 31
                LIMIT 1
                """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sqlFind)) {
            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                idChiTietChiDinh = rs.getInt("id");
                System.out.println("ID CHI TIẾT CHỈ ĐỊNH = " + idChiTietChiDinh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String sql = """
                SELECT bn.ho_ten, ls.ly_do_kham, cs.ghi_chu, cs.nhiet_do, cs.nhip_tim, cs.can_nang, cs.chieu_cao, cs.huyet_ap_tam_thu
                FROM phieu_kham pk
                JOIN benh_nhan bn ON pk.ma_benh_nhan = bn.ma_benh_nhan
                LEFT JOIN kham_lam_sang ls ON pk.ma_phieu_kham = ls.ma_phieu_kham
                LEFT JOIN chi_so_kham_tong_hop cs ON pk.ma_phieu_kham = cs.ma_phieu_kham
                WHERE pk.ma_phieu_kham = ?
                """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                txtThongTin.setText(
                        "===== THÔNG TIN BỆNH NHÂN =====\n\n"
                        + "Họ tên: " + rs.getString("ho_ten")
                        + "\n\nLý do khám: " + nullToEmpty(rs.getString("ly_do_kham"))
                        + "\n\nGhi chú: " + nullToEmpty(rs.getString("ghi_chu"))
                        + "\n\nNhiệt độ: " + nullToEmpty(rs.getString("nhiet_do")) + " °C"
                        + "\n\nNhịp tim: " + nullToEmpty(rs.getString("nhip_tim")) + " bpm"
                        + "\n\nCân nặng: " + nullToEmpty(rs.getString("can_nang")) + " kg"
                        + "\n\nChiều cao: " + nullToEmpty(rs.getString("chieu_cao")) + " cm"
                        + "\n\nHuyết áp: " + nullToEmpty(rs.getString("huyet_ap_tam_thu")) + " mmHg"
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        loadSavedResult();
    }

    private void loadSavedResult() {
        String sql = "SELECT * FROM ket_qua_cdha WHERE id_chi_tiet_chi_dinh = ? LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idChiTietChiDinh);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                txtMoTa.setText(rs.getString("mo_ta_hinh_anh"));
                txtKetLuan.setText(rs.getString("ket_luan"));
                txtDeNghi.setText(rs.getString("de_nghi"));
                txtAnh1.setText(rs.getString("duong_dan_anh_1"));
                txtAnh2.setText(rs.getString("duong_dan_anh_2"));

                showImage(txtAnh1.getText(), lblPreview1);
                showImage(txtAnh2.getText(), lblPreview2);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void choose1() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            txtAnh1.setText(f.getAbsolutePath());
            showImage(f.getAbsolutePath(), lblPreview1);
        }
    }

    private void choose2() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            txtAnh2.setText(f.getAbsolutePath());
            showImage(f.getAbsolutePath(), lblPreview2);
        }
    }

    private void showImage(String path, JLabel label) {
        try {
            if (path == null || path.isEmpty()) {
                label.setIcon(null);
                label.setText("Chưa có hình ảnh chẩn đoán");
                return;
            }
            File file = new File(path);
            if (!file.exists()) {
                label.setText("Không tìm thấy ảnh tại đường dẫn");
                label.setIcon(null);
                return;
            }
            ImageIcon icon = new ImageIcon(path);
            Image img = icon.getImage();
            // Điều chỉnh dynamic scale ăn khớp theo chiều rộng vùng mới (khoảng 450px)
            Image scale = img.getScaledInstance(450, 230, Image.SCALE_SMOOTH);
            label.setText("");
            label.setIcon(new ImageIcon(scale));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openImage(String path) {
        try {
            if (path == null || path.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Chưa có ảnh!");
                return;
            }
            File file = new File(path);
            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy file ảnh!");
                return;
            }
            JFrame f = new JFrame("Xem ảnh chi tiết");
            f.setSize(1000, 750);
            f.setLocationRelativeTo(null);
            JLabel lbl = new JLabel();
            lbl.setHorizontalAlignment(SwingConstants.CENTER);
            ImageIcon icon = new ImageIcon(path);
            Image img = icon.getImage();
            Image scale = img.getScaledInstance(960, 680, Image.SCALE_SMOOTH);
            lbl.setIcon(new ImageIcon(scale));
            f.add(new JScrollPane(lbl));
            f.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void save() {
        if (idChiTietChiDinh == -1) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy ID chi tiết chỉ định X-Quang!");
            return;
        }
        try (Connection con = DBConnection.getConnection()) {
            String check = "SELECT id FROM ket_qua_cdha WHERE id_chi_tiet_chi_dinh = ?";
            PreparedStatement psCheck = con.prepareStatement(check);
            psCheck.setInt(1, idChiTietChiDinh);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                String update = """
                        UPDATE ket_qua_cdha
                        SET mo_ta_hinh_anh=?, ket_luan=?, de_nghi=?, duong_dan_anh_1=?, duong_dan_anh_2=?, ma_nhan_vien_thuc_hien=?
                        WHERE id_chi_tiet_chi_dinh=?
                        """;
                PreparedStatement ps = con.prepareStatement(update);
                ps.setString(1, txtMoTa.getText());
                ps.setString(2, txtKetLuan.getText());
                ps.setString(3, txtDeNghi.getText());
                ps.setString(4, txtAnh1.getText());
                ps.setString(5, txtAnh2.getText());
                ps.setInt(6, Session.currentUser.getMaNhanVien());
                ps.setInt(7, idChiTietChiDinh);
                ps.executeUpdate();
            } else {
                String insert = """
                        INSERT INTO ket_qua_cdha (id_chi_tiet_chi_dinh, mo_ta_hinh_anh, ket_luan, de_nghi, duong_dan_anh_1, duong_dan_anh_2, ma_nhan_vien_thuc_hien)
                        VALUES(?,?,?,?,?,?,?)
                        """;
                PreparedStatement ps = con.prepareStatement(insert);
                ps.setInt(1, idChiTietChiDinh);
                ps.setString(2, txtMoTa.getText());
                ps.setString(3, txtKetLuan.getText());
                ps.setString(4, txtDeNghi.getText());
                ps.setString(5, txtAnh1.getText());
                ps.setString(6, txtAnh2.getText());
                ps.setInt(7, Session.currentUser.getMaNhanVien());
                ps.executeUpdate();
            }

            String updateCT = "UPDATE chi_tiet_chi_dinh SET trang_thai_dv='DA_THUC_HIEN', ma_nhan_vien_thuc_hien=? WHERE id=?";
            PreparedStatement ps2 = con.prepareStatement(updateCT);
            ps2.setInt(1, Session.currentUser.getMaNhanVien());
            ps2.setInt(2, idChiTietChiDinh);
            ps2.executeUpdate();

            String updatePK = "UPDATE phieu_kham SET trang_thai='DANG_KHAM' WHERE ma_phieu_kham=?";
            PreparedStatement ps3 = con.prepareStatement(updatePK);
            ps3.setInt(1, maPhieu);
            ps3.executeUpdate();

            JOptionPane.showMessageDialog(this, "Lưu kết quả CDHA thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi lưu kết quả!");
        }
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}