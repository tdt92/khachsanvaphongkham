package gui;

import javax.swing.*;
import java.awt.*;

public class AdminMainForm extends JFrame {

    public AdminMainForm(){

        setTitle("TRANG QUẢN TRỊ");
        setSize(1000,600);
        setLocationRelativeTo(null);
 
        JMenuBar bar = new JMenuBar();

        JMenu menu = new JMenu("Quản lý");

        JMenuItem nv = new JMenuItem("Nhân viên");
        JMenuItem tk = new JMenuItem("Tài khoản");
        JMenuItem bn = new JMenuItem("Bệnh nhân"); // thêm mới

        menu.add(nv);
        menu.add(tk);
        menu.add(bn); // thêm vào menu

        bar.add(menu);
        setJMenuBar(bar);

 
        nv.addActionListener(e ->
                new QuanLyNhanVienForm().show()
        );

        tk.addActionListener(e ->
                new QuanLyTaiKhoanForm().show()
        );

        bn.addActionListener(e ->
                new QuanLyBenhNhanForm().show()
        );
    }
}
