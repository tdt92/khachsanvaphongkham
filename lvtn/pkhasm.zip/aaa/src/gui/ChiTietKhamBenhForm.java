package gui;

import bus.ChiTietKhamBenhBUS;
import model.ChiTietKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class ChiTietKhamBenhForm extends JFrame {

    private final ChiTietKhamBenhBUS bus = new ChiTietKhamBenhBUS();
    
    // Màu sắc chủ đạo
    private final Color COLOR_PRIMARY = new Color(41, 128, 185);
    private final Color COLOR_BG = new Color(240, 242, 245);

    public ChiTietKhamBenhForm(int maPhieuKham) {
        ChiTietKhamBenh ct = bus.getByMaPhieuKham(maPhieuKham);
        
        setTitle("HỒ SƠ BỆNH ÁN - Mã phiếu: " + maPhieuKham);
        setSize(1000, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(20, 20));
        root.setBackground(COLOR_BG);
        root.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(root);

        // --- PANEL THÔNG TIN HÀNH CHÍNH (SIDEBAR) ---
        JPanel infoPanel = createInfoPanel(ct);
        infoPanel.setPreferredSize(new Dimension(300, 0));
        root.add(infoPanel, BorderLayout.WEST);

        // --- PANEL CHI TIẾT CHUYÊN MÔN (CENTER) ---
        JPanel detailPanel = createDetailPanel(ct);
        root.add(new JScrollPane(detailPanel), BorderLayout.CENTER);
    }

    private JPanel createInfoPanel(ChiTietKhamBenh ct) {
        JPanel p = new JPanel(new GridLayout(7, 1, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(20, 20, 20, 20)));
        
        String[][] data = {
            {"Mã phiếu", String.valueOf(ct.getMaPhieuKham())},
            {"Bệnh nhân", ct.getTenBenhNhan()},
            {"CCCD", ct.getCccd()},
            {"Bác sĩ", ct.getTenBacSi()},
            {"Chuyên khoa", ct.getChuyenKhoa()},
            {"Ngày khám", ct.getNgayKham().toString()},
            {"Trạng thái", ct.getTrangThai()}
        };

        for (String[] item : data) {
            JPanel itemP = new JPanel(new BorderLayout());
            itemP.setOpaque(false);
            JLabel lblKey = new JLabel(item[0]);
            lblKey.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblKey.setForeground(Color.GRAY);
            JLabel lblVal = new JLabel(item[1]);
            lblVal.setFont(new Font("Segoe UI", Font.BOLD, 14));
            
            itemP.add(lblKey, BorderLayout.NORTH);
            itemP.add(lblVal, BorderLayout.CENTER);
            p.add(itemP);
        }
        return p;
    }

    private JPanel createDetailPanel(ChiTietKhamBenh ct) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(20, 20, 20, 20));

        addSection(p, "Lý do khám", ct.getLyDoKham());
        addSection(p, "Tiền sử bản thân", ct.getTienSuBanThan());
        addSection(p, "Bệnh sử", ct.getBenhSu());
        addSection(p, "Chẩn đoán sơ bộ", ct.getChanDoanSoBo());
        addSection(p, "Khám lâm sàng", ct.getKhamLamSang());
        addSection(p, "Kết quả cận lâm sàng", ct.getKetQuaCanLamSang());
        addSection(p, "Lời dặn bác sĩ", ct.getLoiDanBacSi());

        return p;
    }

    private void addSection(JPanel p, String title, String content) {
        JPanel section = new JPanel(new BorderLayout(5, 5));
        section.setOpaque(false);
        section.setBorder(new EmptyBorder(0, 0, 15, 0));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(COLOR_PRIMARY);

        JTextArea area = new JTextArea(content != null ? content : "");
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);
        area.setBorder(new EmptyBorder(10, 10, 10, 10));
        area.setBackground(new Color(249, 249, 249));

        section.add(lblTitle, BorderLayout.NORTH);
        section.add(area, BorderLayout.CENTER);
        p.add(section);
    }
}