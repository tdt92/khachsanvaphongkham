package gui;

import bus.LichTaiKhamBUS;
import model.LichTaiKham;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

public class LichTaiKhamForm extends JFrame {

    private JTextField txtId = new JTextField();
    private JTextField txtMaBN = new JTextField();
    private JTextField txtMaCK = new JTextField();
    private JTextField txtMaPK = new JTextField();
    private JTextField txtMaNV = new JTextField();
    private JTextField txtSearch = new JTextField();

     private JSpinner dateSpinner;

    private JTextArea txtGhiChu = new JTextArea(3,20);

    private JComboBox<String> cboTrangThai =
            new JComboBox<>(new String[]{"CHUA_DEN","DA_DEN","HOAN"});

    private JCheckBox chkDaGui = new JCheckBox("Đã gửi thông báo");

    private JTable table = new JTable();
    private DefaultTableModel model;

    private LichTaiKhamBUS bus = new LichTaiKhamBUS();

    public LichTaiKhamForm(){

        setTitle("QUẢN LÝ LỊCH TÁI KHÁM");
        setSize(1400,750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10,10));

        add(createFormPanel(),BorderLayout.NORTH);
        add(createTablePanel(),BorderLayout.CENTER);

        loadData();
        initEvents();
    }

     private JPanel createFormPanel(){

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new TitledBorder("THÔNG TIN LỊCH TÁI KHÁM"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,10,5,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;

        addField(panel,gbc,y++,"ID",txtId);
        txtId.setEditable(false);

        addField(panel,gbc,y++,"Mã bệnh nhân",txtMaBN);
        addField(panel,gbc,y++,"Mã chuyên khoa",txtMaCK);
        addField(panel,gbc,y++,"Mã phiếu khám",txtMaPK);
        addField(panel,gbc,y++,"Mã nhân viên",txtMaNV);

         gbc.gridx=0; gbc.gridy=y;
        panel.add(new JLabel("Ngày tái khám"),gbc);

        gbc.gridx=1;
        dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor =
                new JSpinner.DateEditor(dateSpinner,"yyyy-MM-dd");
        dateSpinner.setEditor(editor);
        panel.add(dateSpinner,gbc);

        y++;

        gbc.gridx=0; gbc.gridy=y;
        panel.add(new JLabel("Trạng thái"),gbc);
        gbc.gridx=1;
        panel.add(cboTrangThai,gbc);

        gbc.gridx=2;
        panel.add(new JLabel(""),gbc);
        gbc.gridx=3;
        panel.add(chkDaGui,gbc);

        y++;

        gbc.gridx=0; gbc.gridy=y;
        panel.add(new JLabel("Ghi chú"),gbc);
        gbc.gridx=1; gbc.gridwidth=3;
        panel.add(new JScrollPane(txtGhiChu),gbc);
        gbc.gridwidth=1;

        y++;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT,15,5));

        JButton btnAdd = new JButton("THÊM");
        JButton btnUpdate = new JButton("SỬA");
        JButton btnDelete = new JButton("XOÁ");
        JButton btnClear = new JButton("LÀM MỚI");

        btnAdd.setBackground(new Color(46,204,113));
        btnAdd.setForeground(Color.WHITE);

        btnUpdate.setBackground(new Color(52,152,219));
        btnUpdate.setForeground(Color.WHITE);

        btnDelete.setBackground(new Color(231,76,60));
        btnDelete.setForeground(Color.WHITE);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);

        gbc.gridx=0; gbc.gridy=y; gbc.gridwidth=4;
        panel.add(btnPanel,gbc);

        btnAdd.addActionListener(e->add());
        btnUpdate.addActionListener(e->update());
        btnDelete.addActionListener(e->delete());
        btnClear.addActionListener(e->clearForm());

        return panel;
    }

    private void addField(JPanel panel,GridBagConstraints gbc,
                          int y,String label,JTextField field){

        gbc.gridx=0; gbc.gridy=y;
        panel.add(new JLabel(label),gbc);

        gbc.gridx=1;
        panel.add(field,gbc);
    }

    // ================= TABLE =================
    private JPanel createTablePanel(){

        JPanel panel = new JPanel(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID","Mã BN","Tên BN",
                "Mã CK","Chuyên khoa",
                "Mã NV","Tên NV",
                "Ngày","Trạng thái","Đã gửi","Ghi chú"
        },0);

        table.setModel(model);
        panel.add(new JScrollPane(table),BorderLayout.CENTER);

         JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JLabel lbSearch = new JLabel("Tìm theo tên ");

        txtSearch.setPreferredSize(new Dimension(500,32));

        JButton btnSearch = new JButton("🔍");
 
        JButton btnReload = new JButton("↻");

        searchPanel.add(lbSearch);
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        searchPanel.add(btnReload);

        panel.add(searchPanel,BorderLayout.NORTH);

        btnSearch.addActionListener(e->search());
        btnReload.addActionListener(e->loadData());

        txtSearch.addActionListener(e->search());

        return panel;
    }

     private void loadData(){

        model.setRowCount(0);

        List<LichTaiKham> list = bus.getAll();

        for(LichTaiKham l : list){
            model.addRow(new Object[]{
                    l.getId(),
                    l.getMaBenhNhan(),
                    l.getTenBenhNhan(),
                    l.getMaChuyenKhoa(),
                    l.getTenChuyenKhoa(),
                    l.getMaNhanVien(),
                    l.getTenNhanVien(),
                    l.getNgayTaiKham(),
                    l.getTrangThai(),
                    l.isDaGuiThongBao(),
                    l.getGhiChu()
            });
        }
    }

    private void search(){

        model.setRowCount(0);

        List<LichTaiKham> list = bus.search(txtSearch.getText());

        for(LichTaiKham l : list){
            model.addRow(new Object[]{
                    l.getId(),
                    l.getMaBenhNhan(),
                    l.getTenBenhNhan(),
                    l.getMaChuyenKhoa(),
                    l.getTenChuyenKhoa(),
                    l.getMaNhanVien(),
                    l.getTenNhanVien(),
                    l.getNgayTaiKham(),
                    l.getTrangThai(),
                    l.isDaGuiThongBao(),
                    l.getGhiChu()
            });
        }
    }

     private void initEvents(){

        table.getSelectionModel().addListSelectionListener(e->{

            int r = table.getSelectedRow();
            if(r<0) return;

            txtId.setText(model.getValueAt(r,0)+"");
            txtMaBN.setText(model.getValueAt(r,1)+"");
            txtMaCK.setText(model.getValueAt(r,3)+"");
            txtMaNV.setText(model.getValueAt(r,5)+"");

            try{
                java.util.Date d =
                        new SimpleDateFormat("yyyy-MM-dd")
                                .parse(model.getValueAt(r,7)+"");
                dateSpinner.setValue(d);
            }catch(Exception ignored){}

            cboTrangThai.setSelectedItem(model.getValueAt(r,8));
            chkDaGui.setSelected((boolean)model.getValueAt(r,9));
            txtGhiChu.setText(model.getValueAt(r,10)+"");
        });
    }

    // ================= CRUD =================
    private LichTaiKham getForm(){

        if(txtMaBN.getText().isEmpty() ||
           txtMaCK.getText().isEmpty() ||
           txtMaNV.getText().isEmpty()){

            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập đầy đủ thông tin bắt buộc!");
            return null;
        }

        LichTaiKham l = new LichTaiKham();

        if(!txtId.getText().isEmpty())
            l.setId(Integer.parseInt(txtId.getText()));

        l.setMaBenhNhan(Integer.parseInt(txtMaBN.getText()));
        l.setMaChuyenKhoa(Integer.parseInt(txtMaCK.getText()));

        if(!txtMaPK.getText().isEmpty())
            l.setMaPhieuKham(Integer.parseInt(txtMaPK.getText()));

        l.setMaNhanVien(Integer.parseInt(txtMaNV.getText()));

        java.util.Date utilDate =
                (java.util.Date) dateSpinner.getValue();
        l.setNgayTaiKham(new Date(utilDate.getTime()));

        l.setGhiChu(txtGhiChu.getText());
        l.setTrangThai(cboTrangThai.getSelectedItem()+"");
        l.setDaGuiThongBao(chkDaGui.isSelected());

        return l;
    }

    private void add(){
        LichTaiKham l = getForm();
        if(l==null) return;

        bus.insert(l);
        loadData();
        clearForm();
    }

    private void update(){
        if(txtId.getText().isEmpty()) return;

        LichTaiKham l = getForm();
        if(l==null) return;

        bus.update(l);
        loadData();
        clearForm();
    }

    private void delete(){
        if(txtId.getText().isEmpty()) return;

        int confirm = JOptionPane.showConfirmDialog(this,
                "Xoá lịch tái khám này?",
                "Xác nhận",JOptionPane.YES_NO_OPTION);

        if(confirm==JOptionPane.YES_OPTION){
            bus.delete(Integer.parseInt(txtId.getText()));
            loadData();
            clearForm();
        }
    }

    private void clearForm(){
        txtId.setText("");
        txtMaBN.setText("");
        txtMaCK.setText("");
        txtMaPK.setText("");
        txtMaNV.setText("");
        txtGhiChu.setText("");
        chkDaGui.setSelected(false);
        cboTrangThai.setSelectedIndex(0);
        dateSpinner.setValue(new java.util.Date());
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() ->
                new LichTaiKhamForm().setVisible(true));
    }
}