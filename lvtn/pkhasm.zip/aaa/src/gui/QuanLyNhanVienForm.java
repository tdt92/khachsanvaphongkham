package gui;

import bus.NhanVienBUS;
import model.NhanVien;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.sql.Date;

public class QuanLyNhanVienForm {

    JFrame frame = new JFrame("QUẢN LÝ NHÂN VIÊN");

    JTable table = new JTable();
    DefaultTableModel model;

    JTextField txtTen = new JTextField();
    JComboBox<String> cboGT =
    new JComboBox<>(new String[]{"Nam", "Nữ"});

    JSpinner spNgaySinh =
    new JSpinner(new SpinnerDateModel());

    JSpinner spNgayVaoLam =
    new JSpinner(new SpinnerDateModel());

    JTextField txtDiaChi = new JTextField();
    JTextField txtSDT = new JTextField();
    JTextField txtEmail = new JTextField();

    JComboBox<String> cboChuyenKhoa =
    new JComboBox<>(new String[]{
    "Nội tổng quát","Ngoại","Răng - Hàm - Mặt",
    "Tai - Mũi - Họng","Xét nghiệm","Nhi khoa","Tim mạch"});

    JTextField txtBangCap = new JTextField();

    JComboBox<String> cboChucVu =
    new JComboBox<>(new String[]{
    "Bác sĩ","Y tá","Lễ tân",
    "Trợ lý bác sĩ chuyên khoa","Thu ngân","Dược sĩ","Nhân viên kho","Kỹ thuật viên Xét nghiệm","Kỹ thuật viên Chẩn đoán hình ảnh","Quản trị viên"});

    JTextField txtCCCD = new JTextField();

    NhanVienBUS bus = new NhanVienBUS();

    public QuanLyNhanVienForm(){

        frame.setSize(1300,650);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(10,10));

        model = new DefaultTableModel(
        new String[]{
        "ID","Tên","GT","Ngày sinh",
        "Địa chỉ","SDT","Email",
        "Chuyên khoa","Bằng cấp",
        "Chức vụ","Ngày vào làm","CCCD"},0);

        table.setModel(model);

        JScrollPane tablePane =
        new JScrollPane(table);
        tablePane.setBorder(
        new TitledBorder("DANH SÁCH NHÂN VIÊN"));

        JPanel form =
        new JPanel(new GridLayout(13,2,8,8));
        form.setBorder(
        new TitledBorder("THÔNG TIN NHÂN VIÊN"));

        setDateSpinner(spNgaySinh);
        setDateSpinner(spNgayVaoLam);

        setOnlyNumber(txtSDT);
        setOnlyNumber(txtCCCD);

        addField(form,"Họ tên",txtTen);
        form.add(new JLabel("Giới tính"));
        form.add(cboGT);

        form.add(new JLabel("Ngày sinh"));
        form.add(spNgaySinh);

        addField(form,"Địa chỉ",txtDiaChi);
        addField(form,"SĐT",txtSDT);
        addField(form,"Email",txtEmail);

        form.add(new JLabel("Chuyên khoa"));
        form.add(cboChuyenKhoa);

        addField(form,"Bằng cấp",txtBangCap);

        form.add(new JLabel("Chức vụ"));
        form.add(cboChucVu);

        form.add(new JLabel("Ngày vào làm"));
        form.add(spNgayVaoLam);

        addField(form,"CCCD",txtCCCD);

        JButton btnAdd=new JButton("THÊM");
        JButton btnUpdate=new JButton("SỬA");
        JButton btnDelete=new JButton("XOÁ");

        JPanel btnPanel =
        new JPanel(new GridLayout(1,3,10,10));

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);

        JPanel right =
        new JPanel(new BorderLayout());

        right.add(form,BorderLayout.CENTER);
        right.add(btnPanel,BorderLayout.SOUTH);

        frame.add(tablePane,BorderLayout.CENTER);
        frame.add(right,BorderLayout.EAST);

        btnAdd.addActionListener(e->add());
        btnUpdate.addActionListener(e->update());
        btnDelete.addActionListener(e->delete());

        table.getSelectionModel()
        .addListSelectionListener(e->loadToForm());

        loadData();
    }

    private void addField(JPanel p,String lb,
                          JComponent txt){
        p.add(new JLabel(lb));
        p.add(txt);
    }

    private void setDateSpinner(JSpinner sp){
        sp.setEditor(
        new JSpinner.DateEditor(sp,"yyyy-MM-dd"));
    }

    private void setOnlyNumber(JTextField txt){

        ((AbstractDocument)txt.getDocument())
        .setDocumentFilter(new DocumentFilter(){

            public void insertString(
            FilterBypass fb,int offs,
            String str,AttributeSet a)
            throws BadLocationException{

                if(str.matches("\\d+"))
                super.insertString(fb,offs,str,a);
            }

            public void replace(
            FilterBypass fb,int offs,
            int len,String str,AttributeSet a)
            throws BadLocationException{

                if(str.matches("\\d*"))
                super.replace(fb,offs,len,str,a);
            }
        });
    }

    private void loadData(){

        model.setRowCount(0);

        for(NhanVien nv:bus.getAll()){

            model.addRow(new Object[]{
            nv.getMaNhanVien(),
            nv.getHoTen(),
            nv.getGioiTinh(),
            nv.getNgaySinh(),
            nv.getDiaChi(),
            nv.getSoDienThoai(),
            nv.getEmail(),
            nv.getChuyenKhoa(),
            nv.getBangCap(),
            nv.getChucVu(),
            nv.getNgayVaoLam(),
            nv.getCccd()
            });
        }
    }

    private Date getDate(JSpinner sp){
        return new Date(
        ((java.util.Date)sp.getValue())
        .getTime());
    }

    private NhanVien getForm(){

        NhanVien nv=new NhanVien();

        nv.setHoTen(txtTen.getText());
        nv.setGioiTinh(cboGT.getSelectedIndex());
        nv.setNgaySinh(getDate(spNgaySinh));
        nv.setDiaChi(txtDiaChi.getText());
        nv.setSoDienThoai(txtSDT.getText());
        nv.setEmail(txtEmail.getText());
        nv.setChuyenKhoa(
        cboChuyenKhoa.getSelectedItem().toString());
        nv.setBangCap(txtBangCap.getText());
        nv.setChucVu(
        cboChucVu.getSelectedItem().toString());
        nv.setNgayVaoLam(getDate(spNgayVaoLam));
        nv.setCccd(txtCCCD.getText());

        return nv;
    }

    private void loadToForm(){

        int r=table.getSelectedRow();
        if(r<0)return;

        txtTen.setText(
        String.valueOf(model.getValueAt(r,1)));

        cboGT.setSelectedIndex(
        (int)model.getValueAt(r,2));

        spNgaySinh.setValue(
        model.getValueAt(r,3));

        txtDiaChi.setText(
        String.valueOf(model.getValueAt(r,4)));

        txtSDT.setText(
        String.valueOf(model.getValueAt(r,5)));

        txtEmail.setText(
        String.valueOf(model.getValueAt(r,6)));

        cboChuyenKhoa.setSelectedItem(
        model.getValueAt(r,7));

        txtBangCap.setText(
        String.valueOf(model.getValueAt(r,8)));

        cboChucVu.setSelectedItem(
        model.getValueAt(r,9));

        spNgayVaoLam.setValue(
        model.getValueAt(r,10));

        txtCCCD.setText(
        String.valueOf(model.getValueAt(r,11)));
    }

    private void add(){
        bus.insert(getForm());
        loadData();
    }

    private void update(){

        int r=table.getSelectedRow();
        if(r<0)return;

        NhanVien nv=getForm();

        nv.setMaNhanVien(
        (int)model.getValueAt(r,0));

        bus.update(nv);
        loadData();
    }

    private void delete(){

        int r=table.getSelectedRow();
        if(r<0)return;

        bus.delete(
        (int)model.getValueAt(r,0));

        loadData();
    }

    public void show(){
        frame.setVisible(true);
    }
}
