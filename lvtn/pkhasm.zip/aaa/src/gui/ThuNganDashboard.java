package gui;

import config.Session;
import model.TaiKhoan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class ThuNganDashboard extends JFrame {

    private final Color PRIMARY = new Color(52, 152, 219);
    private final Color BG = new Color(240, 242, 245);

    public ThuNganDashboard(){

        setTitle("Dashboard Thu Ngân");
        setSize(1200,700);
        setLocationRelativeTo(null);
        // Đổi thành EXIT_ON_CLOSE để khi tắt Dashboard chính thì ứng dụng đóng hoàn toàn
        setDefaultCloseOperation(EXIT_ON_CLOSE); 

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        setContentPane(root);

        // ================= HEADER =================

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setPreferredSize(new Dimension(0,70));

        JLabel title = new JLabel("HỆ THỐNG THU NGÂN");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI",Font.BOLD,24));
        title.setBorder(new EmptyBorder(0,20,0,0));

        header.add(title,BorderLayout.WEST);

        TaiKhoan tk = Session.currentUser;

        JLabel lbUser = new JLabel(
                "Xin chào: " + tk.getUsername() + "   ");

        lbUser.setForeground(Color.WHITE);
        lbUser.setFont(new Font("Segoe UI",Font.PLAIN,16));

        header.add(lbUser,BorderLayout.EAST);

        root.add(header,BorderLayout.NORTH);

        // ================= MENU =================

        JPanel menu = new JPanel();
        menu.setPreferredSize(new Dimension(260,0));
        menu.setBackground(Color.WHITE);
        menu.setLayout(new BoxLayout(menu,BoxLayout.Y_AXIS));

        menu.add(Box.createVerticalStrut(20));

        JButton btnHoaDon =
                createMenuButton("QUẢN LÝ HÓA ĐƠN");

        JButton btnThanhToan =
                createMenuButton("ĐƠN THUỐC");

        JButton btnLichSu =
                createMenuButton("LỊCH SỬ THANH TOÁN");
        JButton btnLichSuKham =
                createMenuButton("LỊCH SỬ KHÁM BỆNH");

        JButton btnTaiKhoan =
                createMenuButton("TÀI KHOẢN CÁ NHÂN");

        JButton btnLich =
                createMenuButton("LỊCH LÀM VIỆC");

        JButton btnDangXuat =
                createMenuButton("ĐĂNG XUẤT");

        menu.add(btnHoaDon);
        menu.add(Box.createVerticalStrut(10));

        menu.add(btnThanhToan);
        menu.add(Box.createVerticalStrut(10));

        menu.add(btnLichSu);
        menu.add(Box.createVerticalStrut(10));
        menu.add(btnLichSuKham);
        menu.add(Box.createVerticalStrut(10));

        menu.add(btnTaiKhoan);
        menu.add(Box.createVerticalStrut(10));

        menu.add(btnLich);
        menu.add(Box.createVerticalStrut(10));

        menu.add(Box.createVerticalGlue());

        menu.add(btnDangXuat);

        root.add(menu,BorderLayout.WEST);

        // ================= CONTENT =================

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(BG);

        JLabel welcome = new JLabel(
                "MÀN HÌNH QUẢN LÝ THU NGÂN",
                SwingConstants.CENTER);

        welcome.setFont(new Font(
                "Segoe UI",
                Font.BOLD,
                28));

        content.add(welcome,BorderLayout.CENTER);

        root.add(content,BorderLayout.CENTER);

        // =========================================
        // LỊCH SỬ KHÁM BỆNH
        // =========================================

        btnLichSuKham.addActionListener(e -> {
            new LichSuKhamBenhForm1().setVisible(true);
        });
        
        // =========================================
        // QUẢN LÝ HÓA ĐƠN
        // =========================================

        btnHoaDon.addActionListener(e -> {
            new QuanLyHoaDonForm().setVisible(true);
        });

        // =========================================
        // ĐƠN THUỐC
        // =========================================

        btnThanhToan.addActionListener(e -> {
            new ThanhToanForm().setVisible(true);
        });

        // =========================================
        // LỊCH SỬ THANH TOÁN
        // =========================================

        btnLichSu.addActionListener(e -> {
            new LichSuThanhToanForm().setVisible(true);
        });

        // =========================================
        // SỬA CHỔ NÀY: TÀI KHOẢN CÁ NHÂN QUAY LẠI KHÔNG TẮT APP
        // =========================================

        btnTaiKhoan.addActionListener(e -> {
            // Truyền 'this' (ThuNganDashboard) vào constructor để làm parentForm
            new TaiKhoanCaNhanForm().setVisible(true);
 // Ẩn Dashboard hiện tại đi
        });

        // =========================================
        // LỊCH LÀM VIỆC
        // =========================================

        btnLich.addActionListener(e -> {
            new LichLamViecForm().setVisible(true);
        });

        // =========================================
        // ĐĂNG XUẤT
        // =========================================

        btnDangXuat.addActionListener(e -> {

            int confirm =
                    JOptionPane.showConfirmDialog(
                            this,
                            "Bạn có muốn đăng xuất?",
                            "Xác nhận",
                            JOptionPane.YES_NO_OPTION
                    );

            if(confirm == JOptionPane.YES_OPTION){
                dispose();
                new LoginForm().setVisible(true);
            }
        });
    }

    // =========================================
    // STYLE BUTTON
    // =========================================

    private JButton createMenuButton(String text){

        JButton btn = new JButton(text);

        btn.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        50));

        btn.setFocusPainted(false);

        btn.setBackground(
                new Color(245,245,245));

        btn.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15));

        btn.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR));

        btn.setAlignmentX(
                Component.CENTER_ALIGNMENT);

        return btn;
    }

    // =========================================
    // MAIN
    // =========================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ThuNganDashboard().setVisible(true);
        });
    }
}