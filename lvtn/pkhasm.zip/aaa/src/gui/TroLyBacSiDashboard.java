package gui;

import config.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class TroLyBacSiDashboard extends JFrame {

    // ===== BẢNG MÀU GIAO DIỆN PHẲNG HIỆN ĐẠI (FLAT UI) =====
    private final Color BG_WINDOW = new Color(245, 247, 250); 
    private final Color CARD_BG = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 122, 255); 
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);
    private final Color COLOR_LOGOUT = new Color(239, 68, 68); 

    public TroLyBacSiDashboard(){

        setTitle("TRỢ LÝ BÁC SĨ CHUYÊN KHOA");
        setSize(1100, 680); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 20));
        root.setBackground(BG_WINDOW);
        root.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(root);

        // ================= HEADER UI TRỰC QUAN =================
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(15, 25, 10, 25));

        JPanel leftHeader = new JPanel(new GridLayout(2, 1, 0, 4));
        leftHeader.setOpaque(false);
        
        // Sử dụng text thuần thay vì emoji để tránh lỗi hiển thị ở Header
        JLabel lbUser = new JLabel("Xin chào, " + Session.currentUser.getUsername());
        lbUser.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbUser.setForeground(TEXT_MAIN);
        
        JLabel lbRole = new JLabel("Hệ thống quản lý chuyên khoa • Trợ lý Bác sĩ");
        lbRole.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbRole.setForeground(new Color(127, 140, 141));
        
        leftHeader.add(lbUser);
        leftHeader.add(lbRole);

        // Nút đăng xuất dùng ký tự mũi tên chuẩn hệ thống ➜ thay cho ô vuông cửa sổ
        JButton btnLogout = new JButton("Đăng xuất ➜");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setBackground(COLOR_LOGOUT);
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setPreferredSize(new Dimension(130, 38));
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnLogout.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnLogout.setBackground(COLOR_LOGOUT.darker()); }
            @Override public void mouseExited(MouseEvent e) { btnLogout.setBackground(COLOR_LOGOUT); }
        });

        btnLogout.addActionListener(e -> {
            new LoginForm().setVisible(true);
            dispose();
        });

        header.add(leftHeader, BorderLayout.WEST);
        header.add(btnLogout, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // ================= MAIN CONTENT: GRID CARDS =================
        JPanel center = new JPanel(new GridLayout(1, 3, 35, 0));
        center.setBorder(new EmptyBorder(40, 25, 60, 25));
        center.setBackground(BG_WINDOW);

        // Thay thế các Emoji phức tạp bằng các ký hiệu hình học vĩnh viễn không lỗi ô vuông:
        // ✚ (Dấu chữ thập y tế), ✦ (Ngôi sao bốn cánh tài khoản), 📋 (Lịch biểu/Kế hoạch)
        center.add(createCard("✚", "TIẾP NHẬN KHÁM"));
        center.add(createCard("✦", "TÀI KHOẢN CÁ NHÂN"));
        center.add(createCard("📋", "LỊCH LÀM VIỆC"));

        root.add(center, BorderLayout.CENTER);
    }

    private JPanel createCard(String icon, String text) {
        JPanel card = new JPanel(new GridBagLayout()) {
            private Color currentBg = CARD_BG;
            
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getMousePosition() != null) {
                    currentBg = new Color(240, 247, 255);
                } else {
                    currentBg = CARD_BG;
                }
                
                g2.setColor(currentBg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 18, 18));
                g2.dispose();
            }
        };
        card.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.CENTER;

        JLabel lblIcon = new JLabel(icon);
        // QUAN TRỌNG: Đổi phông chữ riêng cho Icon sang Font.DIALOG để ép hệ thống render chuẩn ký hiệu
        lblIcon.setFont(new Font(Font.DIALOG, Font.PLAIN, 52));
        lblIcon.setForeground(PRIMARY_COLOR); // Cho icon có màu xanh dương flat đồng bộ luôn
        gbc.gridy = 0;
        gbc.insets = new java.awt.Insets(0, 0, 15, 0);
        card.add(lblIcon, gbc);

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(TEXT_MAIN);
        gbc.gridy = 1;
        gbc.insets = new java.awt.Insets(0, 0, 0, 0);
        card.add(label, gbc);

        card.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
                label.setForeground(PRIMARY_COLOR);
                card.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e){
                label.setForeground(TEXT_MAIN);
                card.repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e){
                if(text.contains("TIẾP NHẬN")){
                    new TiepNhanKhamForm().setVisible(true);
                    dispose();
                }
                else if(text.contains("TÀI KHOẢN")){
                    new TaiKhoanCaNhanForm().setVisible(true);
                 }
                else if(text.contains("LỊCH")){
                    new LichLamViecForm().setVisible(true);
                 }
            }
        });

        return card;
    }
}