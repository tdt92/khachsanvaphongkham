package gui;

import bus.ThuocBUS;
import model.Thuoc;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import javax.swing.text.*;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;

public class QuanLyThuocForm extends JFrame {

    private JTextField txtTen, txtHoatChat, txtHamLuong, txtDangThuoc,
            txtLoaiThuoc, txtDonVi, txtGiaNhap, txtGiaBan,
            txtNhaSX, txtNuocSX, txtSearch;

    private JTextArea txtGhiChu;
    private JDateChooser dcNSX, dcHSD;

    private JTable table;
    private DefaultTableModel model;

    private ThuocBUS bus = new ThuocBUS();
    private int selectedId = -1;

    // Bảng màu giao diện phẳng hiện đại (Teal & Medical Style)
    private final Color PRIMARY_COLOR = new Color(26, 188, 156);  // Xanh ngọc y tế
    private final Color DARK_BLUE = new Color(44, 62, 80);        // Thanh lịch
    private final Color SUCCESS_COLOR = new Color(39, 174, 96);   // Xanh lá (Thêm)
    private final Color WARNING_COLOR = new Color(241, 196, 15);  // Vàng (Sửa)
    private final Color DANGER_COLOR = new Color(231, 76, 60);    // Đỏ (Xóa)
    private final Color BG_LIGHT = new Color(245, 247, 250);      // Nền xám nhạt

    public QuanLyThuocForm() {
        setTitle("HỆ THỐNG QUẢN LÝ KHO THUỐC LÂM SÀNG");
        setSize(1600, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG_LIGHT);
        root.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(root);

        // Gom cụm phía trên: Gồm Form nhập liệu + Thanh công cụ nút bấm
        JPanel topPanel = new JPanel(new BorderLayout(0, 10));
        topPanel.setBackground(BG_LIGHT);
        topPanel.add(createInputPanel(), BorderLayout.CENTER);
        topPanel.add(createActionToolbar(), BorderLayout.SOUTH);

        root.add(topPanel, BorderLayout.NORTH);
        root.add(createTablePanel(), BorderLayout.CENTER);

        loadData();
    }

    private void onlyNumber(JTextField txt) {
        ((AbstractDocument) txt.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                if (string.matches("\\d*(\\.\\d{0,2})?"))
                    super.insertString(fb, offset, string, attr);
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                if (text.matches("\\d*(\\.\\d{0,2})?"))
                    super.replace(fb, offset, length, text, attrs);
            }
        });
    }

    // Thiết kế lại khu vực nhập liệu bằng GridBagLayout giúp co giãn linh hoạt
    private JPanel createInputPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        
        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 224, 230), 1, true), 
                " THÔNG TIN THUỐC CHI TIẾT "
        );
        border.setTitleFont(new Font("Segoe UI", Font.BOLD, 14));
        border.setTitleColor(DARK_BLUE);
        p.setBorder(BorderFactory.createCompoundBorder(border, new EmptyBorder(15, 15, 15, 15)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.weightx = 1.0;

        // Khởi tạo các Component
        txtTen = new JTextField();
        txtHoatChat = new JTextField();
        txtHamLuong = new JTextField();
        txtDangThuoc = new JTextField();
        txtLoaiThuoc = new JTextField();
        txtDonVi = new JTextField();
        txtGiaNhap = new JTextField();
        txtGiaBan = new JTextField();
        txtNhaSX = new JTextField();
        txtNuocSX = new JTextField();
        txtGhiChu = new JTextArea(3, 20);
        txtGhiChu.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);

        onlyNumber(txtGiaNhap);
        onlyNumber(txtGiaBan);

        dcNSX = new JDateChooser();
        dcNSX.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        dcHSD = new JDateChooser();
        dcHSD.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Đặt font Segoe UI đồng bộ cho toàn bộ JTextField
        Component[] comps = {txtTen, txtHoatChat, txtHamLuong, txtDangThuoc, txtLoaiThuoc, txtDonVi, txtGiaNhap, txtGiaBan, txtNhaSX, txtNuocSX};
        for (Component c : comps) {
            c.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            ((JTextField) c).setPreferredSize(new Dimension(150, 32));
        }

        // Hàng 1
        addGrid(p, new JLabel("Tên thuốc *"), gbc, 0, 0, 0.1);
        addGrid(p, txtTen, gbc, 1, 0, 0.23);
        addGrid(p, new JLabel("Hoạt chất"), gbc, 2, 0, 0.1);
        addGrid(p, txtHoatChat, gbc, 3, 0, 0.23);
        addGrid(p, new JLabel("Hàm lượng"), gbc, 4, 0, 0.1);
        addGrid(p, txtHamLuong, gbc, 5, 0, 0.23);

        // Hàng 2
        addGrid(p, new JLabel("Dạng thuốc"), gbc, 0, 1, 0.1);
        addGrid(p, txtDangThuoc, gbc, 1, 1, 0.23);
        addGrid(p, new JLabel("Loại thuốc"), gbc, 2, 1, 0.1);
        addGrid(p, txtLoaiThuoc, gbc, 3, 1, 0.23);
        addGrid(p, new JLabel("Đơn vị tính"), gbc, 4, 1, 0.1);
        addGrid(p, txtDonVi, gbc, 5, 1, 0.23);

        // Hàng 3
        addGrid(p, new JLabel("Giá nhập (VNĐ) *"), gbc, 0, 2, 0.1);
        addGrid(p, txtGiaNhap, gbc, 1, 2, 0.23);
        addGrid(p, new JLabel("Giá bán (VNĐ) *"), gbc, 2, 2, 0.1);
        addGrid(p, txtGiaBan, gbc, 3, 2, 0.23);
        addGrid(p, new JLabel("Ngày sản xuất *"), gbc, 4, 2, 0.1);
        addGrid(p, dcNSX, gbc, 5, 2, 0.23);

        // Hàng 4
        addGrid(p, new JLabel("Hạn sử dụng *"), gbc, 0, 3, 0.1);
        addGrid(p, dcHSD, gbc, 1, 3, 0.23);
        addGrid(p, new JLabel("Nhà sản xuất"), gbc, 2, 3, 0.1);
        addGrid(p, txtNhaSX, gbc, 3, 3, 0.23);
        addGrid(p, new JLabel("Nước sản xuất"), gbc, 4, 3, 0.1);
        addGrid(p, txtNuocSX, gbc, 5, 3, 0.23);

        // Hàng 5 - Ô Ghi chú chiếm hết không gian rộng phía dưới
        addGrid(p, new JLabel("Ghi chú"), gbc, 0, 4, 0.1);
        gbc.gridwidth = 5;
        JScrollPane scrollGhiChu = new JScrollPane(txtGhiChu);
        scrollGhiChu.setPreferredSize(new Dimension(150, 50));
        addGrid(p, scrollGhiChu, gbc, 1, 4, 0.9);

        return p;
    }

    private void addGrid(JPanel p, Component c, GridBagConstraints gbc, int x, int y, double wx) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.weightx = wx;
        if (c instanceof JLabel) {
            c.setFont(new Font("Segoe UI", Font.BOLD, 13));
            ((JLabel) c).setForeground(DARK_BLUE);
        }
        p.add(c, gbc);
        gbc.gridwidth = 1; // reset
    }

    // Tách riêng nhóm nút xử lý và Tìm kiếm thành một thanh công cụ nằm ngang phẳng đẹp
    private JPanel createActionToolbar() {
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(BG_LIGHT);
        toolbar.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel leftButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftButtons.setBackground(BG_LIGHT);

        JButton btnThem = createStyledButton("Thêm Mới", SUCCESS_COLOR, Color.WHITE);
        JButton btnSua = createStyledButton("Cập Nhật", WARNING_COLOR, DARK_BLUE);
        JButton btnXoa = createStyledButton("Xóa Thuốc", DANGER_COLOR, Color.WHITE);
        JButton btnMoi = createStyledButton("Làm Mới Trống", new Color(149, 165, 166), Color.WHITE);
        JButton btnThongKe = createStyledButton("Thống Kê Theo Loại", PRIMARY_COLOR, Color.WHITE);

        btnThem.addActionListener(e -> add());
        btnSua.addActionListener(e -> update());
        btnXoa.addActionListener(e -> delete());
        btnMoi.addActionListener(e -> clear());
        btnThongKe.addActionListener(e -> thongKe());

        leftButtons.add(btnThem);
        leftButtons.add(btnSua);
        leftButtons.add(btnXoa);
        leftButtons.add(btnMoi);
        leftButtons.add(btnThongKe);

        // Cụm tìm kiếm nhanh đặt gọn bên góc phải thanh công cụ
        JPanel rightSearch = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightSearch.setBackground(BG_LIGHT);
        
        JLabel lblSearch = new JLabel("Tìm kiếm nhanh:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setForeground(DARK_BLUE);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setPreferredSize(new Dimension(280, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(PRIMARY_COLOR, 1, true),
                BorderFactory.createEmptyBorder(0, 8, 0, 8)
        ));

        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) { search(); }
            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) { search(); }
            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) { search(); }
        });

        rightSearch.add(lblSearch);
        rightSearch.add(txtSearch);

        toolbar.add(leftButtons, BorderLayout.WEST);
        toolbar.add(rightSearch, BorderLayout.EAST);
        return toolbar;
    }

    private JButton createStyledButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(150, 36));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(bg.darker(), 1, true));
        return btn;
    }

    private JPanel createTablePanel() {
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(Color.WHITE);

        model = new DefaultTableModel();
        table = new JTable(model);
        model.setColumnIdentifiers(new String[]{
                "Mã", "Tên thuốc", "Hoạt chất", "Hàm lượng", "Dạng",
                "Loại", "ĐVT", "Giá nhập (đ)", "Giá bán (đ)",
                "NSX", "HSD", "Nhà SX", "Nước SX", "Ghi chú"
        });

        // Định dạng Table theo chuẩn lưới UI hiện đại
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setSelectionBackground(new Color(224, 242, 241));
        table.setSelectionForeground(DARK_BLUE);
        table.setGridColor(new Color(230, 235, 240));
        table.setShowVerticalLines(false);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(DARK_BLUE);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(100, 38));

        // Căn lề số liệu cột tiền tệ
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(7).setCellRenderer(rightRenderer);
        table.getColumnModel().getColumn(8).setCellRenderer(rightRenderer);

        // Giữ nguyên logic tô màu cảnh báo HSD nhưng dịu mắt hơn
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Căn lề số liệu cột tiền tệ lồng ghép trong Custom Renderer để tránh mất định dạng màu dòng
                if (column == 7 || column == 8) {
                    setHorizontalAlignment(SwingConstants.RIGHT);
                } else if (column == 0 || column == 3 || column == 6) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }

                Object hsdObj = table.getModel().getValueAt(row, 10);
                if (hsdObj instanceof Date) {
                    Date hsd = (Date) hsdObj;
                    long days = (hsd.getTime() - System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
                    if (days <= 30) {
                        c.setBackground(new Color(255, 230, 230)); // Đỏ hồng phấn nhẹ nhàng cảnh báo cận hạn
                        c.setForeground(new Color(192, 41, 43));
                    } else {
                        c.setBackground(isSelected ? table.getSelectionBackground() : Color.WHITE);
                        c.setForeground(isSelected ? table.getSelectionForeground() : DARK_BLUE);
                    }
                } else {
                    c.setBackground(isSelected ? table.getSelectionBackground() : Color.WHITE);
                    c.setForeground(isSelected ? table.getSelectionForeground() : DARK_BLUE);
                }
                return c;
            }
        });

        table.getSelectionModel().addListSelectionListener(e -> fillForm());

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 230)));
        scroll.getViewport().setBackground(Color.WHITE);
        container.add(scroll, BorderLayout.CENTER);

        return container;
    }

    private void thongKe() {
        Map<String, Integer> map = new HashMap<>();
        for (Thuoc t : bus.getAll()) {
            String loai = t.getLoaiThuoc() == null || t.getLoaiThuoc().trim().isEmpty() ? "Khác" : t.getLoaiThuoc();
            map.put(loai, map.getOrDefault(loai, 0) + 1);
        }

        StringBuilder sb = new StringBuilder("📊 SỐ LIỆU THỐNG KÊ PHÂN LOẠI THUỐC:\n\n");
        for (String key : map.keySet()) {
            sb.append(" ❖ ").append(key).append(": ").append(map.get(key)).append(" sản phẩm\n");
        }

        JTextArea area = new JTextArea(sb.toString());
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setEditable(false);
        area.setBackground(BG_LIGHT);
        area.setBorder(new EmptyBorder(10, 10, 10, 10));

        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Thống kê kho", JOptionPane.INFORMATION_MESSAGE);
    }

    private boolean validateForm() {
        if (txtTen.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên thuốc bắt buộc không được để trống!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtGiaNhap.getText().isEmpty() || txtGiaBan.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ giá nhập và giá bán buôn!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (dcNSX.getDate() == null || dcHSD.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Thời gian Sản xuất & Hạn sử dụng không hợp lệ!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (dcHSD.getDate().before(dcNSX.getDate())) {
            JOptionPane.showMessageDialog(this, "Hạn sử dụng sai lệch (Phải lớn hơn ngày sản xuất)!", "Lỗi dữ liệu", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void add() {
        if (!validateForm()) return;
        bus.insert(getForm());
        loadData();
        clear();
    }

    private void update() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một dòng thuốc từ bảng để cập nhật!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (!validateForm()) return;
        Thuoc t = getForm();
        t.setMaThuoc(selectedId);
        bus.update(t);
        loadData();
        clear();
    }

    private void delete() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng sản phẩm cần xóa khỏi hệ thống!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận xóa thuốc mã số #" + selectedId + " ra khỏi danh mục?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            bus.delete(selectedId);
            loadData();
            clear();
        }
    }

    private void search() {
        model.setRowCount(0);
        DecimalFormat df = new DecimalFormat("#,###");
        for (Thuoc t : bus.search(txtSearch.getText())) {
            model.addRow(new Object[]{
                    t.getMaThuoc(), t.getTenThuoc(), t.getHoatChat(), t.getHamLuong(), t.getDangThuoc(),
                    t.getLoaiThuoc(), t.getDonViTinh(), df.format(t.getDonGiaNhap()), df.format(t.getDonGiaBan()),
                    t.getNgaySanXuat(), t.getHanSuDung(), t.getNhaSanXuat(), t.getNuocSanXuat(), t.getGhiChu()
            });
        }
    }

    private Thuoc getForm() {
        Thuoc t = new Thuoc();
        t.setTenThuoc(txtTen.getText().trim());
        t.setHoatChat(txtHoatChat.getText().trim());
        t.setHamLuong(txtHamLuong.getText().trim());
        t.setDangThuoc(txtDangThuoc.getText().trim());
        t.setLoaiThuoc(txtLoaiThuoc.getText().trim());
        t.setDonViTinh(txtDonVi.getText().trim());
        t.setDonGiaNhap(new BigDecimal(txtGiaNhap.getText()));
        t.setDonGiaBan(new BigDecimal(txtGiaBan.getText()));
        t.setNgaySanXuat(new Date(dcNSX.getDate().getTime()));
        t.setHanSuDung(new Date(dcHSD.getDate().getTime()));
        t.setNhaSanXuat(txtNhaSX.getText().trim());
        t.setNuocSanXuat(txtNuocSX.getText().trim());
        t.setGhiChu(txtGhiChu.getText().trim());
        return t;
    }

    private void loadData() {
        model.setRowCount(0);
        DecimalFormat df = new DecimalFormat("#,###");
        List<Thuoc> list = bus.getAll();
        if (list != null) {
            for (Thuoc t : list) {
                model.addRow(new Object[]{
                        t.getMaThuoc(), t.getTenThuoc(), t.getHoatChat(), t.getHamLuong(), t.getDangThuoc(),
                        t.getLoaiThuoc(), t.getDonViTinh(), df.format(t.getDonGiaNhap()), df.format(t.getDonGiaBan()),
                        t.getNgaySanXuat(), t.getHanSuDung(), t.getNhaSanXuat(), t.getNuocSanXuat(), t.getGhiChu()
                });
            }
        }
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        try {
            selectedId = Integer.parseInt(model.getValueAt(row, 0).toString());
            txtTen.setText(extractString(model.getValueAt(row, 1)));
            txtHoatChat.setText(extractString(model.getValueAt(row, 2)));
            txtHamLuong.setText(extractString(model.getValueAt(row, 3)));
            txtDangThuoc.setText(extractString(model.getValueAt(row, 4)));
            txtLoaiThuoc.setText(extractString(model.getValueAt(row, 5)));
            txtDonVi.setText(extractString(model.getValueAt(row, 6)));

            // Khôi phục lại chuỗi số gốc sạch để tính toán (bỏ dấu phân cách hàng nghìn)
            txtGiaNhap.setText(model.getValueAt(row, 7).toString().replace(",", ""));
            txtGiaBan.setText(model.getValueAt(row, 8).toString().replace(",", ""));

            dcNSX.setDate((java.util.Date) model.getValueAt(row, 9));
            dcHSD.setDate((java.util.Date) model.getValueAt(row, 10));
            txtNhaSX.setText(extractString(model.getValueAt(row, 11)));
            txtNuocSX.setText(extractString(model.getValueAt(row, 12)));
            txtGhiChu.setText(extractString(model.getValueAt(row, 13)));
        } catch (Exception e) {
            // Tránh lỗi ép kiểu dữ liệu null trống
        }
    }

    private String extractString(Object obj) {
        return obj == null ? "" : obj.toString().trim();
    }

    private void clear() {
        selectedId = -1;
        table.clearSelection();
        txtTen.setText(""); txtHoatChat.setText(""); txtHamLuong.setText("");
        txtDangThuoc.setText(""); txtLoaiThuoc.setText(""); txtDonVi.setText("");
        txtGiaNhap.setText(""); txtGiaBan.setText("");
        dcNSX.setDate(null); dcHSD.setDate(null);
        txtNhaSX.setText(""); txtNuocSX.setText(""); txtGhiChu.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new QuanLyThuocForm().setVisible(true));
    }
}