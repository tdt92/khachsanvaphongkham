package gui;

import bus.HoaDonBUS;
import model.HoaDon;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class LichSuThanhToanForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    private HoaDonBUS bus =
            new HoaDonBUS();

    public LichSuThanhToanForm(){

        setTitle("Lịch Sử Thanh Toán");
        setSize(1100,650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root =
                new JPanel(new BorderLayout());

        setContentPane(root);

        // ================= TITLE =================

        JLabel title = new JLabel(
                "LỊCH SỬ THANH TOÁN",
                SwingConstants.CENTER);

        title.setFont(new Font(
                "Segoe UI",
                Font.BOLD,
                28));

        title.setBorder(
                new EmptyBorder(15,0,15,0));

        root.add(title,BorderLayout.NORTH);

        // ================= TABLE =================

        model = new DefaultTableModel(
                new String[]{
                        "Mã HD",
                        "Mã Phiếu",
                        "Thu Ngân",
                        "Tổng Tiền",
                        "Ngày Thanh Toán",
                        "Trạng Thái"
                },0
        );

        table = new JTable(model);

        table.setRowHeight(30);

        JScrollPane scroll =
                new JScrollPane(table);

        root.add(scroll,BorderLayout.CENTER);

        // ================= BOTTOM =================

        JPanel bottom = new JPanel();

        JButton btnRefresh =
                new JButton("LÀM MỚI");

        JButton btnChiTiet =
                new JButton("CHI TIẾT");

        JButton btnDong =
                new JButton("ĐÓNG");

        bottom.add(btnRefresh);
        bottom.add(btnChiTiet);
        bottom.add(btnDong);

        root.add(bottom,BorderLayout.SOUTH);

        // ================= EVENT =================

        btnRefresh.addActionListener(e -> loadData());

        btnDong.addActionListener(e -> dispose());

        btnChiTiet.addActionListener(e -> openChiTiet());

        // ================= LOAD =================

        loadData();
    }

    private void loadData(){

        model.setRowCount(0);

        DecimalFormat df =
                new DecimalFormat("#,###");

        SimpleDateFormat sdf =
                new SimpleDateFormat(
                        "dd/MM/yyyy HH:mm");

        List<HoaDon> list =
                bus.getDaThanhToan();

        for(HoaDon hd : list){

            model.addRow(new Object[]{

                    hd.getMaHoaDon(),

                    hd.getMaPhieuKham(),

                    hd.getMaNhanVien(),

                    df.format(hd.getTongTien())
                            + " VNĐ",

                    hd.getNgayThanhToan()==null
                            ? ""
                            : sdf.format(
                                    hd.getNgayThanhToan()),

                    hd.getTrangThai()
            });
        }
    }

    private void openChiTiet(){

        int row = table.getSelectedRow();

        if(row == -1){

            JOptionPane.showMessageDialog(this,
                    "Chọn hóa đơn!");

            return;
        }

        int maHD = Integer.parseInt(
                model.getValueAt(row,0)
                        .toString());

        new ChiTietHoaDonForm(maHD)
                .setVisible(true);
    }
}