package gui;

import config.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class LeTanDashboard extends JFrame {

    // Hệ màu phẳng cao cấp (Modern Flat UI Colors)
    private final Color BG = new Color(245, 247, 250);         // Nền xám trắng nhạt chuẩn y tế
    private final Color CARD = Color.WHITE;                     // Nền thẻ trắng tinh khiết
    private final Color PRIMARY = new Color(0, 122, 255);       // Xanh dương Modern iOS
    private final Color TEXT_DARK = new Color(44, 62, 80);      // Màu chữ tối dễ nhìn
    private final Color BORDER_COLOR = new Color(225, 230, 238); // Màu viền mờ tinh tế

    public LeTanDashboard(){
        setTitle("LỄ TÂN DASHBOARD");
        setSize(1050, 680); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(25, 35, 25, 35)); 
        setContentPane(root);

        // ===== MODERN HEADER PANEL =====
        JPanel header = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                // Đổ nền trắng bo góc cho khu vực Header chuẩn đồ họa Java 2D
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(15, 25, 15, 25));

        JLabel lbTitle = new JLabel("Xin chào LỄ TÂN: " + Session.currentUser.getUsername().toUpperCase());
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbTitle.setForeground(TEXT_DARK);

        // Nút đăng xuất dạng phẳng thanh lịch
        JButton btnLogout = new JButton("Đăng xuất");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setOpaque(true);
        btnLogout.setBackground(new Color(254, 242, 242)); 
        btnLogout.setForeground(new Color(239, 68, 68));    
        btnLogout.setPreferredSize(new Dimension(110, 36));
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnLogout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLogout.setBackground(new Color(252, 228, 228));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLogout.setBackground(new Color(254, 242, 242));
            }
        });

        btnLogout.addActionListener(e -> {
            new LoginForm().setVisible(true);
            dispose();
        });

        header.add(lbTitle, BorderLayout.WEST);
        header.add(btnLogout, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // ===== MAIN GRID =====
        JPanel center = new JPanel(new GridLayout(2, 2, 30, 30));
        center.setOpaque(false); 
        center.setBorder(new EmptyBorder(25, 0, 10, 0));

        center.add(createCard("📝  ĐĂNG KÝ KHÁM"));
        center.add(createCard("👥  QUẢN LÝ BỆNH NHÂN"));
        center.add(createCard("👤  TÀI KHOẢN CÁ NHÂN"));
        center.add(createCard("📜  LỊCH SỬ HOẠT ĐỘNG"));

        root.add(center, BorderLayout.CENTER);
    }

    // Định nghĩa một lớp con kế thừa từ JPanel để quản lý trạng thái hover tường minh
    private class CardPanel extends JPanel {
        private boolean isHovered = false;

        public CardPanel() {
            setLayout(new GridBagLayout());
            setOpaque(false);
        }

        public void setHovered(boolean hovered) {
            this.isHovered = hovered;
            repaint(); // Vẽ lại giao diện khi trạng thái hover thay đổi
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            // Khử răng cưa giúp nét vẽ bo tròn mượt mà
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Đổi màu nền mượt mà khi hover
            g2.setColor(isHovered ? new Color(248, 251, 255) : CARD);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));

            // Đổi màu viền dựa theo trạng thái hover
            g2.setColor(isHovered ? PRIMARY : BORDER_COLOR);
            g2.setStroke(new BasicStroke(isHovered ? 1.8f : 1.0f));
            g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
            
            g2.dispose();
        }
    }

    private JPanel createCard(String text) {
        CardPanel card = new CardPanel();

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(TEXT_DARK); 

        card.add(label);

        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setHovered(true);
                label.setForeground(PRIMARY); 
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setHovered(false);
                label.setForeground(TEXT_DARK);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (text.contains("ĐĂNG KÝ KHÁM")) {
                    new DangKyKhamForm().setVisible(true);
                 } else if (text.contains("QUẢN LÝ BỆNH NHÂN")) {
                    new QuanLyBenhNhanForm().setVisible(true);
                 } else if (text.contains("TÀI KHOẢN CÁ NHÂN")) {
                    new TaiKhoanCaNhanForm().setVisible(true);
                } else if (text.contains("LỊCH SỬ")) {
                    new LichSuKhamBenhForm().setVisible(true);
                }
            }
        });

        return card;
    }
}