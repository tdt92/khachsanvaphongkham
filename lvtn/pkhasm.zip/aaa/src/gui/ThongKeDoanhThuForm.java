package gui;

import dao.HoaDonDAO;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;

public class ThongKeDoanhThuForm extends JFrame {

    private JComboBox<String> cbLoai;

    private JDateChooser dateChooser;

    private JSpinner monthSpinner;

    private JSpinner yearSpinner;
    private JTable table;

    private DefaultTableModel model;

    private JLabel lbTong;

    HoaDonDAO dao =
            new HoaDonDAO();

    public ThongKeDoanhThuForm(){

        setTitle("THỐNG KÊ DOANH THU");

        setSize(900,600);

        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10,10));

        // =========================================
        // TOP
        // =========================================

        JPanel top =
                new JPanel();

        cbLoai =
                new JComboBox<>(
                        new String[]{
                                "Ngày",
                                "Tháng",
                                "Năm"
                        }
                );
     // =========================================
     // DATE PICKER
     // =========================================

     dateChooser =
             new JDateChooser();

     dateChooser.setDateFormatString(
             "dd/MM/yyyy"
     );

     // =========================================
     // MONTH PICKER
     // =========================================

     monthSpinner =
             new JSpinner(
                     new SpinnerDateModel()
             );

     JSpinner.DateEditor monthEditor =
             new JSpinner.DateEditor(
                     monthSpinner,
                     "MM/yyyy"
             );

     monthSpinner.setEditor(monthEditor);

     // =========================================
     // YEAR PICKER
     // =========================================

     yearSpinner =
             new JSpinner(
                     new SpinnerNumberModel(
                             2026,
                             2000,
                             2100,
                             1
                     )
             );

        JButton btnThongKe =
                new JButton("Thống kê");

        top.add(new JLabel("Loại"));

        top.add(cbLoai);

        top.add(new JLabel("Giá trị"));

        top.add(new JLabel("Ngày"));

        top.add(dateChooser);

        top.add(new JLabel("Tháng"));

        top.add(monthSpinner);

        top.add(new JLabel("Năm"));

        top.add(yearSpinner);
        top.add(btnThongKe);

        add(top,BorderLayout.NORTH);

        // =========================================
        // TABLE
        // =========================================

        model =
                new DefaultTableModel(
                        new String[]{
                                "Mã HD",
                                "Ngày thanh toán",
                                "Thu ngân",
                                "Tổng tiền"
                        },
                        0
                );

        table =
                new JTable(model);

        add(
                new JScrollPane(table),
                BorderLayout.CENTER
        );

        // =========================================
        // FOOTER
        // =========================================

        JPanel bottom =
                new JPanel(new FlowLayout(
                        FlowLayout.RIGHT
                ));

        lbTong =
                new JLabel("Tổng doanh thu: 0 VNĐ");

        lbTong.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        18
                )
        );

        bottom.add(lbTong);

        add(bottom,BorderLayout.SOUTH);

        // =========================================
        // EVENT
        // =========================================

        btnThongKe.addActionListener(
                e -> thongKe()
        );
    }

    // =============================================
    // THỐNG KÊ
    // =============================================

    private void thongKe(){

        model.setRowCount(0);

        String loai =
                cbLoai.getSelectedItem()
                        .toString();

        String value = "";

        SimpleDateFormat sdfNgay =
                new SimpleDateFormat("yyyy-MM-dd");

        SimpleDateFormat sdfThang =
                new SimpleDateFormat("MM/yyyy");

        if(loai.equals("Ngày")){

            Date d =
                    dateChooser.getDate();

            if(d == null){

                JOptionPane.showMessageDialog(
                        this,
                        "Chọn ngày!"
                );

                return;
            }

            value =
                    sdfNgay.format(d);

        }else if(loai.equals("Tháng")){

            Date d =
                    (Date) monthSpinner.getValue();

            value =
                    sdfThang.format(d);

        }else{

            value =
                    yearSpinner.getValue()
                            .toString();
        }

        java.util.List<Object[]> list =
                dao.thongKeDoanhThu(
                        loai,
                        value
                );

        java.math.BigDecimal tong =
                java.math.BigDecimal.ZERO;

        for(Object[] row : list){

            model.addRow(row);

            tong =
                    tong.add(
                            (java.math.BigDecimal) row[3]
                    );
        }

        lbTong.setText(
                "Tổng doanh thu: "
                        + tong
                        + " VNĐ"
        );
    }
}