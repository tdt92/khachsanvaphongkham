package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KyThuatVienCDHADashboard extends JFrame {

    // ===== BẢNG MÀU MEDICAL DASHBOARD CHUẨN UX =====
    private final Color BG_WINDOW = new Color(240, 244, 248);       // Nền xám xanh dịu mát
    private final Color CARD_BG = Color.WHITE;                      // Nền thẻ trắng tinh tế
    private final Color PRIMARY_COLOR = new Color(0, 122, 255);     // Xanh chủ đạo (Medical Blue)
    private final Color TEXT_MAIN = new Color(44, 62, 80);          // Chữ chính xám đậm
    private final Color TEXT_SUB = new Color(127, 140, 141);        // Chữ phụ xám nhạt
    private final Color BORDER_DEFAULT = new Color(220, 224, 230);  // Viền mặc định

    public KyThuatVienCDHADashboard() {
        setTitle("HỆ THỐNG QUẢN LÝ - KỸ THUẬT VIÊN CHẨN ĐOÁN HÌNH ẢNH");
        setSize(1200, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Sử dụng BorderLayout cho khung lớn để tách biệt Header và Content
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(BG_WINDOW);
        setContentPane(rootPanel);

        // ================= 1. HEADER PANEL (Thanh tiêu đề trên cùng) =================
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DEFAULT), // Đường kẻ đáy thanh lịch
                new EmptyBorder(15, 40, 15, 40)
        ));

        // Tiêu đề bên trái
        JLabel lblAppTitle = new JLabel("HỆ THỐNG Y TẾ SỐ - KHOA CHẨN ĐOÁN HÌNH ẢNH");
        lblAppTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblAppTitle.setForeground(PRIMARY_COLOR);
        headerPanel.add(lblAppTitle, BorderLayout.WEST);

        // Thông tin phân quyền bên phải
        JLabel lblUserRole = new JLabel("👤 Vai trò: Kỹ thuật viên viên chức");
        lblUserRole.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblUserRole.setForeground(TEXT_SUB);
        headerPanel.add(lblUserRole, BorderLayout.EAST);

        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // ================= 2. MAIN CONTENT (Khu vực các thẻ chức năng) =================
        JPanel mainContent = new JPanel(new GridLayout(1, 3, 30, 0)); // Tăng khoảng cách giữa các thẻ thành 30px
        mainContent.setOpaque(false); // Để lộ nền xám xanh phía dưới
        mainContent.setBorder(new EmptyBorder(50, 40, 60, 40));      // Tạo khoảng trống bao quanh thoáng đãng

        // Thêm các thẻ với Icon, Tiêu đề và Mô tả chi tiết
        mainContent.add(createCard(
                "🔬", 
                "TIẾN HÀNH KHÁM", 
                "Quản lý danh sách chờ, tiếp nhận bệnh nhân và cập nhật kết quả chụp X-Ray, MRI, CT-Scan."
        ));

        mainContent.add(createCard(
                "👤", 
                "TÀI KHOẢN CÁ NHÂN", 
                "Xem thông tin hồ sơ nhân sự, lịch sử công tác và thay đổi mật khẩu hệ thống."
        ));

        mainContent.add(createCard(
                "📅", 
                "LỊCH LÀM VIỆC", 
                "Theo dõi lịch trực ca, lịch phân công công tác tại các phòng chức năng theo tuần."
        ));

        rootPanel.add(mainContent, BorderLayout.CENTER);
    }

    // Hàm tạo thẻ Card nâng cao với cấu trúc UI/UX hiện đại
    private JPanel createCard(String icon, String title, String description) {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(CARD_BG);
        // Tạo đường viền phức hợp để tạo khoảng đệm (padding) bên trong thẻ
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DEFAULT, 1),
                new EmptyBorder(30, 25, 30, 25)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        // 1. Icon đại diện lớn
        JLabel lblIcon = new JLabel(icon, SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI", Font.PLAIN, 50));
        gbc.gridy = 0;
        gbc.weighty = 0.3;
        card.add(lblIcon, gbc);

        // 2. Tiêu đề thẻ (Viết hoa, Đậm)
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(TEXT_MAIN);
        gbc.gridy = 1;
        gbc.weighty = 0.1;
        gbc.insets = new Insets(15, 0, 10, 0);
        card.add(lblTitle, gbc);

        // 3. Đoạn mô tả ngắn (Giúp người dùng hiểu rõ chức năng trước khi bấm)
        // Dùng thẻ <html> để chữ tự động xuống dòng khi co giãn màn hình
        JLabel lblDesc = new JLabel("<html><center>" + description + "</center></html>", SwingConstants.CENTER);
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblDesc.setForeground(TEXT_SUB);
        gbc.gridy = 2;
        gbc.weighty = 0.4;
        gbc.insets = new Insets(0, 0, 0, 0);
        card.add(lblDesc, gbc);

        // ================= HIỆU ỨNG TƯƠNG TÁC CHUỘT (HOVER EFFECT) =================
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Giữ nguyên hoàn toàn logic phân nhánh form gốc của bạn
                if (title.contains("TIẾN HÀNH KHÁM")) {
                    new DanhSachChoCDHAForm().setVisible(true);
                } else if (title.contains("TÀI KHOẢN")) {
                    new TaiKhoanCaNhanForm().setVisible(true);
                } else if (title.contains("LỊCH")) {
                    new LichLamViecForm().setVisible(true);
                    dispose();
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                card.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Đổi con trỏ thành hình bàn tay chọn
                card.setBackground(new Color(250, 252, 255));   // Nền chuyển sang xanh dương cực nhẹ
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(PRIMARY_COLOR, 1, true), // Viền chuyển sang màu xanh đậm nổi bật
                        new EmptyBorder(30, 25, 30, 25)
                ));
                lblTitle.setForeground(PRIMARY_COLOR); // Chữ tiêu đề sáng lên theo màu chủ đạo
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBackground(CARD_BG); // Trả lại trạng thái ban đầu
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DEFAULT, 1),
                        new EmptyBorder(30, 25, 30, 25)
                ));
                lblTitle.setForeground(TEXT_MAIN);
            }
        });

        return card;
    }
}