package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DuocSiDashboard extends JFrame {

    // ===== BỘ MÀU FLAT UI ĐỒNG BỘ VỚI THANHTOANFORM =====
    private final Color PRIMARY = new Color(41, 128, 185);     // Xanh biển thương hiệu
    private final Color BG_SIDEBAR = new Color(44, 62, 80);    // Xám xanh đậm phong cách Dark Sidebar
    private final Color BG_WINDOW = new Color(240, 244, 248);  // Nền nội dung sáng dịu mắt
    private final Color TEXT_MAIN = new Color(44, 62, 80);     // Chữ chính đậm
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public DuocSiDashboard() {
        setTitle("HỆ THỐNG QUẢN LÝ PHÒNG KHÁM - DƯỢC SĨ");
        setSize(1280, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Layout tổng thể chia làm 2 phần: Trái (Menu) - Phải (Nội dung)
        JPanel mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // =====================================
        // PANEL BÊN TRÁI: SIDEBAR MENU CARD
        // =====================================
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(BG_SIDEBAR);
        sidebar.setPreferredSize(new Dimension(280, 0));

        // Header của Sidebar
        JPanel sidebarHeader = new JPanel(new GridLayout(2, 1, 0, 4));
        sidebarHeader.setOpaque(false);
        sidebarHeader.setBorder(new EmptyBorder(30, 20, 30, 20));

        JLabel lblRole = new JLabel("DƯỢC SĨ LÂM SÀNG", SwingConstants.LEFT);
        lblRole.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblRole.setForeground(new Color(52, 152, 219)); // Màu xanh sáng tạo điểm nhấn

        JLabel lblAppName = new JLabel("MEDICARE SYSTEM", SwingConstants.LEFT);
        lblAppName.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblAppName.setForeground(Color.WHITE);

        sidebarHeader.add(lblRole);
        sidebarHeader.add(lblAppName);
        sidebar.add(sidebarHeader, BorderLayout.NORTH);

        // Các nút điều hướng trong Sidebar (Dùng BoxLayout xếp chồng hàng dọc)
        JPanel sidebarMenu = new JPanel();
        sidebarMenu.setOpaque(false);
        sidebarMenu.setLayout(new BoxLayout(sidebarMenu, BoxLayout.Y_AXIS));
        sidebarMenu.setBorder(new EmptyBorder(0, 15, 0, 15));

        JButton btnThuoc = createMenuButton("📦  QUẢN LÝ THUỐC");
        JButton btnPhieuThuoc = createMenuButton("📄  XEM & CẤP THUỐC");
        JButton btnTaiKhoan = createMenuButton("👤  TÀI KHOẢN CÁ NHÂN");
        JButton btnLich = createMenuButton("📅  LỊCH LÀM VIỆC");

        sidebarMenu.add(btnThuoc);
        sidebarMenu.add(Box.createVerticalStrut(10)); // Khoảng cách giữa các nút
        sidebarMenu.add(btnPhieuThuoc);
        sidebarMenu.add(Box.createVerticalStrut(10));
        sidebarMenu.add(btnTaiKhoan);
        sidebarMenu.add(Box.createVerticalStrut(10));
        sidebarMenu.add(btnLich);

        sidebar.add(sidebarMenu, BorderLayout.CENTER);

        // Footer của Sidebar chứa nút đăng xuất
        JPanel sidebarFooter = new JPanel(new BorderLayout());
        sidebarFooter.setOpaque(false);
        sidebarFooter.setBorder(new EmptyBorder(20, 15, 20, 15));
        JButton btnLogout = createMenuButton("🚪  ĐĂNG XUẤT");
        btnLogout.setForeground(new Color(231, 76, 60)); // Chữ màu đỏ báo hiệu loại trừ
        sidebarFooter.add(btnLogout, BorderLayout.SOUTH);
        sidebar.add(sidebarFooter, BorderLayout.SOUTH);

        mainPanel.add(sidebar, BorderLayout.WEST);

        // =====================================
        // PANEL BÊN PHẢI: WORKSPACE & CARDS
        // =====================================
        JPanel contentPanel = new JPanel(new BorderLayout(0, 20));
        contentPanel.setBackground(BG_WINDOW);
        contentPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        // Top Content: Lời chào và Thời gian thực tế
        JPanel topContent = new JPanel(new BorderLayout());
        topContent.setOpaque(false);

        JLabel lblWelcome = new JLabel("Xin chào, Dược sĩ!", SwingConstants.LEFT);
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblWelcome.setForeground(TEXT_MAIN);

        // Hiển thị ngày giờ hệ thống tự động
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy");
        JLabel lblDate = new JLabel(dtf.format(LocalDateTime.now()), SwingConstants.RIGHT);
        lblDate.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        lblDate.setForeground(new Color(127, 140, 141));

        topContent.add(lblWelcome, BorderLayout.WEST);
        topContent.add(lblDate, BorderLayout.EAST);
        contentPanel.add(topContent, BorderLayout.NORTH);

        // Center Content: Tạo các Widget Card thống kê cho ra dáng "Dashboard" chuyên nghiệp
        JPanel dashboardGrid = new JPanel(new GridLayout(2, 2, 20, 20));
        dashboardGrid.setOpaque(false);

        dashboardGrid.add(createStatCard("Tổng Kho Thuốc", "1,240 Loại", "12 danh mục đang hoạt động", new Color(41, 128, 185)));
        dashboardGrid.add(createStatCard("Chờ Cấp Phát", "08 Bệnh nhân", "Yêu cầu mới từ phòng khám", new Color(39, 174, 96)));
        dashboardGrid.add(createStatCard("Thuốc Sắp Hết Hạn", "03 Lô", "Cần kiểm tra hạn dùng", new Color(230, 126, 34)));
        dashboardGrid.add(createStatCard("Ca Trực Hôm Nay", "07:30 - 16:30", "Khu vực: Quầy phát thuốc A", new Color(142, 68, 173)));

        contentPanel.add(dashboardGrid, BorderLayout.CENTER);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // =====================================
        // ĐĂNG KÝ SỰ KIỆN LẮNG NGHE (EVENTS)
        // =====================================
        btnThuoc.addActionListener(e -> new QuanLyThuocForm().setVisible(true));
        btnPhieuThuoc.addActionListener(e -> new ThanhToanForm().setVisible(true));
        btnTaiKhoan.addActionListener(e -> new TaiKhoanCaNhanForm().setVisible(true));
        btnLich.addActionListener(e -> new LichLamViecForm().setVisible(true));
        
        btnLogout.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                this.dispose();
                // Triển khai form Login của bạn tại đây nếu có, ví dụ: new LoginForm().setVisible(true);
            }
        });
    }

    // =====================================
    // HÀM TẠO NÚT MENU SIDEBAR PHẲNG HIỆN ĐẠI
    // =====================================
    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(new Color(189, 195, 199)); // Màu chữ mặc định xám nhẹ nhã nhặn
        btn.setBackground(BG_SIDEBAR);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Tạo khoảng đệm rộng rãi sang trọng cho nút
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(52, 73, 94)); // Đổi màu nền tối hơn tí khi hover
                btn.setForeground(Color.WHITE);          // Đổi chữ sang trắng sáng
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(BG_SIDEBAR);
                btn.setForeground(new Color(189, 195, 199));
            }
        });

        return btn;
    }

    // =====================================
    // HÀM TẠO CÁC CARD THEO DÕI SỐ LIỆU ĐẸP MẮT
    // =====================================
    private JPanel createStatCard(String title, String value, String desc, Color indicatorColor) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Vẽ thanh màu bo góc nhỏ báo thị trạng thái ở cạnh trái của Card
                g.setColor(indicatorColor);
                g.fillRect(0, 0, 6, getHeight());
            }
        };
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(18, 22, 18, 22)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(new Color(127, 140, 141));

        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblValue.setForeground(TEXT_MAIN);
        lblValue.setBorder(new EmptyBorder(8, 0, 4, 0));

        JLabel lblDesc = new JLabel(desc);
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(165, 175, 185));

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblValue, BorderLayout.CENTER);
        card.add(lblDesc, BorderLayout.SOUTH);

        return card;
    }
}