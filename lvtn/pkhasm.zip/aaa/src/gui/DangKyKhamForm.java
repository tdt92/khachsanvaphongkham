package gui;

import bus.*;
import model.*;
import config.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

public class DangKyKhamForm extends JFrame {

    // ===== BUS =====
    private DangKyKhamBenhBUS dangKyBUS = new DangKyKhamBenhBUS();
    private BenhNhanBUS benhNhanBUS = new BenhNhanBUS();
    private ChuyenKhoaBUS chuyenKhoaBUS = new ChuyenKhoaBUS();
    private NhanVienBUS nhanVienBUS = new NhanVienBUS();

    // ===== LEFT =====
    private JTextField txtSearch = new JTextField();
    private JTable tableBenhNhan;
    private DefaultTableModel modelBenhNhan;

    // ===== RIGHT =====
    private JComboBox<ChuyenKhoa> cbChuyenKhoa = new JComboBox<>();
    private JComboBox<NhanVien> cbBacSi = new JComboBox<>();
    private JTextField txtSTT = new JTextField();
    private JTextArea txtGhiChu = new JTextArea();

    // ===== BOTTOM =====
    private JTable tableCho;
    private DefaultTableModel modelCho;

    private BenhNhan selectedBenhNhan;

    // ===== PALETTE MÀU ĐỒNG BỘ DASHBOARD =====
    private final Color BG = new Color(245, 247, 250);
    private final Color CARD = Color.WHITE;
    private final Color PRIMARY = new Color(0, 122, 255);
    private final Color PRIMARY_HOVER = new Color(0, 100, 210);
    private final Color TEXT_DARK = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);
    private final Color DANGER = new Color(239, 68, 68);
    private final Color DANGER_HOVER = new Color(220, 38, 38);

    public DangKyKhamForm(){
        setTitle("ĐĂNG KÝ KHÁM BỆNH");
        setSize(1300, 780);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel root = new JPanel(new BorderLayout(15, 15));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(root);

        // Thanh điều hướng trên cùng (Thêm nút Quay lại)
        root.add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Khu vực trung tâm gồm bên trái (Chọn BN) và bên phải (Thông tin khám)
        root.add(createTopPanel(), BorderLayout.CENTER);
        
        // Khu vực dưới cùng (Danh sách chờ)
        root.add(createBottomPanel(), BorderLayout.SOUTH);

        loadChuyenKhoa();
        loadBenhNhan();
        loadDanhSachCho();
    }

    // ================= HEADER PANEL =================
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel lbTitle = new JLabel("📝 ĐĂNG KÝ TIẾP NHẬN KHÁM BỆNH");
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(TEXT_DARK);

        JButton btnBack = styleButton("Quay lại Dashboard", new Color(108, 117, 125), Color.WHITE);
        btnBack.setPreferredSize(new Dimension(180, 38));
        btnBack.addActionListener(e -> {
            new LeTanDashboard().setVisible(true);
            dispose();
        });

        header.add(lbTitle, BorderLayout.WEST);
        header.add(btnBack, BorderLayout.EAST);
        return header;
    }

    // ================= TOP CONTAINER =================
    private JPanel createTopPanel(){
        JPanel top = new JPanel(new GridLayout(1, 2, 25, 0));
        top.setOpaque(false);

        top.add(createLeftPanel());
        top.add(createRightPanel());

        return top;
    }

    // ================= LEFT PANEL (CHỌN BỆNH NHÂN) =================
    private JPanel createLeftPanel(){
        JPanel left = new JPanel(new BorderLayout(12, 12)) {
            @Override
            protected void paintComponent(Graphics g) {
                styleCardBackground(this, g);
            }
        };
        left.setOpaque(false);
        left.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(15, 20, 20, 20),
                BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), "CHỌN BỆNH NHÂN", 
                        TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 14), PRIMARY)
        ));

        // ===== SEARCH & TOOLBAR =====
        JPanel searchPanel = new JPanel(new BorderLayout(8, 8));
        searchPanel.setOpaque(false);
        
        JLabel lblSearch = new JLabel("Tìm nhanh bệnh nhân (Tên / CCCD / SĐT):");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSearch.setForeground(TEXT_DARK);
        searchPanel.add(lblSearch, BorderLayout.NORTH);
        
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        searchPanel.add(txtSearch, BorderLayout.CENTER);

        // ===== BUTTONS NGOẠI VI =====
        JButton btnAdd = styleButton("＋ Thêm bệnh nhân", PRIMARY, Color.WHITE);
        JButton btnTaiKham = styleButton("📅 Danh sách tái khám", new Color(40, 167, 69), Color.WHITE);
        JButton btnLich = styleButton("📋 Lịch làm việc bác sĩ", new Color(255, 193, 7), TEXT_DARK);

        JPanel btnPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(btnAdd);
        btnPanel.add(btnTaiKham);
        btnPanel.add(btnLich);

        searchPanel.add(btnPanel, BorderLayout.SOUTH);
        left.add(searchPanel, BorderLayout.NORTH);

        // ===== TABLE BỆNH NHÂN =====
        modelBenhNhan = new DefaultTableModel(
                new String[]{"Mã BN", "Họ tên", "Phái", "Số điện thoại", "CCCD", "Ngày sinh"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tableBenhNhan = new JTable(modelBenhNhan);
        styleTable(tableBenhNhan);
        
        JScrollPane scroll = new JScrollPane(tableBenhNhan);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scroll.getViewport().setBackground(Color.WHITE);
        left.add(scroll, BorderLayout.CENTER);

        // ===== EVENTS =====
        txtSearch.addCaretListener(e -> searchBenhNhan());

        tableBenhNhan.getSelectionModel().addListSelectionListener(e -> {
            int row = tableBenhNhan.getSelectedRow();
            if(row >= 0){
                int maBN = (int) modelBenhNhan.getValueAt(row, 0);
                selectedBenhNhan = benhNhanBUS.getById(maBN);
            }
        });

        btnAdd.addActionListener(e -> new QuanLyBenhNhanForm().setVisible(true));
        btnTaiKham.addActionListener(e -> new LichTaiKhamForm().setVisible(true));
        btnLich.addActionListener(e -> new LichLamViecHomNayForm().setVisible(true));
        
        return left;
    }

 // ================= RIGHT PANEL (THÔNG TIN ĐĂNG KÝ) =================
    private JPanel createRightPanel(){
        JPanel right = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                styleCardBackground(this, g);
            }
        };
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(15, 25, 20, 25),
                BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), "THÔNG TIN ĐĂNG KÝ KHÁM", 
                        TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 14), PRIMARY)
        ));

        // Khống chế kích thước chuẩn cho các ComboBox để không bị BoxLayout kéo giãn chiều cao
        Dimension comboSize = new Dimension(Integer.MAX_VALUE, 35);

        addFormLabel(right, "Chuyên khoa khám:");
        cbChuyenKhoa.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbChuyenKhoa.setMaximumSize(comboSize); // FIX: Giới hạn chiều cao tối đa
        right.add(cbChuyenKhoa);
        right.add(Box.createVerticalStrut(10));

        addFormLabel(right, "Bác sĩ chỉ định (Nếu có):");
        cbBacSi.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbBacSi.setMaximumSize(comboSize); // FIX: Giới hạn chiều cao tối đa
        right.add(cbBacSi);
        right.add(Box.createVerticalStrut(10));

        addFormLabel(right, "Số thứ tự lượt khám kế tiếp:");
        txtSTT.setFont(new Font("Segoe UI", Font.BOLD, 16));
        txtSTT.setEditable(false);
        txtSTT.setBackground(new Color(240, 244, 248));
        txtSTT.setForeground(PRIMARY);
        txtSTT.setHorizontalAlignment(JTextField.CENTER);
        txtSTT.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        txtSTT.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38)); // FIX: Giới hạn chiều cao tối đa
        right.add(txtSTT);
        right.add(Box.createVerticalStrut(10));

        addFormLabel(right, "Lý do khám / Ghi chú bệnh lý:");
        txtGhiChu.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtGhiChu.setLineWrap(true);
        txtGhiChu.setWrapStyleWord(true);
        JScrollPane scrollGhiChu = new JScrollPane(txtGhiChu);
        scrollGhiChu.setPreferredSize(new Dimension(200, 75));
        scrollGhiChu.setMaximumSize(new Dimension(Integer.MAX_VALUE, 85)); // FIX: Giới hạn vùng nhập text
        scrollGhiChu.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        right.add(scrollGhiChu);
        
        // Tạo khoảng trống co giãn đẩy nút bấm luôn nằm vững chắc ở đáy Panel
        right.add(Box.createVerticalGlue());

        // FIX: Bọc nút bấm vào một FlowLayout Panel để đảm bảo nút luôn hiển thị đúng kích thước thực
        JPanel btnWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        btnWrapper.setOpaque(false);
        btnWrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        JButton btnXacNhan = styleButton("⚡ XÁC NHẬN ĐĂNG KÝ KHÁM", PRIMARY, Color.WHITE);
        btnXacNhan.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnXacNhan.setPreferredSize(new Dimension(340, 45)); // Định hình kích thước chuẩn cho nút bấm
        btnXacNhan.addActionListener(e -> xacNhanKham());
        
        btnWrapper.add(btnXacNhan);
        right.add(btnWrapper);

        cbChuyenKhoa.addActionListener(e -> updateSTT());

        return right;
    }

 // ================= BOTTOM PANEL (DANH SÁCH CHỜ) =================
    private JPanel createBottomPanel(){
        JPanel wrapper = new JPanel(new BorderLayout(5, 5)) {
            @Override
            protected void paintComponent(Graphics g) {
                styleCardBackground(this, g);
            }
        };
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        // FIX CHIẾN THUẬT: Khống chế cứng chiều cao tổng của cả cụm phía dưới 
        // Chiều cao 180px là vừa vặn hiển thị 4-5 dòng chờ và nút bấm mà không lấn sân phía trên
        wrapper.setPreferredSize(new Dimension(1300, 180)); 

        modelCho = new DefaultTableModel(
                new String[]{"ID Hàng chờ", "STT", "Mã BN", "Họ và tên bệnh nhân", "Chuyên khoa", "Bác sĩ phụ trách", "Ghi chú"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tableCho = new JTable(modelCho);
        styleTable(tableCho);

        JScrollPane sp = new JScrollPane(tableCho);
        sp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(BORDER_COLOR), 
                " DANH SÁCH HÀNG CHỜ KHÁM TRONG NGÀY ", TitledBorder.LEFT, TitledBorder.TOP, 
                new Font("Segoe UI", Font.BOLD, 13), TEXT_DARK));
        sp.getViewport().setBackground(Color.WHITE);

        // Nút hủy được thiết kế gọn lại một chút về chiều cao (32px thay vì 38px)
        JButton btnHuy = styleButton("❌ HỦY ĐĂNG KÝ LƯỢT KHÁM", DANGER, Color.WHITE);
        btnHuy.setPreferredSize(new Dimension(200, 32));
        btnHuy.addActionListener(e -> huyDangKy());

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        south.setOpaque(false);
        south.add(btnHuy);

        wrapper.add(sp, BorderLayout.CENTER);
        wrapper.add(south, BorderLayout.SOUTH);

        return wrapper;
    }

    // ================= HÀM ĐỊNH DẠNG GIAO DIỆN (UI STYLING) =================
    private void styleCardBackground(JPanel panel, Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(CARD);
        g2.fill(new RoundRectangle2D.Float(0, 0, panel.getWidth(), panel.getHeight(), 16, 16));
        g2.setColor(BORDER_COLOR);
        g2.draw(new RoundRectangle2D.Float(0, 0, panel.getWidth() - 1, panel.getHeight() - 1, 16, 16));
        g2.dispose();
    }

    private void addFormLabel(JPanel panel, String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(TEXT_DARK);
        label.setBorder(new EmptyBorder(0, 2, 4, 0));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(label);
    }

    private JButton styleButton(String text, Color baseColor, Color textColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(textColor);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (baseColor.equals(PRIMARY)) btn.setBackground(PRIMARY_HOVER);
                else if (baseColor.equals(DANGER)) btn.setBackground(DANGER_HOVER);
                else btn.setBackground(baseColor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(baseColor);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setSelectionBackground(new Color(232, 244, 255));
        table.setSelectionForeground(Color.BLACK);
        table.setShowGrid(true);
        table.setGridColor(new Color(240, 242, 245));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(240, 244, 248));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
    }

    // ================= KHÔNG THAY ĐỔI LOGIC XỬ LÝ GỐC =================
    private void loadBenhNhan(){
        modelBenhNhan.setRowCount(0);
        for(BenhNhan bn : benhNhanBUS.getAll()){
            modelBenhNhan.addRow(new Object[]{
                    bn.getMaBenhNhan(),
                    bn.getHoTen(),
                    bn.getGioiTinh()==0?"Nam":"Nữ",
                    bn.getSoDienThoai(),
                    bn.getCccd(),
                    bn.getNgaySinh()
            });
        }
    }

    private void searchBenhNhan(){
        modelBenhNhan.setRowCount(0);
        List<BenhNhan> list = benhNhanBUS.searchByName(txtSearch.getText());
        for(BenhNhan bn : list){
            modelBenhNhan.addRow(new Object[]{
                    bn.getMaBenhNhan(),
                    bn.getHoTen(),
                    bn.getGioiTinh()==0?"Nam":"Nữ",
                    bn.getSoDienThoai(),
                    bn.getCccd(),
                    bn.getNgaySinh()
            });
        }
    }

    private void loadChuyenKhoa(){
        cbChuyenKhoa.removeAllItems();
        for(ChuyenKhoa ck : chuyenKhoaBUS.getAll()){
            cbChuyenKhoa.addItem(ck);
        }
        updateSTT();
    }

    private void updateSTT(){
        ChuyenKhoa ck = (ChuyenKhoa) cbChuyenKhoa.getSelectedItem();
        if(ck!=null){
            int next = dangKyBUS.getNextSTT(ck.getMaChuyenKhoa());
            txtSTT.setText(String.valueOf(next));
            loadBacSiTheoChuyenKhoa();
        }
    }

    private void loadBacSiTheoChuyenKhoa(){
        cbBacSi.removeAllItems();
        ChuyenKhoa ck = (ChuyenKhoa) cbChuyenKhoa.getSelectedItem();
        if(ck==null) return;

        List<NhanVien> list = nhanVienBUS.getByChuyenKhoa(ck.getTenChuyenKhoa());
        for(NhanVien nv : list){
            cbBacSi.addItem(nv);
        }
    }

    private void xacNhanKham(){
        if(selectedBenhNhan==null){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một bệnh nhân từ danh sách bên trái!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        ChuyenKhoa ck = (ChuyenKhoa) cbChuyenKhoa.getSelectedItem();
        NhanVien nv = (NhanVien) cbBacSi.getSelectedItem();
        int nextSTT = Integer.parseInt(txtSTT.getText());

        DangKyKhamBenh dk = new DangKyKhamBenh(
                selectedBenhNhan.getMaBenhNhan(),
                nv!=null ? nv.getMaNhanVien() : null,
                ck.getMaChuyenKhoa(),
                nextSTT,
                "CHO_KHAM_BS",
                txtGhiChu.getText()
        );

        if(dangKyBUS.insert(dk)){
            JOptionPane.showMessageDialog(this, "Đăng ký lượt khám thành công!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
            loadDanhSachCho();
            updateSTT();
            txtGhiChu.setText("");
        }
    }

    private void loadDanhSachCho(){
        modelCho.setRowCount(0);
        dangKyBUS.deleteDangKyCu();

        try(Connection con = DBConnection.getConnection()){
            ResultSet rs = new dao.DangKyKhamBenhDAO().getDanhSachChoHomNay(con);
            while(rs.next()){
                modelCho.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("so_thu_tu"),
                        rs.getInt("ma_benh_nhan"),
                        rs.getString("ho_ten"),
                        rs.getString("ten_chuyen_khoa"),
                        rs.getString("ten_bs"),
                        rs.getString("ghi_chu")
                });
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void huyDangKy(){
        int row = tableCho.getSelectedRow();
        if(row<0){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một lượt khám trong danh sách chờ để hủy!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modelCho.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn hủy đăng ký lượt khám này không?",
                "Xác nhận hủy", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if(confirm==JOptionPane.YES_OPTION){
            if(dangKyBUS.deleteById(id)){
                JOptionPane.showMessageDialog(this, "Đã hủy lượt khám thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                loadDanhSachCho();
                updateSTT();
            }
        }
    }
}