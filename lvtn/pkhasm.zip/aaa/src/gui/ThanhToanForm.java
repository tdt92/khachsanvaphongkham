package gui;

import config.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

public class ThanhToanForm extends JFrame {

    private JTable tableBenhNhan;
    private JTable tableChiTiet;
    private DefaultTableModel modelBN;
    private DefaultTableModel modelCT;
    private JTextField txtSearch;

    // ===== BỘ MÀU FLAT UI ĐỒNG BỘ HỆ THỐNG =====
    private final Color PRIMARY = new Color(52, 152, 219);     // Xanh Sky Blue chủ đạo
    private final Color SUCCESS = new Color(46, 204, 113);     // Xanh lá cho nút Xem / In đơn
    private final Color DANGER = new Color(231, 76, 60);       // Đỏ nhẹ cho nút Đóng
    private final Color REFRESH = new Color(149, 165, 166);    // Xám tinh tế cho nút Làm mới
    private final Color BG_WINDOW = new Color(245, 247, 250);  // Nền cửa sổ sáng dịu
    private final Color TEXT_MAIN = new Color(44, 62, 80);     // Chữ chính đậm rõ ràng
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public ThanhToanForm(){
        setTitle("QUẢN LÝ PHIẾU THUỐC");
        setSize(1200, 660);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Main Container với khoảng đệm an toàn bao quanh
        JPanel mainPanel = new JPanel(new BorderLayout(15, 0));
        mainPanel.setBackground(BG_WINDOW);
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(mainPanel);

        // =====================================
        // PANEL BÊN TRÁI: TÌM KIẾM & BỆNH NHÂN
        // =====================================
        JPanel leftPanel = new JPanel(new BorderLayout(0, 12));
        leftPanel.setOpaque(false);
        leftPanel.setPreferredSize(new Dimension(380, 0));

        // Thanh Tìm Kiếm Flat UI (Bỏ TitledBorder cổ điển)
        JPanel searchPanel = new JPanel(new BorderLayout(8, 0));
        searchPanel.setOpaque(false);

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        JPanel pBtnSearch = new JPanel(new GridLayout(1, 2, 6, 0));
        pBtnSearch.setOpaque(false);
        JButton btnSearch = createFlatButton("TÌM", PRIMARY);
        JButton btnRefresh = createFlatButton("LÀM MỚI", REFRESH);
        pBtnSearch.add(btnSearch);
        pBtnSearch.add(btnRefresh);

        searchPanel.add(txtSearch, BorderLayout.CENTER);
        searchPanel.add(pBtnSearch, BorderLayout.EAST);
        leftPanel.add(searchPanel, BorderLayout.NORTH);

        // Bảng Bệnh Nhân
        modelBN = new DefaultTableModel(
                new String[]{"Mã PK", "Bệnh nhân", "CCCD", "Ngày khám"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tableBenhNhan = new JTable(modelBN);
        styleTable(tableBenhNhan);

        JScrollPane leftScroll = new JScrollPane(tableBenhNhan);
        leftScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1, true));
        leftScroll.getViewport().setBackground(Color.WHITE);
        leftPanel.add(leftScroll, BorderLayout.CENTER);

        mainPanel.add(leftPanel, BorderLayout.WEST);

        // =====================================
        // PANEL BÊN PHẢI: CHI TIẾT ĐƠN THUỐC
        // =====================================
        JPanel rightPanel = new JPanel(new BorderLayout(0, 12));
        rightPanel.setOpaque(false);

        modelCT = new DefaultTableModel(
                new String[]{
                        "Tên Thuốc", "Liều Dùng", "Sáng", "Trưa", 
                        "Chiều", "Tối", "Số Ngày", "Thời Điểm", "Cách Dùng"
                }, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tableChiTiet = new JTable(modelCT);
        styleTable(tableChiTiet);

        JScrollPane rightScroll = new JScrollPane(tableChiTiet);
        rightScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1, true));
        rightScroll.getViewport().setBackground(Color.WHITE);
        rightPanel.add(rightScroll, BorderLayout.CENTER);

        // =====================================
        // THANH NÚT CHỨC NĂNG DƯỚI CÙNG
        // =====================================
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bottomPanel.setOpaque(false);

        JButton btnLoad = createFlatButton("🔎 XEM PHIẾU THUỐC", PRIMARY);
        JButton btnIn = createFlatButton("🖨️ IN PHIẾU THUỐC", SUCCESS);
        JButton btnDong = createFlatButton("ĐÓNG", DANGER);

        bottomPanel.add(btnLoad);
        bottomPanel.add(btnIn);
        bottomPanel.add(btnDong);
        rightPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(rightPanel, BorderLayout.CENTER);

        // =====================================
        // ĐĂNG KÝ SỰ KIỆN LẮNG NGHE (EVENTS)
        // =====================================
        btnLoad.addActionListener(e -> loadChiTiet());
        btnIn.addActionListener(e -> inPhieuThuoc());
        btnDong.addActionListener(e -> dispose());
        btnSearch.addActionListener(e -> loadBenhNhan(txtSearch.getText().trim()));
        txtSearch.addActionListener(e -> loadBenhNhan(txtSearch.getText().trim()));

        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadBenhNhan("");
            modelCT.setRowCount(0);
        });

        // Bổ sung sự kiện double-click vào dòng bảng bệnh nhân để tự tải nhanh đơn thuốc
        tableBenhNhan.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tableBenhNhan.getSelectedRow() != -1) {
                    loadChiTiet();
                }
            }
        });

        // Tải dữ liệu ban đầu
        loadBenhNhan("");
    }

    // Hàm chuẩn hóa giao diện cho bảng (Table Styling) giúp đồng bộ thiết kế
    private void styleTable(JTable targetTable) {
        targetTable.setRowHeight(36);
        targetTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        targetTable.setGridColor(new Color(240, 243, 248));
        targetTable.setSelectionBackground(new Color(230, 242, 255));
        targetTable.setSelectionForeground(TEXT_MAIN);
        targetTable.setShowVerticalLines(false);

        JTableHeader header = targetTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(Color.WHITE);
        header.setForeground(TEXT_MAIN);
        header.setPreferredSize(new Dimension(0, 38));
        ((DefaultTableCellRenderer)header.getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);

        targetTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                if (!isSel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 253));
                }
                setBorder(noFocusBorder);
                return comp;
            }
        });
    }

    // Hàm tạo nút phẳng cao cấp kèm hiệu ứng Hover mượt mà
    private JButton createFlatButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(baseColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width + 16, 38));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(baseColor.darker()); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(baseColor); }
        });
        return btn;
    }

    // =====================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN HOÀN TOÀN)
    // =====================================
    private void loadBenhNhan(String keyword){
        modelBN.setRowCount(0);
        try{
            Connection con = DBConnection.getConnection();
            String sql = "SELECT pk.ma_phieu_kham, bn.ho_ten, bn.cccd, pk.ngay_kham " +
                         "FROM phieu_kham pk " +
                         "JOIN benh_nhan bn ON pk.ma_benh_nhan = bn.ma_benh_nhan " +
                         "WHERE pk.trang_thai='KHAM_XONG' " +
                         "AND (bn.ho_ten LIKE ? OR bn.cccd LIKE ?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            while(rs.next()){
                modelBN.addRow(new Object[]{
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getTimestamp(4) != null ? sdf.format(rs.getTimestamp(4)) : ""
                });
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void loadChiTiet(){
        int row = tableBenhNhan.getSelectedRow();
        if(row == -1){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn bệnh nhân cần xem từ danh sách bên trái!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(modelBN.getValueAt(row,0).toString());
        modelCT.setRowCount(0);

        try{
            Connection con = DBConnection.getConnection();
            String sql = "SELECT t.ten_thuoc, ct.lieu_dung, ct.sang, ct.trua, ct.chieu, ct.toi, ct.so_ngay, ct.thoi_diem_dung, ct.cach_dung " +
                         "FROM ct_toa_thuoc ct " +
                         "JOIN thuoc t ON ct.ma_thuoc=t.ma_thuoc " +
                         "JOIN toa_thuoc tt ON ct.ma_toa_thuoc=tt.ma_toa_thuoc " +
                         "WHERE tt.ma_phieu_kham=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, maPhieu);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                modelCT.addRow(new Object[]{
                        rs.getString("ten_thuoc"),
                        rs.getString("lieu_dung"),
                        rs.getString("sang"),
                        rs.getString("trua"),
                        rs.getString("chieu"),
                        rs.getString("toi"),
                        rs.getInt("so_ngay"),
                        rs.getString("thoi_diem_dung"),
                        rs.getString("cach_dung")
                });
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void inPhieuThuoc(){
        int row = tableBenhNhan.getSelectedRow();
        if(row == -1){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một bệnh nhân để thực hiện chức năng in!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try{
            String tenBN = modelBN.getValueAt(row, 1).toString();
            boolean complete = tableChiTiet.print(
                    JTable.PrintMode.FIT_WIDTH,
                    new java.text.MessageFormat("PHIẾU THUỐC CHI TIẾT - " + tenBN),
                    new java.text.MessageFormat("Hệ Thống Quản Lý Phòng Khám")
            );

            if(complete){
                JOptionPane.showMessageDialog(this, "Hệ thống đã gửi lệnh và in phiếu thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(this, "Tiến trình in ấn đã bị người dùng hủy bỏ!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            }
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Không thể kết nối thiết bị in ấn hoặc lỗi tạo định dạng!", "Lỗi máy in", JOptionPane.ERROR_MESSAGE);
        }
    }
}