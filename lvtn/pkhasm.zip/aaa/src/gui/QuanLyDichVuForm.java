package gui;

import bus.DichVuBUS;
import bus.PhongChucNangBUS;
import bus.ChuyenKhoaBUS;

import model.DichVu;
import model.PhongChucNang;
import model.ChuyenKhoa;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;

import java.math.BigDecimal;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QuanLyDichVuForm extends JFrame {

    private JTextField txtTen, txtGia, txtLoai, txtSearch;
    private JComboBox<PhongChucNang> cboPhong;
    private JComboBox<ChuyenKhoa> cboCK;

    private JTable table;
    private DefaultTableModel model;

    private JPanel cardPanel;

    private DichVuBUS bus = new DichVuBUS();
    private PhongChucNangBUS phongBUS = new PhongChucNangBUS();
    private ChuyenKhoaBUS ckBUS = new ChuyenKhoaBUS();

    private int selectedId = -1;

    private final Color PRIMARY = new Color(33,150,243);
    private final Color BG = new Color(245,247,250);

    public QuanLyDichVuForm() {

        setTitle("DASHBOARD QUẢN LÝ DỊCH VỤ");
        setSize(1500, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10,10));

        getContentPane().setBackground(BG);

        add(createTopPanel(), BorderLayout.NORTH);
        add(createMainPanel(), BorderLayout.CENTER);

        loadCombo();
        loadData();
        updateDashboard();
    }

    // ================= TOP PANEL =================
    private JPanel createTopPanel() {

        JPanel panel = new JPanel(new GridLayout(3,4,15,15));
        panel.setBorder(new EmptyBorder(15,15,15,15));
        panel.setBackground(Color.WHITE);

        txtTen = new JTextField();
        txtGia = new JTextField();
        txtLoai = new JTextField();
        txtSearch = new JTextField();

        cboPhong = new JComboBox<>();
        cboCK = new JComboBox<>();

        panel.add(label("Tên dịch vụ *")); panel.add(txtTen);
        panel.add(label("Đơn giá *")); panel.add(txtGia);
        panel.add(label("Loại dịch vụ *")); panel.add(txtLoai);

        panel.add(label("Phòng *")); panel.add(cboPhong);
        panel.add(label("Chuyên khoa *")); panel.add(cboCK);

        JButton btnThem = button("Thêm");
        JButton btnSua = button("Sửa");
        JButton btnXoa = button("Xóa");
        JButton btnMoi = button("Làm mới");

        btnThem.addActionListener(e -> add());
        btnSua.addActionListener(e -> update());
        btnXoa.addActionListener(e -> delete());
        btnMoi.addActionListener(e -> clear());

        panel.add(btnThem);
        panel.add(btnSua);
        panel.add(btnXoa);
        panel.add(btnMoi);

        panel.add(label("Tìm kiếm"));
        panel.add(txtSearch);

        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e){ search(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e){ search(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e){ search(); }
        });

        // chỉ cho nhập số ở đơn giá
        txtGia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c!='.') {
                    evt.consume();
                }
            }
        });

        return panel;
    }

    // ================= MAIN =================
    private JPanel createMainPanel() {

        JPanel main = new JPanel(new BorderLayout(15,15));
        main.setBorder(new EmptyBorder(10,15,15,15));
        main.setBackground(BG);

        // CARD DASHBOARD
        cardPanel = new JPanel(new GridLayout(1,3,15,15));
        cardPanel.setBackground(BG);

        main.add(cardPanel, BorderLayout.NORTH);

        // TABLE
        model = new DefaultTableModel();
        table = new JTable(model);

        model.setColumnIdentifiers(new String[]{
                "Mã","Tên","Đơn giá","Loại","Phòng","Chuyên khoa"
        });

        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI",Font.PLAIN,14));
        table.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,14));

        table.getSelectionModel().addListSelectionListener(e -> fillForm());

        main.add(new JScrollPane(table), BorderLayout.CENTER);

        return main;
    }

    // ================= CARD =================
    private JPanel createCard(String title,String value){

        JPanel card=new JPanel(new BorderLayout());
        card.setBackground(PRIMARY);
        card.setPreferredSize(new Dimension(200,100));
        card.setBorder(new EmptyBorder(15,15,15,15));

        JLabel lbTitle=new JLabel(title);
        lbTitle.setForeground(Color.WHITE);
        lbTitle.setFont(new Font("Segoe UI",Font.BOLD,16));

        JLabel lbValue=new JLabel(value);
        lbValue.setForeground(Color.WHITE);
        lbValue.setFont(new Font("Segoe UI",Font.BOLD,28));

        card.add(lbTitle,BorderLayout.NORTH);
        card.add(lbValue,BorderLayout.CENTER);

        return card;
    }

    // ================= DASHBOARD =================
    private void updateDashboard(){

        cardPanel.removeAll();

        List<DichVu> list=bus.getAll();

        Map<String,Integer> mapLoai=new HashMap<>();
        Map<Integer,Integer> mapPhong=new HashMap<>();

        for(DichVu dv:list){
            mapLoai.put(dv.getLoaiDichVu(),
                    mapLoai.getOrDefault(dv.getLoaiDichVu(),0)+1);

            mapPhong.put(dv.getPhong(),
                    mapPhong.getOrDefault(dv.getPhong(),0)+1);
        }

        cardPanel.add(createCard("TỔNG DỊCH VỤ", list.size()+""));
        cardPanel.add(createCard("SỐ LOẠI DỊCH VỤ", mapLoai.size()+""));
        cardPanel.add(createCard("SỐ PHÒNG CÓ DV", mapPhong.size()+""));

        cardPanel.revalidate();
        cardPanel.repaint();
    }

    // ================= CRUD =================
    private void add(){

        if(!validateForm()) return;

        bus.insert(getForm());
        loadData();
        updateDashboard();
        clear();
    }

    private void update(){

        if(selectedId==-1) return;
        if(!validateForm()) return;

        DichVu dv=getForm();
        dv.setMaDichVu(selectedId);
        bus.update(dv);

        loadData();
        updateDashboard();
        clear();
    }

    private void delete(){
        if(selectedId==-1) return;
        bus.delete(selectedId);
        loadData();
        updateDashboard();
        clear();
    }

    private void search(){
        model.setRowCount(0);
        for(DichVu dv:bus.search(txtSearch.getText())){
            model.addRow(new Object[]{
                    dv.getMaDichVu(),
                    dv.getTenDichVu(),
                    dv.getDonGia(),
                    dv.getLoaiDichVu(),
                    dv.getPhong(),
                    dv.getMaChuyenKhoa()
            });
        }
    }

    private boolean validateForm(){

        if(txtTen.getText().isEmpty() ||
           txtGia.getText().isEmpty() ||
           txtLoai.getText().isEmpty() ||
           cboPhong.getSelectedItem()==null ||
           cboCK.getSelectedItem()==null){

            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập đầy đủ thông tin bắt buộc!");
            return false;
        }

        try{
            new BigDecimal(txtGia.getText());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,
                    "Đơn giá phải là số hợp lệ!");
            return false;
        }

        return true;
    }

    private void loadCombo(){
        for(PhongChucNang p:phongBUS.getAll())
            cboPhong.addItem(p);

        for(ChuyenKhoa ck:ckBUS.getAll())
            cboCK.addItem(ck);
    }

    private void loadData(){
        model.setRowCount(0);
        for(DichVu dv:bus.getAll()){
            model.addRow(new Object[]{
                    dv.getMaDichVu(),
                    dv.getTenDichVu(),
                    dv.getDonGia(),
                    dv.getLoaiDichVu(),
                    dv.getPhong(),
                    dv.getMaChuyenKhoa()
            });
        }
    }

    private DichVu getForm(){
        DichVu dv=new DichVu();
        dv.setTenDichVu(txtTen.getText());
        dv.setDonGia(new BigDecimal(txtGia.getText()));
        dv.setLoaiDichVu(txtLoai.getText());
        dv.setPhong(((PhongChucNang)cboPhong.getSelectedItem()).getMaPhong());
        dv.setMaChuyenKhoa(((ChuyenKhoa)cboCK.getSelectedItem()).getMaChuyenKhoa());
        return dv;
    }

    private void fillForm(){
        int row=table.getSelectedRow();
        if(row==-1) return;
        selectedId=(int)model.getValueAt(row,0);
        txtTen.setText(model.getValueAt(row,1)+"");
        txtGia.setText(model.getValueAt(row,2)+"");
        txtLoai.setText(model.getValueAt(row,3)+"");
    }

    private void clear(){
        selectedId=-1;
        txtTen.setText("");
        txtGia.setText("");
        txtLoai.setText("");
    }

    private JLabel label(String text){
        JLabel lb=new JLabel(text);
        lb.setFont(new Font("Segoe UI",Font.BOLD,14));
        return lb;
    }

    private JButton button(String text){
        JButton btn=new JButton(text);
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(()->new QuanLyDichVuForm().setVisible(true));
    }
}
