package gui;

import config.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KhoanoiForm extends JFrame {

    private final Color BG = new Color(236,240,245);
    private final Color CARD = Color.WHITE;
    private final Color PRIMARY = new Color(52,152,219);

    public KhoanoiForm(){

        setTitle("BÁC SĨ CHUYÊN KHOA NỘI");
        setSize(1000,650);
        setLocationRelativeTo(null);
 
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        setContentPane(root);

         JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG);
        header.setBorder(new EmptyBorder(20,30,10,30));

        JLabel lbUser = new JLabel(
                "Xin chào: " + Session.currentUser.getUsername());
        lbUser.setFont(new Font("Segoe UI",Font.BOLD,20));

        JButton btnLogout = new JButton("Đăng xuất");
        btnLogout.setFocusPainted(false);
        btnLogout.setBackground(Color.RED);
        btnLogout.setForeground(Color.WHITE);

        btnLogout.addActionListener(e->{
            new LoginForm().setVisible(true);
            dispose();
        });

        header.add(lbUser,BorderLayout.WEST);
        header.add(btnLogout,BorderLayout.EAST);

        root.add(header,BorderLayout.NORTH);

          JPanel center = new JPanel(new GridLayout(1,3,40,40));
        center.setBorder(new EmptyBorder(80,80,80,80));
        center.setBackground(BG);

        center.add(createCard("🩺 TIẾP NHẬN KHÁM"));
        center.add(createCard("👤 TÀI KHOẢN CÁ NHÂN"));
        center.add(createCard("📅 LỊCH LÀM VIỆC"));

        root.add(center,BorderLayout.CENTER);
    }

     private JPanel createCard(String text){

        JPanel card = new JPanel();
        card.setLayout(new GridBagLayout());
        card.setBackground(CARD);
        card.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI",Font.BOLD,20));
        label.setForeground(PRIMARY);

        card.add(label);

        card.addMouseListener(new MouseAdapter(){

            public void mouseEntered(MouseEvent e){
                card.setBackground(new Color(245,250,255));
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(MouseEvent e){
                card.setBackground(CARD);
            }

            public void mouseClicked(MouseEvent e){

                if(text.contains("TIẾP NHẬN")){
                    new KhamnoiForm().setVisible(true);
                 }
                else if(text.contains("TÀI KHOẢN")){
                    new TaiKhoanCaNhanForm().setVisible(true);
                 }
                else if(text.contains("LỊCH")){
                    new LichLamViecForm().setVisible(true);
                 }
            }
        });

        return card;
    }
}