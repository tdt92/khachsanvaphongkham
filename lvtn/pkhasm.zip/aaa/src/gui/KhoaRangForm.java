package gui;

import config.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KhoaRangForm extends JFrame {

    // Hệ màu hiện đại, dịu mắt chuẩn Medical Dashboard
    private final Color BG = new Color(244, 246, 249);       // Nền xám xanh nhẹ thanh lịch
    private final Color CARD_BG = Color.WHITE;               // Nền thẻ trắng tinh khôi
    private final Color PRIMARY = new Color(41, 128, 185);   // Màu xanh đặc trưng chuyên khoa
    private final Color BORDER_COLOR = new Color(225, 230, 235);
    private final Color HOVER_BORDER = new Color(52, 152, 219);
    private final Color TEXT_DARK = new Color(44, 62, 80);

    public KhoaRangForm() {
        setTitle("BÁC SĨ CHUYÊN KHOA RĂNG HAM MẶT");
        setSize(1050, 680); // Tăng nhẹ không gian để các thẻ "thở" tốt hơn
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(BG);
        setContentPane(root);

        // =========================================================================
        // THANH HEADER
        // =========================================================================
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG);
        header.setBorder(new EmptyBorder(25, 40, 10, 40));

        // Khu vực chào hỏi bên trái
        JPanel leftHeader = new JPanel(new GridLayout(2, 1, 0, 4));
        leftHeader.setBackground(BG);
        
        JLabel lbWelcome = new JLabel("HỆ THỐNG QUẢN LÝ PHÒNG KHÁM");
        lbWelcome.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbWelcome.setForeground(new Color(127, 140, 141)); // Chữ phụ màu xám

        JLabel lbUser = new JLabel("Bác sĩ: " + Session.currentUser.getUsername());
        lbUser.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbUser.setForeground(TEXT_DARK);

        leftHeader.add(lbWelcome);
        leftHeader.add(lbUser);

        // Nút Đăng xuất bên phải (Thiết kế phẳng tinh tế)
        JButton btnLogout = new JButton(" Đăng xuất");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogout.setFocusPainted(false);
        btnLogout.setBackground(new Color(231, 76, 60)); // Màu đỏ dịu mắt hơn
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnLogout.addActionListener(e -> {
            new LoginForm().setVisible(true);
            dispose();
        });

        header.add(leftHeader, BorderLayout.WEST);
        header.add(btnLogout, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // =========================================================================
        // KHU VỰC TRUNG TÂM: DANH SÁCH CÁC THẺ TÍNH NĂNG
        // =========================================================================
        JPanel center = new JPanel(new GridLayout(1, 3, 35, 0));
        center.setBorder(new EmptyBorder(40, 40, 60, 40));
        center.setBackground(BG);

        // Tách biệt rõ ràng Icon và Tiêu đề chữ giúp giao diện có chiều sâu
     // Thay thế emoji phức tạp bằng các ký tự hình học cơ bản, sắc nét
        center.add(createCard("❖", "TIẾP NHẬN KHÁM")); 
        center.add(createCard("⚙", "TÀI KHOẢN CÁ NHÂN"));
        center.add(createCard("⏰", "LỊCH LÀM VIỆC"));

        root.add(center, BorderLayout.CENTER);
    }

    /**
     * Hàm tạo Card chức năng cải tiến: Phân tầng Icon - Text theo chiều dọc
     */
    private JPanel createCard(String icon, String title) {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Sử dụng GridBagConstraints để xếp đè cấu trúc theo cột dọc
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.CENTER;

     // 1. Nhãn Icon lớn phía trên
        JLabel lblIcon = new JLabel(icon);
        // Ép sang font chuyên dụng hiển thị biểu tượng của Windows
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 42)); 
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 15, 0);
        card.add(lblIcon, gbc);

        // 2. Nhãn Chữ tiêu đề phía dưới
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(PRIMARY);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        card.add(lblTitle, gbc);

        // Hiệu ứng tương tác chuột (Hover Effect) nâng cao trải nghiệm
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBackground(new Color(250, 252, 255));
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(HOVER_BORDER, 2), // Làm dày viền khi di chuột
                        BorderFactory.createEmptyBorder(19, 19, 19, 19)     // Bù trừ khoảng trống viền tránh giật giật
                ));
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBackground(CARD_BG);
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_COLOR, 1),
                        BorderFactory.createEmptyBorder(20, 20, 20, 20)
                ));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (title.contains("TIẾP NHẬN")) {
                    new KhamRangForm().setVisible(true);
                } else if (title.contains("TÀI KHOẢN")) {
                    new TaiKhoanCaNhanForm().setVisible(true);
                } else if (title.contains("LỊCH")) {
                    new LichLamViecForm().setVisible(true);
                }
             }
        });

        return card;
    }
}