package gui;

import bus.PhanCongCaLamBUS;
import model.PhanCongCaLam;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

public class LichLamViecForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private PhanCongCaLamBUS bus = new PhanCongCaLamBUS();
    
    // Thành phần giao diện thêm mới để lọc dữ liệu
    private JTextField txtSearch = new JTextField();
    private JComboBox<String> cbFilterThu = new JComboBox<>(new String[]{"-- Tất cả các ngày --", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ Nhật"});

    // Danh sách gốc để phục vụ bộ lọc tìm kiếm tại chỗ nhanh (Client-side filtering)
    private List<PhanCongCaLam> originalList = new ArrayList<>();

    // Biến lưu trữ tham chiếu đến Form mẹ (Dashboard) để quay lại khi đóng hoặc bấm nút
    private JFrame parentForm;

    // ===== BẢNG MÀU DASHBOARD ĐỒNG BỘ Y TẾ =====
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color CARD_BG = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 122, 255);
    private final Color PRIMARY_HOVER = new Color(0, 100, 210);
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    // =========================================================================
    // NẠP CHỒNG CONSTRUCTOR (OVERLOADING) - ĐẢM BẢO KHÔNG LỖI BIÊN DỊCH
    // =========================================================================
    
    /**
     * Constructor 1: Không tham số (Hỗ trợ gọi từ các form cũ)
     */
    public LichLamViecForm() {
        this(null); // Chuyển tiếp cấu hình xuống Constructor có tham số với giá trị null
    }

    /**
     * Constructor 2: Có tham số (Được gọi từ Dashboard chính)
     */
    public LichLamViecForm(JFrame parentForm) {
        this.parentForm = parentForm;

        setTitle("LỊCH LÀM VIỆC TOÀN BỆNH VIỆN");
        setSize(1150, 680); // Tăng nhẹ không gian để giao diện thở rộng rãi
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Đổi sang DISPOSE để giải phóng bộ nhớ sạch sẽ khi đóng
        
        // ===== CƠ CHẾ TỰ ĐỘNG HIỆN LẠI DASHBOARD KHI ẤN DẤU X GÓC FORM =====
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                if (parentForm != null) {
                    parentForm.setVisible(true); // Tự động đánh thức Dashboard mẹ
                }
            }
        });

        initUI();
        loadFullLichLam();
    }

    private void initUI() {
        // Sử dụng một tấm nền phẳng, rộng rãi bao phủ toàn ứng dụng
        JPanel root = new JPanel(new BorderLayout(0, 15));
        root.setBackground(BG_WINDOW);
        root.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(root);

        // ================= NORTH: PANEL TIÊU ĐỀ & THANH LỌC DỮ LIỆU =================
        JPanel northPanel = new JPanel(new BorderLayout(0, 12));
        northPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("📅 LỊCH PHÂN CÔNG CÔNG TÁC TOÀN BỆNH VIỆN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_MAIN);
        northPanel.add(lblTitle, BorderLayout.WEST);

        // --- THANH CÔNG CỤ TÌM KIẾM VÀ LỌC (SEARCH TOOLBAR) ---
        JPanel filterBar = new JPanel(new GridBagLayout());
        filterBar.setBackground(CARD_BG);
        filterBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(12, 15, 12, 15)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 15);

        // Ô tìm kiếm theo tên hoặc phòng ban
        gbc.gridx = 0; gbc.weightx = 0.5;
        JPanel searchPane = new JPanel(new BorderLayout(5, 0));
        searchPane.setOpaque(false);
        JLabel lblSearch = new JLabel("Tìm nhân viên / Phòng: ");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setForeground(TEXT_MAIN);
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(5, 8, 5, 8)
        ));
        searchPane.add(lblSearch, BorderLayout.WEST);
        searchPane.add(txtSearch, BorderLayout.CENTER);
        filterBar.add(searchPane, gbc);

        // Ô lọc theo thứ tự ngày trong tuần
        gbc.gridx = 1; gbc.weightx = 0.3;
        JPanel comboPane = new JPanel(new BorderLayout(5, 0));
        comboPane.setOpaque(false);
        JLabel lblFilter = new JLabel("Lọc theo ngày: ");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFilter.setForeground(TEXT_MAIN);
        cbFilterThu.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbFilterThu.setBackground(Color.WHITE);
        comboPane.add(lblFilter, BorderLayout.WEST);
        comboPane.add(cbFilterThu, BorderLayout.CENTER);
        filterBar.add(comboPane, gbc);

        northPanel.add(filterBar, BorderLayout.SOUTH);
        root.add(northPanel, BorderLayout.NORTH);

        // ================= CENTER: BẢNG LỊCH TRỰC HIỆN ĐẠI =================
        model = new DefaultTableModel(
                new String[]{"Mã NV", "Họ tên thành viên", "Phòng ban công tác", "Giờ bắt đầu", "Giờ kết thúc", "Lịch trực (Thứ)"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        styleTable(table);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        sp.getViewport().setBackground(Color.WHITE);
        root.add(sp, BorderLayout.CENTER);

        // ================= SOUTH: HỆ THỐNG ĐIỀU KHIỂN ĐÁY (Đã bổ sung nút Quay lại) =================
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);

        // 1. Thêm nút Quay Lại góc bên trái thanh đáy theo phong cách Flat UI đồng bộ
        JButton btnBack = new JButton("⬅ Quay lại");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setFocusPainted(false);
        btnBack.setContentAreaFilled(false);
        btnBack.setForeground(new Color(127, 140, 141));
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> {
            if (parentForm != null) {
                parentForm.setVisible(true); // Hiện lại Dashboard mẹ
            }
            dispose(); // Giải phóng tài nguyên Form hiện tại
        });

        // 2. Nút bấm Làm mới dữ liệu góc bên phải
        JButton btnRefresh = createModernButton("Làm mới dữ liệu 🔄", PRIMARY_COLOR);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cbFilterThu.setSelectedIndex(0);
            loadFullLichLam();
        });

        south.add(btnBack, BorderLayout.WEST);
        south.add(btnRefresh, BorderLayout.EAST);
        root.add(south, BorderLayout.SOUTH);

        // ================= KẾT NỐI SỰ KIỆN TRUY VẤN TẠI CHỖ TỰ ĐỘNG =================
        txtSearch.addCaretListener(e -> applyFilter());
        cbFilterThu.addActionListener(e -> applyFilter());
    }

    // Tinh chỉnh phong cách bảng y khoa thanh lịch chuyên nghiệp
    private void styleTable(JTable table) {
        table.setRowHeight(36); // Tăng độ cao hàng để hiển thị chữ thoáng đãng
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setShowGrid(true);
        table.setGridColor(new Color(240, 242, 245));
        table.setSelectionBackground(new Color(232, 244, 255)); // Màu xanh dương pastel nhẹ khi click dòng
        table.setSelectionForeground(Color.BLACK);

        // Làm đẹp phần Header của bảng
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 244, 248));
        header.setForeground(TEXT_MAIN);
        header.setPreferredSize(new Dimension(100, 40));
        header.setReorderingAllowed(false);

        // Renderer tạo hiệu ứng đổ màu dòng xen kẽ (Zebra Striping Effect)
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                if (!isSel) {
                    if (r % 2 == 0) {
                        comp.setBackground(Color.WHITE);
                    } else {
                        comp.setBackground(new Color(248, 250, 253)); // Dòng lẻ có màu nền xám xanh dịu mát mắt
                    }
                }
                
                // Căn giữa mã nhân viên, giờ bắt đầu, giờ kết thúc và Thứ để dễ nhìn nhanh số liệu
                if (c == 0 || c == 3 || c == 4 || c == 5) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }
                return comp;
            }
        });
    }

    // Hàm tạo Button phẳng bo góc hiện đại đổ bóng màu khi hover chuột
    private JButton createModernButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(180, 42));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(PRIMARY_HOVER); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(baseColor); }
        });
        return btn;
    }

    // ================= XỬ LÝ LOGIC CHÍNH GỐC =================
    private void loadFullLichLam() {
        // Lưu trữ lại danh sách gốc phục vụ cơ chế lọc thời gian thực
        originalList = bus.getAll();

        // Giữ nguyên logic sắp xếp theo Thứ và Giờ bắt đầu gốc của bạn
        originalList.sort((a, b) -> {
            int thuA = getThuIndex(a.getThu());
            int thuB = getThuIndex(b.getThu());
            if (thuA == thuB) {
                return a.getGioLam().compareTo(b.getGioLam());
            }
            return Integer.compare(thuA, thuB);
        });

        renderTable(originalList);

        if (originalList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có lịch làm việc!");
        }
    }

    // Hàm tách biệt đảm nhận đổ dữ liệu mảng động lên Table model
    private void renderTable(List<PhanCongCaLam> renderList) {
        model.setRowCount(0);
        for (PhanCongCaLam p : renderList) {
            model.addRow(new Object[]{
                    p.getMaNhanVien(),
                    p.getTenNhanVien(),
                    p.getPhong(),
                    p.getGioLam(),
                    p.getGioKetThuc(),
                    p.getThu()
            });
        }
    }

    // Bộ lọc thông minh kết hợp cả Ô Tìm Kiếm chữ và Hộp lựa chọn Thứ trong tuần cùng lúc
    private void applyFilter() {
        String keyword = txtSearch.getText().trim().toLowerCase();
        String selectedThu = (String) cbFilterThu.getSelectedItem();
        
        List<PhanCongCaLam> filteredList = new ArrayList<>();

        for (PhanCongCaLam p : originalList) {
            // Kiểm tra khớp từ khóa tìm kiếm (tên hoặc phòng)
            boolean matchKey = keyword.isEmpty() 
                    || p.getTenNhanVien().toLowerCase().contains(keyword) 
                    || p.getPhong().toLowerCase().contains(keyword);
            
            // Kiểm tra khớp với Thứ được chọn trên ComboBox
            boolean matchThu = selectedThu.equals("-- Tất cả các ngày --") 
                    || p.getThu().trim().equalsIgnoreCase(selectedThu.trim());

            if (matchKey && matchThu) {
                filteredList.add(p);
            }
        }
        renderTable(filteredList);
    }

    // ===== GIỮ NGUYÊN HOÀN TOÀN CƠ CHẾ SẮP XẾP THỨ GỐC =====
    private int getThuIndex(String thu) {
        return switch (thu.trim()) {
            case "Thứ 2" -> 1;
            case "Thứ 3" -> 2;
            case "Thứ 4" -> 3;
            case "Thứ 5" -> 4;
            case "Thứ 6" -> 5;
            case "Thứ 7" -> 6;
            case "Chủ Nhật" -> 7;
            default -> 99;
        };
    }
}