package gui;

import bus.DanhMucBenhLyBUS;
import bus.ChuyenKhoaBUS;
import model.DanhMucBenhLy;
import model.ChuyenKhoa;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class DanhMucBenhLyForm extends JFrame {

    private JTextField txtMaICD, txtTenBenh, txtSearch;
    private JTextArea txtTrieuChung;
    private JComboBox<ChuyenKhoa> cbChuyenKhoa;

    private JTable table;
    private DefaultTableModel model;

    private JPanel cardPanel;

    private DanhMucBenhLyBUS bus = new DanhMucBenhLyBUS();
    private ChuyenKhoaBUS ckBus = new ChuyenKhoaBUS();

    private int selectedId = -1;

    private final Color PRIMARY = new Color(25,118,210);
    private final Color BG = new Color(245,247,250);

    public DanhMucBenhLyForm() {

        setTitle("QUẢN LÝ DANH MỤC BỆNH LÝ");
        setSize(1350,720);
        setLocationRelativeTo(null);
         setLayout(new BorderLayout(15,15));

        getContentPane().setBackground(BG);

        add(createTopPanel(),BorderLayout.NORTH);
        add(createMainPanel(),BorderLayout.CENTER);

        loadChuyenKhoa();
        loadData();
        updateDashboard();
    }

     class UppercaseDocumentFilter extends DocumentFilter {

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                throws BadLocationException {
            if (string != null) {
                fb.insertString(offset, string.toUpperCase(), attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            if (text != null) {
                fb.replace(offset, length, text.toUpperCase(), attrs);
            }
        }
    }

     private JPanel createTopPanel(){

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(BG);
        wrapper.setBorder(new EmptyBorder(10,20,5,20));

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
                new LineBorder(new Color(220,220,220)),
                new EmptyBorder(15,20,15,20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,10,8,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtMaICD = new JTextField(15);
        txtTenBenh = new JTextField(15);
        txtSearch = new JTextField(20);
        txtTrieuChung = new JTextArea(3,20);

        cbChuyenKhoa = new JComboBox<>();

         ((AbstractDocument) txtMaICD.getDocument())
                .setDocumentFilter(new UppercaseDocumentFilter());

        int row = 0;

        gbc.gridx=0; gbc.gridy=row; panel.add(label("Mã ICD *"),gbc);
        gbc.gridx=1; panel.add(txtMaICD,gbc);

        gbc.gridx=2; panel.add(label("Tên bệnh *"),gbc);
        gbc.gridx=3; panel.add(txtTenBenh,gbc);

        row++;
        gbc.gridx=0; gbc.gridy=row; panel.add(label("Chuyên khoa"),gbc);
        gbc.gridx=1; panel.add(cbChuyenKhoa,gbc);

        gbc.gridx=2; panel.add(label("Triệu chứng"),gbc);
        gbc.gridx=3; panel.add(new JScrollPane(txtTrieuChung),gbc);

        row++;
        gbc.gridx=0; gbc.gridy=row;
        panel.add(createButtonPanel(),gbc);

        gbc.gridx=2;
        panel.add(label("Tìm kiếm"),gbc);

        gbc.gridx=3;
        panel.add(txtSearch,gbc);

        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){
            public void insertUpdate(javax.swing.event.DocumentEvent e){ search(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e){ search(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e){ search(); }
        });

        wrapper.add(panel,BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createButtonPanel(){

        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
        p.setBackground(Color.WHITE);

        JButton btnThem = button("Thêm");
        JButton btnSua = button("Sửa");
        JButton btnXoa = button("Xóa");
        JButton btnMoi = button("Làm mới");

        btnThem.addActionListener(e->add());
        btnSua.addActionListener(e->update());
        btnXoa.addActionListener(e->delete());
        btnMoi.addActionListener(e->clear());

        p.add(btnThem);
        p.add(btnSua);
        p.add(btnXoa);
        p.add(btnMoi);

        return p;
    }

     private JPanel createMainPanel(){

        JPanel main=new JPanel(new BorderLayout(15,15));
        main.setBackground(BG);
        main.setBorder(new EmptyBorder(5,20,15,20));

        cardPanel=new JPanel(new GridLayout(1,2,15,15));
        cardPanel.setBackground(BG);

        main.add(cardPanel,BorderLayout.NORTH);

        model=new DefaultTableModel();
        table=new JTable(model);

        model.setColumnIdentifiers(new String[]{
                "ID","Mã ICD","Tên bệnh","Triệu chứng","Chuyên khoa"
        });

        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI",Font.PLAIN,14));
        table.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,14));

        table.getSelectionModel().addListSelectionListener(e->fillForm());

        main.add(new JScrollPane(table),BorderLayout.CENTER);

        return main;
    }

     private void loadChuyenKhoa(){
        cbChuyenKhoa.removeAllItems();
        for(ChuyenKhoa ck : ckBus.getAll()){
            cbChuyenKhoa.addItem(ck);
        }
    }

     private void updateDashboard(){

        cardPanel.removeAll();

        List<DanhMucBenhLy> list=bus.getAll();
        Map<String,Integer> map=new HashMap<>();

        for(DanhMucBenhLy dm:list){
            String ck=dm.getChuyenKhoaLienQuan()==null?"Khác":dm.getChuyenKhoaLienQuan();
            map.put(ck,map.getOrDefault(ck,0)+1);
        }

        cardPanel.add(createCard("TỔNG SỐ BỆNH", list.size()+""));
        cardPanel.add(createCard("SỐ CHUYÊN KHOA", map.size()+""));

        cardPanel.revalidate();
        cardPanel.repaint();
    }

    private JPanel createCard(String title,String value){

        JPanel card=new JPanel(new BorderLayout());
        card.setBackground(PRIMARY);
        card.setBorder(new EmptyBorder(20,20,20,20));

        JLabel lbTitle=new JLabel(title);
        lbTitle.setForeground(Color.WHITE);
        lbTitle.setFont(new Font("Segoe UI",Font.BOLD,15));

        JLabel lbValue=new JLabel(value);
        lbValue.setForeground(Color.WHITE);
        lbValue.setFont(new Font("Segoe UI",Font.BOLD,28));

        card.add(lbTitle,BorderLayout.NORTH);
        card.add(lbValue,BorderLayout.CENTER);

        return card;
    }

     private void add(){
        if(!validateForm()) return;

        if(bus.isMaICDExists(txtMaICD.getText())){
            JOptionPane.showMessageDialog(this,"Mã ICD đã tồn tại!");
            return;
        }

        bus.insert(getForm());
        loadData();
        updateDashboard();
        clear();
    }

    private void update(){
        if(selectedId==-1) return;
        if(!validateForm()) return;

        DanhMucBenhLy dm=getForm();
        dm.setId(selectedId);

        bus.update(dm);
        loadData();
        updateDashboard();
        clear();
    }

    private void delete(){
        if(selectedId==-1) return;
        bus.delete(selectedId);
        loadData();
        updateDashboard();
        clear();
    }

    private void search(){
        model.setRowCount(0);
        for(DanhMucBenhLy dm:bus.search(txtSearch.getText())){
            model.addRow(new Object[]{
                    dm.getId(),
                    dm.getMaICD(),
                    dm.getTenBenh(),
                    dm.getTrieuChungGoiY(),
                    dm.getChuyenKhoaLienQuan()
            });
        }
    }

    private void loadData(){
        model.setRowCount(0);
        for(DanhMucBenhLy dm:bus.getAll()){
            model.addRow(new Object[]{
                    dm.getId(),
                    dm.getMaICD(),
                    dm.getTenBenh(),
                    dm.getTrieuChungGoiY(),
                    dm.getChuyenKhoaLienQuan()
            });
        }
    }

    private DanhMucBenhLy getForm(){

        DanhMucBenhLy dm=new DanhMucBenhLy();
        dm.setMaICD(txtMaICD.getText());
        dm.setTenBenh(txtTenBenh.getText());
        dm.setTrieuChungGoiY(txtTrieuChung.getText());

        ChuyenKhoa ck=(ChuyenKhoa) cbChuyenKhoa.getSelectedItem();
        if(ck!=null) dm.setChuyenKhoaLienQuan(ck.getTenChuyenKhoa());

        return dm;
    }

    private void fillForm(){
        int row=table.getSelectedRow();
        if(row==-1) return;

        selectedId=(int)model.getValueAt(row,0);

        txtMaICD.setText(model.getValueAt(row,1)+"");
        txtTenBenh.setText(model.getValueAt(row,2)+"");
        txtTrieuChung.setText(model.getValueAt(row,3)+"");
    }

    private void clear(){
        selectedId=-1;
        txtMaICD.setText("");
        txtTenBenh.setText("");
        txtTrieuChung.setText("");
    }

    private boolean validateForm(){
        if(txtMaICD.getText().isEmpty() || txtTenBenh.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Mã ICD và Tên bệnh là bắt buộc!");
            return false;
        }
        return true;
    }

    private JLabel label(String text){
        JLabel lb=new JLabel(text);
        lb.setFont(new Font("Segoe UI",Font.BOLD,14));
        return lb;
    }

    private JButton button(String text){
        JButton btn=new JButton(text);
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() ->
                new DanhMucBenhLyForm().setVisible(true));
    }
}
