package gui;

import bus.ChiTietKhamBenhBUS;
import bus.LichSuKhamBenhBUS;
import model.ChiTietKhamBenh;
import model.LichSuKhamBenh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;

public class LichSuKhamBenhForm1 extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtSearch;
    private LichSuKhamBenhBUS bus = new LichSuKhamBenhBUS();

    // ===== HỆ MÀU FLAT UI CAO CẤP =====
    private final Color PRIMARY = new Color(52, 152, 219);     // Xanh dịu mát làm chủ đạo
    private final Color SUCCESS = new Color(46, 204, 113);     // Xanh lá cho nút Xem chi tiết
    private final Color REFRESH = new Color(149, 165, 166);     // Xám tinh tế cho nút làm mới
    private final Color BG_WINDOW = new Color(245, 247, 250);   // Nền cửa sổ nhẹ nhàng
    private final Color TEXT_MAIN = new Color(44, 62, 80);      // Chữ chính đậm rõ ràng
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public LichSuKhamBenhForm1(){

        setTitle("LỊCH SỬ KHÁM BỆNH");
        setSize(1200, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        // Root Panel với khoảng đệm bao quanh vừa phải
        JPanel rootPanel = new JPanel(new BorderLayout(15, 15));
        rootPanel.setBackground(BG_WINDOW);
        rootPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(rootPanel);

        // =====================================
        // THANH TÌM KIẾM (TOP BAR ACTION)
        // =====================================
        JPanel topPanel = new JPanel(new BorderLayout(12, 0));
        topPanel.setOpaque(false);

        // Khung bọc ô tìm kiếm kèm nhãn biểu tượng
        JPanel searchBox = new JPanel(new BorderLayout(8, 0));
        searchBox.setOpaque(false);
        
        JLabel lblIcon = new JLabel("🔍 Nhập CCCD:");
        lblIcon.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblIcon.setForeground(TEXT_MAIN);
        searchBox.add(lblIcon, BorderLayout.WEST);

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        searchBox.add(txtSearch, BorderLayout.CENTER);
        topPanel.add(searchBox, BorderLayout.CENTER);

        // Cụm các nút chức năng bên phải thanh tìm kiếm
        JPanel pBtn = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pBtn.setOpaque(false);

        JButton btnSearch = createFlatButton("TÌM KIẾM", PRIMARY);
        JButton btnRefresh = createFlatButton("LÀM MỚI", REFRESH);
        JButton btnChiTiet = createFlatButton("🔎 XEM CHI TIẾT CA KHÁM", SUCCESS);

        pBtn.add(btnSearch);
        pBtn.add(btnRefresh);
        pBtn.add(btnChiTiet);
        topPanel.add(pBtn, BorderLayout.EAST);

        rootPanel.add(topPanel, BorderLayout.NORTH);

        // =====================================
        // BẢNG DỮ LIỆU HIỆN ĐẠI (TABLE WORKSPACE)
        // =====================================
        model = new DefaultTableModel(
                new String[]{
                        "Mã PK", "Bệnh nhân", "CCCD", "Ngày khám", 
                        "Bác sĩ", "Chuyên khoa", "Chẩn đoán sơ bộ", "Trạng thái"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Khóa không cho sửa trực tiếp trên ô
            }
        };

        table = new JTable(model);
        table.setRowHeight(36); // Tăng chiều cao dòng để chữ không bị kích
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setGridColor(new Color(240, 243, 248));
        table.setSelectionBackground(new Color(230, 242, 255)); // Đổi màu nền khi click chọn dòng
        table.setSelectionForeground(TEXT_MAIN);
        table.setShowVerticalLines(false); // Ẩn đường kẻ dọc theo chuẩn UI hiện đại

        // Custom giao diện cho Thanh đầu bảng (Header)
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(Color.WHITE);
        header.setForeground(TEXT_MAIN);
        header.setPreferredSize(new Dimension(0, 40));
        ((DefaultTableCellRenderer)header.getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);

        // Đổ màu xen kẽ giữa các dòng (Zebra striping) tăng trải nghiệm đọc dữ liệu
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                if (!isSel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 253));
                }
                setBorder(noFocusBorder); // Xóa viền nét đứt khi focus vào ô
                return comp;
            }
        });

        JScrollPane spTable = new JScrollPane(table);
        spTable.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1, true));
        spTable.getViewport().setBackground(Color.WHITE);
        rootPanel.add(spTable, BorderLayout.CENTER);

        // =====================================
        // CÀI ĐẶT SỰ KIỆN (EVENTS)
        // =====================================
        btnChiTiet.addActionListener(e -> xemChiTiet());

        btnSearch.addActionListener(e -> loadData(txtSearch.getText().trim()));
        txtSearch.addActionListener(e -> loadData(txtSearch.getText().trim()));

        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            model.setRowCount(0);
        });
    }

    // Hàm phụ trợ tạo nút phẳng kèm hiệu ứng di chuột chuyển màu nhẹ
    private JButton createFlatButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(baseColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width + 15, 38));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(baseColor.darker()); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(baseColor); }
        });
        return btn;
    }

    // =====================================
    // LOGIC XỬ LÝ (GIỮ NGUYÊN HOÀN TOÀN)
    // =====================================
    private void xemChiTiet(){
        int row = table.getSelectedRow();
        if(row < 0){
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ca khám để xem!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int maPhieu = Integer.parseInt(model.getValueAt(row, 0).toString());
        ChiTietKhamBenhBUS detailedBus = new ChiTietKhamBenhBUS();
        ChiTietKhamBenh ct = detailedBus.getByMaPhieuKham(maPhieu);

        if(ct == null){
            JOptionPane.showMessageDialog(this, "Không tìm thấy dữ liệu chi tiết!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Tối ưu hóa vùng hiển thị chi tiết trong Dialog popup
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setBorder(new EmptyBorder(10, 15, 10, 15));

        area.setText(
                "=========== CHI TIẾT CA KHÁM BỆNH ===========\n\n" +
                "• Mã phiếu khám: " + ct.getMaPhieuKham() + "\n\n" +
                "• Tên bệnh nhân: " + ct.getTenBenhNhan() + "\n\n" +
                "• CCCD: " + ct.getCccd() + "\n\n" +
                "• Bác sĩ phụ trách: " + ct.getTenBacSi() + "\n\n" +
                "• Chuyên khoa: " + ct.getChuyenKhoa() + "\n\n" +
                "• Ngày khám: " + ct.getNgayKham() + "\n\n" +
                "• Lý do đến khám:\n  " + nullToEmpty(ct.getLyDoKham()) + "\n\n" +
                "• Bệnh sử lâm sàng:\n  " + nullToEmpty(ct.getBenhSu()) + "\n\n" +
                "• Tiền sử bệnh bản thân:\n  " + nullToEmpty(ct.getTienSuBanThan()) + "\n\n" +
                "• Chẩn đoán sơ bộ:\n  " + nullToEmpty(ct.getChanDoanSoBo()) + "\n\n" +
                "• Lời dặn từ bác sĩ:\n  " + nullToEmpty(ct.getLoiDanBacSi())
        );

        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(540, 500));
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        JOptionPane.showMessageDialog(this, sp, "Hồ sơ chi tiết ca khám #" + maPhieu, JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadData(String cccd){
        model.setRowCount(0);
        try{
            List<LichSuKhamBenh> list = bus.getByCCCD(cccd);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

            for(LichSuKhamBenh ls : list){
                model.addRow(new Object[]{
                        ls.getMaPhieuKham(),
                        ls.getTenBenhNhan(),
                        ls.getCccd(),
                        ls.getNgayKham() != null ? sdf.format(ls.getNgayKham()) : "",
                        ls.getTenBacSi(),
                        ls.getChuyenKhoa(),
                        ls.getChanDoanSoBo(),
                        ls.getTrangThai()
                });
            }

            if(list.isEmpty()){
                JOptionPane.showMessageDialog(this, "Không tìm thấy lịch sử khám cho CCCD này!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            }
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Có lỗi xảy ra khi truy xuất dữ liệu bệnh viện!", "Lỗi kết nối", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String nullToEmpty(String s){
        return s == null ? "(Chưa có dữ liệu ghi nhận)" : s;
    }
}