package gui;

import javax.swing.*;
import java.awt.*;

public class MainForm extends JFrame {

    public MainForm(){

        setTitle("TRANG QUẢN TRỊ");
        setSize(1000,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar bar = new JMenuBar();

        JMenu menu = new JMenu("Quản lý");

        JMenuItem nv = new JMenuItem("Nhân viên");
        JMenuItem tk = new JMenuItem("Tài khoản");
        JMenuItem bn = new JMenuItem("Bệnh nhân"); // thêm mới
        JMenuItem th = new JMenuItem("thuốc");
        JMenuItem dv = new JMenuItem("dịch vụ");
        JMenuItem pc = new JMenuItem("phân công");
        JMenuItem p = new JMenuItem("phòng");
        JMenuItem dt = new JMenuItem("doanh thu");

        menu.add(nv);
        menu.add(tk);
        menu.add(bn); // thêm vào menu
        menu.add(th);
        menu.add(dv);
        menu.add(pc);
        menu.add(p);
        menu.add(dt);

        bar.add(menu);
        setJMenuBar(bar);

 
        nv.addActionListener(e ->
                new QuanLyNhanVienForm().show()
        );

        tk.addActionListener(e ->
                new QuanLyTaiKhoanForm().show()
        );

        bn.addActionListener(e ->
        new QuanLyBenhNhanForm().show()
);
        dv.addActionListener(e ->
new QuanLyDichVuForm().show()
);
th.addActionListener(e ->
new QuanLyThuocForm().show()
);    
pc.addActionListener(e ->
new QuanLyPhanCongForm().show()
);
p.addActionListener(e ->
new PhongChucNangForm().show()
);
dt.addActionListener(e ->
new ThongKeDoanhThuForm().setVisible(true)
);
    }
}
