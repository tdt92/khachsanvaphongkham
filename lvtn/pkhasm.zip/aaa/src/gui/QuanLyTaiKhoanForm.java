package gui;

import bus.TaiKhoanBUS;
import model.TaiKhoan;
import model.NhanVien;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class QuanLyTaiKhoanForm extends JFrame {

    private JTable tblTaiKhoan = new JTable();
    private JTable tblNhanVienChuaCoTK = new JTable();

    private DefaultTableModel modelTK;
    private DefaultTableModel modelNV;

    private JTextField txtUser = new JTextField();
    private JTextField txtEmail = new JTextField();
    private JTextField txtPass = new JTextField();
    private JTextField txtMaNV = new JTextField();

    private JComboBox<String> cboVaiTro = new JComboBox<>();
    private JCheckBox chkFirstLogin =
            new JCheckBox("Lần đầu đăng nhập");

    private TaiKhoanBUS bus = new TaiKhoanBUS();

    public QuanLyTaiKhoanForm() {

        setTitle("QUẢN LÝ TÀI KHOẢN");
        setSize(1300,700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        add(createFormPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);

        loadVaiTro();
        loadTaiKhoan();
        loadNhanVienChuaCoTK();

        initEvents();
    }

    // ================== FORM PANEL (TRÊN) ==================
    private JPanel createFormPanel(){

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new TitledBorder("CẤP TÀI KHOẢN"));
        panel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,10,8,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ===== DÒNG 1 =====
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Mã nhân viên"), gbc);

        gbc.gridx = 1;
        panel.add(txtMaNV, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Username"), gbc);

        gbc.gridx = 3;
        panel.add(txtUser, gbc);

        // ===== DÒNG 2 =====
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Email"), gbc);

        gbc.gridx = 1;
        panel.add(txtEmail, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Mật khẩu"), gbc);

        gbc.gridx = 3;
        panel.add(txtPass, gbc);

        // ===== DÒNG 3 =====
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Vai trò"), gbc);

        gbc.gridx = 1;
        panel.add(cboVaiTro, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel(""), gbc);

        gbc.gridx = 3;
        panel.add(chkFirstLogin, gbc);

        // ===== BUTTON PANEL =====
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT,15,5));

        JButton btnAdd = new JButton("CẤP TÀI KHOẢN");
        JButton btnUpdate = new JButton("SỬA");
        JButton btnDelete = new JButton("XOÁ");

        btnAdd.setBackground(new Color(46,204,113));
        btnAdd.setForeground(Color.WHITE);

        btnUpdate.setBackground(new Color(52,152,219));
        btnUpdate.setForeground(Color.WHITE);

        btnDelete.setBackground(new Color(231,76,60));
        btnDelete.setForeground(Color.WHITE);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 4;
        gbc.anchor = GridBagConstraints.EAST;

        panel.add(btnPanel, gbc);

        // ===== EVENTS =====
        btnAdd.addActionListener(e -> add());
        btnUpdate.addActionListener(e -> update());
        btnDelete.addActionListener(e -> delete());

        return panel;
    }

    // ================== TABLE PANEL (DƯỚI) ==================
    private JPanel createTablePanel(){

        JPanel panel = new JPanel(new GridLayout(1,2,15,15));

        // ===== BẢNG TÀI KHOẢN =====
        modelTK = new DefaultTableModel(
                new String[]{
                        "ID","Username","Email",
                        "Mã NV","Vai trò","First Login"
                },0);

        tblTaiKhoan.setModel(modelTK);

        JScrollPane sp1 = new JScrollPane(tblTaiKhoan);
        sp1.setBorder(new TitledBorder("NHÂN VIÊN ĐÃ CÓ TÀI KHOẢN"));

        // ===== BẢNG NHÂN VIÊN CHƯA CÓ TK =====
        modelNV = new DefaultTableModel(
                new String[]{
                        "Mã NV","Họ tên","Email"
                },0);

        tblNhanVienChuaCoTK.setModel(modelNV);

        JScrollPane sp2 = new JScrollPane(tblNhanVienChuaCoTK);
        sp2.setBorder(new TitledBorder("NHÂN VIÊN CHƯA CÓ TÀI KHOẢN"));

        panel.add(sp1);
        panel.add(sp2);

        return panel;
    }

    // ================== LOAD DATA ==================
    private void loadVaiTro(){
        cboVaiTro.removeAllItems();
        for(String v : bus.getVaiTro()){
            cboVaiTro.addItem(v);
        }
    }

    private void loadTaiKhoan(){
        modelTK.setRowCount(0);

        for(TaiKhoan tk : bus.getAll()){
            modelTK.addRow(new Object[]{
                    tk.getMaTaiKhoan(),
                    tk.getUsername(),
                    tk.getEmail(),
                    tk.getMaNhanVien(),
                    tk.getVaiTro(),
                    tk.isLanDauDangNhap()
            });
        }
    }

    private void loadNhanVienChuaCoTK(){
        modelNV.setRowCount(0);

        for(NhanVien nv : bus.getNhanVienChuaCoTaiKhoan()){
            modelNV.addRow(new Object[]{
                    nv.getMaNhanVien(),
                    nv.getHoTen(),
                    nv.getEmail()
            });
        }
    }

    // ================== EVENTS ==================
    private void initEvents(){

        // Click tài khoản -> load form
        tblTaiKhoan.getSelectionModel()
                .addListSelectionListener(e -> {

                    int r = tblTaiKhoan.getSelectedRow();
                    if(r < 0) return;

                    txtUser.setText(modelTK.getValueAt(r,1)+"");
                    txtEmail.setText(modelTK.getValueAt(r,2)+"");
                    txtMaNV.setText(modelTK.getValueAt(r,3)+"");
                    cboVaiTro.setSelectedItem(
                            modelTK.getValueAt(r,4));
                    chkFirstLogin.setSelected(
                            (boolean)modelTK.getValueAt(r,5));
                });

        // Click nhân viên chưa có tài khoản -> load form
        tblNhanVienChuaCoTK.getSelectionModel()
                .addListSelectionListener(e -> {

                    int r = tblNhanVienChuaCoTK.getSelectedRow();
                    if(r < 0) return;

                    txtMaNV.setText(
                            modelNV.getValueAt(r,0)+"");

                    txtEmail.setText(
                            modelNV.getValueAt(r,2)+"");

                    txtUser.setText("");
                    txtPass.setText("");
                });
    }

    // ================== CRUD ==================
    private TaiKhoan getForm(){

        TaiKhoan tk = new TaiKhoan();

        tk.setUsername(txtUser.getText());
        tk.setEmail(txtEmail.getText());
        tk.setMatKhau(txtPass.getText());
        tk.setMaNhanVien(
                Integer.parseInt(txtMaNV.getText()));
        tk.setVaiTro(
                cboVaiTro.getSelectedItem().toString());
        tk.setLanDauDangNhap(
                chkFirstLogin.isSelected());

        return tk;
    }

    private void add(){
        bus.insert(getForm());
        loadTaiKhoan();
        loadNhanVienChuaCoTK();
    }

    private void update(){
        int r = tblTaiKhoan.getSelectedRow();
        if(r < 0) return;

        TaiKhoan tk = getForm();
        tk.setMaTaiKhoan(
                (int)modelTK.getValueAt(r,0));

        bus.update(tk);
        loadTaiKhoan();
    }

    private void delete(){
        int r = tblTaiKhoan.getSelectedRow();
        if(r < 0) return;

        bus.delete(
                (int)modelTK.getValueAt(r,0));

        loadTaiKhoan();
        loadNhanVienChuaCoTK();
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() ->
                new QuanLyTaiKhoanForm().setVisible(true));
    }
}