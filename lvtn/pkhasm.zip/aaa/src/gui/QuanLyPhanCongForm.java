package gui;

import bus.PhanCongCaLamBUS;
import model.PhanCongCaLam;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Time;
import java.util.Date;

public class QuanLyPhanCongForm extends JFrame {

    private JTextField txtMaNV, txtPhong, txtSearch;
    private JComboBox<String> cboThu;
    private JSpinner spGioLam, spGioKT;
    private JTable table;
    private DefaultTableModel model;

    private PhanCongCaLamBUS bus = new PhanCongCaLamBUS();
    private int selectedId = -1;

    // ===== BỘ MÀU CHỦ ĐẠO FLAT UI =====
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);   // Xanh dương chính
    private final Color BACKGROUND_COLOR = new Color(245, 247, 250); // Nền xám nhạt dịu mắt
    private final Color TEXT_COLOR = new Color(44, 62, 80);        // Chữ xám đậm sang trọng
    private final Color BORDER_COLOR = new Color(220, 224, 230);

    public QuanLyPhanCongForm() {
        setTitle("HỆ THỐNG PHÒNG KHÁM - QUẢN LÝ PHÂN CÔNG CA LÀM");
        setSize(1250, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Nên dùng DISPOSE thay vì EXIT nếu mở từ Dashboard

        JPanel mainPanel = new JPanel(new BorderLayout(0, 15));
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(mainPanel);

        // Gom cụm phần nhập liệu và các nút chức năng ở phía trên
        JPanel topContainer = new JPanel(new BorderLayout(0, 15));
        topContainer.setOpaque(false);
        topContainer.add(createInputPanel(), BorderLayout.NORTH);
        topContainer.add(createActionPanel(), BorderLayout.CENTER);

        mainPanel.add(topContainer, BorderLayout.NORTH);
        mainPanel.add(createTablePanel(), BorderLayout.CENTER);

        loadData();
    }

    // =====================================
    // KHU VỰC FORM NHẬP LIỆU (GRIDBAGLAYOUT)
    // =====================================
    private JPanel createInputPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        
        // Custom TitledBorder cho hiện đại
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true), " Thông tin phân công "
        );
        titledBorder.setTitleFont(new Font("Segoe UI", Font.BOLD, 14));
        titledBorder.setTitleColor(PRIMARY_COLOR);
        p.setBorder(BorderFactory.createCompoundBorder(titledBorder, new EmptyBorder(15, 20, 15, 20)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Định nghĩa các font chữ thông dụng
        Font labelFont = new Font("Segoe UI", Font.BOLD, 13);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 14);

        txtMaNV = new JTextField(); txtMaNV.setFont(inputFont);
        txtPhong = new JTextField(); txtPhong.setFont(inputFont);

        cboThu = new JComboBox<>(new String[]{
                "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"
        });
        cboThu.setFont(inputFont);
        cboThu.setBackground(Color.WHITE);

        spGioLam = new JSpinner(new SpinnerDateModel());
        spGioKT = new JSpinner(new SpinnerDateModel());
        spGioLam.setFont(inputFont);
        spGioKT.setFont(inputFont);

        JSpinner.DateEditor editor1 = new JSpinner.DateEditor(spGioLam, "HH:mm");
        JSpinner.DateEditor editor2 = new JSpinner.DateEditor(spGioKT, "HH:mm");
        spGioLam.setEditor(editor1);
        spGioKT.setEditor(editor2);

        // --- HÀNG 1 ---
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.1;
        JLabel lblMaNV = new JLabel("Mã Nhân Viên *"); lblMaNV.setFont(labelFont); lblMaNV.setForeground(TEXT_COLOR);
        p.add(lblMaNV, gbc);
        
        gbc.gridx = 1; gbc.weightx = 0.23;
        p.add(txtMaNV, gbc);

        gbc.gridx = 2; gbc.weightx = 0.1;
        JLabel lblPhong = new JLabel("Phòng:"); lblPhong.setFont(labelFont); lblPhong.setForeground(TEXT_COLOR);
        p.add(lblPhong, gbc);
        
        gbc.gridx = 3; gbc.weightx = 0.23;
        p.add(txtPhong, gbc);

        gbc.gridx = 4; gbc.weightx = 0.1;
        JLabel lblThu = new JLabel("Thứ:"); lblThu.setFont(labelFont); lblThu.setForeground(TEXT_COLOR);
        p.add(lblThu, gbc);
        
        gbc.gridx = 5; gbc.weightx = 0.23;
        p.add(cboThu, gbc);

        // --- HÀNG 2 ---
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.1;
        JLabel lblGioLam = new JLabel("Giờ Bắt Đầu:"); lblGioLam.setFont(labelFont); lblGioLam.setForeground(TEXT_COLOR);
        p.add(lblGioLam, gbc);
        
        gbc.gridx = 1; gbc.weightx = 0.23;
        p.add(spGioLam, gbc);

        gbc.gridx = 2; gbc.weightx = 0.1;
        JLabel lblGioKT = new JLabel("Giờ Kết Thúc:"); lblGioKT.setFont(labelFont); lblGioKT.setForeground(TEXT_COLOR);
        p.add(lblGioKT, gbc);
        
        gbc.gridx = 3; gbc.weightx = 0.23;
        p.add(spGioKT, gbc);

        // Đổ rỗng 2 ô cuối của hàng 2 để giữ layout cân đối
        gbc.gridx = 4; gbc.gridy = 1; gbc.gridwidth = 2;
        p.add(Box.createHorizontalStrut(10), gbc);

        return p;
    }

    // =====================================
    // THANH CHỨC NĂNG & TÌM KIẾM (TOOLBAR)
    // =====================================
    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new BorderLayout());
        actionPanel.setOpaque(false);

        // Bên trái: Các nút xử lý nghiệp vụ
        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btnGroup.setOpaque(false);

        JButton btnThem = createStyledButton("Thêm Ca Làm", new Color(46, 204, 113)); // Xanh lá
        JButton btnSua = createStyledButton("Cập Nhật", new Color(241, 196, 15));    // Vàng nhạt
        JButton btnXoa = createStyledButton("Xóa Ca", new Color(231, 76, 60));       // Đỏ
        JButton btnMoi = createStyledButton("Làm Mới", new Color(149, 165, 166));    // Xám

        btnThem.addActionListener(e -> add());
        btnSua.addActionListener(e -> update());
        btnXoa.addActionListener(e -> delete());
        btnMoi.addActionListener(e -> clear());

        btnGroup.add(btnThem);
        btnGroup.add(btnSua);
        btnGroup.add(btnXoa);
        btnGroup.add(btnMoi);

        // Bên phải: Khung tìm kiếm thông minh
        JPanel searchGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        searchGroup.setOpaque(false);

        JLabel lblSearch = new JLabel("🔍 Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearch.setForeground(TEXT_COLOR);

        txtSearch = new JTextField();
        txtSearch.setPreferredSize(new Dimension(220, 35));
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(0, 8, 0, 8)
        ));

        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { search(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { search(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { search(); }
        });

        searchGroup.add(lblSearch);
        searchGroup.add(txtSearch);

        actionPanel.add(btnGroup, BorderLayout.WEST);
        actionPanel.add(searchGroup, BorderLayout.EAST);

        return actionPanel;
    }

    // =====================================
    // KHU VỰC BẢNG HIỂN THỊ (JTABLE)
    // =====================================
    private JScrollPane createTablePanel() {
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho phép sửa trực tiếp trên ô của Table
            }
        };
        
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32); // Tăng chiều cao dòng để bảng thoáng đãng
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(235, 238, 243));

        model.setColumnIdentifiers(new String[]{
                "ID", "Mã NV", "Tên Nhân Viên", "Phòng", "Giờ Bắt Đầu", "Giờ Kết Thúc", "Thứ"
        });

        // Thiết kế lại Header của bảng
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 38));
        header.setReorderingAllowed(false);

        // Canh giữa dữ liệu ở một số cột nhất định để tăng tính thẩm mỹ
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Mã NV
        table.getColumnModel().getColumn(4).setCellRenderer(centerRenderer); // Giờ làm
        table.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); // Giờ KT
        table.getColumnModel().getColumn(6).setCellRenderer(centerRenderer); // Thứ

        table.getSelectionModel().addListSelectionListener(e -> fillForm());

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scrollPane.getViewport().setBackground(Color.WHITE);

        return scrollPane;
    }

    // =====================================
    // HÀM HELPER: DESIGN BUTTON PHẲNG (FLAT)
    // =====================================
    private JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setPreferredSize(new Dimension(125, 35));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(baseColor.darker()); // Tối màu lại một chút khi hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(baseColor);
            }
        });

        return btn;
    }

    // =====================================
    // LOGIC NGHIỆP VỤ (GIỮ NGUYÊN HOẠT ĐỘNG)
    // =====================================
    private void loadData() {
        model.setRowCount(0);
        for (PhanCongCaLam p : bus.getAll()) {
            model.addRow(new Object[]{
                    p.getId(), p.getMaNhanVien(), p.getTenNhanVien(),
                    p.getPhong(), p.getGioLam(), p.getGioKetThuc(), p.getThu()
            });
        }
    }

    private boolean validateForm() {
        if (txtMaNV.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã nhân viên bắt buộc!", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        try {
            Integer.parseInt(txtMaNV.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Mã nhân viên phải là số nguyên!", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        Date start = (Date) spGioLam.getValue();
        Date end = (Date) spGioKT.getValue();
        if (end.before(start)) {
            JOptionPane.showMessageDialog(this, "Giờ kết thúc phải lớn hơn giờ làm!", "Lỗi logic thời gian", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private PhanCongCaLam getForm() {
        PhanCongCaLam p = new PhanCongCaLam();
        p.setMaNhanVien(Integer.parseInt(txtMaNV.getText().trim()));
        p.setPhong(txtPhong.getText().trim());
        p.setThu(cboThu.getSelectedItem().toString());

        Date start = (Date) spGioLam.getValue();
        Date end = (Date) spGioKT.getValue();

        p.setGioLam(new Time(start.getTime()));
        p.setGioKetThuc(new Time(end.getTime()));

        return p;
    }

    private void add() {
        if (!validateForm()) return;
        bus.insert(getForm());
        loadData();
        clear();
    }

    private void update() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một ca làm từ bảng để cập nhật!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validateForm()) return;
        PhanCongCaLam p = getForm();
        p.setId(selectedId);
        bus.update(p);
        loadData();
        clear();
    }

    private void delete() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một ca làm từ bảng để xóa!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa ca làm này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            bus.delete(selectedId);
            loadData();
            clear();
        }
    }

    private void search() {
        model.setRowCount(0);
        for (PhanCongCaLam p : bus.search(txtSearch.getText().trim())) {
            model.addRow(new Object[]{
                    p.getId(), p.getMaNhanVien(), p.getTenNhanVien(),
                    p.getPhong(), p.getGioLam(), p.getGioKetThuc(), p.getThu()
            });
        }
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        selectedId = (int) model.getValueAt(row, 0);
        txtMaNV.setText(model.getValueAt(row, 1) + "");
        txtPhong.setText(model.getValueAt(row, 3) + "");
        cboThu.setSelectedItem(model.getValueAt(row, 6));
        spGioLam.setValue(model.getValueAt(row, 4));
        spGioKT.setValue(model.getValueAt(row, 5));
    }

    private void clear() {
        selectedId = -1;
        txtMaNV.setText("");
        txtPhong.setText("");
        cboThu.setSelectedIndex(0);
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new QuanLyPhanCongForm().setVisible(true));
    }
}