package gui;

import bus.NhanVienBUS;
import bus.TaiKhoanBUS;
import config.Session;
import model.TaiKhoan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class TaiKhoanCaNhanForm extends JFrame {

    private TaiKhoanBUS taiKhoanBUS = new TaiKhoanBUS();
    private NhanVienBUS nhanVienBUS = new NhanVienBUS();

    private JTextField txtUsername = new JTextField();
    private JTextField txtEmail = new JTextField();
    private JTextField txtSDT = new JTextField();

    private JPasswordField txtOldPass = new JPasswordField();
    private JPasswordField txtNewPass = new JPasswordField();
    private JPasswordField txtConfirm = new JPasswordField();

    // ===== BẢNG MÀU GIAO DIỆN PHẲNG HIỆN ĐẠI (FLAT UI) =====
    private final Color BG_WINDOW = new Color(245, 247, 250);
    private final Color CARD_BG = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 122, 255); // Xanh Apple hiện đại
    private final Color TEXT_MAIN = new Color(44, 62, 80);
    private final Color BORDER_COLOR = new Color(225, 230, 238);

    public TaiKhoanCaNhanForm(){

        setTitle("TÀI KHOẢN CÁ NHÂN");
        setSize(540, 680); // Tăng nhẹ kích thước để layout thông thoáng
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);        setResizable(false);

        // Panel nền tổng thể
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(BG_WINDOW);
        rootPanel.setBorder(new EmptyBorder(25, 25, 25, 25));
        setContentPane(rootPanel);

        // ===== CONTAINER CHÍNH BO GÓC (CARD UI) =====
        JPanel cardPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        cardPanel.setOpaque(false);
        cardPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Thiết lập GridBagConstraints để canh chỉnh các ô nhập liệu cân đối
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new java.awt.Insets(6, 0, 6, 0); // Khoảng cách giữa các hàng
        gbc.weightx = 1.0;

        // --- Tiêu đề phụ nằm trong Card ---
        JLabel lblHeader = new JLabel("⚙️ Cấu Hình Tài Khoản");
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblHeader.setForeground(TEXT_MAIN);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new java.awt.Insets(0, 0, 15, 0);
        cardPanel.add(lblHeader, gbc);

        // Khôi phục lại khoảng cách chuẩn cho các hàng sau
        gbc.gridwidth = 1;
        gbc.insets = new java.awt.Insets(6, 0, 6, 0);

        // Đổ dữ liệu từ Session cũ của bạn
        TaiKhoan tk = Session.currentUser;
        txtUsername.setText(tk.getUsername());
        txtUsername.setEditable(false);
        txtUsername.setBackground(new Color(240, 242, 245)); // Đổi màu nền ô không được sửa

        txtEmail.setText(tk.getEmail());

        // Áp dụng kiểu dáng hiện đại cho toàn bộ Input component
        styleTextField(txtUsername);
        styleTextField(txtEmail);
        styleTextField(txtSDT);
        styleTextField(txtOldPass);
        styleTextField(txtNewPass);
        styleTextField(txtConfirm);

        // --- Thêm các trường nhập liệu vào Grid (Dạng nhãn phía trên, ô nhập phía dưới) ---
        int row = 1;
        
        row = addFieldToGrid(cardPanel, gbc, "Tên đăng nhập (Cố định)", txtUsername, row);
        row = addFieldToGrid(cardPanel, gbc, "Địa chỉ Email", txtEmail, row);
        row = addFieldToGrid(cardPanel, gbc, "Số điện thoại nhân viên", txtSDT, row);
        
        // Đường kẻ phân tách nhẹ giữa thông tin và mật khẩu
        JSeparator separator = new JSeparator();
        separator.setForeground(BORDER_COLOR);
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.insets = new java.awt.Insets(12, 0, 12, 0);
        cardPanel.add(separator, gbc);
        gbc.insets = new java.awt.Insets(6, 0, 6, 0);

        row = addFieldToGrid(cardPanel, gbc, "Mật khẩu hiện tại", txtOldPass, row);
        row = addFieldToGrid(cardPanel, gbc, "Mật khẩu mới", txtNewPass, row);
        row = addFieldToGrid(cardPanel, gbc, "Xác nhận lại mật khẩu mới", txtConfirm, row);

        // --- Nút bấm Cập Nhật ---
        JButton btnSave = new JButton("CẬP NHẬT THÔNG TIN");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setBackground(PRIMARY_COLOR);
        btnSave.setForeground(Color.WHITE);
        btnSave.setPreferredSize(new Dimension(0, 42));
        btnSave.setFocusPainted(false);
        btnSave.setBorderPainted(false);
        btnSave.setOpaque(true);
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hiệu ứng rê chuột đổi màu nút
        btnSave.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnSave.setBackground(PRIMARY_COLOR.darker()); }
            @Override public void mouseExited(MouseEvent e) { btnSave.setBackground(PRIMARY_COLOR); }
        });

        btnSave.addActionListener(e -> update());

        gbc.gridx = 0; gbc.gridy = row;
        gbc.insets = new java.awt.Insets(18, 0, 10, 0);
        cardPanel.add(btnSave, gbc);

        rootPanel.add(cardPanel, BorderLayout.CENTER);
    }

    // Hàm phụ trợ tạo Label bên trên và Comp bên dưới trong hệ lưới
    private int addFieldToGrid(JPanel panel, GridBagConstraints gbc, String labelText, Component comp, int startRow) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(TEXT_MAIN);
        
        gbc.gridx = 0; gbc.gridy = startRow;
        panel.add(label, gbc);
        
        gbc.gridx = 0; gbc.gridy = startRow + 1;
        panel.add(comp, gbc);
        
        return startRow + 2;
    }

    // Hàm định dạng các ô văn bản và mật khẩu bo góc nhẹ ôm chữ vừa vặn
    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        field.setPreferredSize(new Dimension(0, 36));
    }

    // ===== KHU VỰC GIỮ NGUYÊN 100% LOGIC CŨ CỦA BẠN (KHÔNG CHỈNH SỬA) =====
    private void update(){

        TaiKhoan tk = Session.currentUser;

        String email = txtEmail.getText();
        String sdt = txtSDT.getText();
        String oldPass = new String(txtOldPass.getPassword());
        String newPass = new String(txtNewPass.getPassword());
        String confirm = new String(txtConfirm.getPassword());

        if(!oldPass.equals(tk.getMatKhau())){
            JOptionPane.showMessageDialog(this,"Sai mật khẩu cũ!");
            return;
        }

        if(!newPass.equals(confirm)){
            JOptionPane.showMessageDialog(this,"Xác nhận mật khẩu không khớp!");
            return;
        }

        boolean ok1 = taiKhoanBUS.updateThongTinCaNhan(
                tk.getMaTaiKhoan(),
                email,
                newPass
        );

        boolean ok2 = nhanVienBUS.updateSDT(
                tk.getMaNhanVien(),
                sdt
        );

        if(ok1 && ok2){

            tk.setEmail(email);
            tk.setMatKhau(newPass);

            JOptionPane.showMessageDialog(this,"Cập nhật thành công!");
            dispose();

        }else{
            JOptionPane.showMessageDialog(this,"Lỗi cập nhật!");
        }
    }
}