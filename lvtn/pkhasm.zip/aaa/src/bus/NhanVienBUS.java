package bus;

import dao.NhanVienDAO;
import model.NhanVien;

import java.util.List;

public class NhanVienBUS {

    NhanVienDAO dao=new NhanVienDAO();

    public List<NhanVien> getAll(){
        return dao.getAll();
    }
    public List<NhanVien> getByChuyenKhoa(String tenCK){
        return dao.getByChuyenKhoa(tenCK);
    }

    public void insert(NhanVien nv){
        dao.insert(nv);
    }
    public boolean updateSDT(int maNV, String sdt){
        return dao.updateSDT(maNV,sdt);
    }
    public String getChuyenKhoa(int maNV){
        return dao.getChuyenKhoaByMaNV(maNV);
    }
    public void update(NhanVien nv){
        dao.update(nv);
    }

    public void delete(int id){
        dao.delete(id);
    }
}
