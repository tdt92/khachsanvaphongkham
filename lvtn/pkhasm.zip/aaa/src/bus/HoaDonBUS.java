package bus;

import dao.HoaDonDAO;
import model.HoaDon;

import java.util.List;

public class HoaDonBUS {

    private HoaDonDAO dao =
            new HoaDonDAO();

    // =====================================
    // LẤY TẤT CẢ HÓA ĐƠN
    // =====================================

    public List<HoaDon> getAll(){

        return dao.getAll();
    }

    // =====================================
    // HÓA ĐƠN ĐÃ THANH TOÁN
    // =====================================

    public List<HoaDon> getDaThanhToan(){

        return dao.getDaThanhToan();
    }

    // =====================================
    // HÓA ĐƠN CHỜ THANH TOÁN
    // =====================================

    public List<HoaDon> getChoThanhToan(){

        return dao.getChoThanhToan();
    }

    // =====================================
    // TÌM HÓA ĐƠN THEO MÃ PHIẾU KHÁM
    // =====================================

    public HoaDon findByMaPhieuKham(int maPhieuKham){

        return dao.findByMaPhieuKham(maPhieuKham);
    }

    // =====================================
    // TẠO HÓA ĐƠN
    // =====================================

    public boolean insert(HoaDon hd){

        if(hd == null){

            return false;
        }

        return dao.insert(hd);
    }

    // =====================================
    // CẬP NHẬT HÓA ĐƠN
    // =====================================

    public boolean update(HoaDon hd){

        if(hd == null){

            return false;
        }

        return dao.update(hd);
    }

    // =====================================
    // XÓA HÓA ĐƠN
    // =====================================

    public boolean delete(int maHoaDon){

        return dao.delete(maHoaDon);
    }

    // =====================================
    // THANH TOÁN HÓA ĐƠN
    // =====================================

    public boolean thanhToan(
            int maHoaDon,
            int maNhanVienThuNgan){

        return dao.thanhToan(
                maHoaDon,
                maNhanVienThuNgan);
    }

    // =====================================
    // TÍNH TỔNG TIỀN
    // =====================================

    public double tinhTongTien(int maHoaDon){

        return dao.tinhTongTien(maHoaDon);
    }

    // =====================================
    // TÌM KIẾM
    // =====================================

    public List<HoaDon> search(String keyword){

        return dao.search(keyword);
    }
    public int taoHoaDonTuPhieuKham(
            int maPhieuKham,
            int maNhanVien){

        return dao.taoHoaDonTuPhieuKham(
                maPhieuKham,
                maNhanVien);
    }
    public List<Object[]> getAllHoaDonFull(){

        return dao.getAllHoaDonFull();
    }
    public Object[] getThongTinHoaDon(int maHoaDon){

        return dao.getThongTinHoaDon(maHoaDon);
    }
    
}