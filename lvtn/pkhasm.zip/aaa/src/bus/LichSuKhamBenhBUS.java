package bus;

import dao.LichSuKhamBenhDAO;
import model.LichSuKhamBenh;

import java.util.List;

public class LichSuKhamBenhBUS {

    private LichSuKhamBenhDAO dao = new LichSuKhamBenhDAO();

    public List<LichSuKhamBenh> search(String keyword){
        return dao.search(keyword);
    }
    public List<LichSuKhamBenh> getByCCCD(String cccd){

        return dao.getByCCCD(cccd);
    }
}