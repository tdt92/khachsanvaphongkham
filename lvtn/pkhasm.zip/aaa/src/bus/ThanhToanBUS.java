package bus;

import dao.ThanhToanDAO;

import java.util.List;

public class ThanhToanBUS {

    ThanhToanDAO dao =
            new ThanhToanDAO();

    public List<Object[]> getDanhSach(){

        return dao.getDanhSachChoThanhToan();
    }
}