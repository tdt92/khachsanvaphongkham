package bus;

import dao.CLSChanDoanHinhAnhDAO;
import model.CLSChanDoanHinhAnh;

import java.util.List;

public class CLSChanDoanHinhAnhBUS {

    CLSChanDoanHinhAnhDAO dao =
            new CLSChanDoanHinhAnhDAO();

    public List<CLSChanDoanHinhAnh> getAll(){

        return dao.getAll();
    }
}