package bus;

import dao.DanhMucBenhLyDAO;
import model.DanhMucBenhLy;

import java.util.List;

public class DanhMucBenhLyBUS {

    private DanhMucBenhLyDAO dao = new DanhMucBenhLyDAO();

    public List<DanhMucBenhLy> getAll() {
        return dao.getAll();
    }

    public boolean insert(DanhMucBenhLy dm) {
        return dao.insert(dm);
    }

    public boolean update(DanhMucBenhLy dm) {
        return dao.update(dm);
    }
    public boolean isMaICDExists(String maICD){
        return dao.existsMaICD(maICD);
    }


    public boolean delete(int id) {
        return dao.delete(id);
    }

    public List<DanhMucBenhLy> search(String keyword) {
        return dao.search(keyword);
    }
}
