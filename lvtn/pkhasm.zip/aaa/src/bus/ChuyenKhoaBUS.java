package bus;

import dao.ChuyenKhoaDAO;
import model.ChuyenKhoa;
import java.util.List;

public class ChuyenKhoaBUS {

    private ChuyenKhoaDAO dao=new ChuyenKhoaDAO();

    public List<ChuyenKhoa> getAll(){
        return dao.getAll();
    }
}
