package bus;

import dao.*;
import model.*;

public class KhamBenhBUS {

    ChiSoKhamTongHopDAO csDao = new ChiSoKhamTongHopDAO();
    KhamLamSangDAO lsDao = new KhamLamSangDAO();

    public boolean insert(ChiSoKhamTongHop cs, KhamLamSang ls){
        return csDao.insert(cs) && lsDao.insert(ls);
    }

    public boolean update(ChiSoKhamTongHop cs, KhamLamSang ls){
        return csDao.update(cs) && lsDao.update(ls);
    }
}