package bus;

import dao.BenhNhanDAO;
import model.BenhNhan;
import java.util.List;

public class BenhNhanBUS {

     private BenhNhanDAO dao = new BenhNhanDAO();

    public List<BenhNhan> getAll(){ return dao.getAll(); }

  
    public List<BenhNhan> searchByName(String keyword){
        return dao.searchByName(keyword);
    }
    public BenhNhan getById(int maBenhNhan){
        return dao.getById(maBenhNhan);
    }

    public boolean existsCCCD(String cccd){
        return dao.existsCCCD(cccd);
    }

    public void insert(BenhNhan bn){ dao.insert(bn); }
    public void update(BenhNhan bn){ dao.update(bn); }
    public void delete(int id){ dao.delete(id); }
}
