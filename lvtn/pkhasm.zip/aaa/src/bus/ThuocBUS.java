package bus;

import dao.ThuocDAO;
import model.Thuoc;
import java.util.List;

public class ThuocBUS {

    ThuocDAO dao = new ThuocDAO();

    public List<Thuoc> getAll(){ return dao.getAll(); }
    public void insert(Thuoc t){ dao.insert(t); }
    public void update(Thuoc t){ dao.update(t); }
    public void delete(int id){ dao.delete(id); }
    public List<Thuoc> search(String keyword){ return dao.search(keyword); }
}
