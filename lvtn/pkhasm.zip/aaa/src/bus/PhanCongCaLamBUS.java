package bus;

import dao.PhanCongCaLamDAO;
import model.PhanCongCaLam;

import java.util.List;

public class PhanCongCaLamBUS {

    private PhanCongCaLamDAO dao=new PhanCongCaLamDAO();

    public List<PhanCongCaLam> getAll(){ return dao.getAll(); }

    public void insert(PhanCongCaLam p){ dao.insert(p); }

    public void update(PhanCongCaLam p){ dao.update(p); }

    public void delete(int id){ dao.delete(id); }

    public List<PhanCongCaLam> search(String key){ return dao.search(key); }
}
