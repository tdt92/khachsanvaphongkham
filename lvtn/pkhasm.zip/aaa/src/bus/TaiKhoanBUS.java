package bus;

import dao.TaiKhoanDAO;
import model.TaiKhoan;
import model.NhanVien;

import java.util.List;

public class TaiKhoanBUS {

    TaiKhoanDAO dao=new TaiKhoanDAO();

    public TaiKhoan dangNhap(String user, String pass) {

        if(user==null || user.isEmpty()) return null;
        if(pass==null || pass.isEmpty()) return null;

        return dao.dangNhap(user, pass);
    }

    public List<TaiKhoan> getAll(){
        return dao.getAll();
    }

    public List<String> getVaiTro(){
        return dao.getVaiTro();
    }

    public void insert(TaiKhoan tk){
        dao.insert(tk);
    }

    public void update(TaiKhoan tk){
        dao.update(tk);
    }
    public boolean updateThongTinCaNhan(int maTK, String email, String matKhau){
        return dao.updateThongTinCaNhan(maTK,email,matKhau);
    }
    public void delete(int id){
        dao.delete(id);
    }

    // ================= THÊM MỚI =================
    public List<NhanVien> getNhanVienChuaCoTaiKhoan(){
        return dao.getNhanVienChuaCoTaiKhoan();
    }
}