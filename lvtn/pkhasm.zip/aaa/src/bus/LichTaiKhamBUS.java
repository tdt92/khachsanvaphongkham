package bus;

import dao.LichTaiKhamDAO;
import model.LichTaiKham;

import java.util.List;

public class LichTaiKhamBUS {

    private LichTaiKhamDAO dao = new LichTaiKhamDAO();

    public List<LichTaiKham> getAll(){
        return dao.getAll();
    }

    public List<LichTaiKham> search(String keyword){
        return dao.search(keyword);
    }

    public void insert(LichTaiKham l){
        dao.insert(l);
    }

    public void update(LichTaiKham l){
        dao.update(l);
    }

    public void delete(int id){
        dao.delete(id);
    }
}