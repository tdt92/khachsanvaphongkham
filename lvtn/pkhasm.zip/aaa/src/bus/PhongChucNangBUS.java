package bus;

import dao.PhongChucNangDAO;
import model.PhongChucNang;

import java.util.List;

public class PhongChucNangBUS {

    PhongChucNangDAO dao = new PhongChucNangDAO();

    public List<PhongChucNang> getAll(){
        return dao.getAll();
    }

    public List<PhongChucNang> search(String keyword){
        return dao.search(keyword);
    }

    public void insert(PhongChucNang p){
        if(p.getTenPhong().isEmpty())
            throw new RuntimeException("Tên phòng không được trống");

        if(dao.isTenPhongExist(p.getTenPhong()))
            throw new RuntimeException("Tên phòng đã tồn tại!");

        dao.insert(p);
    }

    public void update(PhongChucNang p){
        dao.update(p);
    }

    public void delete(int id){
        dao.delete(id);
    }
}