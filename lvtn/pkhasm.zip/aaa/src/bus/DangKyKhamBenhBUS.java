package bus;

import java.util.List;

import dao.DangKyKhamBenhDAO;
import model.DangKyKhamBenh;

public class DangKyKhamBenhBUS {

    private DangKyKhamBenhDAO dao = new DangKyKhamBenhDAO();
    public List<Object[]> getChoKham(){
        return dao.getChoKham();
    }

    public List<Object[]> getVangMat(){
        return dao.getVangMat();
    }

    public boolean insert(DangKyKhamBenh dk){
        return dao.insert(dk);
    }
    public void deleteDangKyCu(){
        dao.deleteDangKyCu();
    }

    public boolean deleteById(int id){
        return dao.deleteById(id);
    }
    public int getNextSTT(){
        return dao.getMaxSTT() + 1;
    }
    public int getNextSTT(int maChuyenKhoa){
        return dao.getMaxSTT(maChuyenKhoa) + 1;
    }
    public boolean updateSTTAndTrangThai(int id, int newSTT){
        return dao.updateSTTAndTrangThai(id,newSTT);
    }
    public boolean updateTrangThai(int id, String trangThai){
        return dao.updateTrangThai(id, trangThai);
    }
}