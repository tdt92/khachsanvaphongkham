package bus;

import dao.KetQuaCDHADAO;
import model.KetQuaCDHA;

public class KetQuaCDHABUS {

    KetQuaCDHADAO dao =
            new KetQuaCDHADAO();

    public boolean save(KetQuaCDHA kq){

        return dao.insert(kq);
    }
}