package bus;

import dao.DichVuDAO;
import model.DichVu;

import java.util.List;

public class DichVuBUS {

    private DichVuDAO dao=new DichVuDAO();

    public List<DichVu> getAll(){ return dao.getAll(); }

    public void insert(DichVu dv){ dao.insert(dv); }

    public void update(DichVu dv){ dao.update(dv); }

    public void delete(int id){ dao.delete(id); }

    public List<DichVu> search(String key){ return dao.search(key); }
    public DichVu getDichVuKhamByChuyenKhoa(int maChuyenKhoa){

        return dao.getDichVuKhamByChuyenKhoa(
                maChuyenKhoa
        );
    }
}
