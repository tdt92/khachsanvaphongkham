package bus;

import dao.ChiTietKhamBenhDAO;
import model.ChiTietKhamBenh;

public class ChiTietKhamBenhBUS {

    private ChiTietKhamBenhDAO dao =
            new ChiTietKhamBenhDAO();

    public ChiTietKhamBenh getByMaPhieuKham(int maPK){
        return dao.getByMaPhieuKham(maPK);
    }
}